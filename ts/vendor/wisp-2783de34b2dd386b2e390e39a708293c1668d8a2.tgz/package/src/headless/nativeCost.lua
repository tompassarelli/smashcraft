local ____exports = {}
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
function ____exports.nativeFrameCost(model, work)
    local luaUs = model.luaFactor * model.hostUsPerThousandInstructions * work.instructions / 1000
    return {callbacksUs = luaUs + model.nativeCallUs * work.natives + model.collectorUsPerKb * work.allocatedKb, typingUs = model.typingUsPerCharacterSquared * work.typedCharacters * work.typedCharacters}
end
____exports.WARCRAFT_COST = {
    hostUsPerThousandInstructions = 0x48cccdp-18,
    luaFactor = 0x95c28fp-23,
    nativeCallUs = 2,
    collectorUsPerKb = 2,
    typingUsPerCharacterSquared = 0x1p-1
}
return ____exports
