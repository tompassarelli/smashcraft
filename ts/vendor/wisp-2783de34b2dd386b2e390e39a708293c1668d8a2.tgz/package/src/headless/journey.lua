local ____lualib = require("lualib_bundle")
local __TS__NumberIsInteger = ____lualib.__TS__NumberIsInteger
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local Set = ____lualib.Set
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArraySort = ____lualib.__TS__ArraySort
local ____exports = {}
function ____exports.runJourney(clients, journey, options)
    if options == nil then
        options = {}
    end
    local clock = options.observationClock
    local stepFrames = clock == nil and (options.stepFrames or journey.frames + 1) or 1
    if not __TS__NumberIsInteger(stepFrames) or stepFrames < 1 then
        do
            local ____thrown = __TS__New(Error, "stepFrames must be a positive integer")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/journey.ts:56"
            end
            error(____thrown, 0)
        end
    end
    clients:start()
    local frames = __TS__ArraySort(
        {__TS__Spread(__TS__New(Set, options.observationFrames or ({})))},
        function(____, a, b) return a - b end
    )
    for ____, frame in ipairs(frames) do
        if not __TS__NumberIsInteger(frame) or frame < 0 or clock == nil and frame > journey.frames then
            do
                local ____thrown = __TS__New(
                    Error,
                    ("observation frame " .. tostring(frame)) .. " is outside the journey"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/journey.ts:59"
                end
                error(____thrown, 0)
            end
        end
    end
    local observation = 0
    local function now()
        return clock == nil and clients.frame or clock(clients)
    end
    local function capture()
        local frame = now()
        if frame == nil or frames[observation + 1] ~= frame then
            return
        end
        local ____opt_0 = options.observe
        if ____opt_0 ~= nil then
            ____opt_0(clients, frame)
        end
        observation = observation + 1
    end
    local function advance(target)
        local function stepTo(frame)
            while clients.frame < frame do
                clients:frames(math.min(stepFrames, frame - clients.frame))
                if clock ~= nil and clients.frame < frame then
                    capture()
                end
            end
        end
        while clock == nil and (frames[observation + 1] or target) < target do
            local frame = frames[observation + 1]
            if frame == nil then
                break
            end
            stepTo(frame)
            capture()
        end
        stepTo(target)
    end
    for ____, event in ipairs(journey.events) do
        if event.frame < clients.frame then
            do
                local ____thrown = __TS__New(
                    Error,
                    ("journey event at frame " .. tostring(event.frame)) .. " is out of order"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/journey.ts:84"
                end
                error(____thrown, 0)
            end
        end
        if event.frame > clients.frame then
            capture()
        end
        advance(event.frame)
        if event.chat ~= nil then
            clients:chat(event.player, event.chat)
        elseif event.key ~= nil then
            if event.down == nil then
                clients:press(event.player, event.key, event.meta)
            else
                clients:key(event.player, event.key, event.meta, event.down)
            end
        else
            clients:reload()
        end
    end
    capture()
    advance(journey.frames)
    capture()
    local results = {}
    for ____, client in ipairs(clients.clients) do
        results[#results + 1] = options.checksums == false and ({
            slot = client.slot,
            calls = client:callCount(),
            errors = client.errors,
            missingNatives = client.missingNatives
        }) or ({
            slot = client.slot,
            calls = client:callCount(),
            checksum = client:checksum(),
            errors = client.errors,
            missingNatives = client.missingNatives
        })
    end
    return {
        frames = clients.frame,
        clients = results,
        divergence = clients:firstDivergence(),
        reloaded = clients.version,
        reloads = clients:unappliedReloads()
    }
end
function ____exports.journeyProblems(result)
    local problems = (result.divergence == nil and 0 or 1) + #result.reloads
    for ____, client in ipairs(result.clients) do
        problems = problems + (#client.errors + #client.missingNatives)
    end
    return problems
end
function ____exports.journeyLines(result)
    local lines = {}
    for ____, client in ipairs(result.clients) do
        lines[#lines + 1] = (((("p" .. tostring(client.slot)) .. ": ") .. tostring(client.calls)) .. " native calls") .. (client.checksum == nil and "" or ", checksum " .. client.checksum)
    end
    lines[#lines + 1] = result.divergence == nil and ("no desync in " .. tostring(result.frames)) .. " frames" or "desync: " .. result.divergence
    if result.reloaded > 0 and #result.reloads == 0 then
        lines[#lines + 1] = ("hot reload " .. tostring(result.reloaded)) .. " running in every client"
    end
    for ____, reload in ipairs(result.reloads) do
        lines[#lines + 1] = reload
    end
    for ____, client in ipairs(result.clients) do
        for ____, ____error in ipairs(client.errors) do
            lines[#lines + 1] = (("p" .. tostring(client.slot)) .. ": ") .. ____error
        end
    end
    for ____, client in ipairs(result.clients) do
        for ____, missing in ipairs(client.missingNatives) do
            lines[#lines + 1] = (((("p" .. tostring(missing.client)) .. " frame ") .. tostring(missing.frame)) .. ": unmodeled native ") .. missing.native
        end
    end
    return lines
end
return ____exports
