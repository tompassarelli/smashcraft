local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
function ____exports.at(items, index)
    local item = items[index + 1]
    if item == nil then
        do
            local ____thrown = __TS__New(
                Error,
                (("no element " .. tostring(index)) .. " in a table of ") .. tostring(#items)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/runtime/lookup.ts:4"
            end
            error(____thrown, 0)
        end
    end
    return item
end
return ____exports
