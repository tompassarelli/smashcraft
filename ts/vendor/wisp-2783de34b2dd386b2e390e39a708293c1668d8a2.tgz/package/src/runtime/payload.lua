local ____exports = {}
local ____intMath = require("src.sim.intMath")
local floorMod = ____intMath.floorMod
function ____exports.checksum(length, byteAt)
    local first = 0
    local second = 0
    do
        local index = 0
        while index < length do
            local byte = byteAt(index)
            first = (first * 257 + byte + 1) % 8165329
            second = (second * 263 + byte + 1) % 8165323
            index = index + 1
        end
    end
    return (tostring(first) .. ":") .. tostring(second)
end
return ____exports
