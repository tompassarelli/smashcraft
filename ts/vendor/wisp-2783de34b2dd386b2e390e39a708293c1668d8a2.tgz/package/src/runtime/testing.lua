local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__InstanceOf = ____lualib.__TS__InstanceOf
local ____exports = {}
____exports.registeredTests = {}
function ____exports.test(name, run)
    local ____exports_registeredTests_0 = ____exports.registeredTests
    ____exports_registeredTests_0[#____exports_registeredTests_0 + 1] = {name = name, run = run}
end
____exports.AssertionFailure = __TS__Class()
local AssertionFailure = ____exports.AssertionFailure
AssertionFailure.name = "AssertionFailure"
function AssertionFailure.prototype.____constructor(self, message)
    self.message = message
end
local function fail(message)
    do
        local ____thrown = __TS__New(____exports.AssertionFailure, message)
        if _G.__wispThrown ~= ____thrown then
            _G.__wispThrown = ____thrown
            _G.__wispThrowSite = "wisp/src/runtime/testing.ts:16"
        end
        error(____thrown, 0)
    end
end
function ____exports.assertTrue(value)
    if value ~= true then
        fail("expected true")
    end
end
function ____exports.assertFalse(value)
    if value ~= false then
        fail("expected false")
    end
end
function ____exports.assertEquals(actual, expected, message)
    if actual ~= expected then
        fail(((((message == nil and "" or message .. ": ") .. "expected ") .. tostring(expected)) .. ", actual ") .. tostring(actual))
    end
end
function ____exports.assertNear(actual, expected, delta)
    if math.abs(actual - expected) > delta then
        fail((((("expected " .. tostring(expected)) .. " within ") .. tostring(delta)) .. ", actual ") .. tostring(actual))
    end
end
function ____exports.assertGreaterThan(actual, bound)
    if not (actual > bound) then
        fail((("expected more than " .. tostring(bound)) .. ", actual ") .. tostring(actual))
    end
end
function ____exports.assertLessThan(actual, bound)
    if not (actual < bound) then
        fail((("expected less than " .. tostring(bound)) .. ", actual ") .. tostring(actual))
    end
end
function ____exports.assertDefined(value, what)
    if what == nil then
        what = "value"
    end
    if value == nil then
        fail(("expected " .. what) .. " to be defined")
    end
    return value
end
function ____exports.runTests(report)
    local failures = 0
    for ____, ____value in ipairs(____exports.registeredTests) do
        local name = ____value.name
        local run = ____value.run
        do
            local function ____catch(____error)
                failures = failures + 1
                report((("fail " .. name) .. ": ") .. (__TS__InstanceOf(____error, ____exports.AssertionFailure) and ____error.message or tostring(____error)))
            end
            local ____try, ____hasReturned = pcall(function()
                run(nil)
            end)
            if not ____try then
                ____catch(____hasReturned)
            end
        end
    end
    report(((tostring(#____exports.registeredTests - failures) .. " of ") .. tostring(#____exports.registeredTests)) .. " passed")
    return failures
end
return ____exports
