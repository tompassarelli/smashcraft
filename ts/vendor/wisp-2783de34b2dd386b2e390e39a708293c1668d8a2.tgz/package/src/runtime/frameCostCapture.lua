local ____exports = {}
local ____frameCost = require("src.runtime.frameCost")
local reportNumber = ____frameCost.reportNumber
____exports.MAX_FRAME_COST_CAPTURE = 18000
____exports.frameCostCaptureFile = function(slot, run, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((((prefix .. "-perf-capture-p") .. tostring(slot)) .. "-run") .. tostring(run)) .. ".txt"
end
____exports.frameCostCaptureHeading = function(run, frames, version, clockStepUs, elapsedMs, changed) return (((((((((("frame capture run=" .. tostring(run)) .. " frames=") .. tostring(frames)) .. " version=") .. tostring(version)) .. " clock-us=") .. reportNumber(clockStepUs)) .. " elapsed-ms=") .. reportNumber(elapsedMs)) .. " changed=") .. tostring(changed and 1 or 0) end
____exports.frameCostCaptureSample = function(frame, luaUs, natives, catchUp) return (((((("sample " .. tostring(frame)) .. " lua-us=") .. (luaUs == nil and "none" or reportNumber(luaUs))) .. " natives=") .. tostring(natives)) .. " catchup=") .. tostring(catchUp) end
return ____exports
