local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local FILE_SLOTS = ____gameFiles.FILE_SLOTS
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
local ____frameCost = require("src.runtime.frameCost")
local frameCostFile = ____frameCost.frameCostFile
local frameCostHeading = ____frameCost.frameCostHeading
local frameWindowLine = ____frameCost.frameWindowLine
local reportNumber = ____frameCost.reportNumber
local spread = ____frameCost.spread
local ____frameCostCapture = require("src.runtime.frameCostCapture")
local MAX_FRAME_COST_CAPTURE = ____frameCostCapture.MAX_FRAME_COST_CAPTURE
local frameCostCaptureFile = ____frameCostCapture.frameCostCaptureFile
local frameCostCaptureHeading = ____frameCostCapture.frameCostCaptureHeading
local frameCostCaptureSample = ____frameCostCapture.frameCostCaptureSample
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
local ____intMath = require("src.sim.intMath")
local floorMod = ____intMath.floorMod
local ____dispatch = require("src.platform.dispatch")
local on = ____dispatch.on
local trampoline = ____dispatch.trampoline
____exports.FRAME_WINDOW = 120
local OVERLAY_FRAMES = 30
local CLOCK_READS = 1000000
local TOGGLE = "wisp.frameMeter.toggle"
local function ring()
    return {values = {}, next = 0, count = 0}
end
local function emptyWindow()
    return {
        lua = ring(),
        natives = ring(),
        catchUp = ring()
    }
end
local function push(target, value)
    target.values[target.next + 1] = value
    target.next = (target.next + 1) % ____exports.FRAME_WINDOW
    if target.count < ____exports.FRAME_WINDOW then
        target.count = target.count + 1
    end
end
local function clear(target)
    for ____, values in ipairs({target.lua, target.natives, target.catchUp}) do
        values.next = 0
        values.count = 0
    end
end
local function summary(state, source)
    local ____source_natives_count_1 = source.natives.count
    local ____temp_0
    if state.clock == nil then
        ____temp_0 = nil
    else
        ____temp_0 = spread(source.lua.values, source.lua.count)
    end
    return {
        frames = ____source_natives_count_1,
        lua = ____temp_0,
        natives = spread(source.natives.values, source.natives.count),
        catchUp = spread(source.catchUp.values, source.catchUp.count)
    }
end
local function meter()
    local globals = _G
    local state = globals[runtimeConfiguration().globalPrefix .. "FrameMeter"]
    if state == nil then
        do
            local ____thrown = __TS__New(Error, "frame meter used before startFrameMeter")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/frameMeter.ts:130"
            end
            error(____thrown, 0)
        end
    end
    return state
end
local function dispatchTable()
    local globals = _G
    local ____table = globals[runtimeConfiguration().globalPrefix .. "Dispatch"]
    if ____table == nil then
        do
            local ____thrown = __TS__New(Error, "frame meter installed before installDispatch")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/frameMeter.ts:137"
            end
            error(____thrown, 0)
        end
    end
    return ____table
end
local function installedVersion()
    local globals = _G
    local ____opt_2 = globals[runtimeConfiguration().globalPrefix .. "Hot"]
    return ____opt_2 and ____opt_2.applied or 0
end
local function findClock()
    if type(os) ~= "table" or os == nil or type(os.clock) ~= "function" then
        return {clock = nil, step = 0}
    end
    local clock = os.clock
    local changes = 0
    local step = 0
    local last = clock()
    do
        local reads = 0
        while reads < CLOCK_READS and changes < 2 do
            do
                local now = clock()
                if now == last then
                    goto __continue18
                end
                if changes > 0 then
                    step = now - last
                end
                changes = changes + 1
                last = now
            end
            ::__continue18::
            reads = reads + 1
        end
    end
    return changes < 2 and ({clock = nil, step = 0}) or ({clock = clock, step = step})
end
local function milliseconds(microseconds)
    return reportNumber(microseconds / 1000)
end
local function ninetyFifth(source)
    local sorted = {}
    do
        local index = 0
        while index < source.count do
            sorted[#sorted + 1] = source.values[index + 1] or 0
            index = index + 1
        end
    end
    __TS__ArraySort(
        sorted,
        function(____, left, right) return left - right end
    )
    return sorted[math.max(
        0,
        math.ceil(0xf33333p-24 * #sorted) - 1
    ) + 1] or 0
end
local function overlayText(state)
    local ____summary_result_4 = summary(state, state.recent)
    local lua = ____summary_result_4.lua
    local natives = ____summary_result_4.natives
    local catchUp = ____summary_result_4.catchUp
    local frames = ____summary_result_4.frames
    local time = lua == nil and "Lua: no clock" or ((((((("Lua ms: " .. milliseconds(lua.median * 1000000)) .. " / ") .. milliseconds(ninetyFifth(state.recent.lua) * 1000000)) .. " / ") .. milliseconds(lua.max * 1000000)) .. " (clock step ") .. (state.step * 100000 < 1 and "under 0.01" or milliseconds(state.step * 1000000))) .. " ms)"
    return (((((((((((((("frame cost, last " .. tostring(frames)) .. " frames, median / p95 / max\n") .. time) .. "\nnatives: ") .. reportNumber(natives.median)) .. " / ") .. reportNumber(ninetyFifth(state.recent.natives))) .. " / ") .. reportNumber(natives.max)) .. "\ncatch-up frames: ") .. reportNumber(catchUp.median)) .. " / ") .. reportNumber(ninetyFifth(state.recent.catchUp))) .. " / ") .. reportNumber(catchUp.max)
end
local function microseconds(window)
    local ____window_5 = window
    local lua = ____window_5.lua
    return lua == nil and window or __TS__ObjectAssign({}, window, {lua = {median = lua.median * 1000000, mean = lua.mean * 1000000, max = lua.max * 1000000}})
end
local function writeReport(state, before)
    PreloadGenClear()
    PreloadGenStart()
    Preload(frameCostHeading(state.version, before.version, state.step * 1000000))
    Preload(frameWindowLine(
        "before",
        microseconds(before.window)
    ))
    Preload(frameWindowLine(
        "after",
        microseconds(summary(state, state.current))
    ))
    PreloadGenEnd(frameCostFile(
        GetPlayerId(GetLocalPlayer()),
        runtimeConfiguration().filePrefix
    ))
end
function ____exports.startFrameCostCapture(frames)
    if frames < 1 or frames > MAX_FRAME_COST_CAPTURE or frames ~= math.floor(frames) then
        do
            local ____thrown = __TS__New(Error, "frame cost capture needs 1 to 18000 frames")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/frameMeter.ts:199"
            end
            error(____thrown, 0)
        end
    end
    local state = meter()
    if state.capture ~= nil then
        do
            local ____thrown = __TS__New(Error, "frame cost capture already running")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/frameMeter.ts:201"
            end
            error(____thrown, 0)
        end
    end
    local run = (state.captureRuns or 0) + 1
    state.captureRuns = run
    local ____run_8 = run
    local ____frames_9 = frames
    local ____installedVersion_result_10 = installedVersion()
    local ____opt_6 = state.clock
    state.capture = {
        run = ____run_8,
        limit = ____frames_9,
        version = ____installedVersion_result_10,
        started = ____opt_6 and ____opt_6() or 0,
        lua = {},
        natives = {},
        catchUp = {},
        skip = true,
        changed = false
    }
    return run
end
local function captureFrame(state, calls, catchUp, version)
    local capture = state.capture
    if capture == nil then
        return
    end
    if capture.skip then
        capture.skip = false
        return
    end
    if not capture.changed then
        capture.changed = version ~= capture.version
    end
    local ____capture_lua_11 = capture.lua
    ____capture_lua_11[#____capture_lua_11 + 1] = state.lua
    local ____capture_natives_12 = capture.natives
    ____capture_natives_12[#____capture_natives_12 + 1] = calls
    local ____capture_catchUp_13 = capture.catchUp
    ____capture_catchUp_13[#____capture_catchUp_13 + 1] = catchUp
    if #capture.lua < capture.limit then
        return
    end
    state.capture = nil
    local elapsed = state.clock == nil and 0 or state.clock() - capture.started
    PreloadGenClear()
    PreloadGenStart()
    Preload(frameCostCaptureHeading(
        capture.run,
        capture.limit,
        capture.version,
        state.step * 1000000,
        elapsed * 1000,
        capture.changed
    ))
    do
        local index = 0
        while index < capture.limit do
            local ____Preload_17 = Preload
            local ____frameCostCaptureSample_16 = frameCostCaptureSample
            local ____temp_15 = index + 1
            local ____temp_14
            if state.clock == nil then
                ____temp_14 = nil
            else
                ____temp_14 = (capture.lua[index + 1] or 0) * 1000000
            end
            ____Preload_17(____frameCostCaptureSample_16(____temp_15, ____temp_14, capture.natives[index + 1] or 0, capture.catchUp[index + 1] or 0))
            index = index + 1
        end
    end
    PreloadGenEnd(frameCostCaptureFile(
        GetPlayerId(GetLocalPlayer()),
        capture.run,
        runtimeConfiguration().filePrefix
    ))
end
local function endFrame(state)
    local calls = state.calls - state.frameCalls
    local read = state.options.simulationFrame
    local simulation = read == nil and 0 or read()
    local catchUp = simulation > state.simulation and simulation - state.simulation or 0
    state.simulation = simulation
    push(state.recent.lua, state.lua)
    push(state.recent.natives, calls)
    push(state.recent.catchUp, catchUp)
    local version = installedVersion()
    captureFrame(state, calls, catchUp, version)
    if version ~= state.version then
        state.before = {
            version = state.version,
            window = summary(state, state.current)
        }
        state.version = version
        clear(state.current)
    else
        push(state.current.lua, state.lua)
        push(state.current.natives, calls)
        push(state.current.catchUp, catchUp)
        local before = state.before
        if before ~= nil and state.current.natives.count >= ____exports.FRAME_WINDOW then
            state.before = nil
            writeReport(state, before)
        end
    end
    state.frames = state.frames + 1
    if state.shown and state.frames % OVERLAY_FRAMES == 0 then
        BlzFrameSetText(
            state.overlay,
            overlayText(state)
        )
    end
    state.lua = 0
    state.frameCalls = state.calls
end
local function measure(state, name)
    local run = state.plain
    if run == nil then
        return
    end
    local clock = state.clock
    if clock == nil then
        run(name)
    else
        local started = clock()
        run(name)
        state.lua = state.lua + (clock() - started)
    end
    if name == state.options.frame then
        endFrame(state)
    end
end
local function toggle()
    local state = meter()
    local calls = state.calls
    if GetTriggerPlayer() ~= GetLocalPlayer() then
        state.frameCalls = state.frameCalls + (state.calls - calls)
        return
    end
    state.shown = not state.shown
    if state.shown then
        BlzFrameSetText(
            state.overlay,
            overlayText(state)
        )
    end
    BlzFrameSetVisible(state.overlay, state.shown)
    state.frameCalls = state.frameCalls + (state.calls - calls)
end
local function countCalls(state)
    local globals = _G
    if type(globals._VERSION) ~= "string" then
        return
    end
    local names = {}
    for name in pairs(globals) do
        local first = string.byte(name, 1) or 0 / 0
        if first >= 65 and first <= 90 and type(globals[name]) == "function" then
            names[#names + 1] = name
        end
    end
    for ____, name in ipairs(names) do
        local native = globals[name]
        globals[name] = function(...)
            state.calls = state.calls + 1
            return native(...)
        end
    end
end
local function createOverlay()
    local frame = BlzCreateFrameByType(
        "TEXT",
        "WispFrameMeter",
        BlzGetOriginFrame(ORIGIN_FRAME_GAME_UI, 0),
        "",
        0
    )
    BlzFrameSetAbsPoint(frame, FRAMEPOINT_TOPLEFT, 0x947ae1p-24, 0x8f5c29p-24)
    BlzFrameSetSize(frame, 0xd70a3dp-26, 0x51eb85p-26)
    BlzFrameSetFont(frame, "Fonts\\FRIZQT__.TTF", 0x24dd2fp-28, 0)
    BlzFrameSetTextAlignment(frame, TEXT_JUSTIFY_TOP, TEXT_JUSTIFY_LEFT)
    BlzFrameSetVisible(frame, false)
    return frame
end
function ____exports.installFrameMeter()
    local globals = _G
    local state = globals[runtimeConfiguration().globalPrefix .. "FrameMeter"]
    if state == nil then
        return
    end
    local ____table = dispatchTable()
    if ____table.run ~= state.measured then
        state.plain = ____table.run
    end
    local function measured(name)
        return measure(state, name)
    end
    state.measured = measured
    ____table.run = measured
    on(TOGGLE, toggle)
end
function ____exports.startFrameMeter(options)
    local configuration = runtimeConfiguration()
    local globals = _G
    local key = configuration.globalPrefix .. "FrameMeter"
    if globals[key] ~= nil then
        return
    end
    local ____findClock_result_18 = findClock()
    local clock = ____findClock_result_18.clock
    local step = ____findClock_result_18.step
    local read = options.simulationFrame
    local state = {
        options = options,
        clock = clock,
        step = step,
        plain = nil,
        measured = nil,
        calls = 0,
        frameCalls = 0,
        lua = 0,
        simulation = read == nil and 0 or read(),
        recent = emptyWindow(),
        current = emptyWindow(),
        version = installedVersion(),
        before = nil,
        overlay = createOverlay(),
        shown = false,
        frames = 0,
        capture = nil,
        captureRuns = 0
    }
    globals[key] = state
    countCalls(state)
    ____exports.installFrameMeter()
    local trigger = CreateTrigger()
    do
        local slot = 0
        while slot < FILE_SLOTS do
            TriggerRegisterPlayerChatEvent(
                trigger,
                Player(slot),
                options.toggle,
                true
            )
            slot = slot + 1
        end
    end
    TriggerAddAction(
        trigger,
        trampoline(TOGGLE)
    )
end
return ____exports
