local ____exports = {}
local ____repro = require("src.runtime.repro")
local reproLines = ____repro.reproLines
local ____fileio = require("src.platform.fileio")
local writeLines = ____fileio.writeLines
function ____exports.writeRepro(filename, header, lines)
    writeLines(
        filename,
        reproLines(header, lines)
    )
end
return ____exports
