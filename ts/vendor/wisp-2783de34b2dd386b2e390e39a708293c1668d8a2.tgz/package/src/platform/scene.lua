local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local Map = ____lualib.Map
local __TS__Spread = ____lualib.__TS__Spread
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local Set = ____lualib.Set
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local now, leftView, wrapUnitNatives
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
local ____scene = require("src.runtime.scene")
local reportedModel = ____scene.reportedModel
local sceneFile = ____scene.sceneFile
local sceneHeading = ____scene.sceneHeading
local sceneModelLine = ____scene.sceneModelLine
local sceneReportGlobal = ____scene.sceneReportGlobal
local ____dispatch = require("src.platform.dispatch")
local on = ____dispatch.on
local trampoline = ____dispatch.trampoline
function now(state)
    local frame = state.options.frame()
    if frame < state.last then
        state.offset = state.offset + (state.last - frame + 1)
    end
    state.last = frame
    return state.offset + frame
end
function leftView(state, effect, frame)
    if effect.since == nil then
        return
    end
    local stayed = frame - effect.since
    if stayed > (state.longest:get(effect.model) or 0) then
        state.longest:set(effect.model, stayed)
    end
    effect.since = nil
end
function wrapUnitNatives(state, unitModel)
    local create = CreateUnit
    local remove = RemoveUnit
    local show = ShowUnit
    local setColor = SetUnitVertexColor
    local setScale = SetUnitScale
    local natives = _G
    natives.CreateUnit = function(owner, unitType, x, y, facing)
        local handle = create(
            owner,
            unitType,
            x,
            y,
            facing
        )
        local model = unitModel(unitType)
        if model ~= nil then
            local frame = now(state)
            state.units:set(handle, {
                model = model,
                created = frame,
                alpha = 255,
                scale = 1.0,
                flat = false,
                since = frame,
                drawn = false,
                hidden = false
            })
        end
        return handle
    end
    natives.RemoveUnit = function(handle)
        local recorded = state.units:get(handle)
        if recorded ~= nil then
            leftView(
                state,
                recorded,
                now(state)
            )
            state.units:delete(handle)
        end
        remove(handle)
    end
    natives.ShowUnit = function(handle, shown)
        show(handle, shown)
        local recorded = state.units:get(handle)
        if recorded == nil then
            return
        end
        recorded.hidden = not shown
        if shown then
            if recorded.since == nil then
                recorded.since = now(state)
            end
        else
            leftView(
                state,
                recorded,
                now(state)
            )
        end
    end
    natives.SetUnitVertexColor = function(handle, red, green, blue, alpha)
        local recorded = state.units:get(handle)
        if recorded ~= nil then
            recorded.alpha = alpha
        end
        setColor(
            handle,
            red,
            green,
            blue,
            alpha
        )
    end
    natives.SetUnitScale = function(handle, x, y, z)
        local recorded = state.units:get(handle)
        if recorded ~= nil then
            recorded.scale = x
            recorded.flat = x == 0 or y == 0 or z == 0
        end
        setScale(handle, x, y, z)
    end
end
local REPORT_SECONDS = 0x1p-1
local REPORT = "scene.report"
local function scene()
    local globals = _G
    local state = globals[sceneReportGlobal(runtimeConfiguration().globalPrefix)]
    if state == nil then
        do
            local ____thrown = __TS__New(Error, "scene report used before startSceneReport")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/scene.ts:66"
            end
            error(____thrown, 0)
        end
    end
    return state
end
local function placed(state, effect, x, y, z)
    if state.options.parked(x, y, z) then
        leftView(
            state,
            effect,
            now(state)
        )
    else
        if effect.since == nil then
            effect.since = now(state)
        end
    end
end
local function created(state, handle, model)
    state.effects:set(
        handle,
        {
            model = model,
            created = now(state),
            alpha = 255,
            scale = 1.0,
            flat = false,
            since = nil,
            drawn = false
        }
    )
    return handle
end
local function wrapNatives(state)
    local add = AddSpecialEffect
    local addAt = AddSpecialEffectLoc
    local attach = AddSpecialEffectTarget
    local destroy = DestroyEffect
    local setAlpha = BlzSetSpecialEffectAlpha
    local setScale = BlzSetSpecialEffectScale
    local setMatrixScale = BlzSetSpecialEffectMatrixScale
    local resetMatrix = BlzResetSpecialEffectMatrix
    local setPosition = BlzSetSpecialEffectPosition
    local setX = BlzSetSpecialEffectX
    local setY = BlzSetSpecialEffectY
    local setZ = BlzSetSpecialEffectZ
    local natives = _G
    natives.AddSpecialEffect = function(model, x, y) return created(
        state,
        add(model, x, y),
        model
    ) end
    natives.AddSpecialEffectLoc = function(model, where) return created(
        state,
        addAt(model, where),
        model
    ) end
    natives.AddSpecialEffectTarget = function(model, target, point) return created(
        state,
        attach(model, target, point),
        model
    ) end
    natives.DestroyEffect = function(handle)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            leftView(
                state,
                effect,
                now(state)
            )
            state.effects:delete(handle)
            if not state.options.parked(
                BlzGetLocalSpecialEffectX(handle),
                BlzGetLocalSpecialEffectY(handle),
                BlzGetLocalSpecialEffectZ(handle)
            ) then
                state.destroyed:set(
                    effect.model,
                    (state.destroyed:get(effect.model) or 0) + 1
                )
            end
        end
        destroy(handle)
    end
    natives.BlzSetSpecialEffectAlpha = function(handle, alpha)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.alpha = alpha
        end
        setAlpha(handle, alpha)
    end
    natives.BlzSetSpecialEffectScale = function(handle, scale)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.scale = scale
        end
        setScale(handle, scale)
    end
    natives.BlzSetSpecialEffectMatrixScale = function(handle, x, y, z)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.flat = effect.flat or x == 0 or y == 0 or z == 0
        end
        setMatrixScale(handle, x, y, z)
    end
    natives.BlzResetSpecialEffectMatrix = function(handle)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.flat = false
        end
        resetMatrix(handle)
    end
    natives.BlzSetSpecialEffectPosition = function(handle, x, y, z)
        setPosition(handle, x, y, z)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            placed(
                state,
                effect,
                x,
                y,
                z
            )
        end
    end
    natives.BlzSetSpecialEffectX = function(handle, x)
        setX(handle, x)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            placed(
                state,
                effect,
                x,
                BlzGetLocalSpecialEffectY(handle),
                BlzGetLocalSpecialEffectZ(handle)
            )
        end
    end
    natives.BlzSetSpecialEffectY = function(handle, y)
        setY(handle, y)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            placed(
                state,
                effect,
                BlzGetLocalSpecialEffectX(handle),
                y,
                BlzGetLocalSpecialEffectZ(handle)
            )
        end
    end
    natives.BlzSetSpecialEffectZ = function(handle, z)
        setZ(handle, z)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            placed(
                state,
                effect,
                BlzGetLocalSpecialEffectX(handle),
                BlzGetLocalSpecialEffectY(handle),
                z
            )
        end
    end
    local ____state_options_0 = state.options
    local unitModel = ____state_options_0.unitModel
    if unitModel ~= nil then
        wrapUnitNatives(state, unitModel)
    end
end
local function observe(state, frame)
    local ____state_options_1 = state.options
    local parked = ____state_options_1.parked
    for ____, ____value in __TS__Iterator(state.effects) do
        local handle = ____value[1]
        local effect = ____value[2]
        local inView = not parked(
            BlzGetLocalSpecialEffectX(handle),
            BlzGetLocalSpecialEffectY(handle),
            BlzGetLocalSpecialEffectZ(handle)
        )
        if not inView then
            leftView(state, effect, frame)
        else
            if effect.since == nil then
                effect.since = frame
            end
        end
        effect.drawn = inView and effect.alpha > 0 and effect.scale > 0 and not effect.flat
    end
    for ____, recorded in __TS__Iterator(state.units:values()) do
        recorded.drawn = not recorded.hidden and recorded.alpha > 0 and recorded.scale > 0 and not recorded.flat
    end
end
local function sceneModels(state, frame)
    local summaries = __TS__New(Map)
    local ____array_2 = __TS__SparseArrayNew(__TS__Spread(state.effects:values()))
    __TS__SparseArrayPush(
        ____array_2,
        __TS__Spread(state.units:values())
    )
    for ____, effect in ipairs({__TS__SparseArraySpread(____array_2)}) do
        do
            local summary = summaries:get(effect.model) or ({
                live = 0,
                inView = 0,
                drawn = 0,
                created = effect.created,
                since = nil
            })
            summaries:set(effect.model, summary)
            summary.live = summary.live + 1
            summary.created = math.min(summary.created, effect.created)
            if effect.drawn then
                summary.drawn = summary.drawn + 1
            end
            if effect.since == nil then
                goto __continue58
            end
            summary.inView = summary.inView + 1
            summary.since = math.min(summary.since or effect.since, effect.since)
        end
        ::__continue58::
    end
    local ____Set_4 = Set
    local ____array_3 = __TS__SparseArrayNew(__TS__Spread(summaries:keys()))
    __TS__SparseArrayPush(
        ____array_3,
        __TS__Spread(state.longest:keys())
    )
    __TS__SparseArrayPush(
        ____array_3,
        __TS__Spread(state.destroyed:keys())
    )
    local models = __TS__ArraySort({__TS__Spread(__TS__New(
        ____Set_4,
        {__TS__SparseArraySpread(____array_3)}
    ))})
    return __TS__ArrayMap(
        models,
        function(____, model)
            local summary = summaries:get(model)
            local ____temp_7
            if (summary and summary.since) == nil then
                ____temp_7 = nil
            else
                ____temp_7 = frame - summary.since
            end
            local age = ____temp_7
            return {
                model = reportedModel(model),
                live = summary and summary.live or 0,
                inView = summary and summary.inView or 0,
                drawn = summary and summary.drawn or 0,
                created = summary and summary.created,
                age = age,
                longest = math.max(
                    state.longest:get(model) or 0,
                    age or 0
                ),
                destroyed = state.destroyed:get(model) or 0
            }
        end
    )
end
local function writeReport()
    local state = scene()
    local frame = now(state)
    observe(state, frame)
    state.serial = state.serial + 1
    PreloadGenClear()
    PreloadGenStart()
    Preload(sceneHeading(state.serial, frame, state.effects.size))
    for ____, model in ipairs(sceneModels(state, frame)) do
        Preload(sceneModelLine(model))
    end
    PreloadGenEnd(sceneFile(
        GetPlayerId(GetLocalPlayer()),
        runtimeConfiguration().filePrefix
    ))
end
function ____exports.installSceneReport()
    on(REPORT, writeReport)
end
function ____exports.startSceneReport(options)
    local globals = _G
    local key = sceneReportGlobal(runtimeConfiguration().globalPrefix)
    if globals[key] ~= nil then
        return
    end
    local state = {
        effects = __TS__New(Map),
        units = __TS__New(Map),
        longest = __TS__New(Map),
        destroyed = __TS__New(Map),
        options = options,
        offset = 0,
        last = options.frame(),
        serial = 0
    }
    globals[key] = state
    wrapNatives(state)
    ____exports.installSceneReport()
    TimerStart(
        CreateTimer(),
        REPORT_SECONDS,
        true,
        trampoline(REPORT)
    )
end
return ____exports
