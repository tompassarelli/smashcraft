/** @noSelfInFile */
/** f32(a + b) in Lua. */
export declare function exactSum(value: number, right: number): number;
/** f32(a - b) in Lua: the sum with b negated, which is exact; the integer -2^31 has no negation. */
export declare function exactDifference(value: number, right: number): number;
/** f32(a * b) in Lua. */
export declare function exactProduct(value: number, right: number): number;
/** f32(a / b) in Lua. */
export declare function exactQuotient(value: number, right: number): number;
declare global {
    /** The operations f32(a + b), f32(a - b), f32(a * b) and f32(a / b) compile to in Lua (wisp:plugins/warcraft-numbers.ts). */
    var __wispF32Add: (value: number, right: number) => number;
    var __wispF32Subtract: (value: number, right: number) => number;
    var __wispF32Multiply: (value: number, right: number) => number;
    var __wispF32Divide: (value: number, right: number) => number;
}
/** Binary32 rounding: Math.fround on the host; the compiler removes it in Lua, whose numbers are binary32. */
export declare function f32(value: number): number;
