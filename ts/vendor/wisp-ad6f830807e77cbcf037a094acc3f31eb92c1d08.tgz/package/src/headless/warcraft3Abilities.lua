local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local Set = ____lualib.Set
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ArrayFrom = ____lualib.__TS__ArrayFrom
local ____exports = {}
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
--- Crow Form and Storm Crow Form: adding either lets a ground unit's flying height change for good.
local FLY_HEIGHT_FORMS = {1097691750, 1098015094}
____exports.Warcraft3Abilities = __TS__Class()
local Warcraft3Abilities = ____exports.Warcraft3Abilities
Warcraft3Abilities.name = "Warcraft3Abilities"
function Warcraft3Abilities.prototype.____constructor(self)
    self.units = __TS__New(Map)
    self.flyHeightUnlocked = __TS__New(Set)
    self.fields = __TS__New(Map)
    self.ids = __TS__New(Map)
end
function Warcraft3Abilities.prototype.state(self, unit)
    local state = self.units:get(unit)
    if state == nil then
        state = {
            cooldowns = __TS__New(Map),
            remaining = __TS__New(Map),
            levels = __TS__New(Map),
            handles = __TS__New(Map),
            attackPeriods = __TS__New(Map),
            attackRemaining = __TS__New(Map),
            auras = true,
            auraUI = true
        }
        self.units:set(unit, state)
    end
    return state
end
function Warcraft3Abilities.prototype.canChangeFlyHeight(self, unit)
    return self.flyHeightUnlocked:has(unit)
end
function Warcraft3Abilities.prototype.removeUnit(self, unit)
    self.flyHeightUnlocked:delete(unit)
    local state = self.units:get(unit)
    if state == nil then
        return
    end
    for ____, ability in __TS__Iterator(state.handles:values()) do
        self.fields:delete(ability)
        self.ids:delete(ability)
    end
    self.units:delete(unit)
end
function Warcraft3Abilities.prototype.tick(self, seconds)
    for ____, unit in __TS__Iterator(self.units:values()) do
        for ____, ____value in __TS__Iterator(unit.remaining) do
            local id = ____value[1]
            local remaining = ____value[2]
            unit.remaining:set(
                id,
                math.max(0, remaining - seconds)
            )
        end
        for ____, ____value in __TS__Iterator(unit.attackRemaining) do
            local index = ____value[1]
            local remaining = ____value[2]
            unit.attackRemaining:set(
                index,
                math.max(0, remaining - seconds)
            )
        end
    end
end
function Warcraft3Abilities.prototype.behaviors(self, handle)
    local function cooldown(unit, id)
        return self:state(unit).cooldowns:get((tostring(id) .. " ") .. tostring((self:state(unit).levels:get(id) or 1) - 1)) or 0
    end
    local function remaining(unit, id)
        return self:state(unit).remaining:get(id) or 0
    end
    local function setRemaining(unit, id, value)
        self:state(unit).remaining:set(
            id,
            math.max(0, value)
        )
    end
    local function field(ability, key)
        local ____opt_0 = self.fields:get(ability)
        return ____opt_0 and ____opt_0:get(key)
    end
    local function setField(ability, key, value)
        local fields = self.fields:get(ability)
        if fields == nil then
            return false
        end
        fields:set(key, value)
        return true
    end
    return {
        UnitAddAbility = function(unit, id)
            local state = self:state(unit)
            if state.handles:has(id) then
                return false
            end
            local ability = handle("ability")
            state.handles:set(id, ability)
            state.levels:set(id, 1)
            self.fields:set(
                ability,
                __TS__New(Map)
            )
            self.ids:set(ability, id)
            if __TS__ArrayIncludes(FLY_HEIGHT_FORMS, id) then
                self.flyHeightUnlocked:add(unit)
            end
            return true
        end,
        UnitRemoveAbility = function(unit, id)
            local state = self:state(unit)
            local ability = state.handles:get(id)
            if ability == nil then
                return false
            end
            state.handles:delete(id)
            state.levels:delete(id)
            state.remaining:delete(id)
            self.fields:delete(ability)
            self.ids:delete(ability)
            return true
        end,
        GetUnitAbilityLevel = function(unit, id) return self:state(unit).levels:get(id) or 0 end,
        SetUnitAbilityLevel = function(unit, id, level)
            local state = self:state(unit)
            if not state.handles:has(id) then
                return 0
            end
            state.levels:set(id, level)
            return level
        end,
        BlzGetUnitAbility = function(unit, id) return self:state(unit).handles:get(id) end,
        BlzGetUnitAbilityByIndex = function(unit, index) return __TS__ArrayFrom(self:state(unit).handles:values())[index + 1] end,
        BlzGetAbilityId = function(ability) return self.ids:get(ability) or 0 end,
        BlzSetUnitAttackCooldown = function(unit, duration, index)
            self:state(unit).attackPeriods:set(index, duration)
        end,
        BlzGetUnitAttackCooldown = function(unit, index) return self:state(unit).attackPeriods:get(index) or 0 end,
        BlzResetUnitAttack = function(unit, index)
            self:state(unit).attackRemaining:set(index, 0)
        end,
        BlzUnitEnableAuras = function(unit, enable, affectsUI)
            local state = self:state(unit)
            state.auras = enable
            if affectsUI then
                state.auraUI = enable
            end
        end,
        BlzSetUnitAbilityCooldown = function(unit, id, level, duration)
            self:state(unit).cooldowns:set(
                (tostring(id) .. " ") .. tostring(level),
                duration
            )
        end,
        BlzGetUnitAbilityCooldown = function(unit, id, level) return self:state(unit).cooldowns:get((tostring(id) .. " ") .. tostring(level)) or 0 end,
        BlzGetUnitAbilityCooldownRemaining = remaining,
        BlzGetUnitAbilityCooldownPercent = function(unit, id) return cooldown(unit, id) == 0 and 0 or f32(
            remaining(unit, id),
            cooldown(unit, id),
            4
        ) end,
        BlzSetUnitAbilityCooldownRemaining = setRemaining,
        BlzSetUnitAbilityCooldownPercent = function(unit, id, percent) return setRemaining(
            unit,
            id,
            f32(
                cooldown(unit, id),
                percent,
                3
            )
        ) end,
        BlzAdjustUnitAbilityCooldownRemaining = function(unit, id, duration) return setRemaining(
            unit,
            id,
            f32(
                remaining(unit, id),
                duration,
                1
            )
        ) end,
        BlzAdjustUnitAbilityCooldownPercent = function(unit, id, percent) return setRemaining(
            unit,
            id,
            f32(
                remaining(unit, id),
                f32(
                    cooldown(unit, id),
                    percent,
                    3
                ),
                1
            )
        ) end,
        BlzStartUnitAbilityCooldown = setRemaining,
        BlzEndUnitAbilityCooldown = function(unit, id) return setRemaining(unit, id, 0) end,
        UnitResetCooldown = function(unit) return self:state(unit).remaining:clear() end,
        BlzGetAbilityRealLevelField = function(ability, which, level)
            local ____field_result_2 = field(
                ability,
                (tostring(which) .. " ") .. tostring(level)
            )
            if ____field_result_2 == nil then
                ____field_result_2 = 0
            end
            return ____field_result_2
        end,
        BlzSetAbilityRealLevelField = function(ability, which, level, value) return setField(
            ability,
            (tostring(which) .. " ") .. tostring(level),
            value
        ) end,
        BlzGetAbilityBooleanLevelField = function(ability, which, level)
            local ____field_result_3 = field(
                ability,
                (tostring(which) .. " ") .. tostring(level)
            )
            if ____field_result_3 == nil then
                ____field_result_3 = false
            end
            return ____field_result_3
        end,
        BlzSetAbilityBooleanLevelField = function(ability, which, level, value) return setField(
            ability,
            (tostring(which) .. " ") .. tostring(level),
            value
        ) end
    }
end
return ____exports
