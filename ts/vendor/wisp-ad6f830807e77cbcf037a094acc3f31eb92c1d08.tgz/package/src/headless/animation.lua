local ____lualib = require("lualib_bundle")
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local ____intMath = require("src.sim.intMath")
local floorMod = ____intMath.floorMod
function ____exports.freshAnimation()
    return {
        animation = nil,
        subAnimations = {},
        animationElapsed = 0,
        animationSought = 0,
        animationTicks = 0,
        animationClock = 0,
        animationBlendTime = 0,
        animationBlend = nil
    }
end
--- Selecting a sequence restarts its clock. With a blend time, a unit that has
-- already animated keeps its old pose and fades it out; a selection during a
-- blend leaves that blend running.
function ____exports.selectAnimation(state, animation, subAnimations)
    if state.animationBlendTime > 0 and state.animation ~= nil and state.animationBlend == nil and state.animationClock * 1000 >= 1 then
        state.animationBlend = {
            from = {
                animation = state.animation,
                subAnimations = {table.unpack(state.subAnimations)},
                elapsed = state.animationElapsed,
                sought = state.animationSought,
                ticks = state.animationTicks
            },
            remaining = state.animationBlendTime * 1000
        }
    end
    state.animation = animation
    if subAnimations ~= nil then
        state.subAnimations = {table.unpack(subAnimations)}
    end
    state.animationElapsed = 0
    state.animationSought = 0
    state.animationTicks = 0
end
--- A seek moves the sample time without spending blend time.
function ____exports.seekAnimation(state, seconds)
    state.animationElapsed = seconds
    state.animationSought = seconds
    state.animationTicks = 0
end
--- One frame: the clock, the global clock and the blend all move by elapsed × time scale.
function ____exports.advanceAnimation(state, timeScale, frameSeconds)
    local step = timeScale * frameSeconds
    if step == 0 then
        return
    end
    state.animationElapsed = state.animationElapsed + step
    state.animationClock = state.animationClock + step
    state.animationTicks = state.animationTicks + 1
    local blend = state.animationBlend
    if blend == nil then
        return
    end
    blend.remaining = blend.remaining - step * 1000
    if blend.remaining <= 0 then
        state.animationBlend = nil
    end
end
--- How much of the saved pose still shows, from 1 at the switch to 0.
function ____exports.blendWeight(state)
    local blend = state.animationBlend
    if blend == nil or state.animationBlendTime <= 0 then
        return 0
    end
    return math.min(1, blend.remaining / (state.animationBlendTime * 1000))
end
local PRIMARY_TAGS = {
    "attack",
    "birth",
    "death",
    "decay",
    "dissipate",
    "morph",
    "portrait",
    "sleep",
    "spell",
    "stand",
    "walk"
}
local SECONDARY_TAGS = {
    "alternate",
    "alternateex",
    "berserk",
    "bone",
    "chain",
    "chainlightning",
    "channel",
    "cinematic",
    "complete",
    "critical",
    "defend",
    "drain",
    "eattree",
    "entangle",
    "fast",
    "fifth",
    "fill",
    "fire",
    "first",
    "five",
    "flail",
    "flesh",
    "four",
    "fourth",
    "gold",
    "hit",
    "large",
    "left",
    "light",
    "looping",
    "lumber",
    "medium",
    "moderate",
    "off",
    "one",
    "puke",
    "ready",
    "right",
    "rooted",
    "second",
    "severe",
    "slam",
    "small",
    "spiked",
    "spin",
    "swim",
    "talk",
    "third",
    "three",
    "throw",
    "turn",
    "two",
    "upgrade",
    "victory",
    "work",
    "wounded"
}
local function tagWord(word)
    local text = string.lower(word)
    if __TS__StringStartsWith(text, "anim_type_") then
        text = __TS__StringSubstring(text, 10)
    end
    if __TS__StringStartsWith(text, "subanim_type_") then
        text = __TS__StringSubstring(text, 13)
    end
    local joined = ""
    do
        local index = 0
        while index < #text do
            if __TS__StringCharAt(text, index) ~= "_" then
                joined = joined .. __TS__StringCharAt(text, index)
            end
            index = index + 1
        end
    end
    return joined
end
local function words(name)
    local out = {}
    local current = ""
    do
        local index = 0
        while index <= #name do
            local character = index < #name and __TS__StringCharAt(name, index) or " "
            if character == " " or character == "\t" or character == "," or character == "\n" or character == "\r" then
                if current ~= "" then
                    out[#out + 1] = current
                end
                current = ""
            else
                current = current .. character
            end
            index = index + 1
        end
    end
    return out
end
--- A name's leading words that are animation tags: "Stand Hit - 2" is stand
-- with hit. The first word that is no tag ends the list.
function ____exports.animationTags(name, extra)
    if extra == nil then
        extra = {}
    end
    local primary = {}
    local secondary = {}
    for ____, word in ipairs(words(name)) do
        local tag = tagWord(word)
        if __TS__ArrayIncludes(PRIMARY_TAGS, tag) then
            if not __TS__ArrayIncludes(primary, tag) then
                primary[#primary + 1] = tag
            end
        elseif __TS__ArrayIncludes(SECONDARY_TAGS, tag) then
            if not __TS__ArrayIncludes(secondary, tag) then
                secondary[#secondary + 1] = tag
            end
        else
            break
        end
    end
    for ____, part in ipairs(extra) do
        local tag = tagWord(type(part) == "number" and tostring(part) or part)
        if __TS__ArrayIncludes(SECONDARY_TAGS, tag) and not __TS__ArrayIncludes(secondary, tag) then
            secondary[#secondary + 1] = tag
        end
    end
    __TS__ArraySort(secondary)
    return {primary = primary, secondary = secondary}
end
local function sameTags(a, b)
    if #a ~= #b then
        return false
    end
    do
        local index = 0
        while index < #a do
            if a[index + 1] ~= b[index + 1] then
                return false
            end
            index = index + 1
        end
    end
    return true
end
--- The sequence a name selects, or -1 for none: the primary tag with exactly
-- the requested secondary tags; failing that, the secondary set sharing most
-- requested tags (the fewest tags on a tie); failing that, the plainest
-- sequence of the primary tag (stand when the name has none). Warcraft draws
-- among equal variants at random, weighted by rarity; Wisp takes the first of
-- the most common.
function ____exports.selectSequence(sequences, animation, subAnimations)
    if subAnimations == nil then
        subAnimations = {}
    end
    if type(animation) == "number" then
        return animation >= 0 and animation < #sequences and animation or -1
    end
    local wanted = ____exports.animationTags(animation, subAnimations)
    local tags = __TS__ArrayMap(
        sequences,
        function(____, sequence) return ____exports.animationTags(sequence.name) end
    )
    local primary = wanted.primary[1]
    local function eligible(own)
        return primary == nil or __TS__ArrayIncludes(own.primary, primary)
    end
    local chosen
    for ____, own in ipairs(tags) do
        if chosen == nil and eligible(own) and sameTags(own.secondary, wanted.secondary) then
            chosen = own.secondary
        end
    end
    if chosen == nil then
        local best = 0
        for ____, own in ipairs(tags) do
            do
                if not eligible(own) then
                    goto __continue49
                end
                local shared = 0
                for ____, tag in ipairs(own.secondary) do
                    if __TS__ArrayIncludes(wanted.secondary, tag) then
                        shared = shared + 1
                    end
                end
                if shared > best or shared > 0 and shared == best and chosen ~= nil and #own.secondary < #chosen then
                    best = shared
                    chosen = own.secondary
                end
            end
            ::__continue49::
        end
    end
    if chosen == nil then
        if primary == nil then
            primary = "stand"
        end
        for ____, own in ipairs(tags) do
            if __TS__ArrayIncludes(own.primary, primary) and (chosen == nil or #own.secondary < #chosen) then
                chosen = own.secondary
            end
        end
    end
    if chosen == nil then
        return -1
    end
    local found = -1
    do
        local index = 0
        while index < #sequences do
            do
                local own = tags[index + 1]
                if own == nil or not eligible(own) or not sameTags(own.secondary, chosen) then
                    goto __continue62
                end
                local ____temp_5 = found < 0
                if not ____temp_5 then
                    local ____opt_0 = sequences[index + 1]
                    local ____temp_4 = ____opt_0 and ____opt_0.rarity or 0
                    local ____opt_2 = sequences[found + 1]
                    ____temp_5 = ____temp_4 < (____opt_2 and ____opt_2.rarity or 0)
                end
                if ____temp_5 then
                    found = index
                end
            end
            ::__continue62::
            index = index + 1
        end
    end
    return found
end
--- The integer MDX frame a sequence shows. The clock starts where the last
-- selection or seek put it and moves by an even step on each of `ticks`
-- frames. Reaching the interval end minus 1 ms, a looping sequence restarts
-- at its start, dropping the overshoot; any other holds there.
function ____exports.sequenceFrame(sequence, soughtMs, advancedMs, ticks, looping)
    if looping == nil then
        looping = sequence.looping
    end
    local start = sequence.start
    local last = math.max(start, sequence["end"] - 1)
    local position = start + soughtMs
    if position >= last then
        position = looping and start or last
    end
    if ticks <= 0 or advancedMs <= 0 then
        return math.floor(position)
    end
    if not looping then
        return math.floor(math.min(last, position + advancedMs))
    end
    local step = advancedMs / ticks
    local first = math.max(
        1,
        math.ceil((last - position) / step)
    )
    if ticks < first then
        return math.floor(position + ticks * step)
    end
    local period = math.max(
        1,
        math.ceil((last - start) / step)
    )
    return math.floor(start + (ticks - first) % period * step)
end
--- The sequence and frame an animation state shows. A name that selects
-- nothing keeps Stand. A unit never told what to play shows Stand; an
-- effect shows Birth once, then Stand looping.
function ____exports.animationSample(sequences, animation, kind)
    local soughtMs = animation.sought * 1000
    local advancedMs = (animation.elapsed - animation.sought) * 1000
    local ticks = animation.ticks
    if animation.animation ~= nil then
        local index = ____exports.selectSequence(sequences, animation.animation, animation.subAnimations)
        if index < 0 and type(animation.animation) == "string" then
            index = ____exports.selectSequence(sequences, "stand")
        end
        local sequence = sequences[index + 1]
        return sequence == nil and ({sequence = -1, frame = 0}) or ({
            sequence = index,
            frame = ____exports.sequenceFrame(sequence, soughtMs, advancedMs, ticks)
        })
    end
    local standIndex = ____exports.selectSequence(sequences, "stand")
    if standIndex < 0 and #sequences > 0 then
        standIndex = 0
    end
    local stand = sequences[standIndex + 1]
    local birthIndex = kind == "effect" and ____exports.selectSequence(sequences, "birth") or -1
    local birth = sequences[birthIndex + 1]
    if birth ~= nil and __TS__ArrayIncludes(
        ____exports.animationTags(birth.name).primary,
        "birth"
    ) then
        local last = math.max(birth.start, birth["end"] - 1)
        local position = birth.start + soughtMs
        local step = ticks > 0 and advancedMs / ticks or 0
        local birthTicks = position >= last and 0 or (step > 0 and math.max(
            1,
            math.ceil((last - position) / step)
        ) or ticks + 1)
        if stand == nil or ticks < birthTicks then
            return {
                sequence = birthIndex,
                frame = ____exports.sequenceFrame(
                    birth,
                    soughtMs,
                    advancedMs,
                    ticks,
                    false
                )
            }
        end
        local after = ticks - birthTicks
        return {
            sequence = standIndex,
            frame = ____exports.sequenceFrame(
                stand,
                0,
                after * step,
                after,
                true
            )
        }
    end
    if stand == nil then
        return {sequence = -1, frame = 0}
    end
    local ____standIndex_8 = standIndex
    local ____exports_sequenceFrame_7 = ____exports.sequenceFrame
    local ____temp_6
    if kind == "effect" then
        ____temp_6 = true
    else
        ____temp_6 = stand.looping
    end
    return {
        sequence = ____standIndex_8,
        frame = ____exports_sequenceFrame_7(
            stand,
            soughtMs,
            advancedMs,
            ticks,
            ____temp_6
        )
    }
end
--- A global sequence's frame: integer animation time since creation, wrapped by its length.
function ____exports.globalSequenceFrame(clockSeconds, length)
    if length <= 0 then
        return 0
    end
    return math.floor(clockSeconds * 1000) % length
end
return ____exports
