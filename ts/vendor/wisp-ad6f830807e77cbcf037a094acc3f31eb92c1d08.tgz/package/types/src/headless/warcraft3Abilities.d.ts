/** @noSelfInFile */
import type { Handle, NativeBehavior } from "./client";
interface UnitAbilities {
    readonly cooldowns: Map<string, number>;
    readonly remaining: Map<number, number>;
    readonly levels: Map<number, number>;
    readonly handles: Map<number, Handle>;
    readonly attackPeriods: Map<number, number>;
    readonly attackRemaining: Map<number, number>;
    auras: boolean;
    auraUI: boolean;
}
export declare class Warcraft3Abilities {
    private readonly units;
    private readonly flyHeightUnlocked;
    private readonly fields;
    private readonly ids;
    state(unit: Handle): UnitAbilities;
    canChangeFlyHeight(unit: Handle): boolean;
    removeUnit(unit: Handle): void;
    tick(seconds: number): void;
    behaviors(handle: (this: void, kind: string) => Handle): Readonly<Record<string, NativeBehavior>>;
}
export {};
