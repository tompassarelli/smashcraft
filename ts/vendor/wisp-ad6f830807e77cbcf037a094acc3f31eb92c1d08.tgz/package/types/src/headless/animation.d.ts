/** @noSelfInFile */
/** A model sequence: its MDX interval in milliseconds. */
export interface AnimationSequence {
    readonly name: string;
    readonly start: number;
    readonly end: number;
    readonly looping: boolean;
    readonly rarity: number;
}
/** The clock and selection pose of the sequence that was playing when a blend began. */
export interface SavedAnimation {
    readonly animation: string | number | undefined;
    readonly subAnimations: readonly (string | number)[];
    readonly elapsed: number;
    readonly sought: number;
    readonly ticks: number;
}
export interface AnimationBlend {
    readonly from: SavedAnimation;
    /** Milliseconds of animation time left before the new pose shows alone. */
    remaining: number;
}
/** What a unit or effect remembers about its animation. Times are in seconds. */
export interface AnimationState {
    animation: string | number | undefined;
    subAnimations: (string | number)[];
    /** Seconds into the current animation: the last seek plus the time advanced since. */
    animationElapsed: number;
    /** Where the last selection (0) or seek put the clock. */
    animationSought: number;
    /** Frames that moved the clock since the last selection or seek. */
    animationTicks: number;
    /** Animation time since creation, which drives the model's global sequences; selections and seeks keep it. */
    animationClock: number;
    animationBlendTime: number;
    animationBlend: AnimationBlend | undefined;
}
export declare function freshAnimation(): AnimationState;
/**
 * Selecting a sequence restarts its clock. With a blend time, a unit that has
 * already animated keeps its old pose and fades it out; a selection during a
 * blend leaves that blend running.
 */
export declare function selectAnimation(state: AnimationState, animation: string | number, subAnimations?: readonly (string | number)[]): void;
/** A seek moves the sample time without spending blend time. */
export declare function seekAnimation(state: AnimationState, seconds: number): void;
/** One frame: the clock, the global clock and the blend all move by elapsed × time scale. */
export declare function advanceAnimation(state: AnimationState, timeScale: number, frameSeconds: number): void;
/** How much of the saved pose still shows, from 1 at the switch to 0. */
export declare function blendWeight(state: AnimationState): number;
export interface AnimationTags {
    readonly primary: readonly string[];
    /** Sorted, without repeats. */
    readonly secondary: readonly string[];
}
/**
 * A name's leading words that are animation tags: "Stand Hit - 2" is stand
 * with hit. The first word that is no tag ends the list.
 */
export declare function animationTags(name: string, extra?: readonly (string | number)[]): AnimationTags;
/**
 * The sequence a name selects, or -1 for none: the primary tag with exactly
 * the requested secondary tags; failing that, the secondary set sharing most
 * requested tags (the fewest tags on a tie); failing that, the plainest
 * sequence of the primary tag (stand when the name has none). Warcraft draws
 * among equal variants at random, weighted by rarity; Wisp takes the first of
 * the most common.
 */
export declare function selectSequence(sequences: readonly AnimationSequence[], animation: string | number, subAnimations?: readonly (string | number)[]): number;
/**
 * The integer MDX frame a sequence shows. The clock starts where the last
 * selection or seek put it and moves by an even step on each of `ticks`
 * frames. Reaching the interval end minus 1 ms, a looping sequence restarts
 * at its start, dropping the overshoot; any other holds there.
 */
export declare function sequenceFrame(sequence: AnimationSequence, soughtMs: number, advancedMs: number, ticks: number, looping?: boolean): number;
export interface SequenceSample {
    /** -1 for no sequence: every track takes its default value. */
    readonly sequence: number;
    readonly frame: number;
}
/**
 * The sequence and frame an animation state shows. A name that selects
 * nothing keeps Stand. A unit never told what to play shows Stand; an
 * effect shows Birth once, then Stand looping.
 */
export declare function animationSample(sequences: readonly AnimationSequence[], animation: SavedAnimation, kind: "effect" | "unit"): SequenceSample;
/** A global sequence's frame: integer animation time since creation, wrapped by its length. */
export declare function globalSequenceFrame(clockSeconds: number, length: number): number;
