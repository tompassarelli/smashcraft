// `wisp client look|read|click|keys CLIENT ...`: reads and drives one
// signed-in client on its private desktop.
//   look CLIENT [gold]          words on screen with positions
//   read CLIENT X Y W H [gold]  text in one region
//   click CLIENT X Y
//   keys CLIENT KEY...
import { Console, Effect } from "effect";
import { Clients, type Ink } from "../clients";
import { type Command, UsageFailure } from "../command";
import { step } from "../timings";

const numbers = (values: readonly string[], count: number) => {
  const parsed = values.slice(0, count).map(Number);
  return parsed.length === count && parsed.every(Number.isInteger) ? parsed : undefined;
};

export const makeClient = (stateFilePath: string): Command => ([action, name, ...rest]) => Effect.gen(function*() {
  const clients = yield* Clients;
  const target = clients.all.find((candidate) => candidate.name === name);
  if (target === undefined) return yield* new UsageFailure({ problem: `unknown client ${name}; known: ${clients.all.map((c) => c.name).join(", ")}` });
  const ink: Ink = rest.includes("gold") ? "gold" : "light";
  const run = Effect.gen(function*() {
    switch (action) {
      case "look":
        for (const word of yield* clients.words(target, ink)) yield* Console.log(`${word.x},${word.y} ${word.text}`);
        return;
      case "read": {
        const [x, y, width, height] = numbers(rest, 4) ?? [];
        if (x === undefined || y === undefined || width === undefined || height === undefined) return yield* new UsageFailure({ problem: "read takes X Y W H" });
        yield* Console.log((yield* clients.read(target, { x, y, width, height }, ink)).trim());
        return;
      }
      case "click": {
        const [x, y] = numbers(rest, 2) ?? [];
        if (x === undefined || y === undefined) return yield* new UsageFailure({ problem: "click takes X Y" });
        yield* clients.click(target, x, y);
        return;
      }
      case "keys":
        yield* clients.keys(target, ...rest);
        return;
      default:
        return yield* new UsageFailure({ problem: `unknown client action ${action}` });
    }
  });
  yield* run.pipe(step(`${action} ${name}`));
}).pipe(Effect.provide(Clients.layer(stateFilePath)));
