local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____f32 = require("src.sim.f32")
--- TextTagSpeed2Velocity's scale: a velocity of 0.071 moves a tag 128 world units a second.
local WORLD_UNITS_PER_VELOCITY = 128 / 0x916873p-27
____exports.TextTags = __TS__Class()
local TextTags = ____exports.TextTags
TextTags.name = "TextTags"
function TextTags.prototype.____constructor(self, handle)
    self.handle = handle
    self.tags = __TS__New(Map)
end
function TextTags.prototype.create(self)
    local handle = self.handle("texttag")
    self.tags:set(handle, {
        handle = handle,
        text = "",
        height = 0,
        x = 0,
        y = 0,
        z = 0,
        color = {255, 255, 255, 255},
        xVelocity = 0,
        yVelocity = 0,
        visible = true,
        suspended = false,
        permanent = true,
        age = 0,
        lifespan = 0,
        fadepoint = 0
    })
    return handle
end
function TextTags.prototype.destroy(self, tag)
    self.tags:delete(tag)
end
function TextTags.prototype.setText(self, tag, text, height)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.text = text
        found.height = height
    end
end
function TextTags.prototype.setPosition(self, tag, x, y, z)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.x = x
        found.y = y
        found.z = z
    end
end
function TextTags.prototype.setColor(self, tag, red, green, blue, alpha)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.color = {red, green, blue, alpha}
    end
end
function TextTags.prototype.setVelocity(self, tag, xVelocity, yVelocity)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.xVelocity = xVelocity
        found.yVelocity = yVelocity
    end
end
function TextTags.prototype.setVisible(self, tag, visible)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.visible = visible
    end
end
function TextTags.prototype.setSuspended(self, tag, suspended)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.suspended = suspended
    end
end
function TextTags.prototype.setPermanent(self, tag, permanent)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.permanent = permanent
    end
end
function TextTags.prototype.setAge(self, tag, age)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.age = age
    end
end
function TextTags.prototype.setLifespan(self, tag, lifespan)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.lifespan = lifespan
    end
end
function TextTags.prototype.setFadepoint(self, tag, fadepoint)
    local found = self.tags:get(tag)
    if found ~= nil then
        found.fadepoint = fadepoint
    end
end
function TextTags.prototype.tick(self, seconds)
    for ____, found in __TS__Iterator(self.tags:values()) do
        do
            if found.suspended then
                goto __continue26
            end
            found.x = found.x + found.xVelocity * WORLD_UNITS_PER_VELOCITY * seconds
            found.y = found.y + found.yVelocity * WORLD_UNITS_PER_VELOCITY * seconds
            found.age = found.age + seconds
            if not found.permanent and found.age >= found.lifespan then
                self.tags:delete(found.handle)
            end
        end
        ::__continue26::
    end
end
function TextTags.prototype.poses(self)
    local poses = {}
    for ____, found in __TS__Iterator(self.tags:values()) do
        do
            if not found.visible or found.text == "" then
                goto __continue31
            end
            local fading = not found.permanent and found.age > found.fadepoint and found.lifespan > found.fadepoint
            local share = fading and math.max(0, 1 - (found.age - found.fadepoint) / (found.lifespan - found.fadepoint)) or 1
            poses[#poses + 1] = {
                handle = found.handle,
                text = found.text,
                height = found.height,
                x = found.x,
                y = found.y,
                z = found.z,
                color = {
                    found.color[1],
                    found.color[2],
                    found.color[3],
                    math.floor(found.color[4] * share + 0x1p-1)
                }
            }
        end
        ::__continue31::
    end
    return poses
end
return ____exports
