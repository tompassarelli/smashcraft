local ____exports = {}
local ____world = require("src.game.native.world")
function ____exports.setCameraField(field, value, duration)
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("SetCameraField", {field, value, duration})
    end
    world.view:setCameraField(field, value)
end
function ____exports.setCameraBounds(x1, y1, x2, y2, x3, y3, x4, y4)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("SetCameraBounds", {
            x1,
            y1,
            x2,
            y2,
            x3,
            y3,
            x4,
            y4
        })
    end
end
function ____exports.setCameraPosition(x, y)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("SetCameraPosition", {x, y})
    end
    world.view:setCameraPosition(x, y)
end
function ____exports.panCameraTo(x, y, duration)
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("PanCameraToTimed", {x, y, duration})
    end
end
function ____exports.setCameraSmoothing(factor)
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("CameraSetSmoothingFactor", {factor})
    end
end
function ____exports.cameraField(field)
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("GetCameraField", {field})
    end
    return world.view:cameraField(field)
end
function ____exports.cameraTargetX()
    local world = ____world.boundWorld()
    local ____opt_12 = world.log
    if ____opt_12 ~= nil then
        ____opt_12("GetCameraTargetPositionX", {})
    end
    return world.view:targetX()
end
function ____exports.cameraTargetY()
    local world = ____world.boundWorld()
    local ____opt_14 = world.log
    if ____opt_14 ~= nil then
        ____opt_14("GetCameraTargetPositionY", {})
    end
    return world.view:targetY()
end
function ____exports.cameraTargetZ()
    local world = ____world.boundWorld()
    local ____opt_16 = world.log
    if ____opt_16 ~= nil then
        ____opt_16("GetCameraTargetPositionZ", {})
    end
    return 0
end
function ____exports.cameraEyeX()
    local world = ____world.boundWorld()
    local ____opt_18 = world.log
    if ____opt_18 ~= nil then
        ____opt_18("GetCameraEyePositionX", {})
    end
    return 0
end
function ____exports.cameraEyeY()
    local world = ____world.boundWorld()
    local ____opt_20 = world.log
    if ____opt_20 ~= nil then
        ____opt_20("GetCameraEyePositionY", {})
    end
    return 0
end
function ____exports.cameraEyeZ()
    local world = ____world.boundWorld()
    local ____opt_22 = world.log
    if ____opt_22 ~= nil then
        ____opt_22("GetCameraEyePositionZ", {})
    end
    return 0
end
function ____exports.setTerrainFog(style, start, ____end, density, red, green, blue)
    local world = ____world.boundWorld()
    local ____opt_24 = world.log
    if ____opt_24 ~= nil then
        ____opt_24("SetTerrainFogEx", {
            style,
            start,
            ____end,
            density,
            red,
            green,
            blue
        })
    end
    world.view:setFog(
        style,
        start,
        ____end,
        density,
        red,
        green,
        blue
    )
end
function ____exports.setTerrainFogHeight(style, start, ____end, density, heightStart, heightEnd, linearStart, linearEnd, red, green, blue)
    local world = ____world.boundWorld()
    local ____opt_26 = world.log
    if ____opt_26 ~= nil then
        ____opt_26("SetTerrainFogExV", {
            style,
            start,
            ____end,
            density,
            heightStart,
            heightEnd,
            linearStart,
            linearEnd,
            red,
            green,
            blue
        })
    end
    world.view:setFogHeight(
        style,
        start,
        ____end,
        density,
        heightStart,
        heightEnd,
        linearStart,
        linearEnd,
        red,
        green,
        blue
    )
end
function ____exports.resetTerrainFog()
    local world = ____world.boundWorld()
    local ____opt_28 = world.log
    if ____opt_28 ~= nil then
        ____opt_28("ResetTerrainFog", {})
    end
    world.view:resetFog()
end
function ____exports.setTerrainFogMaxDensity(density)
    local world = ____world.boundWorld()
    local ____opt_30 = world.log
    if ____opt_30 ~= nil then
        ____opt_30("BlzSetTerrainFogMaxLinearDensity", {density})
    end
    world.view.fog.maxLinearDensity = density
end
function ____exports.setTerrainFogOverSky(overSky)
    local world = ____world.boundWorld()
    local ____opt_32 = world.log
    if ____opt_32 ~= nil then
        ____opt_32("BlzSetTerrainFogDrawOverSky", {overSky})
    end
    world.view.fog.drawOverSky = overSky
end
function ____exports.enableFog(enabled)
    local world = ____world.boundWorld()
    local ____opt_34 = world.log
    if ____opt_34 ~= nil then
        ____opt_34("FogEnable", {enabled})
    end
end
function ____exports.enableFogMask(enabled)
    local world = ____world.boundWorld()
    local ____opt_36 = world.log
    if ____opt_36 ~= nil then
        ____opt_36("FogMaskEnable", {enabled})
    end
end
function ____exports.setSkyModel(model)
    local world = ____world.boundWorld()
    local ____opt_38 = world.log
    if ____opt_38 ~= nil then
        ____opt_38("SetSkyModel", {model})
    end
    world.view.environment.sky = model
end
function ____exports.showSky(visible)
    local world = ____world.boundWorld()
    local ____opt_40 = world.log
    if ____opt_40 ~= nil then
        ____opt_40("BlzShowSkyBox", {visible})
    end
    world.view.environment.skyVisible = visible
end
function ____exports.showTerrain(visible)
    local world = ____world.boundWorld()
    local ____opt_42 = world.log
    if ____opt_42 ~= nil then
        ____opt_42("BlzShowTerrain", {visible})
    end
    world.view.environment.terrainVisible = visible
end
function ____exports.setDayNightModels(terrain, units)
    local world = ____world.boundWorld()
    local ____opt_44 = world.log
    if ____opt_44 ~= nil then
        ____opt_44("SetDayNightModels", {terrain, units})
    end
    world.view.environment.dayNight = {terrain = terrain, unit = units}
end
function ____exports.setTimeOfDay(hours)
    local world = ____world.boundWorld()
    local ____opt_46 = world.log
    if ____opt_46 ~= nil then
        ____opt_46("SetTimeOfDay", {hours})
    end
    world.view.environment.timeOfDay = hours
end
function ____exports.setTimeOfDayScale(scale)
    local world = ____world.boundWorld()
    local ____opt_48 = world.log
    if ____opt_48 ~= nil then
        ____opt_48("SetTimeOfDayScale", {scale})
    end
end
function ____exports.setShadowLightCount(count)
    local world = ____world.boundWorld()
    local ____opt_50 = world.log
    if ____opt_50 ~= nil then
        ____opt_50("BlzSetMinShadowCastingPointLightCount", {count})
    end
    world.view.minShadowCastingPointLightCount = count
end
function ____exports.setFilterTexture(texture)
    local world = ____world.boundWorld()
    local ____opt_52 = world.log
    if ____opt_52 ~= nil then
        ____opt_52("SetCineFilterTexture", {texture})
    end
    world.view:setFilterTexture(texture)
end
function ____exports.setFilterBlendMode(mode)
    local world = ____world.boundWorld()
    local ____opt_54 = world.log
    if ____opt_54 ~= nil then
        ____opt_54("SetCineFilterBlendMode", {mode})
    end
    world.view:setFilterBlendMode(mode)
end
function ____exports.setFilterTexMapFlags(flags)
    local world = ____world.boundWorld()
    local ____opt_56 = world.log
    if ____opt_56 ~= nil then
        ____opt_56("SetCineFilterTexMapFlags", {flags})
    end
    world.view:setFilterTexMapFlags(flags)
end
function ____exports.setFilterStartUV(minU, minV, maxU, maxV)
    local world = ____world.boundWorld()
    local ____opt_58 = world.log
    if ____opt_58 ~= nil then
        ____opt_58("SetCineFilterStartUV", {minU, minV, maxU, maxV})
    end
    world.view:setFilterStartUV(minU, minV, maxU, maxV)
end
function ____exports.setFilterEndUV(minU, minV, maxU, maxV)
    local world = ____world.boundWorld()
    local ____opt_60 = world.log
    if ____opt_60 ~= nil then
        ____opt_60("SetCineFilterEndUV", {minU, minV, maxU, maxV})
    end
    world.view:setFilterEndUV(minU, minV, maxU, maxV)
end
function ____exports.setFilterStartColor(red, green, blue, alpha)
    local world = ____world.boundWorld()
    local ____opt_62 = world.log
    if ____opt_62 ~= nil then
        ____opt_62("SetCineFilterStartColor", {red, green, blue, alpha})
    end
    world.view:setFilterStartColor(red, green, blue, alpha)
end
function ____exports.setFilterEndColor(red, green, blue, alpha)
    local world = ____world.boundWorld()
    local ____opt_64 = world.log
    if ____opt_64 ~= nil then
        ____opt_64("SetCineFilterEndColor", {red, green, blue, alpha})
    end
    world.view:setFilterEndColor(red, green, blue, alpha)
end
function ____exports.setFilterDuration(seconds)
    local world = ____world.boundWorld()
    local ____opt_66 = world.log
    if ____opt_66 ~= nil then
        ____opt_66("SetCineFilterDuration", {seconds})
    end
    world.view:setFilterDuration(seconds)
end
function ____exports.showFilter(visible)
    local world = ____world.boundWorld()
    local ____opt_68 = world.log
    if ____opt_68 ~= nil then
        ____opt_68("DisplayCineFilter", {visible})
    end
    world.view:showFilter(visible)
end
return ____exports
