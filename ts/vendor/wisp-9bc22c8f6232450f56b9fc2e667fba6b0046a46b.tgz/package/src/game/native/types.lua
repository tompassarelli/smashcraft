local ____exports = {}
--- The store's view of a handle that the contract names as a Warcraft handle type.
____exports.asHandle = function(value) return value end
--- A handle the store made, returned as the Warcraft handle type the contract names.
____exports.fromHandle = function(handle) return handle end
--- The value a Warcraft player or animation type holds in the emulation: a slot number, or an animation name or number.
____exports.asNumber = function(value) return value end
--- A value the contract names as a Warcraft handle type that the emulation holds as a plain value, such as a player's slot number.
____exports.fromValue = function(value) return value end
____exports.asAnimation = function(value) return value end
return ____exports
