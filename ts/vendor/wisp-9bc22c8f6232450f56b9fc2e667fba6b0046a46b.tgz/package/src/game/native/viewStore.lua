local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__Delete = ____lualib.__TS__Delete
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local ____exports = {}
local ____frameRate = require("src.game.native.frameRate")
local BLEND_MODES = {
    "BLEND_MODE_NONE",
    "BLEND_MODE_DONT_CARE",
    "BLEND_MODE_KEYALPHA",
    "BLEND_MODE_BLEND",
    "BLEND_MODE_ADDITIVE",
    "BLEND_MODE_MODULATE",
    "BLEND_MODE_MODULATE_2X"
}
local CAMERA_FIELDS = {
    "CAMERA_FIELD_TARGET_DISTANCE",
    "CAMERA_FIELD_FARZ",
    "CAMERA_FIELD_ANGLE_OF_ATTACK",
    "CAMERA_FIELD_FIELD_OF_VIEW",
    "CAMERA_FIELD_ROLL",
    "CAMERA_FIELD_ROTATION",
    "CAMERA_FIELD_ZOFFSET",
    "CAMERA_FIELD_NEARZ",
    "CAMERA_FIELD_LOCAL_PITCH",
    "CAMERA_FIELD_LOCAL_YAW",
    "CAMERA_FIELD_LOCAL_ROLL",
    "CAMERA_FIELD_DEPTH_OF_FIELD_DISTANCE",
    "CAMERA_FIELD_DEPTH_OF_FIELD_SCALE",
    "CAMERA_FIELD_ZABSOLUTE"
}
local function cameraFieldName(field)
    if type(field) == "number" then
        return CAMERA_FIELDS[field + 1] or tostring(field)
    end
    return tostring(field)
end
--- What a player sees of the camera, the fog, the sky and the cinematic filter. Calls that set a mode with no look of their own (camera bounds and smoothing, a pan, fog and fog-mask switches, the time-of-day rate) are logged by the family module and kept nowhere.
____exports.View = __TS__Class()
local View = ____exports.View
View.name = "View"
function View.prototype.____constructor(self, frame)
    self.frame = frame
    self.fog = {}
    self.environment = {
        sky = "",
        skyVisible = true,
        terrainVisible = true,
        dayNight = {terrain = "", unit = ""},
        timeOfDay = 12
    }
    self.minShadowCastingPointLightCount = 0
    self.cameraX = 0
    self.cameraY = 0
    self.cameraFields = {}
    self.cineFilter = {
        texture = "",
        blendMode = "BLEND_MODE_NONE",
        texMapFlags = nil,
        startColor = {255, 255, 255, 255},
        endColor = {255, 255, 255, 255},
        startUV = {0, 0, 1, 1},
        endUV = {0, 0, 1, 1},
        duration = 0,
        shown = nil
    }
end
function View.prototype.cineFilterPose(self)
    local filter = self.cineFilter
    if filter.shown == nil then
        return nil
    end
    local share = filter.duration <= 0 and 1 or math.min(
        1,
        (self.frame() - filter.shown) / ____frameRate.FRAMES_PER_SECOND / filter.duration
    )
    local function mix(from, to)
        return __TS__ArrayMap(
            {0, 1, 2, 3},
            function(____, i) return (from[i + 1] or 0) + ((to[i + 1] or 0) - (from[i + 1] or 0)) * share end
        )
    end
    return {
        texture = filter.texture,
        blendMode = filter.blendMode,
        texMapFlags = filter.texMapFlags,
        color = mix(filter.startColor, filter.endColor),
        uv = mix(filter.startUV, filter.endUV)
    }
end
function View.prototype.cameraPose(self)
    return {
        x = self.cameraX,
        y = self.cameraY,
        fields = __TS__ObjectAssign({}, self.cameraFields)
    }
end
function View.prototype.setCameraPosition(self, x, y)
    self.cameraX = x
    self.cameraY = y
end
function View.prototype.targetX(self)
    return self.cameraX
end
function View.prototype.targetY(self)
    return self.cameraY
end
function View.prototype.setCameraField(self, field, value)
    self.cameraFields[cameraFieldName(field)] = value
end
function View.prototype.cameraField(self, field)
    return self.cameraFields[cameraFieldName(field)] or 0
end
function View.prototype.setFog(self, style, start, ____end, density, red, green, blue)
    self.fog.style = style
    self.fog.zStart = start
    self.fog.zEnd = ____end
    self.fog.density = density
    self.fog.color = {red, green, blue}
end
function View.prototype.setFogHeight(self, style, start, ____end, density, heightStart, heightEnd, linearStart, linearEnd, red, green, blue)
    self.fog.style = style
    self.fog.zStart = start
    self.fog.zEnd = ____end
    self.fog.density = density
    self.fog.heightStart = heightStart
    self.fog.heightEnd = heightEnd
    self.fog.linearStart = linearStart
    self.fog.linearEnd = linearEnd
    self.fog.color = {red, green, blue}
end
function View.prototype.resetFog(self)
    for ____, field in ipairs(__TS__ObjectKeys(self.fog)) do
        __TS__Delete(self.fog, field)
    end
end
function View.prototype.setFilterTexture(self, texture)
    self.cineFilter.texture = texture
end
function View.prototype.setFilterBlendMode(self, mode)
    self.cineFilter.blendMode = type(mode) == "number" and (BLEND_MODES[mode + 1] or "BLEND_MODE_NONE") or tostring(mode)
end
function View.prototype.setFilterTexMapFlags(self, flags)
    self.cineFilter.texMapFlags = flags
end
function View.prototype.setFilterStartUV(self, minU, minV, maxU, maxV)
    self.cineFilter.startUV = {minU, minV, maxU, maxV}
end
function View.prototype.setFilterEndUV(self, minU, minV, maxU, maxV)
    self.cineFilter.endUV = {minU, minV, maxU, maxV}
end
function View.prototype.setFilterStartColor(self, red, green, blue, alpha)
    self.cineFilter.startColor = {red, green, blue, alpha}
end
function View.prototype.setFilterEndColor(self, red, green, blue, alpha)
    self.cineFilter.endColor = {red, green, blue, alpha}
end
function View.prototype.setFilterDuration(self, duration)
    self.cineFilter.duration = duration
end
function View.prototype.showFilter(self, visible)
    self.cineFilter.shown = visible and self.frame() or nil
end
function View.prototype.filterShown(self)
    return self.cineFilter.shown ~= nil
end
return ____exports
