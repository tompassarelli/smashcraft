/** @noSelfInFile */
import { type AnimationState } from "./animation";
import type { FrameTemplate } from "./frames";
import type { NativeDeclarations } from "./declarations";
import { type Frame, Frames } from "./frames";
import { Warcraft3Abilities, type AbilityObjectFixtures } from "./warcraft3Abilities";
import { Scenery, type SceneryFixtures } from "./warcraft3Scenery";
import { TextTags } from "./textTags";
import { Lightnings } from "./lightnings";
import { Warcraft3Inventory, type Warcraft3InventoryFixtures } from "./warcraft3Inventory";
export type Handle = {
    readonly kind: string;
    readonly id: number;
};
export interface NativeCall {
    readonly name: string;
    readonly args: readonly unknown[];
}
export interface SyncMessage {
    readonly sender: number;
    readonly prefix: string;
    readonly data: string;
}
export interface MapEntry {
    start(this: void): void;
    install(this: void): void;
}
export type LocalNatives = Readonly<Record<string, string>>;
export type IntentionalNoops = Readonly<Record<string, string>>;
export interface MissingNative {
    readonly native: string;
    readonly client: number;
    readonly frame: number;
}
export type NativeBehavior = (this: void, ...args: never[]) => unknown;
export type NativeBehaviors = Readonly<Record<string, unknown>>;
export declare const WISP_LOCAL_NATIVES: LocalNatives;
export interface EffectPose extends AnimationState {
    readonly handle: Handle;
    readonly model: string;
    readonly created: number;
    x: number;
    y: number;
    z: number;
    alpha: number;
    scale: number;
    timeScale: number;
    queuedAnimations: string[];
    yaw: number;
    pitch: number;
    roll: number;
    color: [number, number, number];
    teamColor: number;
    matrixScale: [number, number, number];
    flat: boolean;
    destroyed?: number;
    death?: number;
}
export type EffectDeaths = (this: void, model: string) => number | undefined;
export interface CineFilterPose {
    readonly texture: string;
    readonly blendMode: string;
    readonly texMapFlags: unknown;
    readonly color: readonly [number, number, number, number];
    readonly uv: readonly [number, number, number, number];
}
export interface CameraPose {
    readonly x: number;
    readonly y: number;
    readonly fields: Readonly<Record<string, number>>;
}
export interface SoundCue {
    readonly event: "create" | "start" | "stop" | "volume";
    readonly kind: "sound" | "music";
    readonly frame: number;
    readonly handle: Handle;
    readonly source: string | undefined;
    readonly label: string | undefined;
    readonly volume: number;
    readonly effectiveVolume: number;
    readonly looping: boolean;
    readonly pitch: number;
    readonly x: number;
    readonly y: number;
    readonly z: number;
}
export declare function assertSoundCue(log: readonly SoundCue[], expected: {
    readonly source?: string;
    readonly label?: string;
    readonly frame?: number;
    readonly count?: number;
}): void;
export interface UnitPose extends AnimationState {
    readonly handle: Handle;
    readonly typeId: number;
    owner: number;
    x: number;
    y: number;
    z: number;
    facing: number;
    scale: [number, number, number];
    alpha: number;
    color: [number, number, number];
    teamColor: number;
    timeScale: number;
    visible: boolean;
}
export interface UnitStateFixture {
    readonly life: number;
    readonly maxLife: number;
    readonly mana: number;
    readonly maxMana: number;
}
export type UnitStateFixtures = Readonly<Record<number, UnitStateFixture>>;
export interface ClientFiles {
    written(this: void, name: string, lines: readonly string[]): void;
    read(this: void, name: string): readonly string[] | undefined;
}
export interface ClientScope {
    enter(this: void, client: HeadlessClient): void;
    leave(this: void, client: HeadlessClient): void;
}
export interface ClientOptions {
    readonly abilityObjects?: AbilityObjectFixtures;
    readonly unitStates?: UnitStateFixtures;
    readonly scenery?: SceneryFixtures;
    readonly inventory?: Warcraft3InventoryFixtures;
    readonly slot: number;
    readonly filePrefix: string;
    readonly humans: readonly number[];
    readonly playerNames?: Readonly<Record<number, string>>;
    readonly declarations: NativeDeclarations;
    readonly localNatives: LocalNatives;
    readonly intentionalNoops?: IntentionalNoops;
    readonly network: SyncMessage[];
    readonly screenWidth: number;
    readonly scope?: ClientScope;
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly files?: ClientFiles;
    readonly frames?: readonly FrameTemplate[];
    readonly effectDeaths?: EffectDeaths;
    readonly musicSlider?: number;
    /** Whole milliseconds of game time per engine step when effect clocks advance once per step (25 on the 3.0.0 offline LAN pool); unset, once per frame. */
    readonly effectStepMs?: number;
}
export declare const FRAMES_PER_SECOND = 60;
export declare function describeNumber(value: number): string;
export declare function describeValue(value: unknown): string;
export declare function describeCall({ name, args }: NativeCall): string;
export declare function sameCall(left: NativeCall, right: NativeCall): boolean;
export declare class HeadlessClient {
    readonly scenery: Scenery;
    readonly inventory: Warcraft3Inventory;
    readonly abilities: Warcraft3Abilities;
    readonly textTags: TextTags;
    readonly lightnings: Lightnings;
    readonly textAreaAutoScroll: Map<Handle, boolean>;
    readonly heldMouseButtons: Set<unknown>;
    mouseScreenX: number;
    mouseScreenY: number;
    private heldMeta;
    readonly slot: number;
    readonly log: NativeCall[];
    forgotten: number;
    private forgottenHash;
    readonly errors: string[];
    readonly missingNatives: MissingNative[];
    readonly messages: string[];
    readonly thrown: string[];
    readonly files: Map<string, string[]>;
    readonly published: Map<string, readonly string[]>;
    missedLookups: number;
    readonly natives: Record<string, unknown>;
    frame: number;
    private wallSeconds;
    clockSeconds(): number;
    setWallTime(seconds: number): void;
    private nextId;
    private readonly scope;
    private readonly filePrefix;
    private readonly timers;
    private readonly spellHits;
    private readonly passiveAlliances;
    private timerOrder;
    private now;
    private readonly registrations;
    private readonly heldKeys;
    private readonly memo;
    private allPlayers;
    private readonly effects;
    private readonly effectDeaths;
    private readonly effectStepMs;
    private readonly musicSlider;
    private readonly units;
    private removals;
    private readonly unitStates;
    private readonly sounds;
    private readonly locations;
    private readonly groups;
    liveHandleCounts(): {
        readonly locations: number;
        readonly groups: number;
    };
    readonly soundLog: SoundCue[];
    private music;
    private musicVolume;
    private cameraX;
    private cameraY;
    private readonly cameraFields;
    private readonly cineFilter;
    private readonly tooltips;
    /** Preloader runs the content it first read from a path for the rest of the session. */
    private readonly preloaded;
    private event;
    private preload;
    private readonly stored;
    readonly frames: Frames;
    constructor(options: ClientOptions);
    private handle;
    private defaultNative;
    private defaultValue;
    private memoized;
    private created;
    private effectAt;
    private unitAt;
    private unitValue;
    private setLife;
    private unitAnimation;
    private sound;
    private cue;
    private stopAudio;
    private playMusic;
    private startSound;
    private cameraField;
    private liveEffect;
    private destroyEffect;
    private playEffect;
    private show;
    private report;
    private behaviors;
    preloadedFiles(): string[];
    effectPoses(options?: {
        readonly visibleOnly?: boolean;
    }): EffectPose[];
    cineFilterPose(): CineFilterPose | undefined;
    cameraPose(): CameraPose;
    unitPoses(): UnitPose[];
    run(body: (this: void) => void): void;
    private fire;
    step(draw?: boolean): void;
    draw(seconds: number): void;
    /** Engine steps end every `ms` of game time, after the callbacks due by then; frame n runs those ending in [(n - 1)/60, n/60) s first. */
    private stepEffects;
    private timerElapsed;
    private runDueTimers;
    deliverSync({ sender, prefix, data }: SyncMessage): void;
    chat(sender: number, message: string): void;
    key(sender: number, key: number, meta: number, down: boolean): void;
    hold(key: number, meta: number, down: boolean): void;
    keyEvent(sender: number, key: number, meta: number, down: boolean): void;
    type(text: string): boolean;
    clickTarget(x: number, y: number): Frame | undefined;
    frameEvent(sender: number, id: number, event: unknown): void;
    callCount(): number;
    forget(count: number): void;
    checksum(): string;
}
