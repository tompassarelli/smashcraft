import { Duration, Effect, Exit, Fiber, FileSystem, Option, Schedule, Scope, Stream } from "effect";
import { ChildProcess } from "effect/process";

export interface LogFiles {
  readonly stdout: string;
  readonly stderr: string;
}

export const spawnLogged = (command: ChildProcess.Command, files: LogFiles) => Effect.gen(function*() {
  const fs = yield* FileSystem.FileSystem;
  const childScope = yield* Scope.fork(yield* Effect.scope);
  const handle = yield* command.pipe(Scope.provide(childScope));
  const stdout = yield* Effect.forkScoped(Stream.run(handle.stdout, fs.sink(files.stdout)));
  const stderr = yield* Effect.forkScoped(Stream.run(handle.stderr, fs.sink(files.stderr)));
  const written = Effect.all([Fiber.await(stdout), Fiber.await(stderr)], { discard: true });

  yield* Effect.addFinalizer(() => Scope.close(childScope, Exit.void).pipe(Effect.andThen(written)));
  return { handle, written };
});

export interface Collected {
  readonly exitCode: number;
  readonly stdout: Uint8Array;
  readonly stderr: string;
}

export const collect = (command: ChildProcess.Command) => Effect.scoped(Effect.gen(function*() {
  const handle = yield* command;
  const [chunks, stderr, exitCode] = yield* Effect.all([
    Stream.runCollect(handle.stdout),
    Stream.mkString(Stream.decodeText(handle.stderr)),
    handle.exitCode,
  ], { concurrency: "unbounded" });
  const stdout = new Uint8Array(chunks.reduce((length, chunk) => length + chunk.length, 0));
  let at = 0;
  for (const chunk of chunks) {
    stdout.set(chunk, at);
    at += chunk.length;
    chunk.fill(0);
  }
  return { exitCode, stdout, stderr } satisfies Collected;
}));

/** Runs `check` every `every` until `until` holds; after `within` it stops and runs `onTimeout` instead. */
export const pollUntil = <A, E, R, A2, E2, R2>(check: Effect.Effect<A, E, R>, options: {
  readonly until: (value: A) => boolean;
  readonly every: Duration.Input;
  readonly within: Duration.Input;
  readonly onTimeout: () => Effect.Effect<A2, E2, R2>;
}): Effect.Effect<A | A2, E | E2, R | R2> =>
  check.pipe(
    Effect.repeat({ schedule: Schedule.spaced(options.every), until: options.until }),
    Effect.timeoutOrElse({ duration: options.within, orElse: options.onTimeout }),
  );

export const pollFor = <A, E, R>(seconds: number, every: Duration.Input, check: Effect.Effect<A | undefined, E, R>): Effect.Effect<A | undefined, E, R> =>
  check.pipe(
    Effect.repeat({ schedule: Schedule.spaced(every), until: (value) => value !== undefined }),
    Effect.timeoutOption(Duration.seconds(seconds)),
    Effect.map(Option.getOrUndefined),
  );
