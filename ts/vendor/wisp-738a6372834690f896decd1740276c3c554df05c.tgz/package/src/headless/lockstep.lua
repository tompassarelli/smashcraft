local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local ____modules = require("src.runtime.modules")
local ____client = require("src.headless.client")
local function typedKey(code)
    if code >= 97 and code <= 122 then
        return {code - 32, 0}
    end
    if code >= 65 and code <= 90 then
        return {code, 1}
    end
    if code >= 48 and code <= 57 or code == 32 then
        return {code, 0}
    end
    return nil
end
local MAX_MESSAGES_PER_FLUSH = 10000
____exports.Lockstep = __TS__Class()
local Lockstep = ____exports.Lockstep
Lockstep.name = "Lockstep"
function Lockstep.prototype.____constructor(self, options)
    self.network = {}
    self.frame = 0
    self.version = 0
    self.files = nil
    self.inFlight = {}
    self.costs = {}
    self.inFrame = false
    self.options = options
    self.publisher = __TS__New(____modules.ModulePublisher, options.filePrefix, options.hash)
    local localNatives = __TS__ObjectAssign({}, ____client.WISP_LOCAL_NATIVES, options.localNatives)
    local clients = {}
    do
        local index = 0
        while index < #options.players do
            local slot = options.players[index + 1] or index
            local ____opt_0 = options.files
            local files = ____opt_0 and ____opt_0(slot)
            clients[#clients + 1] = __TS__New(
                ____client.HeadlessClient,
                __TS__ObjectAssign(
                    {slot = slot, filePrefix = options.filePrefix, humans = options.humans or options.players},
                    options.playerNames == nil and ({}) or ({playerNames = options.playerNames}),
                    {declarations = options.declarations, localNatives = localNatives},
                    options.intentionalNoops == nil and ({}) or ({intentionalNoops = options.intentionalNoops}),
                    {network = self.network, screenWidth = 1920 + 640 * index},
                    options.scope == nil and ({}) or ({scope = options.scope}),
                    options.natives == nil and ({}) or ({natives = options.natives}),
                    files == nil and ({}) or ({files = files}),
                    options.frames == nil and ({}) or ({frames = options.frames}),
                    options.unitStates == nil and ({}) or ({unitStates = options.unitStates}),
                    options.abilityObjects == nil and ({}) or ({abilityObjects = options.abilityObjects}),
                    options.scenery == nil and ({}) or ({scenery = options.scenery}),
                    options.inventory == nil and ({}) or ({inventory = options.inventory}),
                    options.effectDeaths == nil and ({}) or ({effectDeaths = options.effectDeaths}),
                    options.musicSlider == nil and ({}) or ({musicSlider = options.musicSlider}),
                    options.effectStepMs == nil and ({}) or ({effectStepMs = options.effectStepMs})
                )
            )
            index = index + 1
        end
    end
    self.clients = clients
end
function Lockstep.prototype.start(self, options)
    if options == nil then
        options = {}
    end
    if options.hostFolder ~= false then
        self:prepareHostFolder()
    end
    local entry = self.options.entry
    for ____, client in ipairs(self.clients) do
        client:run(function() return entry(client).start() end)
    end
    self:flush()
end
function Lockstep.prototype.everywhere(self, body)
    for ____, client in ipairs(self.clients) do
        client:run(body)
    end
    self:flush()
end
function Lockstep.prototype.flush(self)
    if self.options.link ~= nil then
        do
            local message = table.remove(self.network, 1)
            while message ~= nil do
                self:send({sender = message.sender, kind = "sync", prefix = message.prefix, data = message.data})
                message = table.remove(self.network, 1)
            end
        end
        return
    end
    local delivery = self.options.delivery
    if delivery ~= nil then
        do
            local message = table.remove(self.network, 1)
            while message ~= nil do
                local arrival = delivery.arrivalFrame(message.sender, self.frame, message)
                if arrival <= self.frame then
                    do
                        local ____thrown = __TS__New(
                            Error,
                            (("a message sent during frame " .. tostring(self.frame)) .. " arrives at frame ") .. tostring(arrival)
                        )
                        if _G.__wispThrown ~= ____thrown then
                            _G.__wispThrown = ____thrown
                            _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:193"
                        end
                        error(____thrown, 0)
                    end
                end
                local index = #self.inFlight
                while true do
                    local ____temp_4 = index > 0
                    if ____temp_4 then
                        local ____opt_2 = self.inFlight[index]
                        ____temp_4 = (____opt_2 and ____opt_2.arrival or 0) > arrival
                    end
                    if not ____temp_4 then
                        break
                    end
                    index = index - 1
                end
                __TS__ArraySplice(self.inFlight, index, 0, {arrival = arrival, message = message})
                message = table.remove(self.network, 1)
            end
        end
        return
    end
    do
        local delivered = 0
        while #self.network > 0 do
            if delivered > MAX_MESSAGES_PER_FLUSH then
                do
                    local ____thrown = __TS__New(Error, "synchronized messages never settle")
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:201"
                    end
                    error(____thrown, 0)
                end
            end
            local message = table.remove(self.network, 1)
            if message ~= nil then
                for ____, client in ipairs(self.clients) do
                    client:deliverSync(message)
                end
            end
            delivered = delivered + 1
        end
    end
end
function Lockstep.prototype.send(self, event)
    local link = self.options.link
    if link ~= nil then
        link.sent(self.frame + link.delay + (self.inFrame and 0 or 1), event)
    end
end
function Lockstep.prototype.apply(self, client, event)
    if event.kind == "sync" then
        client:deliverSync({sender = event.sender, prefix = event.prefix, data = event.data})
    elseif event.kind == "key" then
        client:keyEvent(event.sender, event.key, event.meta, event.down)
    elseif event.kind == "chat" then
        client:chat(event.sender, event.text)
    else
        client:frameEvent(event.sender, event.frame, client.natives.FRAMEEVENT_CONTROL_CLICK)
    end
end
function Lockstep.prototype.arrive(self)
    local link = self.options.link
    if link ~= nil then
        for ____, event in ipairs(link.due(self.frame)) do
            do
                local index = 0
                while index < #self.clients do
                    do
                        local client = self.clients[index + 1]
                        if client == nil then
                            goto __continue43
                        end
                        local ____opt_5 = self.options.cost
                        local started = ____opt_5 and ____opt_5()
                        self:apply(client, event)
                        self:charge(index, started)
                    end
                    ::__continue43::
                    index = index + 1
                end
            end
        end
        self:flush()
        return
    end
    while true do
        local ____opt_11 = self.inFlight[1]
        if not ((____opt_11 and ____opt_11.arrival or self.frame + 1) <= self.frame) then
            break
        end
        do
            local due = table.remove(self.inFlight, 1)
            if due == nil then
                goto __continue46
            end
            do
                local index = 0
                while index < #self.clients do
                    local ____opt_7 = self.options.cost
                    local started = ____opt_7 and ____opt_7()
                    local ____opt_9 = self.clients[index + 1]
                    if ____opt_9 ~= nil then
                        ____opt_9:deliverSync(due.message)
                    end
                    self:charge(index, started)
                    index = index + 1
                end
            end
        end
        ::__continue46::
    end
    self:flush()
end
function Lockstep.prototype.frames(self, count, options)
    if options == nil then
        options = {}
    end
    do
        local frame = 0
        while frame < count do
            self.frame = self.frame + 1
            self.inFrame = true
            do
                local index = 0
                while index < #self.clients do
                    self.costs[index + 1] = 0
                    index = index + 1
                end
            end
            self:arrive()
            do
                local index = 0
                while index < #self.clients do
                    local ____opt_13 = self.options.cost
                    local started = ____opt_13 and ____opt_13()
                    local ____opt_15 = self.clients[index + 1]
                    if ____opt_15 ~= nil then
                        local ____opt_15_step_17 = ____opt_15.step
                        local ____options_draw_16 = options.draw
                        if ____options_draw_16 == nil then
                            ____options_draw_16 = true
                        end
                        ____opt_15_step_17(____opt_15, ____options_draw_16)
                    end
                    self:charge(index, started)
                    index = index + 1
                end
            end
            self:flush()
            self.inFrame = false
            self:settle()
            frame = frame + 1
        end
    end
end
function Lockstep.prototype.charge(self, index, started)
    local clock = self.options.cost
    if clock ~= nil and started ~= nil then
        self.costs[index + 1] = (self.costs[index + 1] or 0) + clock() - started
    end
end
function Lockstep.prototype.settle(self)
    local keep = self.options.keepCalls
    if keep == nil then
        return
    end
    if self.divergence == nil then
        local divergence = self:compare()
        if divergence ~= nil then
            self.divergence = (("after frame " .. tostring(self.frame)) .. ", ") .. divergence
        end
    end
    for ____, client in ipairs(self.clients) do
        if #client.log > keep then
            client:forget(#client.log - keep)
        end
    end
end
function Lockstep.prototype.chat(self, sender, message)
    if self.options.link ~= nil then
        return self:send({sender = sender, kind = "chat", text = message})
    end
    for ____, client in ipairs(self.clients) do
        client:chat(sender, message)
    end
    self:flush()
end
function Lockstep.prototype.press(self, sender, key, meta)
    if meta == nil then
        meta = 0
    end
    for ____, down in ipairs({true, false}) do
        self:key(sender, key, meta, down)
    end
end
function Lockstep.prototype.key(self, sender, key, meta, down)
    if self.options.link ~= nil then
        for ____, client in ipairs(self.clients) do
            if client.slot == sender then
                client:hold(key, meta, down)
            end
        end
        return self:send({
            sender = sender,
            kind = "key",
            key = key,
            meta = meta,
            down = down
        })
    end
    for ____, client in ipairs(self.clients) do
        client:key(sender, key, meta, down)
    end
    self:flush()
end
function Lockstep.prototype.client(self, slot)
    for ____, client in ipairs(self.clients) do
        if client.slot == slot then
            return client
        end
    end
    do
        local ____thrown = __TS__New(
            Error,
            "no client plays slot " .. tostring(slot)
        )
        if _G.__wispThrown ~= ____thrown then
            _G.__wispThrown = ____thrown
            _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:310"
        end
        error(____thrown, 0)
    end
end
function Lockstep.prototype.type(self, sender, text)
    if self:client(sender):type(text) then
        return
    end
    do
        local index = 0
        while index < #text do
            local key = typedKey(__TS__StringCharCodeAt(text, index))
            if key == nil then
                do
                    local ____thrown = __TS__New(
                        Error,
                        ("no key types \"" .. __TS__StringCharAt(text, index)) .. "\" outside an edit box"
                    )
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:322"
                    end
                    error(____thrown, 0)
                end
            end
            self:press(sender, key[1], key[2])
            index = index + 1
        end
    end
end
function Lockstep.prototype.click(self, sender, x, y)
    local clicker = self:client(sender)
    local frame = clicker:clickTarget(x, y)
    if frame == nil then
        return false
    end
    clicker.frames:focus(frame, true)
    if self.options.link ~= nil then
        self:send({sender = sender, kind = "click", frame = frame.id})
        return true
    end
    local click = clicker.natives.FRAMEEVENT_CONTROL_CLICK
    for ____, client in ipairs(self.clients) do
        client:frameEvent(sender, frame.id, click)
    end
    self:flush()
    return true
end
function Lockstep.prototype.publish(self, name, chunks)
    for ____, client in ipairs(self.clients) do
        client.published:set(name, chunks)
    end
end
function Lockstep.prototype.prepareHostFolder(self)
    for ____, client in ipairs(self.clients) do
        client.published:set(
            ____gameFiles.hostFile(self.options.filePrefix),
            {"host"}
        )
    end
end
function Lockstep.prototype.reload(self, modules)
    if modules == nil then
        modules = self.options.modules
    end
    self:prepareHostFolder()
    local previous = self.files
    if previous ~= nil and #self:unappliedReloads() == 0 then
        self.publisher:installed(previous.published)
    end
    self.version = self.version + 1
    local files = self.publisher:files(self.version, modules)
    for ____, ____value in ipairs(files.payloads) do
        local name = ____value[1]
        local text = ____value[2]
        self:publish(name, {text})
    end
    self:publish(
        ____gameFiles.manifestFile(self.version, self.options.filePrefix),
        {____gameFiles.formatManifest(files.manifest)}
    )
    self.files = files
    return self.version
end
function Lockstep.prototype.unappliedReloads(self)
    if self.version == 0 then
        return {}
    end
    local problems = {}
    for ____, client in ipairs(self.clients) do
        do
            local ____opt_19 = client.files:get(____gameFiles.ackFile(client.slot, self.options.filePrefix))
            local acknowledgement = ____opt_19 and ____opt_19[1] or ""
            if __TS__StringStartsWith(
                acknowledgement,
                ("applied " .. tostring(self.version)) .. " at "
            ) then
                goto __continue106
            end
            local reason = "no answer yet"
            for ____, message in ipairs(client.messages) do
                if __TS__StringStartsWith(
                    message,
                    ("hot reload " .. tostring(self.version)) .. " not applied"
                ) then
                    reason = message
                end
            end
            problems[#problems + 1] = (((("p" .. tostring(client.slot)) .. ": hot reload ") .. tostring(self.version)) .. " not running: ") .. reason
        end
        ::__continue106::
    end
    return problems
end
function Lockstep.prototype.firstDivergence(self)
    return self.divergence or self:compare()
end
function Lockstep.prototype.compare(self)
    local first = self.clients[1]
    if first == nil then
        return nil
    end
    do
        local other = 1
        while other < #self.clients do
            do
                local client = self.clients[other + 1]
                if client == nil then
                    goto __continue116
                end
                local length = math.max(#first.log, #client.log)
                do
                    local index = 0
                    local ____index_21 = index
                    local ____firstIteration_22 = true
                    while true do
                        local index = ____index_21
                        if not ____firstIteration_22 then
                            index = index + 1
                        end
                        ____firstIteration_22 = false
                        if not (index < length) then
                            break
                        end
                        do
                            local left = first.log[index + 1]
                            local right = client.log[index + 1]
                            if left ~= nil and right ~= nil and ____client.sameCall(left, right) then
                                goto __continue119
                            end
                            local function context(log)
                                local lines = {}
                                do
                                    local at = math.max(0, index - 4)
                                    while at < math.min(#log, index + 2) do
                                        local call = log[at + 1]
                                        if call ~= nil then
                                            lines[#lines + 1] = ____client.describeCall(call)
                                        end
                                        at = at + 1
                                    end
                                end
                                return table.concat(lines, "\n    ")
                            end
                            return (((((((((((("call " .. tostring(first.forgotten + index)) .. " differs between slot ") .. tostring(first.slot)) .. " and slot ") .. tostring(client.slot)) .. ":\n  slot ") .. tostring(first.slot)) .. ":\n    ") .. context(first.log)) .. "\n  slot ") .. tostring(client.slot)) .. ":\n    ") .. context(client.log)
                        end
                        ::__continue119::
                        ____index_21 = index
                    end
                end
            end
            ::__continue116::
            other = other + 1
        end
    end
    return nil
end
return ____exports
