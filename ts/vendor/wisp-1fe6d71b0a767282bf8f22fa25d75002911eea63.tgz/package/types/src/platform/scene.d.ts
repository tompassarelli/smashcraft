/** @noSelfInFile */
export interface SceneOptions {
    /** The game's frame counter. It should stand still while nothing plays, such as during a pause. */
    readonly frame: (this: void) => number;
    /**
     * Whether a point is where the game parks hidden effects, which no camera
     * sees. Warcraft keeps a model's particle emitters running at any alpha,
     * scale or time scale, so only an effect parked there is out of view.
     */
    readonly parked: (this: void, x: number, y: number, z: number) => boolean;
}
/** Registers the report's handler; a reloaded bundle calls this again. */
export declare function installSceneReport(): void;
/**
 * Starts recording and, every half second of game time, observing and
 * reporting. Call once, after configureRuntime and before the map creates an
 * effect.
 */
export declare function startSceneReport(options: SceneOptions): void;
