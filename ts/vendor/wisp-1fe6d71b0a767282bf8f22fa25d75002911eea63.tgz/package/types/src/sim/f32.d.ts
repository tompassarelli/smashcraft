/** @noSelfInFile */
export declare function f32(value: number): number;
