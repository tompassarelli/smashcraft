/** @noSelfInFile */
import { type Journey } from "./journey";
import { type LuaHeadlessMap } from "./lua";
/** Instructions between the hook's counts: each run of a client counts its instructions rounded down to a multiple of this. */
export declare const HOOK_STEP = 100;
/**
 * Plays `journey` with the bundle and declarations at these paths, measuring
 * every client's frames, prints the result as `wisp perf` reads it and
 * returns how many problems the journey found.
 */
export declare function runLuaPerf(map: LuaHeadlessMap, journey: Journey, bundlePath: string, declarationsPath: string): number;
