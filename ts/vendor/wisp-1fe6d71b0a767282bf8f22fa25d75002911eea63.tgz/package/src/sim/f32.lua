local ____exports = {}
function ____exports.f32(value)
    return value
end
return ____exports
