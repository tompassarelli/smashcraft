local ____lualib = require("lualib_bundle")
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____declarations = require("src.headless.declarations")
local parseNativeDeclarations = ____declarations.parseNativeDeclarations
local ____journey = require("src.headless.journey")
local journeyLines = ____journey.journeyLines
local journeyProblems = ____journey.journeyProblems
local runJourney = ____journey.runJourney
local ____lua = require("src.headless.lua")
local luaLockstep = ____lua.luaLockstep
local readFile = ____lua.readFile
local ____frameCost = require("src.runtime.frameCost")
local spread = ____frameCost.spread
--- Instructions between the hook's counts: each run of a client counts its instructions rounded down to a multiple of this.
____exports.HOOK_STEP = 100
local serve
--- Runs the native it is resumed with on the arguments after it, yields the
-- result and serves the next call it is resumed with; tail calls keep it one
-- frame deep. Varargs pass every argument, nil ones included.
serve = function(...)
    local native = select(1, ...)
    return serve(coroutine.yield(native(select(2, ...))))
end
local function nativeThread()
    return coroutine.create(function(...)
        debug.sethook()
        return serve(...)
    end)
end
local function add(values, index, amount)
    values[index + 1] = (values[index + 1] or 0) + amount
end
--- A value to the nearest whole number: binary32 has too few digits for a frame's hundredths of a million instructions.
local function whole(value)
    return tostring(math.floor(value + 0.5))
end
local function costLines(cost, frames)
    local lines = {}
    local named = {{"instructions", cost.instructions}, {"lua-us", cost.microseconds}, {"natives", cost.natives}}
    for ____, ____value in ipairs(named) do
        local name = ____value[1]
        local values = ____value[2]
        local perFrame = {}
        local total = 0
        do
            local frame = 1
            while frame <= frames do
                local value = values[frame + 1] or 0
                perFrame[#perFrame + 1] = value
                total = total + value
                frame = frame + 1
            end
        end
        local ____spread_result_0 = spread(perFrame, #perFrame)
        local median = ____spread_result_0.median
        local mean = ____spread_result_0.mean
        local max = ____spread_result_0.max
        lines[#lines + 1] = (((((((((((("p" .. tostring(cost.slot)) .. " ") .. name) .. " start=") .. whole(values[1] or 0)) .. " total=") .. whole(total)) .. " median=") .. whole(median)) .. " mean=") .. whole(mean)) .. " max=") .. whole(max)
    end
    return lines
end
--- Plays `journey` with the bundle and declarations at these paths, measuring
-- every client's frames, prints the result as `wisp perf` reads it and
-- returns how many problems the journey found.
function ____exports.runLuaPerf(map, journey, bundlePath, declarationsPath)
    local declarations = readFile(declarationsPath)
    local costs = __TS__New(Map)
    local fired = 0
    local function count()
        fired = fired + 1
    end
    local nativeSeconds = 0
    local depth = 0
    local thread = nativeThread()
    local entered = {fired = 0, seconds = 0, natives = 0, calls = 0}
    local clients
    local scope = {
        enter = function(client)
            debug.sethook(count, "", ____exports.HOOK_STEP)
            local ____fired_3 = fired
            local ____os_clock_result_4 = os.clock()
            local ____nativeSeconds_5 = nativeSeconds
            local ____opt_1 = costs:get(client)
            entered = {fired = ____fired_3, seconds = ____os_clock_result_4, natives = ____nativeSeconds_5, calls = ____opt_1 and ____opt_1.calls or 0}
        end,
        leave = function(client)
            debug.sethook()
            local cost = costs:get(client)
            if cost == nil then
                return
            end
            local frame = clients and clients.frame or 0
            add(cost.instructions, frame, (fired - entered.fired) * ____exports.HOOK_STEP)
            add(
                cost.microseconds,
                frame,
                (os.clock() - entered.seconds - (nativeSeconds - entered.natives)) * 1000000
            )
            add(cost.natives, frame, cost.calls - entered.calls)
        end
    }
    local function counted(cost, native)
        return function(...)
            cost.calls = cost.calls + 1
            if depth > 0 then
                return native(...)
            end
            depth = depth + 1
            local started = os.clock()
            local ran, result = coroutine.resume(thread, native, ...)
            nativeSeconds = nativeSeconds + (os.clock() - started)
            depth = depth - 1
            if not ran then
                thread = nativeThread()
                error(result, 0)
            end
            return result
        end
    end
    local lockstep = luaLockstep(
        map,
        readFile(bundlePath),
        declarations,
        scope
    )
    clients = lockstep
    local names = __TS__ArrayMap(
        parseNativeDeclarations(declarations).functions,
        function(____, ____bindingPattern0)
            local name
            name = ____bindingPattern0[1]
            return name
        end
    )
    for ____, client in ipairs(lockstep.clients) do
        local cost = {
            slot = client.slot,
            instructions = {},
            microseconds = {},
            natives = {},
            calls = 0
        }
        costs:set(client, cost)
        for ____, name in ipairs(names) do
            local native = client.natives[name]
            if type(native) == "function" then
                client.natives[name] = counted(cost, native)
            end
        end
    end
    local result
    do
        local ____try, ____error = pcall(function()
            result = runJourney(lockstep, journey, {checksums = false})
        end)
        do
            debug.sethook()
        end
        if not ____try then
            error(____error, 0)
        end
    end
    local problems = journeyProblems(result)
    print((((("frames " .. tostring(lockstep.frame)) .. " step ") .. tostring(____exports.HOOK_STEP)) .. " problems ") .. tostring(problems))
    for ____, cost in __TS__Iterator(costs:values()) do
        for ____, line in ipairs(costLines(cost, lockstep.frame)) do
            print(line)
        end
    end
    if problems > 0 then
        for ____, line in ipairs(journeyLines(result)) do
            print("journey: " .. line)
        end
    end
    return problems
end
return ____exports
