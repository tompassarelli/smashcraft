/** @noSelfInFile */
import type { FrameTemplate } from "./frames";
import { type Hash, type ModuleSet, type VersionFiles } from "../runtime/modules";
import { type ClientFiles, type ClientScope, HeadlessClient, type LocalNatives, type MapEntry, type NativeBehaviors, type SyncMessage } from "./client";
import type { NativeDeclarations } from "./declarations";
import type { IntentionalNoops } from "./client";
export interface LockstepOptions {
    readonly declarations: NativeDeclarations;
    /** One client per human player slot. */
    readonly players: readonly number[];
    /** The map's configureRuntime() filePrefix, which names its reload, acknowledgement and error files. */
    readonly filePrefix: string;
    /** Each client's map entry; called in that client, so a host can load the bundle there. */
    readonly entry: (this: void, client: HeadlessClient) => MapEntry;
    /** The modules a hot reload publishes; each client's `load` turns their texts back into chunks. */
    readonly modules: ModuleSet;
    /** The checksum the host computes over module texts and indexes; the runtime-neutral one by default. */
    readonly hash?: Hash;
    /** The game's local-only natives, added to WISP_LOCAL_NATIVES. */
    readonly localNatives?: LocalNatives;
    readonly intentionalNoops?: IntentionalNoops;
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly scope?: ClientScope;
    /** When synchronized messages arrive; without it, each arrives before the next frame. */
    readonly delivery?: SyncDelivery;
    /** A player's CustomMapData outside the process, for clients whose files another program reads and writes. */
    readonly files?: (this: void, slot: number) => ClientFiles | undefined;
    /**
     * Compare the clients' calls after every frame and keep only this many of
     * each log, for the context of a later desync, so a long run keeps its memory.
     */
    readonly keepCalls?: number;
    /**
     * A clock, such as process CPU milliseconds: with it, `costs` holds what
     * each client's last frame took, its arriving messages and its callbacks.
     */
    readonly cost?: (this: void) => number;
    /** Frame definitions (wisp:docs/ui.md) whose trees BlzCreateFrame makes by name, as their generated FDF does in Warcraft. */
    readonly frames?: readonly FrameTemplate[];
}
/**
 * When a synchronized message reaches the clients, such as the measured
 * Battle.net latency of wisp:src/headless/syncChannel.ts
 * (wisp:docs/network-model.md).
 */
export interface SyncDelivery {
    /** The frame before whose callbacks every client receives a message `sender` sent during `frame`; later than `frame`. */
    arrivalFrame(this: void, sender: number, frame: number, message: SyncMessage): number;
}
interface InFlight {
    readonly arrival: number;
    readonly message: SyncMessage;
}
export declare class Lockstep {
    readonly network: SyncMessage[];
    readonly clients: readonly HeadlessClient[];
    /** Frames every client has run. */
    frame: number;
    /** Hot reload versions published so far. */
    version: number;
    /** The files of the latest version, as the host wrote them. */
    files: VersionFiles | undefined;
    /** With a delivery: messages sent and not yet received, by arrival frame, then send order. */
    readonly inFlight: InFlight[];
    /** With a `cost` clock: each client's last frame, in the clock's units, by client index. */
    readonly costs: number[];
    private readonly options;
    /** The first desync, once a comparison after a frame found one. */
    private divergence;
    private readonly publisher;
    constructor(options: LockstepOptions);
    /**
     * The map's main(): every client loads its entry and starts it. A host has
     * prepared each client's hot folder first, as `wisp fresh` does before a
     * match, unless `hostFolder` is false: a client no host has touched.
     */
    start(options?: {
        readonly hostFolder?: boolean;
    }): void;
    /** Runs `body` on every client, such as an entry the test chooses or an install() outside the reloader. */
    everywhere(body: (this: void) => void): void;
    /** Synchronized messages reach every client in the order they were sent, at once or at their arrival frame. */
    private flush;
    /** Delivers the messages due at the current frame, before its callbacks, as Warcraft runs a turn's events first. */
    private arrive;
    frames(count: number): void;
    /** Adds the cost clock's time since `started` to a client's frame. */
    private charge;
    /**
     * With keepCalls, compares the clients' calls so far, keeps the first
     * desync with the frame it was found after, and forgets all but the last
     * keepCalls of each log.
     */
    private settle;
    chat(sender: number, message: string): void;
    /** A key press and release with modifiers (2: Ctrl), as every client sees it. */
    press(sender: number, key: number, meta?: number): void;
    /** A held key's press or release, delivered to every client before its next frame. */
    key(sender: number, key: number, meta: number, down: boolean): void;
    /** The client of a player slot. */
    client(slot: number): HeadlessClient;
    /**
     * Text a player's keyboard types, such as an input helper's: into the edit
     * box that has their keyboard, local to their client, or, without one, as a
     * press and release of each character's key, which every client sees.
     */
    type(sender: number, text: string): void;
    /**
     * A player's click at (x, y) in Warcraft's UI coordinates: the frame under
     * it on their client takes the keyboard, and every client sees the click.
     * False when no frame there takes clicks.
     */
    click(sender: number, x: number, y: number): boolean;
    /** Puts a file in every client's CustomMapData, as the host writes it: one chunk per FileIO tooltip level. */
    publish(name: string, chunks: readonly string[]): void;
    /** Puts the host's marker in every client's hot folder, as `wisp fresh` and `wisp hot` do before anything else. */
    prepareHostFolder(): void;
    /**
     * Publishes the map's modules, or `modules`, as the next hot reload version,
     * as `wisp hot` does: the host's marker, payload files, then the manifest.
     * When every client acknowledged the previous version, it offers a delta
     * from that state. The clients find it on their next polls.
     */
    reload(modules?: ModuleSet): number;
    /** Clients whose acknowledgement doesn't name the latest version, each with why. */
    unappliedReloads(): string[];
    /** The first call at which two clients' logs differ, with the calls around it; undefined when they agree. */
    firstDivergence(): string | undefined;
    private compare;
}
export {};
