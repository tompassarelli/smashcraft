/** @noSelfInFile */
import type { Handle } from "./client";
export interface Frame extends Handle {
    /** BlzCreateFrameByType's type, such as "EDITBOX"; a template's name for BlzCreateFrame; "" for frames the game made. */
    readonly type: string;
    readonly name: string;
    readonly context: number;
    readonly parent: Frame | undefined;
    text: string;
    texture: string;
    color: number;
    textColor: number;
    alpha: number;
    visible: boolean;
    enabled: boolean;
    level: number;
    textLimit: number;
    width: number;
    height: number;
    /** Absolute points, by framepointtype value. */
    readonly points: Map<unknown, {
        readonly x: number;
        readonly y: number;
    }>;
    /** Points relative to another frame, as a generated FDF's SetPoint lines place them. */
    readonly anchors: Anchor[];
    destroyed: boolean;
}
/**
 * The framepointtype constants in ConvertFramePointType order, each with its
 * place on the frame: its share of the width from the left and of the height
 * from the top.
 */
export declare const FRAME_POINTS: readonly (readonly [name: string, fromLeft: number, fromTop: number])[];
/**
 * The part of a frame definition (wisp:scripts/wisp/frames.ts, wisp:docs/ui.md)
 * a headless client needs to make its tree; every FrameDefinition is one.
 */
export interface FrameTemplateNode {
    readonly key: string;
    readonly type: string;
    readonly width?: number;
    readonly height?: number;
    readonly text?: string;
    readonly texture?: string;
    readonly points?: readonly {
        readonly point: string;
        readonly relative?: string;
        readonly relativePoint?: string;
        readonly x: number;
        readonly y: number;
    }[];
    readonly children?: readonly FrameTemplateNode[];
}
export interface FrameTemplate {
    readonly name: string;
    readonly type?: string;
    readonly texture?: string;
    readonly width: number;
    readonly height: number;
    readonly children: readonly FrameTemplateNode[];
}
/** A SetPoint: this frame's point sits at the relative frame's point, offset. */
export interface Anchor {
    readonly point: string;
    readonly relative: Frame;
    readonly relativePoint: string;
    readonly x: number;
    readonly y: number;
}
/** A frame's rectangle: left, top, right, bottom. */
export type Rectangle = readonly [number, number, number, number];
export interface FrameSnapshot {
    readonly handle: Handle;
    readonly name: string;
    readonly type: string;
    readonly parentId: number | undefined;
    readonly rectangle: Rectangle | undefined;
    readonly text: string;
    readonly texture: string;
    readonly color: number;
    readonly textColor: number;
    readonly alpha: number;
    /** Includes the visibility of every ancestor. */
    readonly visible: boolean;
    readonly level: number;
}
export declare class Frames {
    private readonly points;
    private readonly all;
    private focused;
    private readonly templates;
    /**
     * `points`: each framepointtype constant's value as the map's code sees it,
     * with its place on the frame.
     */
    constructor(points: ReadonlyMap<unknown, readonly [number, number]>);
    add(handle: Handle, type: string, name: string, parent: Frame | undefined, context: number): Frame;
    /** Frame trees BlzCreateFrame makes by name, as the FDF wisp:scripts/wisp/frames.ts generates for them loads in Warcraft. */
    define(definitions: readonly FrameTemplate[]): void;
    /** BlzCreateFrame: a defined tree's root with every descendant, sized, placed and named as its FDF does; otherwise one frame. */
    create(handle: (this: void) => Handle, name: string, parent: Frame | undefined, context: number): Frame;
    /** A frame the map made by name, if one is alive. */
    named(name: string, context: number): Frame | undefined;
    byId(id: number): Frame | undefined;
    /** BlzDestroyFrame: the frame and its descendants. */
    destroy(frame: Frame): void;
    focus(frame: Frame, flag: boolean): void;
    /** Whether a player sees the frame: it and every parent are visible. */
    shown(frame: Frame): boolean;
    /** The text of every frame a player sees, in creation order. */
    shownText(): string[];
    /** Visual properties copied in creation order, including passive frames. */
    snapshot(): FrameSnapshot[];
    /** Where the frame is, from an absolute point and its size, or two opposite corners; undefined without one. */
    private rectangle;
    /**
     * The frame a click at (x, y) reaches: among shown, enabled frames that
     * `takes`, the highest level whose rectangle holds the point, the latest
     * created on a tie.
     */
    at(x: number, y: number, takes: (frame: Frame) => boolean): Frame | undefined;
    /**
     * Text the keyboard types reaches the focused edit box while a player sees
     * it, up to its character limit, as Warcraft drops the rest. False when no
     * edit box has the keyboard.
     */
    type(text: string): boolean;
}
