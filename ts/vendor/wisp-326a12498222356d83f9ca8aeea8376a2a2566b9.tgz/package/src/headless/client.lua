local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__NumberToFixed = ____lualib.__TS__NumberToFixed
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__Number = ____lualib.__TS__Number
local Map = ____lualib.Map
local __TS__Class = ____lualib.__TS__Class
local Set = ____lualib.Set
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__StringTrim = ____lualib.__TS__StringTrim
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__StringReplace = ____lualib.__TS__StringReplace
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__Spread = ____lualib.__TS__Spread
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local ____exports = {}
local isDigits, mixText, mixName, mixValue, isHandle, mix, nameHashes, INT32_LIMIT
local ____gameFiles = require("src.runtime.gameFiles")
local errorFile = ____gameFiles.errorFile
local FILE_IO_ABILITY = ____gameFiles.FILE_IO_ABILITY
local ____binary32 = require("src.sim.binary32")
local addFloat32 = ____binary32.addFloat32
local addFloat32TowardZero = ____binary32.addFloat32TowardZero
local divideFloat32 = ____binary32.divideFloat32
local multiplyFloat32TowardZero = ____binary32.multiplyFloat32TowardZero
local roundToFloat32 = ____binary32.roundToFloat32
local subtractFloat32 = ____binary32.subtractFloat32
local subtractFloat32TowardZero = ____binary32.subtractFloat32TowardZero
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
local ____animation = require("src.headless.animation")
local advanceAnimation = ____animation.advanceAnimation
local freshAnimation = ____animation.freshAnimation
local seekAnimation = ____animation.seekAnimation
local selectAnimation = ____animation.selectAnimation
local ____frames = require("src.headless.frames")
local FRAME_POINTS = ____frames.FRAME_POINTS
local Frames = ____frames.Frames
local ____warcraft3Abilities = require("src.headless.warcraft3Abilities")
local Warcraft3Abilities = ____warcraft3Abilities.Warcraft3Abilities
local ____warcraft3Natives = require("src.headless.warcraft3Natives")
local WARCRAFT3_ENUM_VALUES = ____warcraft3Natives.WARCRAFT3_ENUM_VALUES
local ____warcraft3Scenery = require("src.headless.warcraft3Scenery")
local Scenery = ____warcraft3Scenery.Scenery
local ____warcraft3Inventory = require("src.headless.warcraft3Inventory")
local Warcraft3Inventory = ____warcraft3Inventory.Warcraft3Inventory
function isDigits(text)
    local start = __TS__StringStartsWith(text, "-") and 1 or 0
    if #text <= start then
        return false
    end
    do
        local index = start
        while index < #text do
            local code = __TS__StringCharCodeAt(text, index)
            if code < 48 or code > 57 then
                return false
            end
            index = index + 1
        end
    end
    return true
end
--- A number as both runtimes print it alike: an integer in digits, any other
-- value exactly, as an integer times a power of two. Lua prints 3.0 for a
-- float that JavaScript prints as 3, and neither prints every binary digit.
function ____exports.describeNumber(value)
    if value ~= value then
        return "nan"
    end
    if value == math.huge then
        return "inf"
    end
    if value == -math.huge then
        return "-inf"
    end
    if value == 0 then
        return "0"
    end
    local text = tostring(value)
    if isDigits(text) then
        return text
    end
    local mantissa = value
    local exponent = 0
    while mantissa ~= math.floor(mantissa) and exponent < 1100 do
        mantissa = mantissa * 2
        exponent = exponent + 1
    end
    return exponent == 0 and __TS__NumberToFixed(mantissa, 0) or (__TS__NumberToFixed(mantissa, 0) .. "p-") .. tostring(exponent)
end
function mixText(hash, text)
    local mixed = hash
    do
        local index = 0
        while index < #text do
            mixed = mix(
                mixed,
                __TS__StringCharCodeAt(text, index)
            )
            index = index + 1
        end
    end
    return mix(mixed, #text)
end
function mixName(hash, name)
    local named = nameHashes:get(name)
    if named == nil then
        named = mixText(0, name)
        nameHashes:set(name, named)
    end
    return mix(hash, named)
end
function mixValue(hash, value)
    if type(value) == "number" then
        if value == math.floor(value) and value >= -INT32_LIMIT and value < INT32_LIMIT then
            return mix(
                mix(hash, 1),
                math.floor(value)
            )
        end
        return mixText(
            mix(hash, 2),
            ____exports.describeNumber(value)
        )
    end
    if type(value) == "string" then
        return mixText(
            mix(hash, 3),
            value
        )
    end
    if type(value) == "boolean" then
        return mix(hash, value and 4 or 5)
    end
    if type(value) == "function" then
        return mix(hash, 6)
    end
    if isHandle(value) then
        return mix(
            mixName(
                mix(hash, 7),
                value.kind
            ),
            value.id
        )
    end
    return mix(hash, (value == nil or value == nil) and 8 or 9)
end
--- Natives Wisp's own runtime calls on one client only. A game adds the ones
-- its code calls that way: local UI, input polling, conversions for local text.
____exports.WISP_LOCAL_NATIVES = {
    GetLocalPlayer = "identifies the client; every local branch starts here",
    GetPlayerId = "names this client's files; no effect",
    BlzSendSyncData = "only the sending client calls it; its message reaches every client as an event",
    PreloadGenClear = "local file output",
    PreloadGenStart = "local file output",
    Preload = "local file output",
    PreloadGenEnd = "local file output",
    Preloader = "local file input, synchronized only through sync data",
    BlzGetAbilityTooltip = "FileIO's local file buffer",
    BlzSetAbilityTooltip = "FileIO's local file buffer",
    DisplayTextToPlayer = "a message on this client: reload results and error reports",
    BlzFrameSetText = "the frame meter's overlay: an existing frame's text on this client",
    BlzFrameSetVisible = "the frame meter's overlay: shows an existing frame on this client",
    TimerGetElapsed = "reads a timer; the reload acknowledgement only reports it",
    BlzGetLocalSpecialEffectX = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectY = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectZ = "the scene report reads an effect's local position"
}
local function copyBlend(blend)
    local ____temp_0
    if blend == nil then
        ____temp_0 = nil
    else
        ____temp_0 = {
            from = __TS__ObjectAssign(
                {},
                blend.from,
                {subAnimations = {table.unpack(blend.from.subAnimations)}}
            ),
            remaining = blend.remaining
        }
    end
    return ____temp_0
end
--- One pure assertion over emitted cues; creation alone never counts as playing.
function ____exports.assertSoundCue(log, expected)
    local count = 0
    for ____, cue in ipairs(log) do
        do
            if cue.event ~= "start" then
                goto __continue4
            end
            if expected.source ~= nil and cue.source ~= expected.source then
                goto __continue4
            end
            if expected.label ~= nil and cue.label ~= expected.label then
                goto __continue4
            end
            if expected.frame ~= nil and cue.frame ~= expected.frame then
                goto __continue4
            end
            count = count + 1
        end
        ::__continue4::
    end
    if count ~= (expected.count or 1) then
        do
            local ____thrown = __TS__New(
                Error,
                (((("sound cue " .. (expected.source or expected.label or "any")) .. ": expected ") .. tostring(expected.count or 1)) .. " starts, got ") .. tostring(count)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/client.ts:165"
            end
            error(____thrown, 0)
        end
    end
end
____exports.FRAMES_PER_SECOND = 60
--- The shortest repeating period: a zero period fires about 10,000 times a game second (wisp:docs/warsmash-notes.md#timers-and-frame-stepping).
local MIN_PERIOD = 0xd1b717p-37
--- The shortest one-shot timeout, 1/1024 s.
local MIN_ONE_SHOT = 0x1p-10
--- A frame's end in binary32 game seconds.
local function frameEnd(frame)
    return divideFloat32(frame, ____exports.FRAMES_PER_SECOND)
end
--- A deadline `length` after `at`, the sum rounded toward zero as Warcraft's
-- timer clock adds. Where `length` is under the clock's resolution (a
-- 0.0001 s period past 1,024 s) it is one resolution later, so a repeat
-- can't stall the frame; Warcraft's behavior there is unmeasured.
local function after(at, length)
    local due = addFloat32TowardZero(at, length)
    return due > at and due or addFloat32TowardZero(at, at * 0x1p-23)
end
local CAMERA_FIELDS = {
    "CAMERA_FIELD_TARGET_DISTANCE",
    "CAMERA_FIELD_FARZ",
    "CAMERA_FIELD_ANGLE_OF_ATTACK",
    "CAMERA_FIELD_FIELD_OF_VIEW",
    "CAMERA_FIELD_ROLL",
    "CAMERA_FIELD_ROTATION",
    "CAMERA_FIELD_ZOFFSET",
    "CAMERA_FIELD_NEARZ",
    "CAMERA_FIELD_LOCAL_PITCH",
    "CAMERA_FIELD_LOCAL_YAW",
    "CAMERA_FIELD_LOCAL_ROLL",
    "CAMERA_FIELD_DEPTH_OF_FIELD_DISTANCE",
    "CAMERA_FIELD_DEPTH_OF_FIELD_SCALE",
    "CAMERA_FIELD_ZABSOLUTE"
}
local PLAYER_COLORS = __TS__ArrayMap(
    {
        "RED",
        "BLUE",
        "CYAN",
        "PURPLE",
        "YELLOW",
        "ORANGE",
        "GREEN",
        "PINK",
        "LIGHT_GRAY",
        "LIGHT_BLUE",
        "AQUA",
        "BROWN",
        "MAROON",
        "NAVY",
        "TURQUOISE",
        "VIOLET",
        "WHEAT",
        "PEACH",
        "MINT",
        "LAVENDER",
        "COAL",
        "SNOW",
        "EMERALD",
        "PEANUT",
        "BLACK"
    },
    function(____, name) return "PLAYER_COLOR_" .. name end
)
isHandle = function(value) return type(value) == "table" and value ~= nil and value.id ~= nil and value.kind ~= nil end
local function isFrame(value)
    return type(value) == "table" and value ~= nil and value.points ~= nil
end
--- Life at or below this kills a living unit.
local DEATH_CUTOFF = 0xcf5c29p-25
local RADIANS_PER_DEGREE = 0x8efa35p-29
local DEGREES_PER_RADIAN = 0xe52ee1p-18
--- 2π as binary32.
local TURN = 0xc90fdbp-21
--- Two ulps above the binary32 nearest 1 / TURN, as 3.0.1 multiplies by it.
local TURNS_PER_RADIAN = 0xa2f985p-26
--- The degrees GetUnitFacing reads after a facing write: 3.0.1 keeps facing in
-- radians with every product rounded toward zero; an angle in [-TURN, 0) gains
-- a turn, and any other outside [0, TURN) keeps its fraction of a turn
-- (wisp:docs/warsmash-notes.md, "Unit position and facing").
local function unitFacing(degrees)
    local radians = multiplyFloat32TowardZero(degrees, RADIANS_PER_DEGREE)
    if radians >= TURN or radians < -TURN then
        local turns = multiplyFloat32TowardZero(radians, TURNS_PER_RADIAN)
        radians = multiplyFloat32TowardZero(
            __wispF32Subtract(
                turns,
                math.floor(turns)
            ),
            TURN
        )
    elseif radians < 0 then
        radians = subtractFloat32TowardZero(TURN, -radians)
    end
    return multiplyFloat32TowardZero(radians, DEGREES_PER_RADIAN)
end
--- A native argument, the same on every client and in both runtimes: handles by kind and number, callbacks as `fn`.
function ____exports.describeValue(value)
    if value == nil or value == nil then
        return "nil"
    end
    if type(value) == "number" then
        return ____exports.describeNumber(value)
    end
    if type(value) == "string" then
        return ("\"" .. value) .. "\""
    end
    if type(value) == "boolean" then
        return value and "true" or "false"
    end
    if type(value) == "function" then
        return "fn"
    end
    if isHandle(value) then
        return (value.kind .. "#") .. ____exports.describeNumber(value.id)
    end
    return "table"
end
function ____exports.describeCall(____bindingPattern0)
    local args
    local name
    name = ____bindingPattern0.name
    args = ____bindingPattern0.args
    local call = name .. "("
    do
        local index = 0
        while index < #args do
            if index > 0 then
                call = call .. ", "
            end
            call = call .. ____exports.describeValue(args[index + 1])
            index = index + 1
        end
    end
    return call .. ")"
end
--- Whether two clients made the same call: equal values, handles with the same kind and number, any two callbacks.
function ____exports.sameCall(left, right)
    if left.name ~= right.name or #left.args ~= #right.args then
        return false
    end
    do
        local index = 0
        while index < #left.args do
            do
                local leftArg = left.args[index + 1]
                local rightArg = right.args[index + 1]
                if leftArg == rightArg then
                    goto __continue45
                end
                if type(leftArg) == "function" and type(rightArg) == "function" then
                    goto __continue45
                end
                if isHandle(leftArg) and isHandle(rightArg) then
                    if leftArg.id ~= rightArg.id or leftArg.kind ~= rightArg.kind then
                        return false
                    end
                    goto __continue45
                end
                if ____exports.describeValue(leftArg) ~= ____exports.describeValue(rightArg) then
                    return false
                end
            end
            ::__continue45::
            index = index + 1
        end
    end
    return true
end
--- JASS S2I and S2R read a leading number and ignore the rest; no digits read
-- as 0. S2I skips leading spaces and S2R doesn't (3.0.1: `S2I(" -7")` is -7,
-- `S2R(" 7.25")` is 0; wisp#50).
local function leadingNumber(text, fraction)
    local start = 0
    while not fraction and start < #text and __TS__StringCharAt(text, start) == " " do
        start = start + 1
    end
    local ____end = start
    if ____end < #text and (__TS__StringCharAt(text, ____end) == "-" or __TS__StringCharAt(text, ____end) == "+") then
        ____end = ____end + 1
    end
    local digits = 0
    local point = false
    while ____end < #text do
        local character = __TS__StringCharAt(text, ____end)
        if character >= "0" and character <= "9" then
            digits = digits + 1
        elseif fraction and character == "." and not point then
            point = true
        else
            break
        end
        ____end = ____end + 1
    end
    if digits == 0 then
        return 0
    end
    local value = __TS__Number(__TS__StringSlice(text, start, ____end))
    return value == value and value or 0
end
--- A binary32 real with `digits` decimals, as Warcraft's R2S and R2SW print
-- it: correctly rounded, exact ties away from zero (3.0.1: 0.0625 reads
-- "0.063", -0.0625 "-0.063"; wisp#50), the sign kept on a negative that
-- rounds to zero. Neither Lua's string.format (ties to even) nor
-- JavaScript's toFixed (ties up, inexact) gives this, so it's done by hand.
local function fixed(value, digits)
    local real = roundToFloat32(value)
    if real ~= real or real == math.huge or real == -math.huge or real >= 1.0000000200408773e+21 or real <= -1.0000000200408773e+21 then
        return __TS__NumberToFixed(real, digits)
    end
    local expanded = __TS__NumberToFixed(real < 0 and -real or real, digits + 30)
    local point = (string.find(expanded, ".", nil, true) or 0) - 1
    local kept = __TS__StringSlice(expanded, 0, point) .. __TS__StringSlice(expanded, point + 1, point + 1 + digits)
    local rest = __TS__StringSlice(expanded, point + 1 + digits)
    local digitsText = kept
    if string.sub(rest, 1, 1) >= "5" then
        local carry = #digitsText - 1
        while carry >= 0 and __TS__StringCharAt(digitsText, carry) == "9" do
            carry = carry - 1
        end
        digitsText = carry < 0 and "1" .. string.rep(
            "0",
            math.floor(#digitsText)
        ) or (__TS__StringSlice(digitsText, 0, carry) .. string.char(__TS__StringCharCodeAt(digitsText, carry) + 1)) .. string.rep(
            "0",
            math.floor(#digitsText - carry - 1)
        )
    end
    local whole = __TS__StringSlice(digitsText, 0, #digitsText - digits)
    local text = digits > 0 and (whole .. ".") .. __TS__StringSlice(digitsText, #digitsText - digits) or whole
    return real < 0 and "-" .. text or text
end
--- Characters of a sync message's data that arrive; the prefix doesn't count (3.0.1: 300 arrive as 255, 252 whole; wisp#50).
local SYNC_DATA_LIMIT = 255
mix = function(hash, value) return hash * 1000003 + value | 0 end
nameHashes = __TS__New(Map)
local function mixCall(hash, ____bindingPattern0)
    local args
    local name
    name = ____bindingPattern0.name
    args = ____bindingPattern0.args
    local mixed = mixName(hash, name)
    do
        local index = 0
        while index < #args do
            mixed = mixValue(mixed, args[index + 1])
            index = index + 1
        end
    end
    return mixed
end
INT32_LIMIT = 2147483648
____exports.HeadlessClient = __TS__Class()
local HeadlessClient = ____exports.HeadlessClient
HeadlessClient.name = "HeadlessClient"
function HeadlessClient.prototype.____constructor(self, options)
    self.abilities = __TS__New(Warcraft3Abilities)
    self.textAreaAutoScroll = __TS__New(Map)
    self.heldMouseButtons = __TS__New(Set)
    self.mouseScreenX = 0
    self.mouseScreenY = 0
    self.heldMeta = 0
    self.log = {}
    self.forgotten = 0
    self.forgottenHash = 0
    self.errors = {}
    self.missingNatives = {}
    self.messages = {}
    self.thrown = {}
    self.files = __TS__New(Map)
    self.published = __TS__New(Map)
    self.missedLookups = 0
    self.natives = {}
    self.frame = 0
    self.nextId = 0
    self.timers = {}
    self.timerOrder = 0
    self.now = 0
    self.registrations = {}
    self.heldKeys = __TS__New(Set)
    self.memo = __TS__New(Map)
    self.effects = __TS__New(Map)
    self.units = __TS__New(Map)
    self.removals = {}
    self.sounds = __TS__New(Map)
    self.soundLog = {}
    self.musicVolume = 127
    self.cameraX = 0
    self.cameraY = 0
    self.cameraFields = {}
    self.tooltips = __TS__New(Map)
    self.preloaded = __TS__New(Map)
    self.event = {
        player = 0,
        syncPrefix = "",
        syncData = "",
        chat = "",
        key = 0,
        timer = nil,
        frame = nil,
        frameEvent = nil
    }
    self.preload = {}
    self.scenery = __TS__New(Scenery, options.scenery)
    self.inventory = __TS__New(
        Warcraft3Inventory,
        {
            handle = function(kind) return self:handle(kind) end,
            getUnitTypeId = function(unit) return unit.typeId end,
            readLife = function(unit) return self:unitValue(unit, "life") end,
            readMaxLife = function(unit) return self:unitValue(unit, "maxLife") end,
            writeLife = function(unit, life) return self:setLife(unit, life) end
        },
        options.inventory
    )
    self.unitStates = options.unitStates or ({})
    self.effectDeaths = options.effectDeaths
    self.slot = options.slot
    self.scope = options.scope
    self.filePrefix = options.filePrefix
    self.stored = options.files
    local behaviors = self:behaviors(options)
    local ____local = options.localNatives
    local log = self.log
    local function logged(name, parameters, behave)
        repeat
            local ____switch86 = parameters
            local ____cond86 = ____switch86 == 0
            if ____cond86 then
                return function()
                    log[#log + 1] = {name = name, args = {}}
                    return behave()
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 1
            if ____cond86 then
                return function(a)
                    log[#log + 1] = {name = name, args = {a}}
                    return behave(a)
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 2
            if ____cond86 then
                return function(a, b)
                    log[#log + 1] = {name = name, args = {a, b}}
                    return behave(a, b)
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 3
            if ____cond86 then
                return function(a, b, c)
                    log[#log + 1] = {name = name, args = {a, b, c}}
                    return behave(a, b, c)
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 4
            if ____cond86 then
                return function(a, b, c, d)
                    log[#log + 1] = {name = name, args = {a, b, c, d}}
                    return behave(a, b, c, d)
                end
            end
            do
                return function(...)
                    local args = {...}
                    log[#log + 1] = {name = name, args = args}
                    return behave(...)
                end
            end
        until true
    end
    local arity = __TS__New(Map)
    local declared = __TS__New(Set)
    local missing = __TS__New(Set)
    local noops = options.intentionalNoops or ({})
    for ____, name in ipairs(__TS__ObjectKeys(noops)) do
        if not __TS__ArraySome(
            options.declarations.functions,
            function(____, ____bindingPattern0)
                local native
                native = ____bindingPattern0[1]
                return native == name
            end
        ) or __TS__StringTrim(noops[name] or "") == "" then
            do
                local ____thrown = __TS__New(Error, ("intentional no-op " .. name) .. " needs a declared native and a concrete reason")
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/client.ts:636"
                end
                error(____thrown, 0)
            end
        end
    end
    for ____, ____value in ipairs(options.declarations.functions) do
        local name = ____value[1]
        local returns = ____value[2]
        local parameters = ____value[3]
        declared:add(name)
        arity:set(name, parameters)
        local fallback = self:defaultNative(returns)
        local behave = behaviors[name] or (__TS__StringStartsWith(name, "Convert") and (function(value) return value end) or (noops[name] ~= nil and fallback or (function()
            if not missing:has(name) then
                missing:add(name)
                local ____self_missingNatives_1 = self.missingNatives
                ____self_missingNatives_1[#____self_missingNatives_1 + 1] = {native = name, client = self.slot, frame = self.frame}
            end
            return fallback()
        end)))
        self.natives[name] = ____local[name] == nil and logged(name, parameters, behave) or behave
    end
    for ____, ____value in ipairs(options.declarations.constants) do
        local name = ____value[1]
        local ____type = ____value[2]
        local ____self_natives_5 = self.natives
        local ____name_6 = name
        local ____WARCRAFT3_ENUM_VALUES_name_4 = WARCRAFT3_ENUM_VALUES[name]
        if ____WARCRAFT3_ENUM_VALUES_name_4 == nil then
            local ____temp_3
            if ____type == "number" then
                ____temp_3 = 0
            else
                local ____temp_2
                if ____type == "boolean" then
                    ____temp_2 = name == "TRUE"
                else
                    ____temp_2 = name
                end
                ____temp_3 = ____temp_2
            end
            ____WARCRAFT3_ENUM_VALUES_name_4 = ____temp_3
        end
        ____self_natives_5[____name_6] = ____WARCRAFT3_ENUM_VALUES_name_4
    end
    for ____, ____value in ipairs(options.declarations.variables) do
        local name = ____value[1]
        local ____type = ____value[2]
        self.natives[name] = self:defaultValue(____type)
    end
    local points = __TS__New(Map)
    do
        local index = 0
        while index < #FRAME_POINTS do
            local name, fromLeft, fromTop = table.unpack(FRAME_POINTS[index + 1] or ({"", 0, 0}), 1, 3)
            local ____points_set_8 = points.set
            local ____self_natives_name_7 = self.natives[name]
            if ____self_natives_name_7 == nil then
                ____self_natives_name_7 = name
            end
            ____points_set_8(points, ____self_natives_name_7, {fromLeft, fromTop})
            points:set(index, {fromLeft, fromTop})
            index = index + 1
        end
    end
    self.frames = __TS__New(Frames, points)
    self.frames:define(options.frames or ({}))
    local ____opt_9 = options.natives
    local extra = ____opt_9 and ____opt_9(self) or ({})
    for ____, name in ipairs(__TS__ObjectKeys(extra)) do
        local value = extra[name]
        self.natives[name] = type(value) == "function" and declared:has(name) and ____local[name] == nil and logged(
            name,
            arity:get(name) or 5,
            value
        ) or value
    end
end
function HeadlessClient.prototype.handle(self, kind)
    self.nextId = self.nextId + 1
    return {kind = kind, id = self.nextId}
end
function HeadlessClient.prototype.defaultNative(self, returns)
    repeat
        local ____switch112 = returns
        local ____cond112 = ____switch112 == "void"
        if ____cond112 then
            return function() return nil end
        end
        ____cond112 = ____cond112 or ____switch112 == "number"
        if ____cond112 then
            return function() return 0 end
        end
        ____cond112 = ____cond112 or ____switch112 == "string"
        if ____cond112 then
            return function() return "" end
        end
        ____cond112 = ____cond112 or ____switch112 == "boolean"
        if ____cond112 then
            return function() return false end
        end
        do
            return function() return self:handle(returns) end
        end
    until true
end
function HeadlessClient.prototype.defaultValue(self, ____type)
    if __TS__StringEndsWith(____type, "[]") then
        return {}
    end
    repeat
        local ____switch120 = ____type
        local ____cond120 = ____switch120 == "boolean"
        if ____cond120 then
            return false
        end
        ____cond120 = ____cond120 or ____switch120 == "number"
        if ____cond120 then
            return 0
        end
        ____cond120 = ____cond120 or ____switch120 == "string"
        if ____cond120 then
            return ""
        end
        do
            return self:handle(____type)
        end
    until true
end
function HeadlessClient.prototype.memoized(self, key, name)
    if name == nil then
        name = ""
    end
    local known = self.memo:get(key)
    if known ~= nil then
        return known
    end
    local created = self.frames:add(
        self:handle("framehandle"),
        "",
        name,
        nil,
        0
    )
    self.memo:set(key, created)
    return created
end
function HeadlessClient.prototype.created(self, ____type, name, owner, context)
    return self.frames:add(
        self:handle("framehandle"),
        ____type,
        name,
        isFrame(owner) and owner or nil,
        context
    )
end
function HeadlessClient.prototype.effectAt(self, model, x, y)
    local handle = self:handle("effect")
    self.effects:set(
        handle,
        __TS__ObjectAssign(
            {},
            freshAnimation(),
            {
                handle = handle,
                model = model,
                created = self.frame,
                x = x,
                y = y,
                z = 0,
                alpha = 255,
                scale = 1,
                timeScale = 1,
                flat = false,
                queuedAnimations = {},
                yaw = 0,
                pitch = 0,
                roll = 0,
                color = {255, 255, 255},
                teamColor = 0,
                matrixScale = {1, 1, 1}
            }
        )
    )
    return handle
end
function HeadlessClient.prototype.unitAt(self, owner, typeId, x, y, facing)
    local handle = self:handle("unit")
    local state = self.unitStates[typeId]
    local unit = __TS__ObjectAssign(
        {},
        handle,
        freshAnimation(),
        {
            handle = handle,
            typeId = typeId,
            owner = owner,
            x = x,
            y = y,
            z = 0,
            facing = unitFacing(facing),
            scale = {1, 1, 1},
            alpha = 255,
            color = {255, 255, 255},
            teamColor = owner,
            timeScale = 1,
            visible = true,
            moveSpeed = 0,
            attackCooldown = 0,
            life = state and state.life,
            maxLife = state and state.maxLife,
            mana = state and state.mana,
            maxMana = state and state.maxMana,
            dead = state ~= nil and state.life <= DEATH_CUTOFF,
            removed = false
        }
    )
    self.units:set(unit, unit)
    return unit
end
function HeadlessClient.prototype.unitValue(self, unit, field)
    if unit.removed then
        return 0
    end
    local value = unit[field]
    if value == nil then
        do
            local ____thrown = __TS__New(
                Error,
                ((((("unit type " .. tostring(unit.typeId)) .. ": declare unitStates.") .. tostring(unit.typeId)) .. ".") .. field) .. " or set it before reading"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/client.ts:731"
            end
            error(____thrown, 0)
        end
    end
    return value
end
function HeadlessClient.prototype.setLife(self, unit, life)
    if unit.removed then
        return
    end
    local value = unit.life == nil and life or addFloat32(
        unit.life,
        subtractFloat32(life, unit.life, true)
    )
    if not unit.dead and value <= DEATH_CUTOFF then
        unit.life = 0
        unit.dead = true
    else
        unit.life = value
    end
end
function HeadlessClient.prototype.unitAnimation(self, unit, animation)
    selectAnimation(unit, animation)
end
function HeadlessClient.prototype.sound(self, source, label, looping)
    local handle = self:handle("sound")
    local sound = {
        kind = "sound",
        handle = handle,
        source = source,
        label = label,
        volume = 127,
        pitch = 1,
        x = 0,
        y = 0,
        z = 0,
        unit = nil,
        looping = looping,
        duration = 0,
        elapsed = 0,
        playing = false,
        killWhenDone = false
    }
    self.sounds:set(handle, sound)
    self:cue(sound, "create")
    return handle
end
function HeadlessClient.prototype.cue(self, sound, event)
    local ____self_soundLog_34 = self.soundLog
    local ____event_23 = event
    local ____sound_kind_24 = sound.kind
    local ____self_frame_25 = self.frame
    local ____sound_handle_26 = sound.handle
    local ____sound_source_27 = sound.source
    local ____sound_label_28 = sound.label
    local ____sound_volume_29 = sound.volume
    local ____temp_30 = sound.volume / 127
    local ____sound_looping_31 = sound.looping
    local ____sound_pitch_32 = sound.pitch
    local ____opt_19 = sound.unit
    local ____temp_33 = ____opt_19 and ____opt_19.x or sound.x
    local ____opt_21 = sound.unit
    ____self_soundLog_34[#____self_soundLog_34 + 1] = {
        event = ____event_23,
        kind = ____sound_kind_24,
        frame = ____self_frame_25,
        handle = ____sound_handle_26,
        source = ____sound_source_27,
        label = ____sound_label_28,
        volume = ____sound_volume_29,
        effectiveVolume = ____temp_30,
        looping = ____sound_looping_31,
        pitch = ____sound_pitch_32,
        x = ____temp_33,
        y = ____opt_21 and ____opt_21.y or sound.y,
        z = sound.z
    }
end
function HeadlessClient.prototype.stopAudio(self, sound)
    if not sound.playing then
        return
    end
    self:cue(sound, "stop")
    sound.playing = false
end
function HeadlessClient.prototype.playMusic(self, source)
    if self.music ~= nil then
        self:stopAudio(self.music)
    end
    self.music = {
        kind = "music",
        handle = {kind = "music", id = 0},
        source = source,
        label = nil,
        volume = self.musicVolume,
        pitch = 1,
        x = 0,
        y = 0,
        z = 0,
        unit = nil,
        looping = true,
        duration = 0,
        elapsed = 0,
        playing = true,
        killWhenDone = false
    }
    self:cue(self.music, "start")
end
function HeadlessClient.prototype.startSound(self, handle)
    local sound = self.sounds:get(handle)
    if sound == nil or sound.playing then
        return
    end
    self:cue(sound, "start")
    sound.elapsed = 0
    sound.playing = sound.looping or sound.duration > 0
    if not sound.playing and sound.killWhenDone then
        self.sounds:delete(handle)
    end
end
function HeadlessClient.prototype.cameraField(self, field)
    if type(field) == "number" then
        return CAMERA_FIELDS[field + 1] or ____exports.describeValue(field)
    end
    if type(field) == "string" then
        return field
    end
    return ____exports.describeValue(field)
end
function HeadlessClient.prototype.liveEffect(self, effect)
    local pose = self.effects:get(effect)
    local ____temp_37
    if (pose and pose.destroyed) == nil then
        ____temp_37 = pose
    else
        ____temp_37 = nil
    end
    return ____temp_37
end
function HeadlessClient.prototype.destroyEffect(self, effect)
    local pose = self:liveEffect(effect)
    if pose == nil then
        return
    end
    local ____opt_38 = self.effectDeaths
    local death = ____opt_38 and ____opt_38(pose.model)
    pose.destroyed = self.frame
    __TS__ArraySetLength(pose.queuedAnimations, 0)
    if death ~= nil and death > 0 then
        pose.death = death
        selectAnimation(pose, "death", {})
    end
end
function HeadlessClient.prototype.playEffect(self, effect, animation, timeScale)
    local pose = self:liveEffect(effect)
    if pose == nil then
        return
    end
    selectAnimation(pose, animation, nil, true)
    if timeScale ~= nil then
        pose.timeScale = timeScale
    end
end
function HeadlessClient.prototype.show(self, text)
    local ____self_messages_40 = self.messages
    ____self_messages_40[#____self_messages_40 + 1] = text
end
function HeadlessClient.prototype.report(self, lines)
    local heading = lines[1] or ""
    local ____self_errors_41 = self.errors
    ____self_errors_41[#____self_errors_41 + 1] = (("error in " .. __TS__StringSlice(
        heading,
        (string.find(heading, " in ", nil, true) or 0) - 1 + 4
    )) .. ": ") .. (lines[2] or "")
end
function HeadlessClient.prototype.behaviors(self, ____bindingPattern0)
    local screenWidth
    local network
    local humans
    humans = ____bindingPattern0.humans
    network = ____bindingPattern0.network
    screenWidth = ____bindingPattern0.screenWidth
    local function playing(player)
        return __TS__ArrayIncludes(humans, player)
    end
    return __TS__ObjectAssign(
        {},
        self.scenery:behaviors({handle = function(kind) return self:handle(kind) end}),
        self.inventory:behaviors(),
        {
            GetLocalPlayer = function() return self.slot end,
            Player = function(n) return n end,
            GetPlayerId = function(player) return player end,
            GetTriggerPlayer = function() return self.event.player end,
            GetHandleId = function(handle) return isHandle(handle) and handle.id or handle end,
            GetPlayerController = function(player) return playing(player) and "MAP_CONTROL_USER" or "MAP_CONTROL_NONE" end,
            GetPlayerSlotState = function(player) return playing(player) and "PLAYER_SLOT_STATE_PLAYING" or "PLAYER_SLOT_STATE_EMPTY" end,
            GetPlayersAll = function()
                if self.allPlayers == nil then
                    self.allPlayers = self:handle("force")
                end
                return self.allPlayers
            end,
            CreateUnit = function(owner, typeId, x, y, facing) return self:unitAt(
                owner,
                typeId,
                x,
                y,
                facing
            ) end,
            CreateUnitByName = function(owner, name, x, y, facing) return self:unitAt(
                owner,
                #name == 4 and (string.byte(name, 1) or 0 / 0) * 16777216 + (string.byte(name, 2) or 0 / 0) * 65536 + (string.byte(name, 3) or 0 / 0) * 256 + (string.byte(name, 4) or 0 / 0) or 0,
                x,
                y,
                facing
            ) end,
            RemoveUnit = function(unit)
                local ____self_removals_42 = self.removals
                ____self_removals_42[#____self_removals_42 + 1] = unit
                self.units:delete(unit)
                self.abilities:removeUnit(unit)
            end,
            GetOwningPlayer = function(unit) return unit.owner end,
            GetWidgetLife = function(unit) return self:unitValue(unit, "life") end,
            SetWidgetLife = function(unit, life) return self:setLife(unit, life) end,
            KillUnit = function(unit)
                if not unit.removed then
                    unit.life = 0
                    unit.dead = true
                end
            end,
            GetUnitState = function(unit, state)
                if state == "UNIT_STATE_LIFE" then
                    return self:unitValue(unit, "life")
                end
                if state == "UNIT_STATE_MAX_LIFE" then
                    return self:unitValue(unit, "maxLife")
                end
                if state == "UNIT_STATE_MANA" then
                    return self:unitValue(unit, "mana")
                end
                if state == "UNIT_STATE_MAX_MANA" then
                    return self:unitValue(unit, "maxMana")
                end
                do
                    local ____thrown = __TS__New(Error, "GetUnitState: unsupported state " .. state)
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/client.ts:861"
                    end
                    error(____thrown, 0)
                end
            end,
            SetUnitState = function(unit, state, value)
                if unit.removed then
                    return
                end
                if state == "UNIT_STATE_LIFE" then
                    self:setLife(unit, value)
                elseif state == "UNIT_STATE_MANA" then
                    unit.mana = unit.mana == nil and value or addFloat32(
                        unit.mana,
                        subtractFloat32(value, unit.mana, true)
                    )
                elseif state ~= "UNIT_STATE_MAX_LIFE" and state ~= "UNIT_STATE_MAX_MANA" then
                    do
                        local ____thrown = __TS__New(Error, "SetUnitState: unsupported state " .. state)
                        if _G.__wispThrown ~= ____thrown then
                            _G.__wispThrown = ____thrown
                            _G.__wispThrowSite = "wisp/src/headless/client.ts:868"
                        end
                        error(____thrown, 0)
                    end
                end
            end,
            BlzGetUnitMaxHP = function(unit) return self:unitValue(unit, "maxLife") end,
            BlzSetUnitMaxHP = function(unit, value)
                if not unit.removed then
                    unit.maxLife = value
                end
            end,
            BlzGetUnitMaxMana = function(unit) return self:unitValue(unit, "maxMana") end,
            BlzSetUnitMaxMana = function(unit, value)
                if not unit.removed then
                    unit.maxMana = value
                end
            end,
            ShowUnit = function(unit, show)
                unit.visible = show
            end,
            IsUnitHidden = function(unit) return not unit.visible end,
            GetUnitFlyHeight = function(unit) return unit.z end,
            SetUnitFlyHeight = function(unit, height)
                unit.z = height
            end,
            GetUnitFacing = function(unit) return unit.facing end,
            SetUnitFacing = function(unit, facing)
                unit.facing = unitFacing(facing)
            end,
            BlzSetUnitFacingEx = function(unit, facing)
                unit.facing = unitFacing(facing)
            end,
            SetUnitScale = function(unit, x, y, z)
                unit.scale = {x, y, z}
            end,
            SetUnitTimeScale = function(unit, timeScale)
                unit.timeScale = timeScale
            end,
            SetUnitBlendTime = function(unit, blendTime)
                unit.animationBlendTime = blendTime
            end,
            SetUnitVertexColor = function(unit, red, green, blue, alpha)
                unit.color = {red, green, blue}
                unit.alpha = alpha
            end,
            SetUnitColor = function(unit, color)
                unit.teamColor = type(color) == "number" and color or __TS__ArrayIndexOf(PLAYER_COLORS, color)
            end,
            SetUnitAnimation = function(unit, animation) return self:unitAnimation(unit, animation) end,
            SetUnitAnimationByIndex = function(unit, animation) return self:unitAnimation(unit, animation) end,
            SetUnitAnimationWithRarity = function(unit, animation) return self:unitAnimation(unit, animation) end,
            GetUnitTypeId = function(unit) return unit.removed and 0 or unit.typeId end,
            GetUnitX = function(unit) return unit.x end,
            GetUnitY = function(unit) return unit.y end,
            SetUnitX = function(unit, x)
                unit.x = x
            end,
            SetUnitY = function(unit, y)
                unit.y = y
            end,
            SetUnitPosition = function(unit, x, y)
                unit.x = x
                unit.y = y
            end,
            SetUnitMoveSpeed = function(unit, value)
                unit.moveSpeed = value
            end,
            GetUnitMoveSpeed = function(unit) return unit.moveSpeed end
        },
        self.abilities:behaviors(function(kind) return self:handle(kind) end),
        {
            BlzGetLocalClientWidth = function() return screenWidth end,
            BlzGetLocalClientHeight = function() return 1080 end,
            BlzIsLocalClientActive = function() return true end,
            BlzIsKeyPressed = function(key) return self.heldKeys:has(key) end,
            BlzIsMetaKeyPressed = function(meta) return self.heldMeta & meta == meta end,
            BlzIsMouseButtonPressed = function(button) return self.heldMouseButtons:has(button) end,
            BlzGetMouseScreenPosX = function() return self.mouseScreenX end,
            BlzGetMouseScreenPosY = function() return self.mouseScreenY end,
            BlzPixelToFrameX = function(pixel) return __wispF32Divide(pixel * 0xcccccdp-24, screenWidth) end,
            BlzPixelToFrameY = function(pixel) return __wispF32Divide(pixel * 0x4ccccdp-23, 1080) end,
            BlzFrameToPixelX = function(frame) return math.floor(frame * screenWidth / 0xcccccdp-24 + 0x1p-1) end,
            BlzFrameToPixelY = function(frame) return math.floor(frame * 1080 / 0x4ccccdp-23 + 0x1p-1) end,
            BlzTextAreaFrameSetAutoScroll = function(frame, value)
                self.textAreaAutoScroll:set(frame, value)
            end,
            BlzLoadTOCFile = function() return true end,
            BlzGetOriginFrame = function(____type, index) return self:memoized((("origin " .. ____exports.describeValue(____type)) .. " ") .. tostring(index)) end,
            BlzGetFrameByName = function(name, context) return self.frames:named(name, context) or self:memoized(
                (("name " .. name) .. " ") .. tostring(context),
                name
            ) end,
            BlzFrameGetChildrenCount = function(frame) return isFrame(frame) and #self.frames:children(frame) or 0 end,
            BlzFrameGetChild = function(frame, index)
                local ____isFrame_result_43
                if isFrame(frame) then
                    ____isFrame_result_43 = self.frames:children(frame)[index + 1]
                else
                    ____isFrame_result_43 = nil
                end
                return ____isFrame_result_43 or self:memoized((("child " .. tostring(frame.id)) .. " ") .. tostring(index))
            end,
            BlzCreateFrame = function(name, owner, _priority, context) return self.frames:create(
                function() return self:handle("framehandle") end,
                name,
                isFrame(owner) and owner or nil,
                context
            ) end,
            BlzCreateSimpleFrame = function(name, owner, context) return self:created(name, name, owner, context) end,
            BlzCreateFrameByType = function(____type, name, owner, _inherits, context) return self:created(____type, name, owner, context) end,
            BlzDestroyFrame = function(frame)
                if isFrame(frame) then
                    self.frames:destroy(frame)
                end
            end,
            BlzFrameGetName = function(frame) return isFrame(frame) and frame.name or "" end,
            BlzFrameGetParent = function(frame)
                local ____isFrame_result_44
                if isFrame(frame) then
                    ____isFrame_result_44 = frame.parent
                else
                    ____isFrame_result_44 = nil
                end
                return ____isFrame_result_44
            end,
            BlzFrameSetText = function(frame, text)
                if isFrame(frame) then
                    frame.text = frame.textLimit >= 0 and __TS__StringSlice(text, 0, frame.textLimit) or text
                end
            end,
            BlzFrameGetText = function(frame) return isFrame(frame) and frame.text or "" end,
            BlzFrameSetTexture = function(frame, texture)
                if isFrame(frame) then
                    frame.texture = texture
                end
            end,
            BlzFrameSetVertexColor = function(frame, color)
                if isFrame(frame) then
                    frame.color = color
                end
            end,
            BlzFrameSetTextColor = function(frame, color)
                if isFrame(frame) then
                    frame.textColor = color
                end
            end,
            BlzFrameSetAlpha = function(frame, alpha)
                if isFrame(frame) then
                    frame.alpha = alpha
                end
            end,
            BlzFrameGetAlpha = function(frame) return isFrame(frame) and frame.alpha or 0 end,
            BlzFrameSetTextSizeLimit = function(frame, size)
                if isFrame(frame) then
                    frame.textLimit = size
                end
            end,
            BlzFrameGetTextSizeLimit = function(frame) return isFrame(frame) and frame.textLimit or 0 end,
            BlzFrameSetFont = function(frame, file, height, flags)
                if isFrame(frame) then
                    frame.font = {file = file, height = height, flags = flags}
                end
            end,
            BlzFrameSetTextAlignment = function(frame, vertical, horizontal)
                if isFrame(frame) then
                    frame.alignment = {vertical = vertical, horizontal = horizontal}
                end
            end,
            BlzFrameSetVisible = function(frame, visible)
                if isFrame(frame) then
                    frame.visible = visible
                end
            end,
            BlzFrameIsVisible = function(frame)
                local ____isFrame_result_45
                if isFrame(frame) then
                    ____isFrame_result_45 = self.frames:shown(frame)
                else
                    ____isFrame_result_45 = false
                end
                return ____isFrame_result_45
            end,
            BlzFrameSetEnable = function(frame, enabled)
                if isFrame(frame) then
                    frame.enabled = enabled
                end
            end,
            BlzFrameGetEnable = function(frame)
                local ____isFrame_result_46
                if isFrame(frame) then
                    ____isFrame_result_46 = frame.enabled
                else
                    ____isFrame_result_46 = false
                end
                return ____isFrame_result_46
            end,
            BlzFrameSetFocus = function(frame, flag)
                if isFrame(frame) then
                    self.frames:focus(frame, flag)
                end
            end,
            BlzFrameSetLevel = function(frame, level)
                if isFrame(frame) then
                    frame.level = level
                end
            end,
            BlzFrameSetSize = function(frame, width, height)
                if isFrame(frame) then
                    frame.width = width
                    frame.height = height
                end
            end,
            BlzFrameSetAbsPoint = function(frame, point, x, y)
                if isFrame(frame) then
                    frame.points:set(point, {x = x, y = y})
                end
            end,
            BlzFrameClearAllPoints = function(frame)
                if isFrame(frame) then
                    frame.points:clear()
                    __TS__ArraySetLength(frame.anchors, 0)
                end
            end,
            BlzFrameSetPoint = function(frame, point, relative, relativePoint, x, y)
                if not isFrame(frame) or not isFrame(relative) then
                    return
                end
                local function name(value)
                    local ____temp_49
                    if type(value) == "number" then
                        local ____opt_47 = FRAME_POINTS[value + 1]
                        ____temp_49 = ____opt_47 and ____opt_47[1] or ""
                    else
                        ____temp_49 = type(value) == "string" and value or ""
                    end
                    return ____temp_49
                end
                local ownPoint = __TS__StringReplace(
                    name(point),
                    "FRAMEPOINT_",
                    ""
                )
                do
                    local index = #frame.anchors - 1
                    while index >= 0 do
                        local ____opt_50 = frame.anchors[index + 1]
                        if (____opt_50 and ____opt_50.point) == ownPoint then
                            __TS__ArraySplice(frame.anchors, index, 1)
                        end
                        index = index - 1
                    end
                end
                local ____frame_anchors_52 = frame.anchors
                ____frame_anchors_52[#____frame_anchors_52 + 1] = {
                    point = ownPoint,
                    relative = relative,
                    relativePoint = __TS__StringReplace(
                        name(relativePoint),
                        "FRAMEPOINT_",
                        ""
                    ),
                    x = x,
                    y = y
                }
            end,
            BlzFrameSetAllPoints = function(frame, relative)
                if not isFrame(frame) or not isFrame(relative) then
                    return false
                end
                frame.points:clear()
                __TS__ArraySetLength(frame.anchors, 0)
                for ____, point in ipairs({"TOPLEFT", "BOTTOMRIGHT"}) do
                    local ____frame_anchors_53 = frame.anchors
                    ____frame_anchors_53[#____frame_anchors_53 + 1] = {
                        point = point,
                        relative = relative,
                        relativePoint = point,
                        x = 0,
                        y = 0
                    }
                end
                return true
            end,
            BlzTriggerRegisterFrameEvent = function(trigger, frame, event)
                if isFrame(frame) then
                    local ____self_registrations_54 = self.registrations
                    ____self_registrations_54[#____self_registrations_54 + 1] = {kind = "frame", trigger = trigger, frame = frame, event = event}
                end
                return self:handle("event")
            end,
            BlzGetTriggerFrame = function() return self.event.frame end,
            BlzGetTriggerFrameEvent = function() return self.event.frameEvent end,
            BlzGetTriggerFrameText = function()
                local ____opt_55 = self.event.frame
                return ____opt_55 and ____opt_55.text or ""
            end,
            BlzGetTriggerSyncData = function() return self.event.syncData end,
            BlzGetTriggerSyncPrefix = function() return self.event.syncPrefix end,
            GetEventPlayerChatString = function() return self.event.chat end,
            BlzGetTriggerPlayerKey = function() return self.event.key end,
            GetExpiredTimer = function() return self.event.timer end,
            CreateTrigger = function() return __TS__ObjectAssign(
                {},
                self:handle("trigger"),
                {actions = {}, destroyed = false, running = false, interrupted = false}
            ) end,
            BlzTriggerIsRunning = function(trigger) return trigger.running end,
            BlzTriggerInterrupt = function(trigger)
                trigger.interrupted = true
            end,
            DestroyTrigger = function(trigger)
                trigger.destroyed = true
            end,
            TriggerAddAction = function(trigger, action)
                local ____trigger_actions_57 = trigger.actions
                ____trigger_actions_57[#____trigger_actions_57 + 1] = action
                return self:handle("triggeraction")
            end,
            BlzTriggerRegisterPlayerSyncEvent = function(trigger, player, prefix)
                local ____self_registrations_58 = self.registrations
                ____self_registrations_58[#____self_registrations_58 + 1] = {kind = "sync", trigger = trigger, player = player, prefix = prefix}
                return self:handle("event")
            end,
            TriggerRegisterPlayerChatEvent = function(trigger, player, text, exact)
                local ____self_registrations_59 = self.registrations
                ____self_registrations_59[#____self_registrations_59 + 1] = {
                    kind = "chat",
                    trigger = trigger,
                    player = player,
                    text = text,
                    exact = exact
                }
                return self:handle("event")
            end,
            BlzTriggerRegisterPlayerKeyEvent = function(trigger, player, key, meta, down)
                local ____self_registrations_60 = self.registrations
                ____self_registrations_60[#____self_registrations_60 + 1] = {
                    kind = "key",
                    trigger = trigger,
                    player = player,
                    key = key,
                    meta = meta,
                    down = down
                }
                return self:handle("event")
            end,
            CreateTimer = function()
                local timer = __TS__ObjectAssign(
                    {},
                    self:handle("timer"),
                    {
                        callback = nil,
                        periodic = false,
                        timeout = 0,
                        period = 0,
                        due = 0,
                        order = 0,
                        running = false,
                        expired = false,
                        paused = nil
                    }
                )
                local ____self_timers_61 = self.timers
                ____self_timers_61[#____self_timers_61 + 1] = timer
                return timer
            end,
            TimerStart = function(timer, timeout, periodic, callback)
                local seconds = roundToFloat32(timeout)
                local shortest = periodic and MIN_PERIOD or MIN_ONE_SHOT
                timer.callback = callback
                timer.periodic = periodic
                timer.timeout = seconds
                timer.period = seconds >= shortest and seconds or shortest
                timer.due = after(self.now, timer.period)
                local ____timer_65 = timer
                local ____self_62, ____timerOrder_63 = self, "timerOrder"
                local ____self_timerOrder_64 = ____self_62[____timerOrder_63] + 1
                ____self_62[____timerOrder_63] = ____self_timerOrder_64
                ____timer_65.order = ____self_timerOrder_64
                timer.running = true
                timer.expired = false
                timer.paused = nil
            end,
            PauseTimer = function(timer)
                if timer.running then
                    timer.paused = self:timerElapsed(timer)
                end
                timer.running = false
            end,
            DestroyTimer = function(timer)
                timer.running = false
                local index = __TS__ArrayIndexOf(self.timers, timer)
                if index >= 0 then
                    __TS__ArraySplice(self.timers, index, 1)
                end
            end,
            TimerGetElapsed = function(timer) return self:timerElapsed(timer) end,
            BlzSendSyncData = function(prefix, data)
                network[#network + 1] = {
                    sender = self.slot,
                    prefix = prefix,
                    data = __TS__StringSlice(data, 0, SYNC_DATA_LIMIT)
                }
                return true
            end,
            DisplayTextToPlayer = function(player, _x, _y, text)
                if player == self.slot then
                    self:show(text)
                end
            end,
            DisplayTimedTextToPlayer = function(player, _x, _y, _duration, text)
                if player == self.slot then
                    self:show(text)
                end
            end,
            DisplayTextToForce = function(_force, text) return self:show(text) end,
            PreloadGenClear = function()
                self.preload = {}
            end,
            PreloadGenStart = function() return nil end,
            Preload = function(line)
                local ____self_preload_66 = self.preload
                ____self_preload_66[#____self_preload_66 + 1] = line
            end,
            PreloadGenEnd = function(name)
                self.files:set(name, self.preload)
                if name == errorFile(self.slot, self.filePrefix) then
                    self:report(self.preload)
                end
                local ____opt_67 = self.stored
                if ____opt_67 ~= nil then
                    ____opt_67.written(name, self.preload)
                end
            end,
            Preloader = function(name)
                local ____temp_71 = self.preloaded:get(name) or self.published:get(name)
                if ____temp_71 == nil then
                    local ____opt_69 = self.stored
                    ____temp_71 = ____opt_69 and ____opt_69.read(name)
                end
                local chunks = ____temp_71
                if chunks == nil then
                    self.missedLookups = self.missedLookups + 1
                    return
                end
                self.preloaded:set(name, chunks)
                do
                    local level = 0
                    while level < #chunks do
                        self.tooltips:set(
                            (tostring(FILE_IO_ABILITY) .. " ") .. tostring(level),
                            chunks[level + 1] or ""
                        )
                        level = level + 1
                    end
                end
            end,
            BlzSetAbilityTooltip = function(ability, text, level)
                self.tooltips:set(
                    (tostring(ability) .. " ") .. tostring(level),
                    text
                )
            end,
            BlzGetAbilityTooltip = function(ability, level) return self.tooltips:get((tostring(ability) .. " ") .. tostring(level)) or "" end,
            AddSpecialEffect = function(model, x, y) return self:effectAt(model, x, y) end,
            SetCameraPosition = function(x, y)
                self.cameraX = x
                self.cameraY = y
            end,
            SetCameraTargetController = function()
                self.scenery.cameraAllowsHotkeyTargetLock = false
            end,
            SetCameraOrientController = function()
                self.scenery.cameraAllowsHotkeyTargetLock = false
            end,
            SetCameraField = function(field, value)
                self.cameraFields[self:cameraField(field)] = value
            end,
            GetCameraField = function(field) return self.cameraFields[self:cameraField(field)] or 0 end,
            CreateSound = function(source, loop) return self:sound(source, nil, loop) end,
            CreateSoundFromLabel = function(label, loop) return self:sound(nil, label, loop) end,
            CreateSoundFilenameWithLabel = function(source, loop, _is3D, _stop, _fadeIn, _fadeOut, label) return self:sound(source, label, loop) end,
            SetSoundDuration = function(handle, duration)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.duration = math.max(0, duration)
                end
            end,
            GetSoundDuration = function(handle)
                local ____opt_72 = self.sounds:get(handle)
                return ____opt_72 and ____opt_72.duration or 0
            end,
            GetSoundIsPlaying = function(handle)
                local sound = self.sounds:get(handle)
                return sound ~= nil and sound.playing and not sound.killWhenDone
            end,
            KillSoundWhenDone = function(handle)
                local sound = self.sounds:get(handle)
                if sound == nil then
                    return
                end
                sound.killWhenDone = true
                if not sound.playing then
                    self.sounds:delete(handle)
                end
            end,
            StopSound = function(handle, killWhenDone)
                local sound = self.sounds:get(handle)
                if sound == nil then
                    return
                end
                self:stopAudio(sound)
                if killWhenDone or sound.killWhenDone then
                    self.sounds:delete(handle)
                end
            end,
            SetSoundParamsFromLabel = function(handle, label)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.label = label
                end
            end,
            SetSoundVolume = function(handle, volume)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.volume = math.max(
                        0,
                        math.min(127, volume)
                    )
                    if sound.playing then
                        self:cue(sound, "volume")
                    end
                end
            end,
            PlayMusic = function(source) return self:playMusic(source) end,
            PlayMusicEx = function(source) return self:playMusic(source) end,
            StopMusic = function()
                if self.music ~= nil then
                    self:stopAudio(self.music)
                end
            end,
            ResumeMusic = function()
                if self.music == nil or self.music.playing then
                    return
                end
                self.music.playing = true
                self:cue(self.music, "start")
            end,
            SetMusicVolume = function(volume)
                self.musicVolume = math.max(
                    0,
                    math.min(127, volume)
                )
                if self.music ~= nil then
                    self.music.volume = self.musicVolume
                    if self.music.playing then
                        self:cue(self.music, "volume")
                    end
                end
            end,
            SetSoundPitch = function(handle, pitch)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.pitch = pitch
                end
            end,
            SetSoundPosition = function(handle, x, y, z)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.x = x
                    sound.y = y
                    sound.z = z
                    sound.unit = nil
                end
            end,
            AttachSoundToUnit = function(handle, unit)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.unit = unit
                end
            end,
            StartSound = function(handle) return self:startSound(handle) end,
            StartSoundEx = function(handle) return self:startSound(handle) end,
            AddSpecialEffectLoc = function(model) return self:effectAt(model, 0, 0) end,
            AddSpecialEffectTarget = function(model) return self:effectAt(model, 0, 0) end,
            DestroyEffect = function(effect) return self:destroyEffect(effect) end,
            BlzRemoveEffect = function(effect)
                if self:liveEffect(effect) ~= nil then
                    self.effects:delete(effect)
                end
            end,
            BlzSetSpecialEffectAnimationBlendTime = function(effect, time)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.animationBlendTime = time
                end
            end,
            BlzSetSpecialEffectAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    __TS__ArraySetLength(pose.queuedAnimations, 0)
                    self:playEffect(effect, animation)
                end
            end,
            BlzQueueSpecialEffectAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    local ____pose_queuedAnimations_74 = pose.queuedAnimations
                    ____pose_queuedAnimations_74[#____pose_queuedAnimations_74 + 1] = animation
                end
            end,
            BlzSetSpecialEffectPosition = function(effect, x, y, z)
                local pose = self:liveEffect(effect)
                if pose == nil then
                    return
                end
                pose.x = x
                pose.y = y
                pose.z = z
            end,
            BlzSetSpecialEffectX = function(effect, x)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.x = x
                end
            end,
            BlzSetSpecialEffectY = function(effect, y)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.y = y
                end
            end,
            BlzSetSpecialEffectZ = function(effect, z)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.z = z
                end
            end,
            BlzSetSpecialEffectAlpha = function(effect, alpha)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.alpha = alpha
                end
            end,
            BlzSetSpecialEffectScale = function(effect, scale)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.scale = scale
                end
            end,
            BlzSetSpecialEffectTimeScale = function(effect, timeScale)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.timeScale = timeScale
                end
            end,
            BlzSetSpecialEffectTime = function(effect, time)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    seekAnimation(pose, time)
                end
            end,
            BlzPlaySpecialEffect = function(effect, animation) return self:playEffect(effect, animation) end,
            BlzPlaySpecialEffectWithTimeScale = function(effect, animation, timeScale) return self:playEffect(effect, animation, timeScale) end,
            BlzSpecialEffectClearSubAnimations = function(effect)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    __TS__ArraySetLength(pose.subAnimations, 0)
                end
            end,
            BlzSpecialEffectAddSubAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose ~= nil and not __TS__ArrayIncludes(pose.subAnimations, animation) then
                    local ____pose_subAnimations_75 = pose.subAnimations
                    ____pose_subAnimations_75[#____pose_subAnimations_75 + 1] = animation
                end
            end,
            BlzSpecialEffectRemoveSubAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose == nil then
                    return
                end
                local index = __TS__ArrayIndexOf(pose.subAnimations, animation)
                if index >= 0 then
                    __TS__ArraySplice(pose.subAnimations, index, 1)
                end
            end,
            BlzSetSpecialEffectOrientation = function(effect, yaw, pitch, roll)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.yaw = yaw
                    pose.pitch = pitch
                    pose.roll = roll
                end
            end,
            BlzSetSpecialEffectYaw = function(effect, yaw)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.yaw = yaw
                end
            end,
            BlzSetSpecialEffectPitch = function(effect, pitch)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.pitch = pitch
                end
            end,
            BlzSetSpecialEffectRoll = function(effect, roll)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.roll = roll
                end
            end,
            BlzSetSpecialEffectColor = function(effect, r, g, b)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.color = {r, g, b}
                end
            end,
            BlzSetSpecialEffectColorByPlayer = function(effect, player)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.teamColor = player
                end
            end,
            BlzSetSpecialEffectMatrixScale = function(effect, x, y, z)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.matrixScale = {
                        __wispF32Multiply(pose.matrixScale[1], x),
                        __wispF32Multiply(pose.matrixScale[2], y),
                        __wispF32Multiply(pose.matrixScale[3], z)
                    }
                    pose.flat = __TS__ArrayIncludes(pose.matrixScale, 0)
                end
            end,
            BlzResetSpecialEffectMatrix = function(effect)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.flat = false
                    pose.matrixScale = {1, 1, 1}
                    pose.yaw = 0
                    pose.pitch = 0
                    pose.roll = 0
                end
            end,
            BlzGetLocalSpecialEffectX = function(effect)
                local ____opt_76 = self.effects:get(effect)
                return ____opt_76 and ____opt_76.x or 0
            end,
            BlzGetLocalSpecialEffectY = function(effect)
                local ____opt_78 = self.effects:get(effect)
                return ____opt_78 and ____opt_78.y or 0
            end,
            BlzGetLocalSpecialEffectZ = function(effect)
                local ____opt_80 = self.effects:get(effect)
                return ____opt_80 and ____opt_80.z or 0
            end,
            I2S = function(n) return ____exports.describeNumber(n) end,
            R2S = function(n) return fixed(n, 3) end,
            R2SW = function(n, width, precision)
                local text = fixed(n, precision > 0 and precision or 0)
                if precision <= 0 then
                    text = text .. ".0"
                end
                while #text < width + 1 do
                    text = " " .. text
                end
                return text
            end,
            R2I = function(n) return n < 0 and math.ceil(n) or math.floor(n) end,
            I2R = function(n) return n end,
            S2I = function(text)
                local value = leadingNumber(text, false)
                return value < 0 and math.ceil(value) or math.floor(value)
            end,
            S2R = function(text) return leadingNumber(text, true) end,
            SubString = function(text, start, ____end) return __TS__StringSubstring(text, start, ____end) end,
            StringLength = function(text) return #text end,
            SquareRoot = function(n) return math.sqrt(n) end,
            Atan2 = function(y, x) return math.atan(y, x) end,
            BlzBitAnd = function(a, b) return a & b end,
            BlzBitOr = function(a, b) return a | b end,
            BlzBitXor = function(a, b) return a ~ b end
        }
    )
end
function HeadlessClient.prototype.preloadedFiles(self)
    return {__TS__Spread(self.preloaded:keys())}
end
function HeadlessClient.prototype.effectPoses(self, options)
    if options == nil then
        options = {}
    end
    local poses = {}
    for ____, pose in __TS__Iterator(self.effects:values()) do
        if options.visibleOnly ~= true or pose.alpha > 0 and pose.scale > 0 and not pose.flat then
            poses[#poses + 1] = __TS__ObjectAssign(
                {},
                pose,
                {
                    subAnimations = {table.unpack(pose.subAnimations)},
                    animationBlend = copyBlend(pose.animationBlend),
                    color = {table.unpack(pose.color)},
                    matrixScale = {table.unpack(pose.matrixScale)}
                }
            )
        end
    end
    return poses
end
function HeadlessClient.prototype.cameraPose(self)
    return {
        x = self.cameraX,
        y = self.cameraY,
        fields = __TS__ObjectAssign({}, self.cameraFields)
    }
end
function HeadlessClient.prototype.unitPoses(self)
    local poses = {}
    for ____, unit in __TS__Iterator(self.units:values()) do
        poses[#poses + 1] = {
            handle = unit.handle,
            typeId = unit.typeId,
            owner = unit.owner,
            x = unit.x,
            y = unit.y,
            z = unit.z,
            facing = unit.facing,
            scale = {table.unpack(unit.scale)},
            alpha = unit.alpha,
            color = {table.unpack(unit.color)},
            teamColor = unit.teamColor,
            timeScale = unit.timeScale,
            visible = unit.visible,
            animation = unit.animation,
            subAnimations = {table.unpack(unit.subAnimations)},
            animationElapsed = unit.animationElapsed,
            animationClock = unit.animationClock,
            animationBlendTime = unit.animationBlendTime,
            animationBlend = copyBlend(unit.animationBlend)
        }
    end
    return poses
end
function HeadlessClient.prototype.run(self, body)
    local ____opt_82 = self.scope
    if ____opt_82 ~= nil then
        ____opt_82.enter(self)
    end
    do
        local ____try, ____error = pcall(function()
            body()
        end)
        do
            local ____opt_84 = self.scope
            if ____opt_84 ~= nil then
                ____opt_84.leave(self)
            end
        end
        if not ____try then
            error(____error, 0)
        end
    end
end
function HeadlessClient.prototype.fire(self, trigger, event)
    if trigger.destroyed then
        return
    end
    if event.player ~= nil then
        self.event.player = event.player
    end
    if event.syncPrefix ~= nil then
        self.event.syncPrefix = event.syncPrefix
    end
    if event.syncData ~= nil then
        self.event.syncData = event.syncData
    end
    if event.chat ~= nil then
        self.event.chat = event.chat
    end
    if event.key ~= nil then
        self.event.key = event.key
    end
    if event.frame ~= nil then
        self.event.frame = event.frame
    end
    if event.frameEvent ~= nil then
        self.event.frameEvent = event.frameEvent
    end
    local running = trigger.running
    local interrupted = trigger.interrupted
    trigger.running = true
    trigger.interrupted = false
    do
        local ____try, ____error = pcall(function()
            for ____, action in ipairs(trigger.actions) do
                if trigger.interrupted then
                    break
                end
                action()
            end
        end)
        do
            trigger.running = running
            trigger.interrupted = interrupted
        end
        if not ____try then
            error(____error, 0)
        end
    end
end
function HeadlessClient.prototype.step(self)
    self.frame = self.frame + 1
    self.abilities:tick(__wispF32Divide(1, ____exports.FRAMES_PER_SECOND))
    self.scenery:tick(__wispF32Divide(1, ____exports.FRAMES_PER_SECOND))
    local died = {}
    for ____, pose in __TS__Iterator(self.effects:values()) do
        advanceAnimation(
            pose,
            pose.timeScale,
            __wispF32Divide(1, ____exports.FRAMES_PER_SECOND)
        )
        if pose.destroyed ~= nil and self.frame - pose.destroyed >= 5 * ____exports.FRAMES_PER_SECOND then
            died[#died + 1] = pose.handle
        end
    end
    for ____, handle in ipairs(died) do
        self.effects:delete(handle)
    end
    for ____, unit in __TS__Iterator(self.units:values()) do
        advanceAnimation(
            unit,
            unit.timeScale,
            __wispF32Divide(1, ____exports.FRAMES_PER_SECOND)
        )
    end
    for ____, sound in __TS__Iterator(self.sounds:values()) do
        do
            if not sound.playing or sound.looping then
                goto __continue474
            end
            sound.elapsed = sound.elapsed + sound.pitch * 1000 / ____exports.FRAMES_PER_SECOND
            if sound.elapsed < sound.duration then
                goto __continue474
            end
            self:stopAudio(sound)
            if sound.killWhenDone then
                self.sounds:delete(sound.handle)
            end
        end
        ::__continue474::
    end
    self:run(function() return self:runDueTimers() end)
    for ____, unit in ipairs(self.removals) do
        unit.removed = true
    end
    self.removals = {}
end
function HeadlessClient.prototype.timerElapsed(self, timer)
    if timer.paused ~= nil then
        return timer.paused
    end
    if timer.expired then
        return timer.timeout
    end
    if not timer.running then
        return 0
    end
    local remaining = timer.due > self.now and subtractFloat32TowardZero(timer.due, self.now) or 0
    return remaining < timer.period and subtractFloat32TowardZero(timer.period, remaining) or 0
end
function HeadlessClient.prototype.runDueTimers(self)
    local ____end = frameEnd(self.frame)
    self.now = ____end
    do
        while true do
            local next
            for ____, timer in ipairs(self.timers) do
                do
                    if not timer.running or timer.callback == nil or timer.due > ____end then
                        goto __continue489
                    end
                    if next == nil or timer.due < next.due or timer.due == next.due and timer.order < next.order then
                        next = timer
                    end
                end
                ::__continue489::
            end
            if next == nil or next.callback == nil then
                break
            end
            self.now = next.due
            if next.periodic then
                next.due = after(next.due, next.period)
            else
                next.running = false
                next.expired = true
            end
            self.event.timer = next
            do
                local ____try, ____error = pcall(function()
                    next.callback()
                end)
                do
                    self.now = ____end
                end
                if not ____try then
                    error(____error, 0)
                end
            end
        end
    end
end
function HeadlessClient.prototype.deliverSync(self, ____bindingPattern0)
    local data
    local prefix
    local sender
    sender = ____bindingPattern0.sender
    prefix = ____bindingPattern0.prefix
    data = ____bindingPattern0.data
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "sync" and registration.player == sender and registration.prefix == prefix then
                self:fire(registration.trigger, {player = sender, syncPrefix = prefix, syncData = data})
            end
        end
    end)
end
function HeadlessClient.prototype.chat(self, sender, message)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            do
                if registration.kind ~= "chat" or registration.player ~= sender then
                    goto __continue505
                end
                local ____registration_exact_86
                if registration.exact then
                    ____registration_exact_86 = message == registration.text
                else
                    ____registration_exact_86 = __TS__StringIncludes(message, registration.text)
                end
                if ____registration_exact_86 then
                    self:fire(registration.trigger, {player = sender, chat = message})
                end
            end
            ::__continue505::
        end
    end)
end
function HeadlessClient.prototype.key(self, sender, key, meta, down)
    if sender == self.slot then
        self.heldMeta = meta
        if down then
            self.heldKeys:add(key)
        else
            self.heldKeys:delete(key)
        end
    end
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "key" and registration.player == sender and registration.key == key and registration.meta == meta and registration.down == down then
                self:fire(registration.trigger, {player = sender, key = key})
            end
        end
    end)
end
function HeadlessClient.prototype.type(self, text)
    return self.frames:type(text)
end
function HeadlessClient.prototype.clickTarget(self, x, y)
    local click = self.natives.FRAMEEVENT_CONTROL_CLICK
    return self.frames:at(
        x,
        y,
        function(frame) return __TS__ArraySome(
            self.registrations,
            function(____, registration) return registration.kind == "frame" and registration.frame == frame and registration.event == click and not registration.trigger.destroyed end
        ) end
    )
end
function HeadlessClient.prototype.frameEvent(self, sender, id, event)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "frame" and registration.frame.id == id and registration.event == event then
                self:fire(registration.trigger, {player = sender, frame = registration.frame, frameEvent = event})
            end
        end
    end)
end
function HeadlessClient.prototype.callCount(self)
    return self.forgotten + #self.log
end
function HeadlessClient.prototype.forget(self, count)
    local hash = self.forgottenHash
    do
        local index = 0
        while index < count do
            local call = self.log[index + 1]
            if call ~= nil then
                hash = mixCall(hash, call)
            end
            index = index + 1
        end
    end
    self.forgottenHash = hash
    __TS__ArraySplice(self.log, 0, count)
    self.forgotten = self.forgotten + count
end
function HeadlessClient.prototype.checksum(self)
    local hash = self.forgottenHash
    for ____, call in ipairs(self.log) do
        hash = mixCall(hash, call)
    end
    return ____exports.describeNumber(hash)
end
return ____exports
