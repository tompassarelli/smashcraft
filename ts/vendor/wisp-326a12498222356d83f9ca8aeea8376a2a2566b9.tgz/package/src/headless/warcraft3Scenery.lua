local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local ____exports = {}
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
--- Map data supplies facts which Warcraft would read from its assets.
____exports.Scenery = __TS__Class()
local Scenery = ____exports.Scenery
Scenery.name = "Scenery"
function Scenery.prototype.____constructor(self, fixtures)
    if fixtures == nil then
        fixtures = {}
    end
    self.fixtures = fixtures
    self.destructables = __TS__New(Map)
    self.fog = {}
    self.water = {}
    self.cameraInput = __TS__New(Map)
    self.cameraSetups = __TS__New(Map)
    self.cameraBlockers = __TS__New(Map)
    self.cameraType = 0
    self.cameraAllowsHotkeyTargetLock = true
    self.terrainShown = true
    self.minShadowCastingPointLightCount = 0
    self.cinematicEnabledDE = true
    self.thematicMusicPauseOnFocusLost = false
    self.doodads = __TS__ArrayMap(
        fixtures.doodads or ({}),
        function(____, d) return __TS__ObjectAssign({}, d) end
    )
    self.hudScale = fixtures.hudScale or 1
end
function Scenery.prototype.tick(self, seconds)
    if self.cinematic ~= nil then
        self.cinematic.elapsed = __wispF32Add(self.cinematic.elapsed, seconds)
    end
end
function Scenery.prototype.shots(self, model)
    local ____opt_0 = self.fixtures.cinematics
    local shots = ____opt_0 and ____opt_0[model]
    if shots == nil then
        do
            local ____thrown = __TS__New(Error, ("cinematic " .. model) .. " needs a scenery.cinematics fixture")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Scenery.ts:84"
            end
            error(____thrown, 0)
        end
    end
    return shots
end
function Scenery.prototype.currentShot(self)
    local cinematic = self.cinematic
    if cinematic == nil then
        return 0
    end
    local ____end = 0
    do
        local i = 0
        while i < #cinematic.shots do
            ____end = __wispF32Add(____end, cinematic.shots[i + 1] or 0)
            if cinematic.elapsed < ____end then
                return i
            end
            i = i + 1
        end
    end
    return #cinematic.shots
end
function Scenery.prototype.remaining(self)
    local cinematic = self.cinematic
    if cinematic == nil then
        return 0
    end
    local total = 0
    for ____, seconds in ipairs(cinematic.shots) do
        total = __wispF32Add(total, seconds)
    end
    return math.max(
        0,
        __wispF32Subtract(total, cinematic.elapsed)
    )
end
function Scenery.prototype.select(self, x, y, radius, id, nearestOnly)
    local selected = {}
    local nearest
    local distance = radius * radius
    for ____, doodad in ipairs(self.doodads) do
        do
            local dx = doodad.x - x
            local dy = doodad.y - y
            local square = dx * dx + dy * dy
            if doodad.id ~= id or square > radius * radius then
                goto __continue18
            end
            if not nearestOnly then
                selected[#selected + 1] = doodad
            elseif nearest == nil or square < distance then
                nearest = doodad
                distance = square
            end
        end
        ::__continue18::
    end
    if nearestOnly and nearest ~= nil then
        selected[#selected + 1] = nearest
    end
    return selected
end
function Scenery.prototype.inRect(self, rect, id)
    return __TS__ArrayFilter(
        self.doodads,
        function(____, d) return d.id == id and d.x >= rect.minX and d.x <= rect.maxX and d.y >= rect.minY and d.y <= rect.maxY end
    )
end
function Scenery.prototype.behaviors(self, context)
    local behaviors = {
        Rect = function(minX, minY, maxX, maxY) return __TS__ObjectAssign(
            {},
            context.handle("rect"),
            {minX = minX, minY = minY, maxX = maxX, maxY = maxY}
        ) end,
        SetTerrainFogExV = function(style, zstart, zend, density, heightStart, heightEnd, linearStart, linearEnd, red, green, blue)
            self.fog.style = style
            self.fog.zStart = zstart
            self.fog.zEnd = zend
            self.fog.density = density
            self.fog.heightStart = heightStart
            self.fog.heightEnd = heightEnd
            self.fog.linearStart = linearStart
            self.fog.linearEnd = linearEnd
            self.fog.color = {red, green, blue}
        end,
        SetSkyModel = function(model)
            self.sky = model
        end,
        BlzShowTerrain = function(show)
            self.terrainShown = show
        end,
        BlzSetTerrainFogColor = function(red, green, blue)
            self.fog.color = {red, green, blue}
        end,
        BlzSetMinShadowCastingPointLightCount = function(count)
            self.minShadowCastingPointLightCount = count
        end,
        BlzGetMinShadowCastingPointLightCount = function() return self.minShadowCastingPointLightCount end,
        SetCameraFieldControlledByInput = function(field, controlled)
            self.cameraInput:set(field, controlled)
        end,
        GetCameraFieldControlledByInput = function(field)
            local ____temp_2 = self.cameraInput:get(field)
            if ____temp_2 == nil then
                ____temp_2 = false
            end
            return ____temp_2
        end,
        BlzCameraSetCameraType = function(____type)
            self.cameraType = ____type
        end,
        BlzCameraGetCameraType = function() return self.cameraType end,
        BlzCameraSetupSetCameraType = function(setup, ____type)
            self.cameraSetups:set(setup, ____type)
        end,
        BlzCameraSetupGetCameraType = function(setup) return self.cameraSetups:get(setup) or 0 end,
        AddCameraBlocker = function(rect)
            self.cameraBlockers:set(rect, true)
        end,
        EnableCameraBlocker = function(rect, flag)
            self.cameraBlockers:set(rect, flag)
        end,
        BlzGetCameraAllowsHotkeyTargetLock = function() return self.cameraAllowsHotkeyTargetLock end,
        BlzSetCameraAllowsHotkeyTargetLock = function(allows)
            self.cameraAllowsHotkeyTargetLock = allows
        end,
        BlzGetHUDScale = function() return self.hudScale end,
        BlzPreloadModelCinematicGame = function(model)
            self:shots(model)
            self.preloadedCinematic = model
            return true
        end,
        BlzGetModelCinematicGameShotCount = function()
            local ____opt_3 = self.cinematic
            return ____opt_3 and #____opt_3.shots or (self.preloadedCinematic == nil and 0 or #self:shots(self.preloadedCinematic))
        end,
        BlzGetModelCinematicGameCurrentShot = function() return self:currentShot() end,
        BlzGetModelCinematicGameRemainingTime = function() return self:remaining() end,
        BlzPlayModelCinematicGameAtPosition = function(model, x, y, z, rotation)
            self.cinematic = {
                model = model,
                x = x,
                y = y,
                z = z,
                rotation = rotation,
                elapsed = 0,
                shots = self:shots(model)
            }
        end,
        BlzSetCinematicEnabledDE = function(enable)
            self.cinematicEnabledDE = enable
        end,
        BlzPauseThematicMusicOnFocusLost = function(pause)
            self.thematicMusicPauseOnFocusLost = pause
        end,
        BlzSetThematicMusicAbsoluteVolume = function(volume)
            self.thematicMusicAbsoluteVolume = volume
        end,
        SetHDWaterParams = function(red, green, blue, override, vertexDisplacement, minOpacity, maxOpacity, reflectivity, emissivity, edgeSoftness, waveStrength)
            self.water.color = {red, green, blue}
            self.water.override = override
            self.water.vertexDisplacement = vertexDisplacement
            self.water.minOpacity = minOpacity
            self.water.maxOpacity = maxOpacity
            self.water.reflectivity = reflectivity
            self.water.emissivity = emissivity
            self.water.edgeSoftness = edgeSoftness
            self.water.waveStrength = waveStrength
        end,
        SetHDWaterParamsEx = function(red, green, blue, override, vertexDisplacement, minOpacity, maxOpacity, reflectivity, emissivity, edgeSoftness, waveStrength, envMapStrength)
            self.water.color = {red, green, blue}
            self.water.override = override
            self.water.vertexDisplacement = vertexDisplacement
            self.water.minOpacity = minOpacity
            self.water.maxOpacity = maxOpacity
            self.water.reflectivity = reflectivity
            self.water.emissivity = emissivity
            self.water.edgeSoftness = edgeSoftness
            self.water.waveStrength = waveStrength
            self.water.envMapStrength = envMapStrength
        end,
        BlzSetHDWaterColor = function(red, green, blue)
            self.water.color = {red, green, blue}
        end,
        BlzIsTerrainPathableEx = function(x, y, ____type)
            local ____opt_5 = self.fixtures.pathing
            local cell = ____opt_5 and __TS__ArrayFind(
                self.fixtures.pathing,
                function(____, c) return c.x == x and c.y == y and c.type == ____type end
            )
            if cell == nil then
                do
                    local ____thrown = __TS__New(
                        Error,
                        ((("terrain pathing at " .. tostring(x)) .. ",") .. tostring(y)) .. " needs a scenery.pathing fixture"
                    )
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/warcraft3Scenery.ts:167"
                    end
                    error(____thrown, 0)
                end
            end
            return cell.blocked
        end,
        BlzGetNumDoodads = function() return #self.doodads end,
        BlzSetSingleDoodadAnimation = function(index, animation, random)
            local d = self.doodads[index + 1]
            if d ~= nil then
                d.animation = animation
                d.animationRandom = random
            end
        end,
        SetDoodadAnimation = function(x, y, radius, id, nearestOnly, animation, random)
            for ____, d in ipairs(self:select(
                x,
                y,
                radius,
                id,
                nearestOnly
            )) do
                d.animation = animation
                d.animationRandom = random
            end
        end,
        SetDoodadAnimationRect = function(rect, id, animation, random)
            for ____, d in ipairs(self:inRect(rect, id)) do
                d.animation = animation
                d.animationRandom = random
            end
        end,
        BlzSetSingleDoodadColor = function(index, color)
            local d = self.doodads[index + 1]
            if d ~= nil then
                d.color = color
            end
        end,
        SetDoodadColor = function(x, y, radius, id, nearestOnly, color)
            for ____, d in ipairs(self:select(
                x,
                y,
                radius,
                id,
                nearestOnly
            )) do
                d.color = color
            end
        end,
        SetDoodadColorRect = function(rect, id, color)
            for ____, d in ipairs(self:inRect(rect, id)) do
                d.color = color
            end
        end,
        SetDestructableColor = function(d, color)
            local state = self.destructables:get(d)
            if state ~= nil then
                state.color = color
            end
        end,
        SetDestructableVertexColor = function(d, red, green, blue, alpha)
            local state = self.destructables:get(d)
            if state ~= nil then
                state.vertexColor = {red, green, blue, alpha}
            end
        end
    }
    local fogFields = {
        Style = "style",
        ZStart = "zStart",
        ZEnd = "zEnd",
        Density = "density",
        HeightStart = "heightStart",
        HeightEnd = "heightEnd",
        LinearStart = "linearStart",
        LinearEnd = "linearEnd",
        MaxLinearDensity = "maxLinearDensity",
        DrawOverSky = "drawOverSky"
    }
    for ____, suffix in ipairs(__TS__ObjectKeys(fogFields)) do
        local field = fogFields[suffix]
        if field ~= nil then
            behaviors["BlzSetTerrainFog" .. suffix] = function(value)
                self.fog[field] = value
            end
        end
    end
    local waterFields = {
        "ColorOverride",
        "VertexDisplacement",
        "MinOpacity",
        "MaxOpacity",
        "Reflectivity",
        "Emissivity",
        "EdgeSoftness",
        "WaveStrength",
        "EnvMapStrength"
    }
    for ____, suffix in ipairs(waterFields) do
        local field = suffix == "ColorOverride" and "override" or string.lower(string.sub(suffix, 1, 1)) .. string.sub(suffix, 2)
        behaviors["BlzSetHDWater" .. suffix] = function(value)
            self.water[field] = value
        end
    end
    local doodadFields = {
        X = "x",
        Y = "y",
        Z = "z",
        ScaleX = "scaleX",
        ScaleY = "scaleY",
        ScaleZ = "scaleZ",
        IsUsingModelAxes = "usingModelAxes",
        Yaw = "yaw",
        Pitch = "pitch",
        Roll = "roll",
        Variation = "variation",
        Id = "id"
    }
    for ____, suffix in ipairs(__TS__ObjectKeys(doodadFields)) do
        local field = doodadFields[suffix]
        if field ~= nil then
            behaviors["BlzGetDoodad" .. suffix] = function(index)
                local ____opt_7 = self.doodads[index + 1]
                local ____temp_10 = ____opt_7 and ____opt_7[field]
                if ____temp_10 == nil then
                    local ____temp_9
                    if field == "usingModelAxes" then
                        ____temp_9 = false
                    else
                        ____temp_9 = 0
                    end
                    ____temp_10 = ____temp_9
                end
                return ____temp_10
            end
        end
    end
    for ____, dead in ipairs({false, true}) do
        for ____, z in ipairs({false, true}) do
            for ____, skin in ipairs({false, true}) do
                for ____, orientation in ipairs({false, true}) do
                    for ____, color in ipairs({false, true}) do
                        do
                            if not orientation and not color then
                                goto __continue95
                            end
                            local name = ((((("BlzCreate" .. (dead and "Dead" or "")) .. "Destructable") .. (z and "Z" or "")) .. (skin and "WithSkin" or "")) .. (orientation and "PitchRoll" or "")) .. (color and (skin and "Color" or "WithColor") or "")
                            behaviors[name] = function(...)
                                local args = {...}
                                local offset = 3
                                local ____z_13
                                if z then
                                    local ____args_12 = args
                                    local ____offset_11 = offset
                                    offset = ____offset_11 + 1
                                    ____z_13 = ____args_12[____offset_11 + 1]
                                else
                                    ____z_13 = 0
                                end
                                local altitude = ____z_13
                                local ____args_15 = args
                                local ____offset_14 = offset
                                offset = ____offset_14 + 1
                                local facing = ____args_15[____offset_14 + 1]
                                local ____orientation_18
                                if orientation then
                                    local ____args_17 = args
                                    local ____offset_16 = offset
                                    offset = ____offset_16 + 1
                                    ____orientation_18 = ____args_17[____offset_16 + 1]
                                else
                                    ____orientation_18 = 0
                                end
                                local roll = ____orientation_18
                                local ____orientation_21
                                if orientation then
                                    local ____args_20 = args
                                    local ____offset_19 = offset
                                    offset = ____offset_19 + 1
                                    ____orientation_21 = ____args_20[____offset_19 + 1]
                                else
                                    ____orientation_21 = 0
                                end
                                local pitch = ____orientation_21
                                local ____args_23 = args
                                local ____offset_22 = offset
                                offset = ____offset_22 + 1
                                local scale = ____args_23[____offset_22 + 1]
                                local ____args_25 = args
                                local ____offset_24 = offset
                                offset = ____offset_24 + 1
                                local variation = ____args_25[____offset_24 + 1]
                                local typeId = args[1]
                                local ____skin_28
                                if skin then
                                    local ____args_27 = args
                                    local ____offset_26 = offset
                                    offset = ____offset_26 + 1
                                    ____skin_28 = ____args_27[____offset_26 + 1]
                                else
                                    ____skin_28 = typeId
                                end
                                local skinId = ____skin_28
                                local state = __TS__ObjectAssign(
                                    {},
                                    context.handle("destructable"),
                                    {
                                        typeId = typeId,
                                        skinId = skinId,
                                        x = args[2],
                                        y = args[3],
                                        z = altitude,
                                        facing = facing,
                                        roll = roll,
                                        pitch = pitch,
                                        scale = scale,
                                        variation = variation,
                                        dead = dead,
                                        removed = false
                                    }
                                )
                                if color then
                                    state.color = args[offset + 1]
                                end
                                self.destructables:set(state, state)
                                return state
                            end
                        end
                        ::__continue95::
                    end
                end
            end
        end
    end
    return behaviors
end
return ____exports
