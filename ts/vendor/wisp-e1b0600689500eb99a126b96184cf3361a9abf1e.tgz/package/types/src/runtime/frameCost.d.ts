/** @noSelfInFile */
export declare const frameCostFile: (slot: number, prefix?: string) => string;
export interface Spread {
    readonly median: number;
    readonly mean: number;
    readonly max: number;
}
export interface FrameWindow {
    readonly frames: number;
    readonly lua: Spread | undefined;
    readonly natives: Spread;
    readonly catchUp: Spread;
}
export declare function spread(values: readonly number[], count: number): Spread;
export declare function reportNumber(value: number): string;
export declare const frameCostHeading: (version: number, previous: number, clockStep: number) => string;
export declare const frameWindowLine: (label: string, window: FrameWindow) => string;
