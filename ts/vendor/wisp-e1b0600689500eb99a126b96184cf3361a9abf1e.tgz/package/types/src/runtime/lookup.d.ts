/** @noSelfInFile */
export declare function at<T>(items: readonly T[], index: number): T;
