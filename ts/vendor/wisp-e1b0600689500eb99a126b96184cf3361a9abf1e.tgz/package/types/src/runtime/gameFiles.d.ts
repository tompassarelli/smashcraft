/** @noSelfInFile */
export declare const CHUNKS_PER_FILE = 64;
export declare const PAYLOAD_FILE_BYTES = 200000;
export declare const FILE_IO_ABILITY = 611808108;
export declare const FILE_SLOTS = 4;
export declare const hotFolder: (prefix?: string) => string;
export declare const hostFile: (prefix?: string) => string;
export declare const manifestFile: (version: number, prefix?: string) => string;
export declare const payloadKey: (payloadChecksum: string) => string;
export declare const payloadFile: (state: string, index: number, prefix?: string) => string;
export declare const deltaFile: (state: string, base: string, index: number, prefix?: string) => string;
export declare const ackFile: (slot: number, prefix?: string) => string;
export declare const errorFile: (slot: number, prefix?: string) => string;
export declare const modelFailureRequestFile: (slot: number, prefix?: string) => string;
export declare const modelFailureTokenFile: (slot: number, ordinal: number, prefix?: string) => string;
export declare const modelFailureFile: (token: string, ordinal: number, prefix?: string) => string;
export declare const NO_BASE = "-";
export interface Manifest {
    version: number;
    state: string;
    files: number;
    base: string;
    changes: number;
}
export declare const formatManifest: ({ version, state, files, base, changes }: Manifest) => string;
export declare function parseManifest(text: string): Manifest | undefined;
export declare const acknowledgementLine: (version: number, elapsed: number) => string;
export declare const errorHeading: (count: number, handler: string) => string;
