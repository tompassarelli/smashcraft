/** @noSelfInFile */
export declare const REPRO_HEADER = "wisp-repro 1";
/** Characters per game line; Wisp's error reports cut Preload lines at 240. */
export declare const REPRO_LINE_WIDTH = 200;
export interface ReproHeader {
    readonly build: string;
    readonly frame: number;
    readonly checksum: string;
}
export interface Repro extends ReproHeader {
    readonly lines: readonly string[];
}
export interface ReproResult {
    readonly checksum: string;
    readonly frames: number;
    readonly problems: readonly string[];
}
export type ReproReplay = (this: void, repro: Repro) => ReproResult;
export interface ReproInspection {
    readonly frame: number;
    readonly checksum: string;
    readonly state: string;
    readonly fields: readonly {
        readonly path: string;
        readonly value: string;
    }[];
}
export type ReproInspector = (this: void, repro: Repro, frame: number) => ReproInspection | string;
/** A new name for each repro a client saves, as Preloader runs the first content it read from a name for the rest of the session. */
export declare const reproFile: (slot: number, frame: number, serial: number, prefix?: string) => string;
export declare function reproLines({ build, frame, checksum }: ReproHeader, lines: readonly string[]): string[];
export declare function parseRepro(lines: readonly string[]): Repro | string;
export declare function assertReproLands(lines: readonly string[], replay: ReproReplay): void;
