/** @noSelfInFile */
export declare function checksum(length: number, byteAt: (index: number) => number): string;
