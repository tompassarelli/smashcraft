/** @noSelfInFile */
import { type Manifest } from "./gameFiles";
export interface HotModule {
    readonly name: string;
    readonly text: string;
}
export interface ModuleSet {
    readonly entry: string;
    readonly modules: readonly HotModule[];
}
export declare const MODULE_HEAD = "local require = ... return function(...) \n";
export declare const MODULE_TAIL = " end\n";
export declare const moduleChunk: (code: string) => string;
export declare const BUNDLE_MODULE = "bundle";
export declare const bundleModules: (bundle: string) => ModuleSet;
export type Hash = (this: void, text: string) => string;
export declare const textChecksum: Hash;
export declare const moduleHashText: (name: string, text: string) => string;
export declare function moduleIndex(entry: string, hashes: readonly (readonly [name: string, hash: string])[]): string;
/** The index, a blank line, a line per carried module (its byte length and name), a blank line, then their texts. */
export declare function modulePayload(index: string, carried: readonly HotModule[]): string;
export interface Payload {
    readonly index: string;
    readonly entry: string;
    readonly hashes: readonly (readonly [string, string])[];
    readonly texts: Readonly<Record<string, string | undefined>>;
}
export declare function parsePayload(text: string): Payload | undefined;
/** Pieces of at most PAYLOAD_FILE_BYTES, cut before an ASCII byte so no UTF-8 character is split. */
export declare function payloadPieces(text: string): string[];
export interface ModuleState {
    readonly state: string;
    readonly hashes: Readonly<Record<string, string | undefined>>;
}
export interface VersionFiles {
    readonly manifest: Manifest;
    readonly payloads: readonly (readonly [string, string])[];
    readonly published: ModuleState;
    readonly changed: readonly string[];
    readonly changedBytes: number;
    readonly fullBytes: number;
}
export declare class ModulePublisher {
    private readonly prefix;
    private readonly hash;
    private known;
    private base;
    constructor(prefix: string, hash?: Hash);
    installed(state: ModuleState): void;
    files(version: number, set: ModuleSet): VersionFiles;
}
