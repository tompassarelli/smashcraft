/** @noSelfInFile */
export type TestCase = {
    name: string;
    run: () => void;
};
export declare const registeredTests: TestCase[];
export declare function test(name: string, run: () => void): void;
export declare class AssertionFailure {
    readonly message: string;
    constructor(message: string);
}
export declare function assertTrue(value: boolean): void;
export declare function assertFalse(value: boolean): void;
export declare function assertEquals<T>(actual: T, expected: T, message?: string): void;
export declare function assertNear(actual: number, expected: number, delta: number): void;
export declare function assertGreaterThan(actual: number, bound: number): void;
export declare function assertLessThan(actual: number, bound: number): void;
export declare function assertDefined<T>(value: T | undefined, what?: string): T;
export declare function runTests(report: (this: void, line: string) => void): number;
