/** @noSelfInFile */
export interface RuntimeConfiguration {
    readonly filePrefix: string;
    readonly readyPrefix: string;
    readonly globalPrefix: string;
    readonly errorsOnScreen?: boolean;
}
export declare function configureRuntime(next: RuntimeConfiguration): void;
export declare function runtimeConfiguration(): RuntimeConfiguration;
