/** @noSelfInFile */
export declare class IntegerKeysUndeclared extends Error {
}
export declare function recordTokens(record: object, keyedByInteger?: readonly string[]): string[] | undefined;
export declare function parseRecord(tokens: readonly string[]): Record<string, unknown> | undefined;
export declare function tokenLines(tokens: readonly string[], width: number): string[];
export declare function lineTokens(lines: readonly string[]): string[];
