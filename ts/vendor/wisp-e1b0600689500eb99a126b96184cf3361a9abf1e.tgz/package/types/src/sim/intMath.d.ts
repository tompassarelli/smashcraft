/** @noSelfInFile */
export declare function floorDiv(a: number, b: number): number;
export declare function floorMod(a: number, b: number): number;
export declare function idiv(a: number, b: number): number;
export declare function imod(a: number, b: number): number;
