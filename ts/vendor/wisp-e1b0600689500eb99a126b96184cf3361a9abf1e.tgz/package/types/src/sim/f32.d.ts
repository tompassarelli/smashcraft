/** @noSelfInFile */
export declare function exactSum(value: number, right: number): number;
export declare function exactDifference(value: number, right: number): number;
export declare function exactProduct(value: number, right: number): number;
export declare function exactQuotient(value: number, right: number): number;
declare global {
    var __wispF32Add: (value: number, right: number) => number;
    var __wispF32Subtract: (value: number, right: number) => number;
    var __wispF32Multiply: (value: number, right: number) => number;
    var __wispF32Divide: (value: number, right: number) => number;
}
export declare function f32(value: number): number;
