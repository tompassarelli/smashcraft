/** @noSelfInFile */
export declare function toInt(value: number): number;
export declare function roundToFloat32(value: number): number;
export declare function addFloat32(a: number, b: number): number;
/** Unit-state writes use halfway differences toward zero; ordinary subtraction keeps nearest-even. */
export declare function subtractFloat32(a: number, b: number, tiesTowardZero?: boolean): number;
export declare function addFloat32TowardZero(a: number, b: number): number;
export declare function subtractFloat32TowardZero(a: number, b: number): number;
export declare function multiplyFloat32(a: number, b: number): number;
/** a * b rounded toward zero, as Warcraft's raw * rounds (wisp:docs/headless.md#raw-float-rounding); a result outside the normal range rounds to nearest. */
export declare function multiplyFloat32TowardZero(a: number, b: number): number;
export declare function fusedMultiplyAddFloat32(a: number, b: number, c: number): number;
export declare function divideFloat32(numerator: number, denominator: number): number;
export declare function squareRootFloat32(value: number): number;
