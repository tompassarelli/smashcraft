/** @noSelfInFile */
type Handler = (this: void) => void;
export declare function installDispatch(): void;
export declare function on(name: string, handler: Handler): void;
export declare function trampoline(name: string): Handler;
export {};
