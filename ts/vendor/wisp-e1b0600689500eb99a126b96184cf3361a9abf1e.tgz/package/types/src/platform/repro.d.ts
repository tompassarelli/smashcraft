/** @noSelfInFile */
import { type ReproHeader } from "../runtime/repro";
export declare function writeRepro(filename: string, header: ReproHeader, lines: readonly string[]): void;
