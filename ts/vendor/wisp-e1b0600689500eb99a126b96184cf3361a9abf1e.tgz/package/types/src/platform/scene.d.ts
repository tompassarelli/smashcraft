/** @noSelfInFile */
export interface SceneOptions {
    readonly frame: (this: void) => number;
    readonly parked: (this: void, x: number, y: number, z: number) => boolean;
    readonly unitModel?: ((this: void, unitType: number) => string | undefined) | undefined;
}
export declare function installSceneReport(): void;
export declare function startSceneReport(options: SceneOptions): void;
