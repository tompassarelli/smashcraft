/** @noSelfInFile */
export interface Reloadable {
    install(this: void): void;
}
export declare function installHotReload(): void;
export declare function startHotReload(): void;
