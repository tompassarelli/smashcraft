/** @noSelfInFile */
export declare function readChunks(filename: string): string[];
export declare function readChunk(filename: string): string | undefined;
export declare function writeLine(filename: string, line: string): void;
export declare function writeLines(filename: string, lines: readonly string[]): void;
export declare function writeChunks(filename: string, chunks: readonly string[]): boolean;
