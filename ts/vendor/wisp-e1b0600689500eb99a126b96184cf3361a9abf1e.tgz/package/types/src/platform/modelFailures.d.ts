/** @noSelfInFile */
export declare function startModelFailures(): void;
/** Local file results only change existing visual handles, never synchronized state. */
export declare function pollModelFailures(): void;
export declare function modelFailed(path: string): boolean;
