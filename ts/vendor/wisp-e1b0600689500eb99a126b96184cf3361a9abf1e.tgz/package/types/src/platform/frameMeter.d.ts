/** @noSelfInFile */
export declare const FRAME_WINDOW = 120;
export interface FrameMeterOptions {
    readonly frame: string;
    readonly simulationFrame?: (this: void) => number;
    readonly toggle: string;
}
export declare function startFrameCostCapture(frames: number): number;
export declare function installFrameMeter(): void;
export declare function startFrameMeter(options: FrameMeterOptions): void;
