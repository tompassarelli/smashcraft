/** @noSelfInFile */
export interface AnimationSequence {
    readonly name: string;
    readonly start: number;
    readonly end: number;
    readonly looping: boolean;
    readonly rarity: number;
}
export interface SavedAnimation {
    readonly animation: string | number | undefined;
    readonly subAnimations: readonly (string | number)[];
    readonly elapsed: number;
}
export interface AnimationBlend {
    readonly from: SavedAnimation;
    remaining: number;
}
export interface AnimationState {
    animation: string | number | undefined;
    subAnimations: (string | number)[];
    animationElapsed: number;
    animationClock: number;
    animationBlendTime: number;
    animationBlend: AnimationBlend | undefined;
    /** Effect selections restart once on the next drawn frame, after the caller's writes. */
    animationRestartPending?: boolean;
}
export declare function freshAnimation(): AnimationState;
export declare function selectAnimation(state: AnimationState, animation: string | number, subAnimations?: readonly (string | number)[], restartOnNextFrame?: boolean): void;
export declare function seekAnimation(state: AnimationState, seconds: number): void;
export declare function advanceAnimation(state: AnimationState, timeScale: number, frameSeconds: number): void;
export declare function blendWeight(state: AnimationState): number;
export interface AnimationTags {
    readonly primary: readonly string[];
    readonly secondary: readonly string[];
}
export declare function animationTags(name: string, extra?: readonly (string | number)[]): AnimationTags;
export declare function selectSequence(sequences: readonly AnimationSequence[], animation: string | number, subAnimations?: readonly (string | number)[]): number;
export declare function sequenceFrame(sequence: AnimationSequence, ms: number, looping?: boolean): number;
export interface SequenceSample {
    readonly sequence: number;
    readonly frame: number;
}
export declare function animationSample(sequences: readonly AnimationSequence[], animation: SavedAnimation, kind: "effect" | "unit"): SequenceSample;
export declare function globalSequenceFrame(clockSeconds: number, length: number): number;
