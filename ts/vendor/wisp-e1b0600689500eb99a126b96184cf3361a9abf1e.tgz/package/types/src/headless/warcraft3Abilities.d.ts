/** @noSelfInFile */
import type { Handle, NativeBehavior } from "./client";
export interface AbilityObjectFixture {
    readonly base: string;
    readonly realLevelFields: Readonly<Record<string, readonly number[]>>;
    readonly impactDelay: number;
}
export type AbilityObjectFixtures = Readonly<Record<number, AbilityObjectFixture>>;
interface UnitAbilities {
    readonly cooldowns: Map<string, number>;
    readonly remaining: Map<number, number>;
    readonly levels: Map<number, number>;
    readonly handles: Map<number, Handle>;
    readonly attackPeriods: Map<number, number>;
    readonly attackRemaining: Map<number, number>;
    auras: boolean;
    auraUI: boolean;
}
export declare class Warcraft3Abilities {
    private readonly objects;
    constructor(objects?: AbilityObjectFixtures);
    private readonly units;
    private readonly fields;
    private readonly ids;
    shadowStrike(unit: Handle): {
        interval: number;
        duration: number;
        range: number;
        initial: number;
        periodic: number;
        impactDelay: number;
    } | undefined;
    state(unit: Handle): UnitAbilities;
    removeUnit(unit: Handle): void;
    tick(seconds: number): void;
    behaviors(handle: (this: void, kind: string) => Handle): Readonly<Record<string, NativeBehavior>>;
}
export {};
