/** @noSelfInFile */
import type { LinkEvent, LockstepLink } from "./lockstep";
export interface Turn {
    readonly frame: number;
    readonly at: number;
    readonly events: readonly LinkEvent[];
}
export interface TurnPacket {
    readonly from: number;
    readonly frontier: number;
    readonly ack: number;
    readonly turns: readonly Turn[];
    readonly checks: readonly (readonly [frame: number, checksum: string])[];
    readonly done: boolean;
}
export interface ChecksumMismatch {
    readonly frame: number;
    readonly local: string;
    readonly remote: string;
}
/** One process's side of a two-player match: its own events by due frame, the peer's as packets bring them, and checksum agreement (wisp:docs/network-model.md). */
export declare class TurnLedger implements LockstepLink {
    readonly local: number;
    readonly remote: number;
    private readonly clock;
    delay: number;
    executed: number;
    remoteFrontier: number;
    peerAck: number;
    remoteDone: boolean;
    compared: number;
    lastCompared: number;
    mismatch: ChecksumMismatch | undefined;
    readonly latencies: number[];
    private advertised;
    private readonly outgoing;
    private readonly incoming;
    private readonly localChecks;
    private readonly remoteChecks;
    constructor(local: number, remote: number, clock: (this: void) => number);
    frontier(): number;
    ready(frame: number): boolean;
    readonly sent: (frame: number, event: LinkEvent) => void;
    /** Every event due at `frame`, the lower slot's first, each sender's in the order it sent them. */
    readonly due: (frame: number) => readonly LinkEvent[];
    check(frame: number, checksum: string): void;
    /** Everything the peer may lack: this side's turns after its last acknowledgement, up to the frontier this packet promises. */
    packet(done?: boolean): TurnPacket;
    receive(packet: TurnPacket): void;
    private compare;
    private prune;
}
