/** @noSelfInFile */
import type { Handle } from "./client";
export interface LightningPose {
    readonly handle: Handle;
    readonly codeName: string;
    readonly from: readonly [number, number, number];
    readonly to: readonly [number, number, number];
    readonly color: readonly [number, number, number, number];
}
export declare class Lightnings {
    private readonly bolts;
    behaviors(context: {
        handle(this: void, kind: string): Handle;
    }): Record<string, (...args: never[]) => unknown>;
    poses(): LightningPose[];
}
