/** @noSelfInFile */
import type { Handle } from "./client";
export interface Frame extends Handle {
    readonly type: string;
    readonly name: string;
    readonly context: number;
    readonly parent: Frame | undefined;
    text: string;
    texture: string;
    color: number;
    textColor: number;
    alpha: number;
    visible: boolean;
    enabled: boolean;
    level: number;
    textLimit: number;
    font: {
        readonly file: string;
        readonly height: number;
        readonly flags: number;
    };
    alignment: {
        readonly vertical: unknown;
        readonly horizontal: unknown;
    } | undefined;
    scale: number;
    width: number;
    height: number;
    readonly points: Map<unknown, {
        readonly x: number;
        readonly y: number;
    }>;
    readonly anchors: Anchor[];
    destroyed: boolean;
}
export declare const FRAME_POINTS: readonly (readonly [name: string, fromLeft: number, fromTop: number])[];
export interface FrameTemplateNode {
    readonly key: string;
    readonly type: string;
    readonly width?: number;
    readonly height?: number;
    readonly text?: string;
    readonly texture?: string;
    readonly font?: TemplateFont;
    readonly justify?: TemplateJustify;
    readonly points?: readonly {
        readonly point: string;
        readonly relative?: string;
        readonly relativePoint?: string;
        readonly x: number;
        readonly y: number;
    }[];
    readonly children?: readonly FrameTemplateNode[];
}
export interface FrameTemplate {
    readonly name: string;
    readonly type?: string;
    readonly texture?: string;
    readonly text?: string;
    readonly font?: TemplateFont;
    readonly justify?: TemplateJustify;
    readonly width: number;
    readonly height: number;
    readonly children: readonly FrameTemplateNode[];
}
export interface TemplateFont {
    readonly file: string;
    readonly size: number;
    readonly flags?: number;
}
export interface TemplateJustify {
    readonly horizontal: "LEFT" | "CENTER" | "RIGHT";
    readonly vertical: "TOP" | "MIDDLE" | "BOTTOM";
}
export interface FrameFont {
    readonly file: string;
    readonly height: number;
    readonly flags: number;
}
export interface TextAlignment {
    readonly vertical: "top" | "middle" | "bottom";
    readonly horizontal: "left" | "center" | "right";
}
export declare function textAlignment(alignment: Frame["alignment"]): TextAlignment | undefined;
export interface Anchor {
    readonly point: string;
    readonly relative: Frame;
    readonly relativePoint: string;
    readonly x: number;
    readonly y: number;
}
export type Rectangle = readonly [number, number, number, number];
export interface FrameSnapshot {
    readonly handle: Handle;
    readonly name: string;
    readonly type: string;
    readonly parentId: number | undefined;
    readonly rectangle: Rectangle | undefined;
    readonly text: string;
    readonly texture: string;
    readonly color: number;
    readonly textColor: number;
    readonly alpha: number;
    readonly visible: boolean;
    readonly level: number;
    readonly font: FrameFont;
    readonly alignment: TextAlignment | undefined;
    readonly scale: number;
}
export declare class Frames {
    private readonly points;
    private readonly all;
    private focused;
    private readonly templates;
    constructor(points: ReadonlyMap<unknown, readonly [number, number]>);
    add(handle: Handle, type: string, name: string, parent: Frame | undefined, context: number): Frame;
    define(definitions: readonly FrameTemplate[]): void;
    create(handle: (this: void) => Handle, name: string, parent: Frame | undefined, context: number): Frame;
    named(name: string, context: number): Frame | undefined;
    byId(id: number): Frame | undefined;
    children(parent: Frame): Frame[];
    destroy(frame: Frame): void;
    focus(frame: Frame, flag: boolean): void;
    shown(frame: Frame): boolean;
    shownText(): string[];
    snapshot(options?: {
        readonly visibleOnly?: boolean;
    }): FrameSnapshot[];
    private rectangle;
    at(x: number, y: number, takes: (frame: Frame) => boolean): Frame | undefined;
    type(text: string): boolean;
}
