/** @noSelfInFile */
/** Frames headless clients have stepped in this process: a test's deterministic cost (wisp:scripts/wisp/testCostPreload.ts). */
export declare const steppedFrames: {
    count: number;
};
