/** @noSelfInFile */
/** Park-Miller minimal standard generator in Schrage's form: every product stays below 2^31. */
export declare class Random {
    private state;
    constructor(seed: number);
    next(): number;
    between(low: number, high: number): number;
    chance(p: number): boolean;
    pick<T>(items: readonly T[]): T;
}
