/** @noSelfInFile */
import type { Handle, NativeBehavior } from "./client";
export interface DoodadFixture {
    readonly id: number;
    readonly x: number;
    readonly y: number;
    readonly z: number;
    readonly scaleX: number;
    readonly scaleY: number;
    readonly scaleZ: number;
    readonly usingModelAxes: boolean;
    readonly yaw: number;
    readonly pitch: number;
    readonly roll: number;
    readonly variation: number;
}
export interface DoodadState extends DoodadFixture {
    color?: unknown;
    animation?: string;
    animationRandom?: boolean;
}
export interface SceneryFixtures {
    readonly doodads?: readonly DoodadFixture[];
    readonly cinematics?: Readonly<Record<string, readonly number[]>>;
    readonly pathing?: readonly {
        readonly x: number;
        readonly y: number;
        readonly type: unknown;
        readonly blocked: boolean;
    }[];
    readonly hudScale?: number;
}
export interface DestructableState extends Handle {
    readonly typeId: number;
    readonly skinId: number;
    x: number;
    y: number;
    z: number;
    facing: number;
    roll: number;
    pitch: number;
    scale: number;
    variation: number;
    dead: boolean;
    removed: boolean;
    color?: unknown;
    vertexColor?: readonly [number, number, number, number];
}
export interface SceneryContext {
    handle(this: void, kind: string): Handle;
}
export interface Environment {
    sky: string;
    skyVisible: boolean;
    terrainVisible: boolean;
    dayNight: {
        terrain: string;
        unit: string;
    };
    timeOfDay: number;
}
export declare class Scenery {
    private readonly fixtures;
    readonly doodads: DoodadState[];
    readonly destructables: Map<Handle, DestructableState>;
    readonly fog: Record<string, unknown>;
    readonly environment: Environment;
    readonly water: Record<string, unknown>;
    readonly cameraInput: Map<unknown, boolean>;
    readonly cameraSetups: Map<Handle, number>;
    readonly cameraBlockers: Map<Handle, boolean>;
    cameraType: number;
    cameraAllowsHotkeyTargetLock: boolean;
    minShadowCastingPointLightCount: number;
    cinematicEnabledDE: boolean;
    thematicMusicPauseOnFocusLost: boolean;
    thematicMusicAbsoluteVolume: number | undefined;
    cinematic: {
        model: string;
        x: number;
        y: number;
        z: number;
        rotation: number;
        elapsed: number;
        shots: readonly number[];
    } | undefined;
    preloadedCinematic: string | undefined;
    readonly hudScale: number;
    constructor(fixtures?: SceneryFixtures);
    tick(seconds: number): void;
    private shots;
    private currentShot;
    private remaining;
    private select;
    private inRect;
    behaviors(context: SceneryContext): Readonly<Record<string, NativeBehavior>>;
}
