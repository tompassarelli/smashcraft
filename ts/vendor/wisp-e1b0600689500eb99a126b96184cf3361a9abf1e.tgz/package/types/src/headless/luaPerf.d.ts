/** @noSelfInFile */
import { type Journey } from "./journey";
import { Lockstep, type SyncDelivery } from "./lockstep";
import { type LuaHeadlessMap } from "./lua";
import { type NativeCostModel } from "./nativeCost";
export declare const HOOK_STEP = 100;
export interface PerfMeasure {
    typed(this: void, slot: number, characters: number): void;
    begin(this: void): void;
}
export interface LuaPerfOptions {
    readonly model?: NativeCostModel;
    readonly samples?: boolean;
    readonly delivery?: SyncDelivery;
}
export declare const TOP_SHARE: number;
export declare function runLuaPerfWith(map: LuaHeadlessMap, bundlePath: string, declarationsPath: string, play: (this: void, clients: Lockstep, measure: PerfMeasure) => {
    readonly problems: number;
    readonly lines: readonly string[];
}, options?: LuaPerfOptions): number;
export declare function runLuaPerf(map: LuaHeadlessMap, journey: Journey, bundlePath: string, declarationsPath: string, options?: LuaPerfOptions): number;
