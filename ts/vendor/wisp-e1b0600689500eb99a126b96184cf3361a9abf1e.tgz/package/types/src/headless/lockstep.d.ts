/** @noSelfInFile */
import type { FrameTemplate } from "./frames";
import { type Hash, type ModuleSet, type VersionFiles } from "../runtime/modules";
import { type ClientFiles, type ClientScope, HeadlessClient, type LocalNatives, type MapEntry, type NativeBehaviors, type SyncMessage } from "./client";
import type { NativeDeclarations } from "./declarations";
import type { EffectDeaths, UnitStateFixtures } from "./client";
import type { IntentionalNoops } from "./client";
import type { SceneryFixtures } from "./warcraft3Scenery";
import type { Warcraft3InventoryFixtures } from "./warcraft3Inventory";
import type { AbilityObjectFixtures } from "./warcraft3Abilities";
export interface LockstepOptions {
    readonly abilityObjects?: AbilityObjectFixtures;
    readonly unitStates?: UnitStateFixtures;
    readonly scenery?: SceneryFixtures;
    readonly inventory?: Warcraft3InventoryFixtures;
    readonly declarations: NativeDeclarations;
    readonly players: readonly number[];
    readonly humans?: readonly number[];
    readonly link?: LockstepLink;
    readonly playerNames?: Readonly<Record<number, string>>;
    readonly filePrefix: string;
    readonly entry: (this: void, client: HeadlessClient) => MapEntry;
    readonly modules: ModuleSet;
    readonly hash?: Hash;
    readonly localNatives?: LocalNatives;
    readonly intentionalNoops?: IntentionalNoops;
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly scope?: ClientScope;
    readonly delivery?: SyncDelivery;
    readonly files?: (this: void, slot: number) => ClientFiles | undefined;
    readonly keepCalls?: number;
    readonly effectDeaths?: EffectDeaths;
    readonly musicSlider?: number;
    readonly effectStepMs?: number;
    readonly cost?: (this: void) => number;
    readonly frames?: readonly FrameTemplate[];
}
export interface SyncDelivery {
    arrivalFrame(this: void, sender: number, frame: number, message: SyncMessage): number;
}
export type LinkEvent = {
    readonly sender: number;
    readonly kind: "sync";
    readonly prefix: string;
    readonly data: string;
} | {
    readonly sender: number;
    readonly kind: "key";
    readonly key: number;
    readonly meta: number;
    readonly down: boolean;
} | {
    readonly sender: number;
    readonly kind: "chat";
    readonly text: string;
} | {
    readonly sender: number;
    readonly kind: "click";
    readonly frame: number;
};
/** Carries this process's events to the clients other processes run, each due on one frame everywhere (wisp:docs/network-model.md). */
export interface LockstepLink {
    readonly delay: number;
    sent(this: void, frame: number, event: LinkEvent): void;
    due(this: void, frame: number): readonly LinkEvent[];
}
interface InFlight {
    readonly arrival: number;
    readonly message: SyncMessage;
}
export declare class Lockstep {
    readonly network: SyncMessage[];
    readonly clients: readonly HeadlessClient[];
    frame: number;
    version: number;
    files: VersionFiles | undefined;
    readonly inFlight: InFlight[];
    readonly costs: number[];
    private readonly options;
    private divergence;
    private inFrame;
    private readonly publisher;
    constructor(options: LockstepOptions);
    start(options?: {
        readonly hostFolder?: boolean;
    }): void;
    everywhere(body: (this: void) => void): void;
    /** Synchronized messages reach every client in the order they were sent, at once or at their arrival frame. */
    private flush;
    /** An event raised during frame n is due at n + delay; one raised between frames n and n + 1, at n + 1 + delay. */
    private send;
    private apply;
    /** Delivers the messages due at the current frame, before its callbacks, as Warcraft runs a turn's events first. */
    private arrive;
    frames(count: number, options?: {
        readonly draw?: boolean;
    }): void;
    private charge;
    private settle;
    chat(sender: number, message: string): void;
    press(sender: number, key: number, meta?: number): void;
    key(sender: number, key: number, meta: number, down: boolean): void;
    client(slot: number): HeadlessClient;
    type(sender: number, text: string): void;
    click(sender: number, x: number, y: number): boolean;
    publish(name: string, chunks: readonly string[]): void;
    prepareHostFolder(): void;
    reload(modules?: ModuleSet): number;
    unappliedReloads(): string[];
    firstDivergence(): string | undefined;
    private compare;
}
export {};
