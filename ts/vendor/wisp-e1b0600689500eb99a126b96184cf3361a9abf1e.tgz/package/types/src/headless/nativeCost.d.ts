/** @noSelfInFile */
export interface FrameWork {
    readonly instructions: number;
    readonly natives: number;
    readonly allocatedKb: number;
    readonly typedCharacters: number;
}
export interface NativeCostModel {
    readonly hostUsPerThousandInstructions: number;
    readonly luaFactor: number;
    readonly nativeCallUs: number;
    readonly collectorUsPerKb: number;
    readonly typingUsPerCharacterSquared: number;
}
export interface NativeFrameCost {
    readonly callbacksUs: number;
    readonly typingUs: number;
}
export declare function nativeFrameCost(model: NativeCostModel, work: FrameWork): NativeFrameCost;
export declare const WARCRAFT_COST: NativeCostModel;
