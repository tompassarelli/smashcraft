/** @noSelfInFile */
import type { Handle, NativeBehavior } from "./client";
export interface Warcraft3ItemFixture {
    readonly itemType: number;
    readonly level: number;
    readonly equipmentType: number;
    readonly tag: number;
    readonly validMorph: boolean;
    readonly pickRandom: boolean;
}
export interface Warcraft3InventoryUnitFixture {
    readonly bagSize: number;
    readonly inventorySize: number;
    readonly extendedInventorySize: number;
    readonly loadout: Readonly<Record<number, readonly number[]>>;
    readonly heroGlowAllowed?: boolean;
    readonly animations?: Readonly<Record<string, number>>;
    readonly animationIndices?: Readonly<Record<number, number>>;
    readonly healMultiplier?: number;
    readonly itemHealMultiplier?: number;
    readonly talents?: Readonly<Record<string, number>>;
}
export interface Warcraft3InventoryFixtures {
    readonly items?: Readonly<Record<number, Warcraft3ItemFixture>>;
    readonly units?: Readonly<Record<number, Warcraft3InventoryUnitFixture>>;
    readonly chooseRandom?: (this: void, candidates: readonly number[]) => number;
}
export type InventoryEventKind = "equip" | "unequip";
export interface Warcraft3InventoryContext {
    handle(this: void, kind: string): Handle;
    getUnitTypeId(this: void, unit: Handle): number;
    readLife(this: void, unit: Handle): number;
    readMaxLife(this: void, unit: Handle): number;
    writeLife(this: void, unit: Handle, life: number): void;
    inventoryEvent?(this: void, unit: Handle, item: Handle, kind: InventoryEventKind): void;
}
export interface InventoryItemState {
    readonly handle: Handle;
    readonly typeId: number;
    x: number;
    y: number;
    color: number | string | undefined;
    holder: Handle | undefined;
    equipped: boolean;
    removed: boolean;
}
export interface InventoryUnitState {
    readonly bag: Map<number, Handle>;
    readonly equipment: Map<number, Handle>;
    readonly talents: Map<string, number>;
    heroGlowAllowed: boolean | undefined;
}
export declare class Warcraft3Inventory {
    private readonly context;
    private readonly fixtures;
    readonly items: Map<Handle, InventoryItemState>;
    readonly units: Map<Handle, InventoryUnitState>;
    readonly playerRaceSkins: Map<number, string | number>;
    private event;
    constructor(context: Warcraft3InventoryContext, fixtures?: Warcraft3InventoryFixtures);
    withInventoryEvent<T>(unit: Handle, item: Handle, kind: InventoryEventKind, callback: (this: void) => T): T;
    private unitFixture;
    private item;
    private itemFixture;
    unit(unit: Handle): InventoryUnitState;
    private detach;
    private bagSlot;
    private addItem;
    private equip;
    private unequip;
    private randomItem;
    behaviors(): Readonly<Record<string, NativeBehavior>>;
}
