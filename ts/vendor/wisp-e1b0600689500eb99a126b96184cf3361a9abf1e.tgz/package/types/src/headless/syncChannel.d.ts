/** @noSelfInFile */
import type { SyncMessage } from "./client";
import type { SyncDelivery } from "./lockstep";
export interface SyncLatency {
    readonly latencyMs: number;
    readonly turnMs: number;
    readonly extraTurns: readonly number[];
}
export declare const MEASURED_BATTLE_NET: SyncLatency;
export declare const CALLBACK_MS: number;
export declare function syncAgeMs(latency: SyncLatency, frame: number, extraTurns: number): number;
export declare function syncDelivery(latency?: SyncLatency, seed?: number): SyncDelivery;
export interface ReplayedArrival {
    readonly accepts: (this: void, message: SyncMessage) => boolean;
    readonly atMs: number;
}
export declare function replayedDelivery(arrivals: (this: void) => readonly ReplayedArrival[], fallback: SyncDelivery, nowMs: (this: void) => number): SyncDelivery;
