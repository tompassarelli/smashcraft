/** @noSelfInFile */
import type { ClientScope, EffectDeaths, LocalNatives, IntentionalNoops, HeadlessClient, NativeBehaviors, UnitStateFixtures } from "./client";
import type { FrameTemplate } from "./frames";
import type { SyncDelivery } from "./lockstep";
import { type Journey } from "./journey";
import { Lockstep } from "./lockstep";
import type { SceneryFixtures } from "./warcraft3Scenery";
import type { Warcraft3InventoryFixtures } from "./warcraft3Inventory";
import type { AbilityObjectFixtures } from "./warcraft3Abilities";
export interface LuaHeadlessMap {
    readonly abilityObjects?: AbilityObjectFixtures;
    readonly unitStates?: UnitStateFixtures;
    readonly scenery?: SceneryFixtures;
    readonly inventory?: Warcraft3InventoryFixtures;
    readonly filePrefix: string;
    readonly localNatives?: LocalNatives;
    readonly intentionalNoops?: IntentionalNoops;
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly players?: readonly number[];
    readonly playerNames?: Readonly<Record<number, string>>;
    readonly frames?: readonly FrameTemplate[];
    readonly effectDeaths?: EffectDeaths;
}
export declare function readFile(path: string): string;
export declare function luaLockstep(map: LuaHeadlessMap, bundle: string, declarations: string, scope?: ClientScope, delivery?: SyncDelivery): Lockstep;
export declare function runLuaJourney(map: LuaHeadlessMap, journey: Journey, bundlePath: string, declarationsPath: string): number;
