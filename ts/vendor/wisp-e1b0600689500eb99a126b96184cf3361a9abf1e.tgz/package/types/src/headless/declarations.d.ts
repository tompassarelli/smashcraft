/** @noSelfInFile */
export interface NativeDeclarations {
    readonly functions: readonly (readonly [name: string, returns: string, parameters: number])[];
    readonly constants: readonly (readonly [name: string, type: string])[];
    readonly variables: readonly (readonly [name: string, type: string])[];
}
export declare function parseNativeDeclarations(text: string): NativeDeclarations;
