/** @noSelfInFile */
import type { Handle } from "./client";
export interface TextTagPose {
    readonly handle: Handle;
    readonly text: string;
    readonly height: number;
    readonly x: number;
    readonly y: number;
    readonly z: number;
    readonly color: readonly [number, number, number, number];
}
export interface TextTagContext {
    handle(this: void, kind: string): Handle;
    unitPosition(this: void, unit: unknown): {
        readonly x: number;
        readonly y: number;
        readonly z: number;
    } | undefined;
}
export declare class TextTags {
    private readonly tags;
    behaviors(context: TextTagContext): Record<string, (...args: never[]) => unknown>;
    tick(seconds: number): void;
    poses(): TextTagPose[];
}
