local ____exports = {}
function ____exports.floorDiv(a, b)
    return math.floor(a / b)
end
function ____exports.floorMod(a, b)
    return a - b * math.floor(a / b)
end
function ____exports.idiv(a, b)
    local quotient = a // b
    return quotient < 0 and quotient * b ~= a and quotient + 1 or quotient
end
function ____exports.imod(a, b)
    local remainder = a - ____exports.idiv(a, b) * b
    return remainder < 0 and remainder + b or remainder
end
return ____exports
