local ____lualib = require("lualib_bundle")
local __TS__ObjectValues = ____lualib.__TS__ObjectValues
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Number = ____lualib.__TS__Number
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__ObjectEntries = ____lualib.__TS__ObjectEntries
local __TS__ArrayFrom = ____lualib.__TS__ArrayFrom
local ____exports = {}
local ____f32 = require("src.sim.f32")
local REAL_FIELDS = {
    ABILITY_RLF_CASTING_TIME = "acas",
    ABILITY_RLF_DURATION_NORMAL = "adur",
    ABILITY_RLF_DURATION_HERO = "ahdu",
    ABILITY_RLF_CAST_RANGE = "aran",
    ABILITY_RLF_DECAYING_DAMAGE = "Esh1",
    ABILITY_RLF_MOVEMENT_SPEED_FACTOR_ESH2 = "Esh2",
    ABILITY_RLF_ATTACK_SPEED_FACTOR_ESH3 = "Esh3",
    ABILITY_RLF_DECAY_POWER = "Esh4",
    ABILITY_RLF_INITIAL_DAMAGE_ESH5 = "Esh5"
}
local function realField(which)
    if type(which) == "number" then
        for ____, field in ipairs(__TS__ObjectValues(REAL_FIELDS)) do
            if which == (string.byte(field, 1) or 0 / 0) * 16777216 + (string.byte(field, 2) or 0 / 0) * 65536 + (string.byte(field, 3) or 0 / 0) * 256 + (string.byte(field, 4) or 0 / 0) then
                return field
            end
        end
    end
    return REAL_FIELDS[tostring(which)] or tostring(which)
end
____exports.Warcraft3Abilities = __TS__Class()
local Warcraft3Abilities = ____exports.Warcraft3Abilities
Warcraft3Abilities.name = "Warcraft3Abilities"
function Warcraft3Abilities.prototype.____constructor(self, objects)
    if objects == nil then
        objects = {}
    end
    self.objects = objects
    self.units = __TS__New(Map)
    self.fields = __TS__New(Map)
    self.ids = __TS__New(Map)
end
function Warcraft3Abilities.prototype.shadowStrike(self, unit)
    local state = self:state(unit)
    for ____, ____value in __TS__Iterator(state.handles) do
        local id = ____value[1]
        local ability = ____value[2]
        do
            local object = self.objects[id]
            if (object and object.base) ~= "AEsh" then
                goto __continue9
            end
            local level = (state.levels:get(id) or 1) - 1
            local function value(field)
                local ____opt_2 = self.fields:get(ability)
                local ____temp_4 = ____opt_2 and ____opt_2:get((field .. " ") .. tostring(level))
                if ____temp_4 == nil then
                    ____temp_4 = 0
                end
                return __TS__Number(____temp_4)
            end
            if value("Esh2") ~= 0 or value("Esh3") ~= 0 or value("Esh4") ~= 0 then
                return nil
            end
            return {
                interval = value("acas"),
                duration = value("adur"),
                range = value("aran"),
                initial = value("Esh5"),
                periodic = value("Esh1"),
                impactDelay = object.impactDelay
            }
        end
        ::__continue9::
    end
    return nil
end
function Warcraft3Abilities.prototype.state(self, unit)
    local state = self.units:get(unit)
    if state == nil then
        state = {
            cooldowns = __TS__New(Map),
            remaining = __TS__New(Map),
            levels = __TS__New(Map),
            handles = __TS__New(Map),
            attackPeriods = __TS__New(Map),
            attackRemaining = __TS__New(Map),
            auras = true,
            auraUI = true
        }
        self.units:set(unit, state)
    end
    return state
end
function Warcraft3Abilities.prototype.removeUnit(self, unit)
    local state = self.units:get(unit)
    if state == nil then
        return
    end
    for ____, ability in __TS__Iterator(state.handles:values()) do
        self.fields:delete(ability)
        self.ids:delete(ability)
    end
    self.units:delete(unit)
end
function Warcraft3Abilities.prototype.tick(self, seconds)
    for ____, unit in __TS__Iterator(self.units:values()) do
        for ____, ____value in __TS__Iterator(unit.remaining) do
            local id = ____value[1]
            local remaining = ____value[2]
            unit.remaining:set(
                id,
                math.max(0, remaining - seconds)
            )
        end
        for ____, ____value in __TS__Iterator(unit.attackRemaining) do
            local index = ____value[1]
            local remaining = ____value[2]
            unit.attackRemaining:set(
                index,
                math.max(0, remaining - seconds)
            )
        end
    end
end
function Warcraft3Abilities.prototype.behaviors(self, handle)
    local function cooldown(unit, id)
        return self:state(unit).cooldowns:get((tostring(id) .. " ") .. tostring((self:state(unit).levels:get(id) or 1) - 1)) or 0
    end
    local function remaining(unit, id)
        return self:state(unit).remaining:get(id) or 0
    end
    local function setRemaining(unit, id, value)
        self:state(unit).remaining:set(
            id,
            math.max(0, value)
        )
    end
    local function field(ability, key)
        local ____opt_5 = self.fields:get(ability)
        return ____opt_5 and ____opt_5:get(key)
    end
    local function setField(ability, key, value)
        local fields = self.fields:get(ability)
        if fields == nil then
            return false
        end
        fields:set(key, value)
        return true
    end
    return {
        UnitAddAbility = function(unit, id)
            local state = self:state(unit)
            if state.handles:has(id) then
                return false
            end
            local ability = handle("ability")
            state.handles:set(id, ability)
            state.levels:set(id, 1)
            local fields = __TS__New(Map)
            local object = self.objects[id]
            if object ~= nil then
                for ____, ____value in ipairs(__TS__ObjectEntries(object.realLevelFields)) do
                    local field = ____value[1]
                    local levels = ____value[2]
                    do
                        local level = 0
                        while level < #levels do
                            fields:set(
                                (field .. " ") .. tostring(level),
                                levels[level + 1]
                            )
                            level = level + 1
                        end
                    end
                end
            end
            self.fields:set(ability, fields)
            self.ids:set(ability, id)
            return true
        end,
        UnitRemoveAbility = function(unit, id)
            local state = self:state(unit)
            local ability = state.handles:get(id)
            if ability == nil then
                return false
            end
            state.handles:delete(id)
            state.levels:delete(id)
            state.remaining:delete(id)
            self.fields:delete(ability)
            self.ids:delete(ability)
            return true
        end,
        GetUnitAbilityLevel = function(unit, id) return self:state(unit).levels:get(id) or 0 end,
        SetUnitAbilityLevel = function(unit, id, level)
            local state = self:state(unit)
            if not state.handles:has(id) then
                return 0
            end
            state.levels:set(id, level)
            return level
        end,
        BlzGetUnitAbility = function(unit, id) return self:state(unit).handles:get(id) end,
        BlzGetUnitAbilityByIndex = function(unit, index) return __TS__ArrayFrom(self:state(unit).handles:values())[index + 1] end,
        BlzGetAbilityId = function(ability) return self.ids:get(ability) or 0 end,
        BlzSetUnitAttackCooldown = function(unit, duration, index)
            self:state(unit).attackPeriods:set(index, duration)
        end,
        BlzGetUnitAttackCooldown = function(unit, index) return self:state(unit).attackPeriods:get(index) or 0 end,
        BlzResetUnitAttack = function(unit, index)
            self:state(unit).attackRemaining:set(index, 0)
        end,
        BlzUnitEnableAuras = function(unit, enable, affectsUI)
            local state = self:state(unit)
            state.auras = enable
            if affectsUI then
                state.auraUI = enable
            end
        end,
        BlzSetUnitAbilityCooldown = function(unit, id, level, duration)
            self:state(unit).cooldowns:set(
                (tostring(id) .. " ") .. tostring(level),
                duration
            )
        end,
        BlzGetUnitAbilityCooldown = function(unit, id, level) return self:state(unit).cooldowns:get((tostring(id) .. " ") .. tostring(level)) or 0 end,
        BlzGetUnitAbilityCooldownRemaining = remaining,
        BlzGetUnitAbilityCooldownPercent = function(unit, id) return cooldown(unit, id) == 0 and 0 or __wispF32Divide(
            remaining(unit, id),
            cooldown(unit, id)
        ) end,
        BlzSetUnitAbilityCooldownRemaining = setRemaining,
        BlzSetUnitAbilityCooldownPercent = function(unit, id, percent) return setRemaining(
            unit,
            id,
            __wispF32Multiply(
                cooldown(unit, id),
                percent
            )
        ) end,
        BlzAdjustUnitAbilityCooldownRemaining = function(unit, id, duration) return setRemaining(
            unit,
            id,
            __wispF32Add(
                remaining(unit, id),
                duration
            )
        ) end,
        BlzAdjustUnitAbilityCooldownPercent = function(unit, id, percent) return setRemaining(
            unit,
            id,
            __wispF32Add(
                remaining(unit, id),
                __wispF32Multiply(
                    cooldown(unit, id),
                    percent
                )
            )
        ) end,
        BlzStartUnitAbilityCooldown = setRemaining,
        BlzEndUnitAbilityCooldown = function(unit, id) return setRemaining(unit, id, 0) end,
        UnitResetCooldown = function(unit) return self:state(unit).remaining:clear() end,
        BlzGetAbilityRealLevelField = function(ability, which, level)
            local ____field_result_7 = field(
                ability,
                (realField(which) .. " ") .. tostring(level)
            )
            if ____field_result_7 == nil then
                ____field_result_7 = 0
            end
            return ____field_result_7
        end,
        BlzSetAbilityRealLevelField = function(ability, which, level, value) return setField(
            ability,
            (realField(which) .. " ") .. tostring(level),
            value
        ) end,
        BlzGetAbilityBooleanLevelField = function(ability, which, level)
            local ____field_result_8 = field(
                ability,
                (tostring(which) .. " ") .. tostring(level)
            )
            if ____field_result_8 == nil then
                ____field_result_8 = false
            end
            return ____field_result_8
        end,
        BlzSetAbilityBooleanLevelField = function(ability, which, level, value) return setField(
            ability,
            (tostring(which) .. " ") .. tostring(level),
            value
        ) end
    }
end
return ____exports
