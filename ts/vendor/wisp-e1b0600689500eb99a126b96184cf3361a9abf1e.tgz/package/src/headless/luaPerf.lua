local ____lualib = require("lualib_bundle")
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____declarations = require("src.headless.declarations")
local ____journey = require("src.headless.journey")
local ____lua = require("src.headless.lua")
local ____nativeCost = require("src.headless.nativeCost")
local ____f32 = require("src.sim.f32")
local ____intMath = require("src.sim.intMath")
____exports.HOOK_STEP = 100
local COLLECT_EVERY_KB = 16384
local serve
serve = function(...)
    local native = select(1, ...)
    return serve(coroutine.yield(native(select(2, ...))))
end
local function nativeThread()
    return coroutine.create(function(...)
        debug.sethook()
        return serve(...)
    end)
end
local function add(values, index, amount)
    values[index + 1] = (values[index + 1] or 0) + amount
end
local function whole(value)
    return tostring(math.floor(value + 0x1p-1))
end
local function rank(sorted, share)
    if #sorted == 0 then
        return 0
    end
    local index = math.max(
        0,
        math.min(
            #sorted - 1,
            math.ceil(share * #sorted) - 1
        )
    )
    return sorted[index + 1] or 0
end
local function bundleModules(bundle)
    local modules = {}
    local name = "(bundle)"
    local line = 0
    for ____, text in ipairs(__TS__StringSplit(bundle, "\n")) do
        line = line + 1
        local header = string.match(text, "^%[\"(.-)\"%] = function%(%.%.%.%) $")
        if header ~= nil then
            name = header
        end
        modules[line + 1] = name
    end
    return modules
end
____exports.TOP_SHARE = 0x51eb85p-29
local function topMean(sorted)
    if #sorted == 0 then
        return 0
    end
    local count = math.max(
        1,
        math.ceil(____exports.TOP_SHARE * #sorted)
    )
    local sum = 0
    do
        local index = #sorted - count
        while index < #sorted do
            sum = sum + (sorted[index + 1] or 0)
            index = index + 1
        end
    end
    return sum / count
end
local function valueLine(slot, name, values, first, last)
    local perFrame = {}
    local total = 0
    do
        local frame = first
        while frame <= last do
            local value = values[frame + 1] or 0
            perFrame[#perFrame + 1] = value
            total = total + value
            frame = frame + 1
        end
    end
    __TS__ArraySort(
        perFrame,
        function(____, left, right) return left - right end
    )
    local middle = #perFrame // 2
    local median = #perFrame == 0 and 0 or (#perFrame % 2 == 1 and (perFrame[middle + 1] or 0) or ((perFrame[middle] or 0) + (perFrame[middle + 1] or 0)) / 2)
    local mean = #perFrame == 0 and 0 or total / #perFrame
    return (((((((((((((((("p" .. tostring(slot)) .. " ") .. name) .. " start=") .. whole(values[1] or 0)) .. " total=") .. whole(total)) .. " median=") .. whole(median)) .. " p95=") .. whole(rank(perFrame, 0xf33333p-24))) .. " mean=") .. whole(mean)) .. " max=") .. whole(rank(perFrame, 1))) .. " top=") .. whole(topMean(perFrame))
end
local function sum(values, first, last)
    local total = 0
    do
        local frame = first
        while frame <= last do
            total = total + (values[frame + 1] or 0)
            frame = frame + 1
        end
    end
    return total
end
local function moduleLines(cost, first, last)
    local names = {}
    for ____, ____value in __TS__Iterator(cost.moduleKb) do
        local name = ____value[1]
        names[#names + 1] = name
    end
    __TS__ArraySort(
        names,
        function(____, left, right) return left < right and -1 or (left > right and 1 or 0) end
    )
    local frames = math.max(1, last - first + 1)
    return __TS__ArrayMap(
        names,
        function(____, name)
            local bytes = sum(
                cost.moduleKb:get(name) or ({}),
                first,
                last
            ) * 1024
            return (((((("p" .. tostring(cost.slot)) .. " module-alloc-bytes ") .. name) .. " total=") .. whole(bytes)) .. " mean=") .. whole(bytes / frames)
        end
    )
end
local function costLines(cost, first, last, model)
    local callbacks = {}
    local typing = {}
    do
        local frame = 0
        while frame <= last do
            local predicted = ____nativeCost.nativeFrameCost(model, {instructions = cost.instructions[frame + 1] or 0, natives = cost.natives[frame + 1] or 0, allocatedKb = cost.allocatedKb[frame + 1] or 0, typedCharacters = cost.typed[frame + 1] or 0})
            callbacks[#callbacks + 1] = predicted.callbacksUs
            typing[#typing + 1] = predicted.typingUs
            frame = frame + 1
        end
    end
    local named = {
        {"instructions", cost.instructions},
        {"lua-us", cost.microseconds},
        {"natives", cost.natives},
        {"alloc-kb", cost.allocatedKb},
        {"typed", cost.typed},
        {"native-us", callbacks},
        {"typing-us", typing},
        {"runtime-instructions", cost.runtimeInstructions},
        {"runtime-alloc-kb", cost.runtimeKb}
    }
    local ____array_0 = __TS__SparseArrayNew(table.unpack(__TS__ArrayMap(
        named,
        function(____, ____bindingPattern0)
            local values
            local name
            name = ____bindingPattern0[1]
            values = ____bindingPattern0[2]
            return valueLine(
                cost.slot,
                name,
                values,
                first,
                last
            )
        end
    )))
    __TS__SparseArrayPush(
        ____array_0,
        table.unpack(moduleLines(cost, first, last))
    )
    return {__TS__SparseArraySpread(____array_0)}
end
function ____exports.runLuaPerfWith(map, bundlePath, declarationsPath, play, options)
    if options == nil then
        options = {}
    end
    local clients
    local declarations = ____lua.readFile(declarationsPath)
    local costs = __TS__New(Map)
    local bySlot = __TS__New(Map)
    local ____opt_1 = debug.getinfo(1, "S")
    local runtimeSource = ____opt_1 and ____opt_1.source
    local moduleOfLine = bundleModules(____lua.readFile(bundlePath))
    local active
    local lastKb = 0
    local lastNativeKb = 0
    local count
    count = function()
        local heap = collectgarbage("count")
        local info = debug.getinfo(2, "Sl")
        local cost = active
        if cost ~= nil and info ~= nil then
            local frame = clients and clients.frame or 0
            local kb = heap - lastKb - (cost.nativeKb - lastNativeKb)
            local source = info.source or ""
            if source == runtimeSource then
                add(cost.runtimeInstructions, frame, ____exports.HOOK_STEP)
                add(cost.runtimeKb, frame, kb)
            else
                add(cost.instructions, frame, ____exports.HOOK_STEP)
                add(cost.allocatedKb, frame, kb)
                local name = source == "=map" and (moduleOfLine[(info.currentline or 0) + 1] or "(bundle)") or source
                local series = cost.moduleKb:get(name)
                if series == nil then
                    series = {}
                    cost.moduleKb:set(name, series)
                end
                add(series, frame, kb)
            end
            lastNativeKb = cost.nativeKb
        end
        lastKb = collectgarbage("count")
        debug.sethook(count, "", ____exports.HOOK_STEP)
    end
    local nativeSeconds = 0
    local depth = 0
    local thread = nativeThread()
    local entered = {seconds = 0, natives = 0, calls = 0}
    local collectedKb = collectgarbage("count")
    local collector = {us = 0, kb = 0}
    local scope = {
        enter = function(client)
            local heap = collectgarbage("count")
            if heap > collectedKb + COLLECT_EVERY_KB then
                local started = os.clock()
                collectgarbage("collect")
                collectedKb = collectgarbage("count")
                collector.us = collector.us + (os.clock() - started) * 1000000
                collector.kb = collector.kb + (heap - collectedKb)
            end
            collectgarbage("stop")
            local cost = costs:get(client)
            active = cost
            lastKb = collectgarbage("count")
            lastNativeKb = cost and cost.nativeKb or 0
            debug.sethook(count, "", ____exports.HOOK_STEP)
            entered = {
                seconds = os.clock(),
                natives = nativeSeconds,
                calls = cost and cost.calls or 0
            }
        end,
        leave = function(client)
            local seconds = os.clock()
            debug.sethook()
            local kb = collectgarbage("count")
            collectgarbage("restart")
            active = nil
            local cost = costs:get(client)
            if cost == nil then
                return
            end
            local frame = clients and clients.frame or 0
            add(cost.microseconds, frame, (seconds - entered.seconds - (nativeSeconds - entered.natives)) * 1000000)
            add(cost.natives, frame, cost.calls - entered.calls)
            add(cost.runtimeKb, frame, kb - lastKb - (cost.nativeKb - lastNativeKb))
        end
    }
    local function counted(cost, native)
        return function(...)
            cost.calls = cost.calls + 1
            if depth > 0 then
                return native(...)
            end
            depth = depth + 1
            local started = os.clock()
            local kb = collectgarbage("count")
            local ran, result = coroutine.resume(thread, native, ...)
            cost.nativeKb = cost.nativeKb + (collectgarbage("count") - kb)
            nativeSeconds = nativeSeconds + (os.clock() - started)
            depth = depth - 1
            if not ran then
                thread = nativeThread()
                error(result, 0)
            end
            return result
        end
    end
    local lockstep = ____lua.luaLockstep(
        map,
        ____lua.readFile(bundlePath),
        declarations,
        scope,
        options.delivery
    )
    clients = lockstep
    local names = __TS__ArrayMap(
        ____declarations.parseNativeDeclarations(declarations).functions,
        function(____, ____bindingPattern0)
            local name
            name = ____bindingPattern0[1]
            return name
        end
    )
    for ____, client in ipairs(lockstep.clients) do
        local cost = {
            slot = client.slot,
            instructions = {},
            microseconds = {},
            natives = {},
            allocatedKb = {},
            runtimeInstructions = {},
            runtimeKb = {},
            moduleKb = __TS__New(Map),
            typed = {},
            calls = 0,
            nativeKb = 0
        }
        costs:set(client, cost)
        bySlot:set(client.slot, cost)
        for ____, name in ipairs(names) do
            local native = client.natives[name]
            if type(native) == "function" then
                client.natives[name] = counted(cost, native)
            end
        end
    end
    local first = 1
    local measure = {
        begin = function()
            first = lockstep.frame + 1
        end,
        typed = function(slot, characters)
            local cost = bySlot:get(slot)
            if cost ~= nil then
                add(cost.typed, lockstep.frame + 1, characters)
            end
        end
    }
    local result
    do
        local ____try, ____error = pcall(function()
            result = play(lockstep, measure)
        end)
        do
            debug.sethook()
            collectgarbage("restart")
        end
        if not ____try then
            error(____error, 0)
        end
    end
    print((((("frames " .. tostring(lockstep.frame - first + 1)) .. " step ") .. tostring(____exports.HOOK_STEP)) .. " problems ") .. tostring(result.problems))
    print((("collector us=" .. whole(collector.us)) .. " kb=") .. whole(collector.kb))
    local model = options.model or ____nativeCost.WARCRAFT_COST
    for ____, cost in __TS__Iterator(costs:values()) do
        for ____, line in ipairs(costLines(cost, first, lockstep.frame, model)) do
            print(line)
        end
    end
    if options.samples == true then
        do
            local frame = first
            while frame <= lockstep.frame do
                for ____, cost in __TS__Iterator(costs:values()) do
                    print((((((((((((("frame " .. tostring(frame)) .. " p") .. tostring(cost.slot)) .. " instructions=") .. tostring(cost.instructions[frame + 1] or 0)) .. " lua-us=") .. whole(cost.microseconds[frame + 1] or 0)) .. " natives=") .. tostring(cost.natives[frame + 1] or 0)) .. " alloc-bytes=") .. whole((cost.allocatedKb[frame + 1] or 0) * 1024)) .. " typed=") .. tostring(cost.typed[frame + 1] or 0))
                end
                frame = frame + 1
            end
        end
    end
    if result.problems > 0 then
        for ____, line in ipairs(result.lines) do
            print("journey: " .. line)
        end
    end
    return result.problems
end
function ____exports.runLuaPerf(map, journey, bundlePath, declarationsPath, options)
    if options == nil then
        options = {}
    end
    return ____exports.runLuaPerfWith(
        map,
        bundlePath,
        declarationsPath,
        function(clients)
            local result = ____journey.runJourney(clients, journey, {checksums = false})
            return {
                problems = ____journey.journeyProblems(result),
                lines = ____journey.journeyLines(result)
            }
        end,
        options
    )
end
return ____exports
