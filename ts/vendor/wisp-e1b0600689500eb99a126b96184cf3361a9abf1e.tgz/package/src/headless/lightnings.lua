local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local ____f32 = require("src.sim.f32")
____exports.Lightnings = __TS__Class()
local Lightnings = ____exports.Lightnings
Lightnings.name = "Lightnings"
function Lightnings.prototype.____constructor(self)
    self.bolts = __TS__New(Map)
end
function Lightnings.prototype.behaviors(self, context)
    local function bolt(value)
        return self.bolts:get(value)
    end
    local function add(codeName, x1, y1, z1, x2, y2, z2)
        local handle = context.handle("lightning")
        self.bolts:set(handle, {
            handle = handle,
            codeName = codeName,
            from = {x1, y1, z1},
            to = {x2, y2, z2},
            color = {1, 1, 1, 1}
        })
        return handle
    end
    local function move(value, x1, y1, z1, x2, y2, z2)
        local found = bolt(value)
        if found == nil then
            return false
        end
        found.from = {x1, y1, z1}
        found.to = {x2, y2, z2}
        return true
    end
    local function channel(index)
        return function(value)
            local ____opt_0 = bolt(value)
            return ____opt_0 and ____opt_0.color[index + 1] or 0
        end
    end
    return {
        AddLightning = function(codeName, _visible, x1, y1, x2, y2) return add(
            codeName,
            x1,
            y1,
            0,
            x2,
            y2,
            0
        ) end,
        AddLightningEx = function(codeName, _visible, x1, y1, z1, x2, y2, z2) return add(
            codeName,
            x1,
            y1,
            z1,
            x2,
            y2,
            z2
        ) end,
        DestroyLightning = function(value) return self.bolts:delete(value) end,
        MoveLightning = function(value, _visible, x1, y1, x2, y2) return move(
            value,
            x1,
            y1,
            0,
            x2,
            y2,
            0
        ) end,
        MoveLightningEx = function(value, _visible, x1, y1, z1, x2, y2, z2) return move(
            value,
            x1,
            y1,
            z1,
            x2,
            y2,
            z2
        ) end,
        SetLightningColor = function(value, red, green, blue, alpha)
            local found = bolt(value)
            if found == nil then
                return false
            end
            found.color = {red, green, blue, alpha}
            return true
        end,
        GetLightningColorR = channel(0),
        GetLightningColorG = channel(1),
        GetLightningColorB = channel(2),
        GetLightningColorA = channel(3)
    }
end
function Lightnings.prototype.poses(self)
    return __TS__ArrayMap(
        {__TS__Spread(self.bolts:values())},
        function(____, found) return {
            handle = found.handle,
            codeName = found.codeName,
            from = {table.unpack(found.from)},
            to = {table.unpack(found.to)},
            color = {table.unpack(found.color)}
        } end
    )
end
return ____exports
