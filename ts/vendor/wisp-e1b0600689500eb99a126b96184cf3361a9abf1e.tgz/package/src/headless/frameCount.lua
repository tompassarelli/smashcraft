local ____exports = {}
--- Frames headless clients have stepped in this process: a test's deterministic cost (wisp:scripts/wisp/testCostPreload.ts).
____exports.steppedFrames = {count = 0}
return ____exports
