local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local ____exports = {}
local CHECKS_PER_PACKET = 4
--- One process's side of a two-player match: its own events by due frame, the peer's as packets bring them, and checksum agreement (wisp:docs/network-model.md).
____exports.TurnLedger = __TS__Class()
local TurnLedger = ____exports.TurnLedger
TurnLedger.name = "TurnLedger"
function TurnLedger.prototype.____constructor(self, ____local, remote, clock)
    self["local"] = ____local
    self.remote = remote
    self.clock = clock
    self.delay = 1
    self.executed = 0
    self.remoteFrontier = 0
    self.peerAck = 0
    self.remoteDone = false
    self.compared = 0
    self.lastCompared = 0
    self.latencies = {}
    self.advertised = 0
    self.outgoing = __TS__New(Map)
    self.incoming = __TS__New(Map)
    self.localChecks = {}
    self.remoteChecks = __TS__New(Map)
    self.sent = function(____, frame, event)
        if frame <= self.advertised or frame <= self.executed then
            do
                local ____thrown = __TS__New(
                    Error,
                    ((("an event due at frame " .. tostring(frame)) .. " comes after frame ") .. tostring(math.max(self.advertised, self.executed))) .. " was promised complete"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/turnLedger.ts:54"
                end
                error(____thrown, 0)
            end
        end
        local turn = self.outgoing:get(frame)
        if turn == nil then
            local ____self_1 = self.outgoing
            local ____self_1_set_2 = ____self_1.set
            local ____frame_0 = frame
            turn = {
                at = self.clock(),
                events = {}
            }
            ____self_1_set_2(____self_1, ____frame_0, turn)
        end
        local ____turn_events_3 = turn.events
        ____turn_events_3[#____turn_events_3 + 1] = event
    end
    self.due = function(____, frame)
        if frame ~= self.executed + 1 then
            do
                local ____thrown = __TS__New(
                    Error,
                    (("frame " .. tostring(frame)) .. " runs after frame ") .. tostring(self.executed)
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/turnLedger.ts:62"
                end
                error(____thrown, 0)
            end
        end
        if not self:ready(frame) then
            do
                local ____thrown = __TS__New(
                    Error,
                    ((((("frame " .. tostring(frame)) .. " runs before slot ") .. tostring(self.remote)) .. "'s events for it arrived (they reach frame ") .. tostring(self.remoteFrontier)) .. ")"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/turnLedger.ts:63"
                end
                error(____thrown, 0)
            end
        end
        self.executed = frame
        local ____opt_4 = self.outgoing:get(frame)
        local own = ____opt_4 and ____opt_4.events or ({})
        local theirs = self.incoming:get(frame)
        self.incoming:delete(frame)
        self:prune()
        if theirs == nil then
            return own
        end
        local ____self_latencies_6 = self.latencies
        ____self_latencies_6[#____self_latencies_6 + 1] = self.clock() - theirs.at
        local ____temp_9
        if self["local"] < self.remote then
            local ____array_7 = __TS__SparseArrayNew(table.unpack(own))
            __TS__SparseArrayPush(
                ____array_7,
                table.unpack(theirs.events)
            )
            ____temp_9 = {__TS__SparseArraySpread(____array_7)}
        else
            local ____array_8 = __TS__SparseArrayNew(table.unpack(theirs.events))
            __TS__SparseArrayPush(
                ____array_8,
                table.unpack(own)
            )
            ____temp_9 = {__TS__SparseArraySpread(____array_8)}
        end
        return ____temp_9
    end
end
function TurnLedger.prototype.frontier(self)
    return self.executed + self.delay
end
function TurnLedger.prototype.ready(self, frame)
    return frame <= self.remoteFrontier
end
function TurnLedger.prototype.check(self, frame, checksum)
    local ____self_localChecks_10 = self.localChecks
    ____self_localChecks_10[#____self_localChecks_10 + 1] = {frame, checksum}
    if #self.localChecks > CHECKS_PER_PACKET then
        table.remove(self.localChecks, 1)
    end
    self:compare(
        frame,
        checksum,
        self.remoteChecks:get(frame)
    )
end
function TurnLedger.prototype.packet(self, done)
    if done == nil then
        done = false
    end
    local frontier = self:frontier()
    self.advertised = math.max(self.advertised, frontier)
    local turns = {}
    local frames = __TS__ArraySort(
        __TS__ArrayFilter(
            {__TS__Spread(self.outgoing:keys())},
            function(____, frame) return frame > self.peerAck and frame <= frontier end
        ),
        function(____, a, b) return a - b end
    )
    for ____, frame in ipairs(frames) do
        local turn = self.outgoing:get(frame)
        if turn ~= nil then
            turns[#turns + 1] = {frame = frame, at = turn.at, events = turn.events}
        end
    end
    return {
        from = self["local"],
        frontier = frontier,
        ack = self.remoteFrontier,
        turns = turns,
        checks = {table.unpack(self.localChecks)},
        done = done
    }
end
function TurnLedger.prototype.receive(self, packet)
    if packet.from ~= self.remote then
        return
    end
    if packet.done then
        self.remoteDone = true
    end
    self.peerAck = math.max(self.peerAck, packet.ack)
    if packet.frontier > self.remoteFrontier then
        for ____, turn in ipairs(packet.turns) do
            if turn.frame > self.remoteFrontier then
                self.incoming:set(turn.frame, turn)
            end
        end
        self.remoteFrontier = packet.frontier
    end
    for ____, ____value in ipairs(packet.checks) do
        local frame = ____value[1]
        local checksum = ____value[2]
        do
            if self.remoteChecks:has(frame) or frame <= self.lastCompared then
                goto __continue27
            end
            self.remoteChecks:set(frame, checksum)
            local ____local = __TS__ArrayFind(
                self.localChecks,
                function(____, ____bindingPattern0)
                    local at
                    at = ____bindingPattern0[1]
                    return at == frame
                end
            )
            if ____local ~= nil then
                self:compare(frame, ____local[2], checksum)
            end
        end
        ::__continue27::
    end
    self:prune()
end
function TurnLedger.prototype.compare(self, frame, ____local, remote)
    if remote == nil then
        return
    end
    self.compared = self.compared + 1
    self.lastCompared = math.max(self.lastCompared, frame)
    self.remoteChecks:delete(frame)
    if ____local ~= remote and self.mismatch == nil then
        self.mismatch = {frame = frame, ["local"] = ____local, remote = remote}
    end
end
function TurnLedger.prototype.prune(self)
    for ____, frame in ipairs({__TS__Spread(self.outgoing:keys())}) do
        if frame <= self.peerAck and frame <= self.executed then
            self.outgoing:delete(frame)
        end
    end
end
return ____exports
