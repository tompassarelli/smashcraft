local ____lualib = require("lualib_bundle")
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringTrim = ____lualib.__TS__StringTrim
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local function declaredName(line, keyword)
    local start = #keyword
    local ____end = start
    while ____end < #line do
        local character = __TS__StringCharAt(line, ____end)
        if character == "(" or character == ":" or character == " " then
            break
        end
        ____end = ____end + 1
    end
    return ____end > start and __TS__StringSlice(line, start, ____end) or nil
end
local function declaredType(line)
    if not __TS__StringEndsWith(line, ";") then
        return nil
    end
    do
        local colon = #line - 2
        while colon > 0 do
            if __TS__StringCharAt(line, colon) == ":" and __TS__StringCharAt(line, colon + 1) == " " then
                return __TS__StringSlice(line, colon + 2, #line - 1)
            end
            colon = colon - 1
        end
    end
    return nil
end
local function declaredParameters(line, from)
    local depth = 0
    local count = 0
    local any = false
    do
        local index = (string.find(
            line,
            "(",
            math.max(from + 1, 1),
            true
        ) or 0) - 1
        while index < #line do
            do
                local character = __TS__StringCharAt(line, index)
                if character == "(" then
                    depth = depth + 1
                    goto __continue12
                end
                if character == ")" then
                    depth = depth - 1
                    if depth == 0 then
                        break
                    end
                    goto __continue12
                end
                if depth == 1 and character == "," then
                    count = count + 1
                elseif character ~= " " then
                    any = true
                end
            end
            ::__continue12::
            index = index + 1
        end
    end
    return any and count + 1 or 0
end
function ____exports.parseNativeDeclarations(text)
    local functions = {}
    local constants = {}
    local variables = {}
    for ____, line in ipairs(__TS__StringSplit(text, "\n")) do
        do
            local keyword = __TS__StringStartsWith(line, "declare function ") and "declare function " or (__TS__StringStartsWith(line, "declare const ") and "declare const " or (__TS__StringStartsWith(line, "declare let ") and "declare let " or nil))
            if keyword == nil then
                goto __continue19
            end
            local name = declaredName(line, keyword)
            local ____type = declaredType(__TS__StringTrim(line))
            if name == nil or ____type == nil then
                goto __continue19
            end
            if keyword == "declare function " then
                functions[#functions + 1] = {
                    name,
                    ____type,
                    declaredParameters(line, #keyword + #name)
                }
            elseif keyword == "declare const " then
                constants[#constants + 1] = {name, ____type}
            else
                variables[#variables + 1] = {name, ____type}
            end
        end
        ::__continue19::
    end
    return {functions = functions, constants = constants, variables = variables}
end
return ____exports
