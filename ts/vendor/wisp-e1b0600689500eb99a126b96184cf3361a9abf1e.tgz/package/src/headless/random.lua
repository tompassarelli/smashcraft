local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__MathTrunc = ____lualib.__TS__MathTrunc
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____intMath = require("src.sim.intMath")
--- Park-Miller minimal standard generator in Schrage's form: every product stays below 2^31.
____exports.Random = __TS__Class()
local Random = ____exports.Random
Random.name = "Random"
function Random.prototype.____constructor(self, seed)
    self.state = math.abs(__TS__MathTrunc(seed)) % 2147483646 + 1
end
function Random.prototype.next(self)
    local high = self.state // 44488
    local next = 48271 * (self.state - high * 44488) - 3399 * high
    self.state = next > 0 and next or next + 2147483647
    return self.state / 2147483647
end
function Random.prototype.between(self, low, high)
    return low + math.min(
        high - low,
        math.floor(self:next() * (high - low + 1))
    )
end
function Random.prototype.chance(self, p)
    return self:next() < p
end
function Random.prototype.pick(self, items)
    local item = items[self:between(0, #items - 1) + 1]
    if item == nil then
        do
            local ____thrown = __TS__New(Error, "pick from no items")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/random.ts:28"
            end
            error(____thrown, 0)
        end
    end
    return item
end
return ____exports
