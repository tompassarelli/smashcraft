local ____exports = {}
--- Warcraft III's simulation rate, which headless clients, lockstep peers and the renderers step at.
____exports.FRAMES_PER_SECOND = 60
____exports.FRAME_MS = 1000 / ____exports.FRAMES_PER_SECOND
return ____exports
