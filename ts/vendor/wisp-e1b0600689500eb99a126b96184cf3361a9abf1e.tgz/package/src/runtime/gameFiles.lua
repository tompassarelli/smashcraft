local ____lualib = require("lualib_bundle")
local __TS__StringReplace = ____lualib.__TS__StringReplace
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__Number = ____lualib.__TS__Number
local ____exports = {}
____exports.CHUNKS_PER_FILE = 64
____exports.PAYLOAD_FILE_BYTES = 200000
____exports.FILE_IO_ABILITY = 611808108
____exports.FILE_SLOTS = 4
____exports.hotFolder = function(prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return prefix .. "-hot"
end
____exports.hostFile = function(prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ____exports.hotFolder(prefix) .. "\\host.pld"
end
____exports.manifestFile = function(version, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((____exports.hotFolder(prefix) .. "\\manifest-") .. tostring(version)) .. ".pld"
end
____exports.payloadKey = function(payloadChecksum) return __TS__StringReplace(payloadChecksum, ":", "-") end
____exports.payloadFile = function(state, index, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((((____exports.hotFolder(prefix) .. "\\") .. ____exports.payloadKey(state)) .. "-") .. tostring(index)) .. ".pld"
end
____exports.deltaFile = function(state, base, index, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((((((____exports.hotFolder(prefix) .. "\\") .. ____exports.payloadKey(state)) .. "-") .. ____exports.payloadKey(base)) .. "-") .. tostring(index)) .. ".pld"
end
____exports.ackFile = function(slot, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((prefix .. "-hot-ack-p") .. tostring(slot)) .. ".txt"
end
____exports.errorFile = function(slot, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((prefix .. "-error-p") .. tostring(slot)) .. ".txt"
end
____exports.modelFailureRequestFile = function(slot, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((prefix .. "-model-load-p") .. tostring(slot)) .. ".txt"
end
____exports.modelFailureTokenFile = function(slot, ordinal, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((((____exports.hotFolder(prefix) .. "\\model-load-token-p") .. tostring(slot)) .. "-") .. tostring(ordinal)) .. ".pld"
end
____exports.modelFailureFile = function(token, ordinal, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((((____exports.hotFolder(prefix) .. "\\model-load-") .. token) .. "-") .. tostring(ordinal)) .. ".pld"
end
____exports.NO_BASE = "-"
____exports.formatManifest = function(____bindingPattern0)
    local changes
    local base
    local files
    local state
    local version
    version = ____bindingPattern0.version
    state = ____bindingPattern0.state
    files = ____bindingPattern0.files
    base = ____bindingPattern0.base
    changes = ____bindingPattern0.changes
    return (((((((tostring(version) .. " ") .. state) .. " ") .. tostring(files)) .. " ") .. base) .. " ") .. tostring(changes)
end
function ____exports.parseManifest(text)
    local versionText, state, filesText, base, changesText = table.unpack(
        __TS__StringSplit(text, " "),
        1,
        5
    )
    local version = __TS__Number(versionText)
    local files = __TS__Number(filesText)
    local changes = __TS__Number(changesText)
    if not (version >= 1) or not (files >= 1) or not (changes >= 0) or state == nil or base == nil then
        return nil
    end
    if base == ____exports.NO_BASE ~= (changes == 0) then
        return nil
    end
    return {
        version = version,
        state = state,
        files = files,
        base = base,
        changes = changes
    }
end
____exports.acknowledgementLine = function(version, elapsed) return (("applied " .. tostring(version)) .. " at ") .. tostring(elapsed) end
____exports.errorHeading = function(count, handler) return (("error " .. tostring(count)) .. " in ") .. handler end
return ____exports
