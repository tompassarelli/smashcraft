local ____lualib = require("lualib_bundle")
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local ____config = require("src.runtime.config")
local MAX_LINE = 240
function ____exports.stackDepth()
    local ____opt_0 = _G.__wispStack
    return ____opt_0 and ____opt_0.depth or 0
end
function ____exports.restoreStack(depth)
    local stack = _G.__wispStack
    if stack == nil then
        return
    end
    stack.depth = depth
    stack.failure = nil
end
--- Lua runtime errors are strings that start with their position; thrown Errors are tables.
local function describe(____error)
    if type(____error) == "string" then
        return ____error
    end
    if type(____error) == "table" and ____error ~= nil and ____error.message ~= nil then
        local name = ____error.name ~= nil and tostring(____error.name) or "Error"
        return (name .. ": ") .. tostring(____error.message)
    end
    return tostring(____error)
end
--- Compiler-recorded TypeScript frames work in Warcraft without Lua's debug library.
function ____exports.traceback(____error)
    local stack = _G.__wispStack
    if stack ~= nil then
        local frames = stack.failure ~= nil and stack.failure.error == ____error and stack.failure or stack
        local lines = {}
        do
            local depth = frames.depth
            while depth > 0 do
                local frame = frames.frames[depth]
                if frame ~= nil then
                    lines[#lines + 1] = frame
                end
                depth = depth - 1
            end
        end
        return table.concat(lines, "\n")
    end
    return type(debug) == "table" and debug.traceback(nil, 3) or ""
end
local function throwSite(____error, stack)
    local ____temp_2
    if stack == "" and ____error == _G.__wispThrown then
        ____temp_2 = _G.__wispThrowSite
    else
        ____temp_2 = nil
    end
    return ____temp_2
end
function ____exports.reportError(handler, ____error, stack)
    local configuration = ____config.runtimeConfiguration()
    local globals = _G
    local ____globals_3, ____temp_4 = globals, configuration.globalPrefix .. "Errors"
    if ____globals_3[____temp_4] == nil then
        ____globals_3[____temp_4] = {last = nil, count = 0}
    end
    local state = globals[configuration.globalPrefix .. "Errors"]
    local site = throwSite(____error, stack)
    local message = site == nil and describe(____error) or (site .. ": ") .. describe(____error)
    if message == state.last then
        return
    end
    state.last = message
    state.count = state.count + 1
    if configuration.errorsOnScreen ~= false then
        DisplayTextToPlayer(
            GetLocalPlayer(),
            0,
            0,
            (("error in " .. handler) .. ": ") .. message
        )
    end
    PreloadGenClear()
    PreloadGenStart()
    Preload(____gameFiles.errorHeading(state.count, handler))
    for ____, line in ipairs({
        message,
        table.unpack(__TS__StringSplit(stack, "\n"))
    }) do
        if line ~= "" then
            Preload(__TS__StringSlice(line, 0, MAX_LINE))
        end
    end
    PreloadGenEnd(____gameFiles.errorFile(
        GetPlayerId(GetLocalPlayer()),
        configuration.filePrefix
    ))
end
return ____exports
