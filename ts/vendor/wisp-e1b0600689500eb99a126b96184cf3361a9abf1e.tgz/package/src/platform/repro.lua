local ____exports = {}
local ____repro = require("src.runtime.repro")
local ____fileio = require("src.platform.fileio")
function ____exports.writeRepro(filename, header, lines)
    ____fileio.writeLines(
        filename,
        ____repro.reproLines(header, lines)
    )
end
return ____exports
