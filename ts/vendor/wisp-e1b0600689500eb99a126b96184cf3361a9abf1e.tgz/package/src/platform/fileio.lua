local ____lualib = require("lualib_bundle")
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
function ____exports.writeLines(filename, lines)
    PreloadGenClear()
    PreloadGenStart()
    for ____, line in ipairs(lines) do
        Preload(line)
    end
    PreloadGenEnd(filename)
end
local EMPTY = " "
function ____exports.readChunks(filename)
    do
        local level = 0
        while level < ____gameFiles.CHUNKS_PER_FILE do
            BlzSetAbilityTooltip(____gameFiles.FILE_IO_ABILITY, EMPTY, level)
            level = level + 1
        end
    end
    Preloader(filename)
    local chunks = {}
    do
        local level = 0
        while level < ____gameFiles.CHUNKS_PER_FILE do
            local chunk = BlzGetAbilityTooltip(____gameFiles.FILE_IO_ABILITY, level)
            if chunk == EMPTY then
                break
            end
            chunks[#chunks + 1] = chunk
            BlzSetAbilityTooltip(____gameFiles.FILE_IO_ABILITY, EMPTY, level)
            level = level + 1
        end
    end
    return chunks
end
function ____exports.readChunk(filename)
    BlzSetAbilityTooltip(____gameFiles.FILE_IO_ABILITY, EMPTY, 0)
    Preloader(filename)
    local chunk = BlzGetAbilityTooltip(____gameFiles.FILE_IO_ABILITY, 0)
    BlzSetAbilityTooltip(____gameFiles.FILE_IO_ABILITY, EMPTY, 0)
    local ____temp_0
    if chunk == EMPTY or chunk == "" then
        ____temp_0 = nil
    else
        ____temp_0 = chunk
    end
    return ____temp_0
end
function ____exports.writeLine(filename, line)
    ____exports.writeLines(filename, {line})
end
--- FileIO chunks are spliced into JASS string literals, so these characters cannot be stored.
local UNSTORABLE = {"\\", "\"", "\n", "\r"}
function ____exports.writeChunks(filename, chunks)
    if #chunks >= ____gameFiles.CHUNKS_PER_FILE or __TS__ArraySome(
        chunks,
        function(____, chunk) return __TS__ArraySome(
            UNSTORABLE,
            function(____, character) return __TS__StringIncludes(chunk, character) end
        ) end
    ) then
        return false
    end
    local lines = __TS__ArrayMap(
        chunks,
        function(____, chunk, level) return ((("\" )\ncall BlzSetAbilityTooltip('$wsl', \"" .. chunk) .. "\", ") .. tostring(level)) .. ")\n//" end
    )
    local ____exports_writeLines_3 = ____exports.writeLines
    local ____filename_2 = filename
    local ____array_1 = __TS__SparseArrayNew(table.unpack(lines))
    __TS__SparseArrayPush(____array_1, "\" )\nendfunction\nfunction a takes nothing returns nothing\n //")
    ____exports_writeLines_3(
        ____filename_2,
        {__TS__SparseArraySpread(____array_1)}
    )
    return true
end
return ____exports
