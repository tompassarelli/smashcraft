local ____lualib = require("lualib_bundle")
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__Number = ____lualib.__TS__Number
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____config = require("src.runtime.config")
local ____nativeDriver = require("src.runtime.nativeDriver")
local ____payload = require("src.runtime.payload")
local ____intMath = require("src.sim.intMath")
local ____dispatch = require("src.platform.dispatch")
local ____fileio = require("src.platform.fileio")
local SYNC = "wisp.nativeDriver"
local PREFIX = "WISP_DRIVE"
local function status(state)
    ____fileio.writeLine(
        ____nativeDriver.driverStatusFile(____config.runtimeConfiguration().filePrefix),
        (((((((((((("drive " .. tostring(state.serial)) .. " ") .. tostring(state.frame)) .. " ") .. state.checksum) .. " ") .. tostring(state.paused and 1 or 0)) .. " ") .. tostring(state.players)) .. " ") .. tostring(GetPlayerId(GetLocalPlayer()))) .. " ") .. tostring(state.refused and 1 or 0)
    )
end
local function prepare(state)
    if state.payload ~= nil then
        return
    end
    local text = ____fileio.readChunk(____nativeDriver.driverCommandFile(
        ____config.runtimeConfiguration().filePrefix,
        state.serial + 1
    ))
    if text == nil then
        return
    end
    state.payload = text
    state.digest = ____payload.checksum(
        #text,
        function(index) return __TS__StringCharCodeAt(text, index) end
    )
end
--- Every client first verifies its numbered payload; the last matching sync answer applies it everywhere.
function ____exports.installNativeDriver(handler)
    ____dispatch.on(
        SYNC,
        function()
            local state = _G.__wispDrive
            if state == nil then
                return
            end
            local fields = __TS__StringSplit(
                BlzGetTriggerSyncData(),
                " "
            )
            local serial = __TS__Number(fields[2])
            local sender = GetPlayerId(GetTriggerPlayer())
            if serial ~= state.serial + 1 or state.players & 1 << sender == 0 then
                return
            end
            if fields[1] == "offer" then
                if sender ~= state.leader then
                    return
                end
                prepare(state)
                if state.payload == nil or fields[3] ~= state.digest then
                    state.refused = true
                end
                state.offered = true
                state.sent = false
                return
            end
            if fields[1] ~= "ready" then
                return
            end
            if fields[3] == "refuse" or fields[3] ~= state.digest then
                state.refused = true
            end
            state.answers = state.answers | 1 << sender
            if state.answers ~= state.players then
                return
            end
            if state.refused or state.payload == nil then
                status(state)
                return
            end
            local payload = state.payload
            handler(payload)
            state.serial = serial
            state.payload = nil
            state.digest = nil
            state.answers = 0
            state.sent = false
            state.offered = false
            status(state)
        end
    )
end
--- Opt-in once at synchronized startup, before any commands are published.
function ____exports.startNativeDriver(players, leader)
    if leader == nil then
        leader = 0
    end
    if _G.__wispDrive ~= nil then
        do
            local ____thrown = __TS__New(Error, "native driver already started")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/nativeDriver.ts:82"
            end
            error(____thrown, 0)
        end
    end
    local prefix = ____config.runtimeConfiguration().filePrefix
    local function exists(serial)
        return ____fileio.readChunk(____nativeDriver.driverReadyFile(prefix, serial)) ~= nil
    end
    local serial = 0
    if exists(1) then
        local low = 1
        while exists(low * 2) do
            low = low * 2
        end
        local high = low * 2
        while high - low > 1 do
            local middle = (low + high) // 2
            if exists(middle) then
                low = middle
            else
                high = middle
            end
        end
        serial = low
    end
    local mask = 0
    for ____, slot in ipairs(players) do
        mask = mask | 1 << slot
    end
    local state = {
        serial = serial,
        players = mask,
        leader = leader,
        frame = 0,
        checksum = "00000000",
        paused = true,
        payload = nil,
        digest = nil,
        answers = 0,
        sent = false,
        polls = 0,
        refused = false,
        offered = false
    }
    _G.__wispDrive = state
    local trigger = CreateTrigger()
    for ____, slot in ipairs(players) do
        BlzTriggerRegisterPlayerSyncEvent(
            trigger,
            Player(slot),
            PREFIX,
            false
        )
    end
    TriggerAddAction(
        trigger,
        ____dispatch.trampoline(SYNC)
    )
    status(state)
end
--- Call on the existing callback even while simulation is held; no clock or timer is replaced.
function ____exports.serviceNativeDriver()
    local state = _G.__wispDrive
    if state == nil then
        return
    end
    state.polls = state.polls + 1
    if state.polls < 2 then
        return
    end
    state.polls = 0
    if state.offered then
        if not state.sent then
            state.sent = BlzSendSyncData(
                PREFIX,
                (("ready " .. tostring(state.serial + 1)) .. " ") .. (state.refused and "refuse" or (state.digest or "refuse"))
            )
        end
    elseif GetPlayerId(GetLocalPlayer()) == state.leader and not state.sent and ____fileio.readChunk(____nativeDriver.driverReadyFile(
        ____config.runtimeConfiguration().filePrefix,
        state.serial + 1
    )) ~= nil then
        prepare(state)
        if state.payload ~= nil and BlzSendSyncData(
            PREFIX,
            (("offer " .. tostring(state.serial + 1)) .. " ") .. (state.digest or "")
        ) then
            state.sent = true
        end
    end
end
function ____exports.publishNativeDriverStatus(frame, checksum, paused)
    local state = _G.__wispDrive
    if state == nil then
        return
    end
    state.frame = frame
    state.checksum = checksum
    state.paused = paused
    status(state)
end
return ____exports
