local ____lualib = require("lualib_bundle")
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local ____config = require("src.runtime.config")
local ____gameFiles = require("src.runtime.gameFiles")
local ____fileio = require("src.platform.fileio")
local function state()
    local globals = _G
    return globals[____config.runtimeConfiguration().globalPrefix .. "ModelFailures"]
end
function ____exports.startModelFailures()
    local config = ____config.runtimeConfiguration()
    local globals = _G
    local slot = GetPlayerId(GetLocalPlayer())
    local ordinal = 1
    while ____fileio.readChunk(____gameFiles.modelFailureTokenFile(slot, ordinal, config.filePrefix)) ~= nil do
        ordinal = ordinal + 1
    end
    local token = (tostring(slot) .. "-") .. tostring(ordinal)
    globals[config.globalPrefix .. "ModelFailures"] = {token = token, next = 1, ticks = 0, paths = {}}
    ____fileio.writeLine(
        ____gameFiles.modelFailureRequestFile(slot, config.filePrefix),
        token
    )
end
--- Local file results only change existing visual handles, never synchronized state.
function ____exports.pollModelFailures()
    local failures = state()
    if failures == nil then
        return
    end
    failures.ticks = failures.ticks + 1
    if failures.ticks < 32 then
        return
    end
    failures.ticks = 0
    local path = ____fileio.readChunk(____gameFiles.modelFailureFile(
        failures.token,
        failures.next,
        ____config.runtimeConfiguration().filePrefix
    ))
    while path ~= nil do
        failures.paths[string.lower(table.concat(
            __TS__StringSplit(path, "\\"),
            "/"
        ))] = true
        failures.next = failures.next + 1
        path = ____fileio.readChunk(____gameFiles.modelFailureFile(
            failures.token,
            failures.next,
            ____config.runtimeConfiguration().filePrefix
        ))
    end
end
function ____exports.modelFailed(path)
    local ____opt_0 = state()
    return (____opt_0 and ____opt_0.paths[string.lower(table.concat(
        __TS__StringSplit(path, "\\"),
        "/"
    ))]) == true
end
return ____exports
