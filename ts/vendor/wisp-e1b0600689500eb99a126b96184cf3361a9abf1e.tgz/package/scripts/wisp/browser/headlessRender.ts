import { ModelRenderer, decodeBLP, getBLPImageData, parseMDL, parseMDX, type model } from "../../../vendor/war3-model.mjs";
import { type AnimationSequence, animationSample, blendWeight, globalSequenceFrame, type SequenceSample } from "../../../src/headless/animation";
import type { DrawnPose as EffectPose, PopcornEmitterPose, RenderedFrame, RenderScene } from "../headlessRender";
import { parsableModel } from "../models";
import { drawnPoses } from "../culling";
import { advanceEmitters, type EmitterRenderer } from "./emitters";
import { drawTerrain } from "./terrain";
import { drawWater } from "./water";
import { depthTarget, type DepthTarget, invert, parsePostProcessing, POINT_FACE, pointFaces, postProcessor, type PostSettings, postSettings, resolve, sceneTarget, type SceneTarget, SUN_MAP, sunView } from "./passes";
import { terrainRows } from "../terrainMesh";
import { doodadSkinRows, terrainDoodadPoses } from "../terrainDoodads";
import { ddsTexture } from "./ddsTexture";
import { cliffOverrideTextures, cliffTexturePath } from "../terrainCliffs";

interface Material { readonly Layers: readonly { readonly FilterMode?: number }[] }

function orderDrawnModels<T>(poses: readonly T[], materials: (pose: T) => readonly Material[]): T[] {
  const transparent = (pose: T) => materials(pose).some((material) => material.Layers.some((layer) => (layer.FilterMode ?? 0) < 2)) ? 0 : 1;
  return [...poses].sort((a, b) => transparent(a) - transparent(b));
}

let cliffOverrides: ReadonlyMap<string, string> = new Map();
const cliffOverridesByTerrain = new Map<string, Promise<ReadonlyMap<string, string>>>();
async function bindCliffTextures(scene: RenderScene): Promise<void> {
  const tiles = scene.terrain?.cliffTiles ?? [];
  if (tiles.length === 0) { cliffOverrides = new Map(); return; }
  const key = tiles.join(",");
  let loading = cliffOverridesByTerrain.get(key);
  if (loading === undefined) cliffOverridesByTerrain.set(key, loading = asset("TerrainArt\\CliffTypes.slk").then((bytes) => cliffOverrideTextures(tiles, terrainRows(new Uint8Array(bytes)))));
  cliffOverrides = await loading;
}

let installedDoodads: Promise<ReadonlyMap<string, Readonly<Record<string, string>>>> | undefined;
async function scenePoses(scene: RenderScene): Promise<readonly EffectPose[]> {
  if (scene.terrainDoodads === undefined || scene.terrain === undefined) return scene.effects;
  installedDoodads ??= (async () => {
    const rows = new Map(terrainRows(new Uint8Array(await asset("Doodads\\Doodads.slk"))));
    try {
      for (const [id, skin] of doodadSkinRows(new Uint8Array(await asset("Doodads\\DoodadSkins.txt")))) rows.set(id, { ...rows.get(id), ...skin });
    } catch (cause) { if (!(cause instanceof AbsentAsset)) throw cause; }
    return rows;
  })();
  const special = terrainDoodadPoses(scene.terrainDoodads.placements, scene.terrain, await installedDoodads, scene.frame, scene.terrainDoodads.models);
  return [...scene.effects, ...special];
}

type Matrix = Float32Array;
const identity = (): Matrix => new Float32Array([1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1]);
function multiply(a: Matrix, b: Matrix): Matrix {
  const out = new Float32Array(16);
  for (let column = 0; column < 4; column++) for (let row = 0; row < 4; row++) {
    for (let k = 0; k < 4; k++) out[column * 4 + row] = (out[column * 4 + row] ?? 0) + (a[k * 4 + row] ?? 0) * (b[column * 4 + k] ?? 0);
  }
  return out;
}
function transform(pose: EffectPose): Matrix {
  const matrix = identity();
  matrix[12] = pose.x; matrix[13] = pose.y; matrix[14] = pose.z;
  let out = matrix;
  for (const [axis, angle] of [[2, pose.yaw], [1, pose.pitch], [0, pose.roll]] as const) {
    const rotation = identity(), c = Math.cos(angle), s = Math.sin(angle);
    const a = (axis + 1) % 3, b = (axis + 2) % 3;
    rotation[a * 4 + a] = c; rotation[b * 4 + b] = c; rotation[a * 4 + b] = s; rotation[b * 4 + a] = -s;
    out = multiply(out, rotation);
  }
  for (let axis = 0; axis < 3; axis++) for (let row = 0; row < 4; row++) out[axis * 4 + row] = (out[axis * 4 + row] ?? 0) * pose.scale * (pose.matrixScale[axis] ?? 1);
  return out;
}
const normalize = (v: readonly number[]): number[] => { const length = Math.hypot(...v); return v.map((value) => value / length); };
const cross = (a: readonly number[], b: readonly number[]): number[] => [(a[1] ?? 0) * (b[2] ?? 0) - (a[2] ?? 0) * (b[1] ?? 0), (a[2] ?? 0) * (b[0] ?? 0) - (a[0] ?? 0) * (b[2] ?? 0), (a[0] ?? 0) * (b[1] ?? 0) - (a[1] ?? 0) * (b[0] ?? 0)];
function camera(scene: RenderScene, aspect: number) {
  const field = (name: string, fallback: number) => scene.camera.fields[`CAMERA_FIELD_${name}`] ?? fallback;
  const yaw = field("ROTATION", 90) * Math.PI / 180, pitch = field("ANGLE_OF_ATTACK", 350) * Math.PI / 180;
  const distance = field("TARGET_DISTANCE", 1650);
  const target = [scene.camera.x, scene.camera.y, field("ZOFFSET", 0)];
  const forward = [Math.cos(yaw) * Math.cos(pitch), Math.sin(yaw) * Math.cos(pitch), Math.sin(pitch)];
  const eye = target.map((v, i) => v - (forward[i] ?? 0) * distance);
  const z = forward.map((v) => -v), x = normalize(cross([0, 0, 1], z)), y = cross(z, x);
  const view = identity();
  for (let axis = 0; axis < 3; axis++) {
    view[axis * 4] = x[axis] ?? 0; view[axis * 4 + 1] = y[axis] ?? 0; view[axis * 4 + 2] = z[axis] ?? 0;
    view[12] = (view[12] ?? 0) - (x[axis] ?? 0) * (eye[axis] ?? 0);
    view[13] = (view[13] ?? 0) - (y[axis] ?? 0) * (eye[axis] ?? 0);
    view[14] = (view[14] ?? 0) - (z[axis] ?? 0) * (eye[axis] ?? 0);
  }
  const tangent = Math.tan(field("FIELD_OF_VIEW", 70) * Math.PI / 360);
  const near = field("NEARZ", 10), far = field("FARZ", 10000);
  const perspective = (to: number) => {
    const out = new Float32Array(16);
    out[0] = 1 / tangent; out[5] = aspect / tangent;
    out[10] = (to + near) / (near - to); out[11] = -1; out[14] = 2 * to * near / (near - to);
    return out;
  };
  const projection = perspective(far);
  const rotation = yaw - Math.PI, elevation = -pitch;
  const halfYaw = rotation / 2, halfPitch = -elevation / 2;
  const quaternion: [number, number, number, number] = [-Math.sin(halfYaw) * Math.sin(halfPitch), Math.cos(halfYaw) * Math.sin(halfPitch), Math.sin(halfYaw) * Math.cos(halfPitch), Math.cos(halfYaw) * Math.cos(halfPitch)];

  return { view, projection, skyProjection: perspective(SKY_FAR), eye, quaternion, near, far, shadow: { eye, right: x, up: y, back: z, tangent, aspect, near, reach: Math.min(far, distance * SHADOW_REACH) } };
}
const SKY_FAR = 1_000_000;

const SHADOW_REACH = 2.5;

function sample(track: model.AnimVector | ArrayLike<number> | number | undefined, frame: number, fallback: readonly number[]): number[] {
  if (track === undefined) return [...fallback];
  if (typeof track === "number") return [track];
  if (!("Keys" in track)) return Array.from(track);
  const keys = track.Keys;
  const first = keys[0];
  if (first === undefined) return [...fallback];
  if (frame <= first.Frame) return Array.from(first.Vector);
  for (let index = 1; index < keys.length; index++) {
    const before = keys[index - 1], after = keys[index];
    if (before === undefined || after === undefined || frame >= after.Frame) continue;
    if (track.LineType === 0) return Array.from(before.Vector);
    const t = (frame - before.Frame) / (after.Frame - before.Frame);
    return Array.from(before.Vector, (value, i) => value + ((after.Vector[i] ?? value) - value) * t);
  }
  return Array.from(keys[keys.length - 1]?.Vector ?? fallback);
}
function rotate(q: readonly number[], v: readonly number[]): number[] {
  const [x = 0, y = 0, z = 0, w = 1] = normalize(q), [vx = 0, vy = 0, vz = 0] = v;
  const tx = 2 * (y * vz - z * vy), ty = 2 * (z * vx - x * vz), tz = 2 * (x * vy - y * vx);
  return [vx + w * tx + (y * tz - z * ty), vy + w * ty + (z * tx - x * tz), vz + w * tz + (x * ty - y * tx)];
}

interface WorldLight { readonly toward: readonly number[]; readonly key: readonly number[]; readonly ambient: readonly number[]; readonly linear: boolean }
let environmentLight: Promise<number[]> | undefined;

function environmentAmbient(): Promise<number[]> {
  environmentLight ??= textureAt("ReplaceableTextures\\EnvironmentMap.blp").then((texture) => {
    const context = texture.getContext("2d"); if (context === null) throw new Error("no 2D texture context");
    const { data, width, height } = context.getImageData(0, 0, texture.width, texture.height), sum = [0, 0, 0];
    const linear = (value: number) => { const c = value / 255; return c <= 0.04045 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4; };
    let weights = 0;
    for (let row = 0; row < height; row++) {
      const weight = Math.cos(((row + 0.5) / height - 0.5) * Math.PI);
      for (let column = 0; column < width; column++) for (let channel = 0; channel < 3; channel++) sum[channel]! += weight * linear(data[(row * width + column) * 4 + channel] ?? 0);
      weights += weight * width;
    }
    return sum.map((value) => value / weights);
  });
  return environmentLight;
}
const dayNightModels = new Map<string, Promise<model.Model | undefined>>();

async function dayNightLight(path: string, hours: number): Promise<WorldLight | undefined> {
  if (path === "") return undefined;
  let loading = dayNightModels.get(path);
  if (loading === undefined) {

    loading = asset(path).then((bytes) => new TextDecoder().decode(bytes.slice(0, 4)) === "MDLX" ? parseMDX(bytes) : parseMDL(new TextDecoder().decode(bytes)));
    dayNightModels.set(path, loading);
  }
  const data = await loading;
  const light = data?.Lights.find((candidate) => candidate.LightType === 1) ?? data?.Lights[0];
  if (data === undefined || light === undefined) return undefined;
  const [start = 0, end = 0] = Array.from(data.Sequences[0]?.Interval ?? [0, 0]);
  const frame = start + (end - start) * (((hours % 24) + 24) % 24) / 24;
  if ((sample(light.Visibility, frame, [1])[0] ?? 1) <= 0) return undefined;
  const colour = (track: typeof light.Color, intensity: typeof light.Intensity) => {
    const [blue = 1, green = 1, red = 1] = sample(track, frame, [1, 1, 1]), scale = sample(intensity, frame, [1])[0] ?? 1;
    return [red * scale, green * scale, blue * scale];
  };
  const toward = light.LightType === 1 ? normalize(rotate(sample(light.Rotation, frame, [0, 0, 0, 1]), [0, 0, 1])) : [0, 0, 1];
  const key = light.LightType === 2 ? [0, 0, 0] : colour(light.Color, light.Intensity);

  if ((sample(light.AmbIntensity, frame, [1])[0] ?? 1) <= 0) return { toward, key, ambient: await environmentAmbient(), linear: true };
  return { toward, key, ambient: colour(light.AmbColor, light.AmbIntensity), linear: false };
}

function modelDirection(matrix: Matrix, toward: readonly number[]): number[] {
  const m = (row: number, column: number) => matrix[column * 4 + row] ?? 0;
  const [x = 0, y = 0, z = 1] = toward;
  const a = [[m(0, 0), m(0, 1), m(0, 2)], [m(1, 0), m(1, 1), m(1, 2)], [m(2, 0), m(2, 1), m(2, 2)]] as const;
  const c = (r: number, k: number) => a[r]?.[k] ?? 0;
  const cofactor = (r: number, k: number) => c((r + 1) % 3, (k + 1) % 3) * c((r + 2) % 3, (k + 2) % 3) - c((r + 1) % 3, (k + 2) % 3) * c((r + 2) % 3, (k + 1) % 3);

  const out = [0, 1, 2].map((k) => cofactor(0, k) * x + cofactor(1, k) * y + cofactor(2, k) * z);
  return Math.hypot(...out) > 0 ? normalize(out) : [0, 0, 1];
}

function sceneFog(scene: RenderScene, view: ReturnType<typeof camera>, sky: boolean) {
  const fog = scene.environment?.fog;
  if (fog === undefined || (sky && fog.drawOverSky !== true)) return undefined;
  const height = fog.style === 3;
  const start = height ? fog.linearStart ?? fog.zStart : fog.zStart, end = height ? fog.linearEnd ?? fog.zEnd : fog.zEnd;
  const falloff = height && graphics === "definitive" && fog.heightStart !== undefined && fog.heightEnd !== undefined && !sky
    ? { bottom: fog.heightStart, top: fog.heightEnd, start: fog.zStart, end: fog.zEnd } : undefined;
  return { color: fog.color, start, end, near: view.near, far: sky ? SKY_FAR : view.far, max: fog.maxLinearDensity ?? 1, ...(falloff === undefined ? {} : { height: falloff }) };
}

const canvas = document.createElement("canvas");
const output = document.createElement("canvas");
const overlay = document.createElement("canvas");
const display = document.createElement("div");
display.style.cssText = "display:grid;max-width:100%;max-height:100%";
for (const layer of [canvas, overlay, output]) {
  layer.style.gridArea = "1 / 1";
  display.append(layer);
}
canvas.style.display = overlay.style.display = "none";
document.body.append(display);
let gl: WebGL2RenderingContext;
let sceneBuffer: SceneTarget;
let compose: ReturnType<typeof postProcessor>;
let sunMap: DepthTarget | undefined, pointMap: DepthTarget | undefined;
let graphics = "classic";
const models = new Map<string, Promise<model.Model>>();
const textures = new Map<string, Promise<HTMLCanvasElement>>();
const tinted = new Map<string, HTMLCanvasElement>();

interface ModelInstance { renderer: ModelRenderer; model: model.Model; path: string; sequences: AnimationSequence[]; sequence: number; clock: number; posed: number }
let sceneDraw = 0;
const instances = new Map<number, ModelInstance>();
const preparedModels = new Map<string, ModelInstance>();

class AbsentAsset extends Error {}
async function asset(path: string, body?: string): Promise<ArrayBuffer> {
  const response = await fetch(`/asset?path=${encodeURIComponent(path)}${body === undefined ? "" : `&body=${encodeURIComponent(body)}`}`);
  if (response.status === 410) throw new AbsentAsset(`absent in ${graphics}: ${path}`);
  if (!response.ok) throw new Error(`missing map asset: ${path}`);
  return response.arrayBuffer();
}
async function modelAt(path: string): Promise<model.Model> {
  let result = models.get(path);
  if (result === undefined) {
    result = asset(path).then((bytes) => new TextDecoder().decode(bytes.slice(0, 4)) === "MDLX" ? parseMDX(parsableModel(new Uint8Array(bytes)).bytes.slice().buffer) : parseMDL(new TextDecoder().decode(bytes)));
    models.set(path, result);
  }
  return result;
}
function tga(bytes: ArrayBuffer): ImageData {
  const data = new Uint8Array(bytes), header = new DataView(bytes), type = data[2] ?? 0;
  if (data[1] !== 0 || ![2, 3, 10, 11].includes(type)) throw new Error("texture is neither PNG/JPEG, BLP1 nor supported TGA; supply decoded PNG bytes");
  const width = header.getUint16(12, true), height = header.getUint16(14, true), stride = (data[16] ?? 0) / 8;
  if (![1, 3, 4].includes(stride)) throw new Error("unsupported TGA pixel size");
  const out = new ImageData(width, height), top = ((data[17] ?? 0) & 32) !== 0;
  let offset = 18 + (data[0] ?? 0), pixel = 0;
  while (pixel < width * height) {
    const packet = type >= 10 ? data[offset++] ?? 0 : 0, repeat = (packet & 128) !== 0, count = (packet & 127) + 1;
    for (let i = 0; i < count; i++) {
      const row = Math.floor(pixel / width), index = ((top ? row : height - 1 - row) * width + pixel % width) * 4;
      out.data[index] = data[offset + (stride === 1 ? 0 : 2)] ?? 0; out.data[index + 1] = data[offset + (stride === 1 ? 0 : 1)] ?? 0; out.data[index + 2] = data[offset] ?? 0; out.data[index + 3] = stride === 4 ? data[offset + 3] ?? 255 : 255;
      pixel++; if (!repeat || i === count - 1) offset += stride;
    }
  }
  return out;
}
function textureAt(path: string, body?: string): Promise<HTMLCanvasElement> {
  const cacheKey = `${body ?? ""}:${path}`;
  let result = textures.get(cacheKey);
  if (result === undefined) {
    result = asset(path, body).then(async (bytes) => {
      const texture = document.createElement("canvas"), context = texture.getContext("2d");
      if (context === null) throw new Error("no 2D texture context");
      const magic = new Uint8Array(bytes, 0, Math.min(4, bytes.byteLength));
      if (magic[0] === 137 || magic[0] === 255) {
        const image = await createImageBitmap(new Blob([bytes])); texture.width = image.width; texture.height = image.height; context.drawImage(image, 0, 0); image.close();
      } else {
        const decoded = magic[0] === 66 && magic[1] === 76 ? getBLPImageData(decodeBLP(bytes), 0)
          : magic[0] === 68 && magic[1] === 68 && magic[2] === 83 && magic[3] === 32 ? ddsTexture(bytes) : tga(bytes);
        texture.width = decoded.width; texture.height = decoded.height;
        context.putImageData(new ImageData(new Uint8ClampedArray(decoded.data), decoded.width, decoded.height), 0, 0);
      }
      return texture;
    }); textures.set(cacheKey, result);
  }
  return result;
}
const teams = [[255, 3, 3], [0, 66, 255], [28, 230, 185], [84, 0, 129], [255, 252, 1], [254, 138, 14], [32, 192, 0], [229, 91, 176], [149, 150, 151], [126, 191, 241], [16, 98, 70], [78, 42, 4]];

interface Sampler {
  rendererData: { frame: number; animation: number; animationInfo: { Interval: ArrayLike<number> }; globalSequencesFrames: number[]; rootNode: unknown; nodes: { matrix: Matrix }[] };
  interp: { vec3(out: Float32Array, vector: unknown): Float32Array | null; quat(out: Float32Array, vector: unknown): Float32Array | null; animVectorVal(vector: unknown, fallback: number): number };
  updateNode(node: { node: { Translation?: unknown; Rotation?: unknown; Scaling?: unknown } }): void;
}

const NO_SEQUENCE = { Interval: [0xffffffff, 0xffffffff] };
function show(sampler: Sampler, data: model.Model, sample: SequenceSample): void {
  sampler.rendererData.animation = sample.sequence;
  sampler.rendererData.animationInfo = data.Sequences[sample.sequence] ?? NO_SEQUENCE;
  sampler.rendererData.frame = sample.frame;
}
function slerp(a: Float32Array, b: Float32Array, t: number): Float32Array {
  let dot = (a[0] ?? 0) * (b[0] ?? 0) + (a[1] ?? 0) * (b[1] ?? 0) + (a[2] ?? 0) * (b[2] ?? 0) + (a[3] ?? 1) * (b[3] ?? 1), sign = 1;
  if (dot < 0) { dot = -dot; sign = -1; }
  let left = 1 - t, right = t;
  if (1 - dot > 0.000001) { const angle = Math.acos(dot), sine = Math.sin(angle); left = Math.sin((1 - t) * angle) / sine; right = Math.sin(t * angle) / sine; }
  return new Float32Array([0, 1, 2, 3].map((i) => left * (a[i] ?? 0) + right * sign * (b[i] ?? 0)));
}

function poseNodes(sampler: Sampler, data: model.Model, saved: SequenceSample | undefined, weight: number): void {
  if (saved === undefined || weight <= 0) { sampler.updateNode(sampler.rendererData.rootNode as Parameters<Sampler["updateNode"]>[0]); return; }
  const { interp } = sampler, vec3 = interp.vec3.bind(interp), quat = interp.quat.bind(interp), updateNode = sampler.updateNode.bind(sampler);
  const current = { animation: sampler.rendererData.animation, animationInfo: sampler.rendererData.animationInfo, frame: sampler.rendererData.frame };
  let node: Parameters<Sampler["updateNode"]>[0]["node"] | undefined;
  const savedValue = <T>(read: () => T): T => {
    show(sampler, data, saved);
    try { return read(); } finally { Object.assign(sampler.rendererData, current); }
  };
  interp.vec3 = (out, vector) => {
    const now = vec3(new Float32Array(3), vector);
    if (node === undefined || (vector !== node.Translation && vector !== node.Scaling)) return now === null ? null : new Float32Array(now);
    const before = savedValue(() => vec3(new Float32Array(3), vector));
    if (now === null && before === null) return null;
    const fallback = vector === node.Scaling ? 1 : 0;
    for (let i = 0; i < 3; i++) out[i] = (1 - weight) * (now?.[i] ?? fallback) + weight * (before?.[i] ?? fallback);
    return out;
  };
  interp.quat = (out, vector) => {
    const now = quat(new Float32Array(4), vector);
    if (node === undefined || vector !== node.Rotation) return now === null ? null : new Float32Array(now);
    const before = savedValue(() => quat(new Float32Array(4), vector));
    if (now === null && before === null) return null;
    const identity = new Float32Array([0, 0, 0, 1]);
    out.set(slerp(now === null ? identity : new Float32Array(now), before === null ? identity : new Float32Array(before), weight));
    return out;
  };
  sampler.updateNode = (next) => { node = next.node; updateNode(next); };
  try { updateNode(sampler.rendererData.rootNode as Parameters<Sampler["updateNode"]>[0]); }
  finally { interp.vec3 = vec3; interp.quat = quat; sampler.updateNode = updateNode; node = undefined; }
}

const spare = new Map<string, ModelInstance[]>();
const stateless = (instance: ModelInstance) => instance.model.ParticleEmitters2.length === 0 && instance.model.RibbonEmitters.length === 0;
function release(instance: ModelInstance): void {
  if (!stateless(instance)) { instance.renderer.destroy(); return; }
  instance.sequence = -2; instance.clock = 0; instance.posed = -1;
  let free = spare.get(instance.path);
  if (free === undefined) spare.set(instance.path, free = []);
  free.push(instance);
}

function releaseAbsent(effects: readonly { readonly handle: { readonly id: number } }[]): void {
  const present = new Set(effects.map((effect) => effect.handle.id));
  for (const [handle, instance] of instances) {
    if (present.has(handle) || !stateless(instance)) continue;
    instances.delete(handle); release(instance);
  }
}
async function prepareInstance(pose: EffectPose) {
  let instance = instances.get(pose.handle.id);
  if (instance === undefined || instance.path !== pose.model) {
    if (instance !== undefined) { instances.delete(pose.handle.id); release(instance); }
    instance = spare.get(pose.model)?.pop() ?? preparedModels.get(pose.model);
    if (instance === undefined) instance = await createInstance(pose.model);
    else preparedModels.delete(pose.model);
    instances.set(pose.handle.id, instance);
  }
  return instance;
}
const pixels = new Map<string, Promise<ImageData | undefined>>();

function texturePixels(path: string, body: string): Promise<ImageData | undefined> {
  const cacheKey = `${body}:${path}`;
  let result = pixels.get(cacheKey);
  if (result === undefined) {
    result = textureAt(path, body).then((bitmap) => bitmap.getContext("2d")?.getImageData(0, 0, bitmap.width, bitmap.height));
    pixels.set(cacheKey, result);
  }
  return result;
}

const loading = new Map<number, { readonly path: string; failure?: unknown }>();
function liveInstance(pose: EffectPose): ModelInstance | undefined {
  const ready = instances.get(pose.handle.id);
  if (ready !== undefined && ready.path === pose.model) return ready;
  const pending = loading.get(pose.handle.id);
  if (pending?.path === pose.model) {
    if (pending.failure !== undefined) throw pending.failure;
    return undefined;
  }
  const entry: { readonly path: string; failure?: unknown } = { path: pose.model };
  loading.set(pose.handle.id, entry);
  prepareInstance(pose).then(() => { if (loading.get(pose.handle.id) === entry) loading.delete(pose.handle.id); }, (cause: unknown) => { entry.failure = cause; });

  const taken = instances.get(pose.handle.id);
  return taken?.path === pose.model ? taken : undefined;
}
async function createInstance(path: string): Promise<ModelInstance> {
  const data = await modelAt(path);

  const images = await Promise.all(data.Textures.map((texture) => texture.Image === "" ? undefined : texturePixels(cliffTexturePath(texture.Image, cliffOverrides), path)));
  const renderer = new ModelRenderer(data); renderer.initGL(gl);
  data.Textures.forEach((texture, index) => {
    const image = images[index];
    if (image !== undefined) renderer.setTextureImageData(texture.Image, [image]);
  });
  const sequences = data.Sequences.map((sequence) => ({ name: sequence.Name, start: sequence.Interval[0] ?? 0, end: sequence.Interval[1] ?? 0, looping: !sequence.NonLooping, rarity: sequence.Rarity }));
  return { renderer, model: data, path, sequences, sequence: -2, clock: 0, posed: -1 };
}

interface DepthPass { readonly view: Matrix; readonly projection: Matrix }

interface Shadows { readonly sun?: { readonly map: WebGLTexture; readonly viewProjection: Matrix; readonly bias: number; readonly texel: number }; readonly points?: { readonly map: WebGLTexture; readonly matrices: Float32Array; readonly far: number } }
async function drawEffect(pose: EffectPose, view: ReturnType<typeof camera>, light: WorldLight | undefined, fog: ReturnType<typeof sceneFog>, points: readonly PointLight[], popcornEmitters: PopcornEmitterPose[], shadows: Shadows = {}, depthPass?: DepthPass) {
  const instance = await prepareInstance(pose);
  const { renderer, model: data } = instance;
  renderer.setInstanceAlpha(pose.alpha / 255);
  renderer.setInstanceColor(new Float32Array(pose.color.map((value) => value / 255)));
  renderer.setCamera(new Float32Array(view.eye), view.quaternion);
  const sampler = renderer as unknown as Sampler;

  if (instance.posed !== sceneDraw) {
    instance.posed = sceneDraw;
    const kind = pose.unit === true ? "unit" : "effect";
    const sample = animationSample(instance.sequences, { animation: pose.animation, subAnimations: pose.subAnimations, elapsed: pose.animationElapsed }, kind);
    const elapsed = pose.animationElapsed * 1000;
    if (instance.sequence !== sample.sequence || elapsed < instance.clock) {
      if (sample.sequence >= 0) renderer.setSequence(sample.sequence);
      instance.sequence = sample.sequence; instance.clock = 0;
    }
    if (sample.sequence >= 0 && (data.ParticleEmitters2.length > 0 || data.RibbonEmitters.length > 0)) {
      instance.clock = advanceEmitters(renderer as unknown as EmitterRenderer, data.Sequences, instance.sequences, { animation: pose.animation, subAnimations: pose.subAnimations, elapsed: pose.animationElapsed }, kind, instance.clock, elapsed);
    }
    show(sampler, data, sample);
    data.GlobalSequences.forEach((length, index) => { sampler.rendererData.globalSequencesFrames[index] = globalSequenceFrame(pose.animationClock, length); });
    const blend = pose.animationBlend, weight = blendWeight(pose);
    const saved = blend === undefined ? undefined : animationSample(instance.sequences, blend.from, kind);
    renderer.update(0);
    if (saved !== undefined && weight > 0) poseNodes(sampler, data, saved, weight);
  }
  renderer.setTeamColor(new Float32Array((teams[pose.teamColor] ?? [160, 160, 160]).map((v) => v / 255)));
  renderer.setLightPosition([1000, -1000, 3000]); renderer.setLightColor([1, 1, 1]);
  const placed = transform(pose);
  if (depthPass !== undefined) {
    renderer.setWispEnvironment(undefined);
    renderer.render(multiply(depthPass.view, placed), depthPass.projection, {});
    return;
  }
  for (const emitter of data.ParticleEmitterPopcorns ?? []) {
    if (sampler.interp.animVectorVal(emitter.Visibility, 1) <= 0 || sampler.interp.animVectorVal(emitter.Alpha, 1) <= 0) continue;
    const node = sampler.rendererData.nodes[emitter.ObjectId];
    if (node === undefined) throw new Error(`missing node for Popcorn emitter "${emitter.Name}"`);
    const world = multiply(placed, node.matrix), pivot = emitter.PivotPoint ?? data.PivotPoints[emitter.ObjectId];
    const position = [0, 1, 2].map((row) => (world[12 + row] ?? 0) + [0, 1, 2].reduce((sum, axis) => sum + (world[axis * 4 + row] ?? 0) * (pivot?.[axis] ?? 0), 0)) as [number, number, number];
    const scale = [0, 1, 2].map((axis) => Math.hypot(world[axis * 4] ?? 0, world[axis * 4 + 1] ?? 0, world[axis * 4 + 2] ?? 0)) as [number, number, number];
    popcornEmitters.push({ model: pose.model, handle: pose.handle.id, emitter: emitter.Name, effect: emitter.Path ?? "", position, scale });
  }
  const sun = shadows.sun, pointShadow = shadows.points;
  renderer.setWispEnvironment({
    ...(light === undefined ? {} : { light: { direction: modelDirection(placed, light.toward), key: light.key, ambient: light.ambient, linear: light.linear, overbright: graphics === "definitive" } }), ...(fog === undefined ? {} : { fog: fog.height === undefined ? fog : { ...fog, height: { ...fog.height, model: placed } } }),
    ...(points.length === 0 ? {} : { points: { model: placed, normal: normalMatrix(placed), lights: nearest(points, placed) } }),
    ...(sun === undefined ? {} : { shadow: { map: sun.map, matrix: multiply(sun.viewProjection, placed), bias: sun.bias, texel: sun.texel } }),
    ...(pointShadow === undefined ? {} : { pointShadow: { map: pointShadow.map, matrices: pointShadow.matrices, near: POINT_NEAR_PLANE, far: pointShadow.far, texel: 1 / POINT_FACE } }),
  });

  bindScene();
  renderer.render(multiply(view.view, placed), view.projection, {});
}

interface PointLight { readonly position: readonly number[]; readonly color: readonly number[]; readonly start: number; readonly end: number; readonly casts: boolean; shadowSlot?: number }
const MAX_POINT_LIGHTS = 8;
const lightModels = new Map<string, Promise<model.Model | undefined>>();

async function pointLights(poses: readonly EffectPose[]): Promise<PointLight[]> {
  const lights: PointLight[] = [];
  for (const pose of poses) {
    let loading = lightModels.get(pose.model);
    if (loading === undefined) lightModels.set(pose.model, loading = asset(pose.model).then((bytes) => {
      if (new TextDecoder().decode(bytes.slice(0, 4)) !== "MDLX") return parseMDL(new TextDecoder().decode(bytes));

      const kept = parsableModel(new Uint8Array(bytes), true);
      return kept.lights > 0 ? parseMDX(kept.bytes.slice().buffer) : undefined;
    }));
    const data = await loading;
    if (data === undefined || data.Lights.length === 0) continue;
    const instance = instances.get(pose.handle.id);
    const kind = pose.unit === true ? "unit" : "effect";
    const { frame } = animationSample(instance?.sequences ?? [], { animation: pose.animation, subAnimations: pose.subAnimations, elapsed: pose.animationElapsed }, kind);
    const placed = transform(pose), scale = Math.cbrt(Math.abs(determinant(placed)));
    for (const light of data.Lights) {
      if (light.LightType !== 0 || (sample(light.Visibility, frame, [1])[0] ?? 1) <= 0) continue;
      const [blue = 1, green = 1, red = 1] = sample(light.Color, frame, [1, 1, 1]), intensity = sample(light.Intensity, frame, [1])[0] ?? 1;
      if (intensity <= 0) continue;
      const pivot = Array.from(data.PivotPoints[light.ObjectId] ?? [0, 0, 0]);
      const position = [0, 1, 2].map((row) => (placed[row] ?? 0) * (pivot[0] ?? 0) + (placed[4 + row] ?? 0) * (pivot[1] ?? 0) + (placed[8 + row] ?? 0) * (pivot[2] ?? 0) + (placed[12 + row] ?? 0));
      lights.push({ position, color: [red * intensity, green * intensity, blue * intensity], start: (sample(light.AttenuationStart, frame, [0])[0] ?? 0) * scale, end: (sample(light.AttenuationEnd, frame, [0])[0] ?? 0) * scale, casts: ((light as { ShadowCasting?: number }).ShadowCasting ?? 0) !== 0 });
    }
  }
  return lights;
}
function determinant(m: Matrix): number {
  const a = (row: number, column: number) => m[column * 4 + row] ?? 0;
  return a(0, 0) * (a(1, 1) * a(2, 2) - a(1, 2) * a(2, 1)) - a(0, 1) * (a(1, 0) * a(2, 2) - a(1, 2) * a(2, 0)) + a(0, 2) * (a(1, 0) * a(2, 1) - a(1, 1) * a(2, 0));
}

function normalMatrix(m: Matrix): Float32Array {
  const a = (row: number, column: number) => m[column * 4 + row] ?? 0;
  const det = determinant(m) || 1, out = new Float32Array(9);
  for (let row = 0; row < 3; row++) for (let column = 0; column < 3; column++) {
    const r1 = (row + 1) % 3, r2 = (row + 2) % 3, c1 = (column + 1) % 3, c2 = (column + 2) % 3;

    out[column * 3 + row] = (a(r1, c1) * a(r2, c2) - a(r1, c2) * a(r2, c1)) / det;
  }
  return out;
}

function nearest(points: readonly PointLight[], placed: Matrix): PointLight[] {
  const origin = [placed[12] ?? 0, placed[13] ?? 0, placed[14] ?? 0];
  const gap = (light: PointLight) => Math.hypot(...light.position.map((value, i) => value - (origin[i] ?? 0))) - light.end;
  return [...points].sort((a, b) => gap(a) - gap(b)).slice(0, MAX_POINT_LIGHTS);
}
const skies = new Map<string, Promise<ModelInstance>>();

async function drawSky(scene: RenderScene, view: ReturnType<typeof camera>) {
  const environment = scene.environment;
  if (environment === undefined || environment.sky === "" || !environment.skyVisible) return;
  let loading = skies.get(environment.sky);
  if (loading === undefined) skies.set(environment.sky, loading = createInstance(environment.sky));
  const { renderer, model: data } = await loading;
  const placed = identity();
  placed[12] = view.eye[0] ?? 0; placed[13] = view.eye[1] ?? 0; placed[14] = view.eye[2] ?? 0;
  renderer.setCamera(new Float32Array(view.eye), view.quaternion);
  if (data.Sequences.length > 0) { renderer.setSequence(0); show(renderer as unknown as Sampler, data, { sequence: 0, frame: data.Sequences[0]?.Interval[0] ?? 0 }); }
  renderer.update(0);
  const fog = sceneFog(scene, view, true);
  renderer.setWispEnvironment(fog === undefined ? undefined : { fog });
  bindScene();
  renderer.render(multiply(view.view, placed), view.skyProjection, {});

  gl.depthMask(true); gl.clear(gl.DEPTH_BUFFER_BIT);
}
type FilterPose = NonNullable<RenderScene["filter"]>;
let filterQuad: { program: WebGLProgram; vao: WebGLVertexArrayObject; color: WebGLUniformLocation | null; uv: WebGLUniformLocation | null; textured: WebGLUniformLocation | null } | undefined;
const filterTextures = new Map<string, Promise<WebGLTexture>>();
function filterProgram() {
  if (filterQuad !== undefined) return filterQuad;
  const shader = (type: number, source: string) => {
    const made = gl.createShader(type); if (made === null) throw new Error("no filter shader");
    gl.shaderSource(made, source); gl.compileShader(made);
    if (!gl.getShaderParameter(made, gl.COMPILE_STATUS)) throw new Error(`filter shader: ${gl.getShaderInfoLog(made)}`);
    return made;
  };
  const program = gl.createProgram(), vao = gl.createVertexArray(), buffer = gl.createBuffer();
  gl.attachShader(program, shader(gl.VERTEX_SHADER, `#version 300 es
in vec2 position; uniform vec4 uvRect; out vec2 uv;
void main() { uv = mix(uvRect.xy, uvRect.zw, vec2(position.x * 0.5 + 0.5, 0.5 - position.y * 0.5)); gl_Position = vec4(position, 0.0, 1.0); }`));
  gl.attachShader(program, shader(gl.FRAGMENT_SHADER, `#version 300 es
precision mediump float; in vec2 uv; uniform sampler2D map; uniform vec4 color; uniform bool textured; out vec4 fragment;
void main() { fragment = (textured ? texture(map, uv) : vec4(1.0)) * color; }`));
  gl.bindAttribLocation(program, 0, "position"); gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) throw new Error(`filter program: ${gl.getProgramInfoLog(program)}`);
  gl.bindVertexArray(vao); gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0); gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  gl.bindVertexArray(null);
  filterQuad = { program, vao, color: gl.getUniformLocation(program, "color"), uv: gl.getUniformLocation(program, "uvRect"), textured: gl.getUniformLocation(program, "textured") };
  return filterQuad;
}
function filterTexture(path: string, wrap: boolean): Promise<WebGLTexture> {
  const key = `${path}:${wrap}`;
  let result = filterTextures.get(key);
  if (result === undefined) {
    result = textureAt(path).then((image) => {
      const texture = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, texture);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, image);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      for (const axis of [gl.TEXTURE_WRAP_S, gl.TEXTURE_WRAP_T]) gl.texParameteri(gl.TEXTURE_2D, axis, wrap ? gl.REPEAT : gl.CLAMP_TO_EDGE);
      return texture;
    });
    filterTextures.set(key, result = tracked(result));
  }
  return result;
}

async function drawFilter(filter: FilterPose, live: boolean): Promise<void> {
  const quad = filterProgram();
  const load = filter.texture === "" ? undefined : filterTexture(filter.texture, /WRAP/.test(String(filter.texMapFlags)));

  const texture = load === undefined ? undefined : live ? loaded(load) : await load;
  if (load !== undefined && texture === undefined) return;
  gl.disable(gl.DEPTH_TEST); gl.depthMask(false); gl.disable(gl.CULL_FACE);
  gl.useProgram(quad.program); gl.bindVertexArray(quad.vao);
  gl.uniform4f(quad.color, ...filter.color.map((value) => Math.max(0, Math.min(255, value)) / 255) as [number, number, number, number]);
  gl.uniform4f(quad.uv, ...filter.uv);
  gl.uniform1i(quad.textured, texture === undefined ? 0 : 1);
  gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, texture ?? null);
  gl.enable(gl.BLEND); gl.blendEquation(gl.FUNC_ADD);
  switch (filter.blendMode) {
    case "BLEND_MODE_BLEND": case "BLEND_MODE_KEYALPHA": gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); break;
    case "BLEND_MODE_ADDITIVE": gl.blendFunc(gl.SRC_ALPHA, gl.ONE); break;
    case "BLEND_MODE_MODULATE": gl.blendFunc(gl.DST_COLOR, gl.ZERO); break;

    case "BLEND_MODE_MODULATE_2X": gl.blendFunc(gl.DST_COLOR, gl.SRC_COLOR); break;
    default: gl.disable(gl.BLEND);
  }
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
  gl.bindVertexArray(null); gl.disable(gl.BLEND); gl.enable(gl.DEPTH_TEST); gl.depthMask(true);
}
const fonts = new Map<string, Promise<string>>();

function fontFamily(file: string): Promise<string> {
  if (!/\.(ttf|otf)$/i.test(file)) return Promise.resolve("sans-serif");
  let family = fonts.get(file);
  if (family === undefined) {
    const name = `wisp-font-${fonts.size}`;
    family = tracked(asset(file).then(async (bytes) => { const face = new FontFace(name, bytes); await face.load(); document.fonts.add(face); return `"${name}", sans-serif`; }).catch(() => "sans-serif"));
    fonts.set(file, family);
  }
  return family;
}

function drawText(context: CanvasRenderingContext2D, raw: string, family: string, size: number, color: string, outline: boolean, x: number, horizontal: "left" | "center" | "right", y: number, vertical: "top" | "middle" | "bottom") {
  const lines = raw.replace(/\|c[0-9a-f]{8}|\|r/gi, "").replaceAll("|n", "\n").split("\n"), leading = size * 1.2;
  const top = vertical === "top" ? y : vertical === "middle" ? y - lines.length * leading / 2 : y - lines.length * leading;
  context.font = `${size}px ${family}`; context.textAlign = horizontal; context.textBaseline = "top";

  const coded = /\|c([0-9a-f]{2})([0-9a-f]{6})/i.exec(raw);
  context.lineWidth = Math.max(1, size / 12); context.strokeStyle = "rgba(0,0,0,0.9)"; context.lineJoin = "round";
  context.fillStyle = coded === null ? color : `#${coded[2]}${coded[1]}`;
  lines.forEach((line, index) => {
    if (outline) context.strokeText(line, x, top + index * leading);
    context.fillText(line, x, top + index * leading);
  });
  context.textAlign = "left";
}
function cssColor(color: number, alpha = 255): string { return `rgba(${(color >>> 16) & 255},${(color >>> 8) & 255},${color & 255},${((color >>> 24) / 255) * alpha / 255})`; }
const settled = new WeakMap<Promise<unknown>, { value?: unknown; failure?: unknown }>();

function tracked<T>(load: Promise<T>): Promise<T> {
  if (settled.has(load)) return load;
  const entry: { value?: unknown; failure?: unknown } = {};
  settled.set(load, entry);
  load.then((value) => { entry.value = value; }, (cause: unknown) => { entry.failure = cause ?? new Error("load failed"); });
  return load;
}

function loaded<T>(load: Promise<T>): T | undefined {
  const state = settled.get(tracked(load));
  if (state?.failure !== undefined) throw state.failure;
  return state?.value as T | undefined;
}
const uiLoads = new Map<string, Promise<HTMLCanvasElement>>();
function uiTextureLoad(path: string, color: number): Promise<HTMLCanvasElement> {
  const key = `${path}:${color}`;
  let load = uiLoads.get(key);
  if (load === undefined) uiLoads.set(key, load = tracked(uiTexture(path, color)));
  return load;
}
async function uiTexture(path: string, color: number): Promise<HTMLCanvasElement> {
  const original = await textureAt(path);
  if ((color & 0xffffff) === 0xffffff) return original;
  const key = `${path}:${color}`;
  let result = tinted.get(key);
  if (result === undefined) {
    result = document.createElement("canvas"); result.width = original.width; result.height = original.height;
    const context = result.getContext("2d"); if (context === null) throw new Error("no tint canvas");
    context.drawImage(original, 0, 0); context.globalCompositeOperation = "multiply"; context.fillStyle = cssColor(color | 0xff000000); context.fillRect(0, 0, result.width, result.height);
    context.globalCompositeOperation = "destination-in"; context.drawImage(original, 0, 0); tinted.set(key, result);
  }
  return result;
}

const POINT_NEAR_PLANE = 5;

function bindScene(): void { gl.bindFramebuffer(gl.FRAMEBUFFER, sceneBuffer.framebuffer); gl.viewport(0, 0, canvas.width, canvas.height); }

interface DepthView extends DepthPass { readonly viewport: readonly [number, number, number, number]; readonly near?: { readonly position: readonly number[]; readonly reach: number } }

async function depthPass(target: DepthTarget, poses: readonly EffectPose[], view: ReturnType<typeof camera>, views: readonly DepthView[]): Promise<void> {
  gl.bindFramebuffer(gl.FRAMEBUFFER, target.framebuffer); gl.viewport(0, 0, target.width, target.height);
  gl.depthMask(true); gl.clear(gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST);
  for (const unit of [7, 8]) { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, null); }
  gl.activeTexture(gl.TEXTURE0);
  for (const depth of views) for (const pose of poses) {

    if (depth.near !== undefined && Math.hypot(pose.x - (depth.near.position[0] ?? 0), pose.y - (depth.near.position[1] ?? 0), pose.z - (depth.near.position[2] ?? 0)) > depth.near.reach + 1500) continue;
    gl.bindFramebuffer(gl.FRAMEBUFFER, target.framebuffer); gl.viewport(...depth.viewport);
    try { await drawEffect(pose, view, undefined, undefined, [], [], {}, depth); } catch {                              }
  }
}

function shadowCasters(points: readonly PointLight[], minimum: number, focus: readonly number[]): PointLight[] {
  const gap = (light: PointLight) => Math.hypot(...light.position.map((value, i) => value - (focus[i] ?? 0)));
  const byGap = [...points].sort((a, b) => gap(a) - gap(b));
  const flagged = byGap.filter((light) => light.casts), others = byGap.filter((light) => !light.casts);
  return [...flagged, ...others.slice(0, Math.max(0, minimum - flagged.length))].slice(0, 2);
}
let postConfig: Promise<PostSettings> | undefined;

function postProcessing(): Promise<PostSettings> {
  const text = (path: string) => asset(path).then((bytes) => new TextDecoder().decode(bytes), () => "");
  postConfig ??= Promise.all([text("PostProcessingConfig.txt"), text("war3mapPostProcessing.txt")]).then(([stock, map]) => postSettings(parsePostProcessing(stock, map)));
  return postConfig;
}

declare global {
  interface Window {
    prepareRenderer: (width: number, height: number, graphics?: string) => string;
    prepareScene: (scene: RenderScene, models?: readonly string[], progress?: (completed: number, total: number) => void) => Promise<{ models: number; instances: number; textures: number }>;
    renderScene: (scene: RenderScene, options?: { capture?: boolean }) => Promise<RenderedFrame>;
  }
}
window.prepareRenderer = (width, height, mode = "classic") => {
  graphics = mode;
  canvas.width = output.width = overlay.width = width; canvas.height = output.height = overlay.height = height;

  const context = canvas.getContext("webgl2", { antialias: false, alpha: false });
  if (context === null) throw new Error("Chrome could not create a WebGL2 context");
  gl = context;
  gl.depthFunc(gl.LEQUAL);
  sceneBuffer = sceneTarget(gl, width, height);
  compose = postProcessor(gl, sceneBuffer);
  const debug = gl.getExtension("WEBGL_debug_renderer_info");
  return debug === null ? String(gl.getParameter(gl.RENDERER)) : String(gl.getParameter(debug.UNMASKED_RENDERER_WEBGL));
};
window.prepareScene = async (scene, extraModels = [], progress) => {
  await bindCliffTextures(scene);
  const view = camera(scene, canvas.width / canvas.height);
  const poses = drawnPoses(await scenePoses(scene), view.eye, view.far, scene.world);
  const frames = scene.ui.filter(frame => frame.visible && frame.alpha > 0 && frame.texture !== "");
  const total = poses.length + extraModels.length + frames.length;
  let completed = 0;
  const advanced = () => progress?.(++completed, total);
  for (const pose of poses) { await prepareInstance(pose); advanced(); }
  for (const path of extraModels) { preparedModels.set(path, await createInstance(path)); advanced(); }
  for (const frame of frames) { await uiTextureLoad(frame.texture, frame.color); advanced(); }
  for (const file of new Set(scene.ui.filter((frame) => frame.visible && frame.text !== "").map((frame) => frame.font.file))) await fontFamily(file);
  return { models: models.size, instances: instances.size + preparedModels.size, textures: textures.size };
};
window.renderScene = async (scene, options) => {
  bindScene(); gl.depthMask(true); gl.clearColor(0.04, 0.06, 0.09, 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT); gl.enable(gl.DEPTH_TEST);
  const view = camera(scene, canvas.width / canvas.height);
  const visible: EffectPose[] = [], notDrawn: string[] = [], absent = new Set<string>(), popcornEmitters: PopcornEmitterPose[] = [];
  let poses: readonly EffectPose[] = scene.effects;
  try { await bindCliffTextures(scene); poses = await scenePoses(scene); } catch (cause) { notDrawn.push(`terrain doodads: ${String(cause)}`); }
  releaseAbsent(poses);
  sceneDraw++;
  for (const pose of drawnPoses(poses, view.eye, view.far, scene.world)) {

    try {
      if (options?.capture !== false) await prepareInstance(pose);
      else if (liveInstance(pose) === undefined) continue;
      visible.push(pose);
    } catch (cause) {
      if (cause instanceof AbsentAsset) absent.add(pose.model); else notDrawn.push(`${pose.model}: ${String(cause)}`);
    }
  }
  await drawSky(scene, view);
  if (scene.environment.terrainVisible && scene.terrain !== undefined) {
    try { bindScene(); await drawTerrain(gl, scene.terrain, view.view, view.projection, textureAt, asset); }
    catch (cause) { notDrawn.push(`terrain: ${String(cause)}`); }
  }
  const light = scene.environment === undefined ? undefined : await dayNightLight(scene.environment.dayNight.unit, scene.environment.timeOfDay);
  const fog = sceneFog(scene, view, false);

  const points = graphics === "classic" ? [] : await pointLights(visible);
  const ordered = orderDrawnModels(visible, (pose) => instances.get(pose.handle.id)?.model.Materials ?? []);
  const shadows: { sun?: NonNullable<Shadows["sun"]>; points?: NonNullable<Shadows["points"]> } = {};

  if (light !== undefined && light.key.some((value) => value > 0)) {
    const sun = sunView(view.shadow, light.toward);
    sunMap ??= depthTarget(gl, SUN_MAP, SUN_MAP);
    await depthPass(sunMap, ordered, view, [{ view: sun.view, projection: sun.projection, viewport: [0, 0, SUN_MAP, SUN_MAP] }]);
    shadows.sun = { map: sunMap.texture, viewProjection: sun.viewProjection, bias: sun.bias, texel: sun.texel };
  }

  const casters = shadowCasters(points, scene.environment?.shadowCastingPointLights ?? 0, [scene.camera.x, scene.camera.y, view.shadow.eye[2] ?? 0]);
  if (casters.length > 0) {
    const far = Math.max(...casters.map((light) => light.end)), faces = pointFaces(far), passes: DepthView[] = [];
    pointMap ??= depthTarget(gl, 3 * POINT_FACE, 4 * POINT_FACE);
    casters.forEach((light, slot) => {
      light.shadowSlot = slot;
      const toLight = identity(); toLight[12] = -(light.position[0] ?? 0); toLight[13] = -(light.position[1] ?? 0); toLight[14] = -(light.position[2] ?? 0);
      faces.forEach((face, index) => passes.push({ view: multiply(face.view, toLight), projection: face.projection, viewport: [(index % 3) * POINT_FACE, (Math.floor(index / 3) + 2 * slot) * POINT_FACE, POINT_FACE, POINT_FACE], near: { position: light.position, reach: light.end } }));
    });
    await depthPass(pointMap, ordered, view, passes);
    const matrices = new Float32Array(16 * 6);
    faces.forEach((face, index) => matrices.set(face.viewProjection, index * 16));
    shadows.points = { map: pointMap.texture, matrices, far };
  }
  for (const pose of ordered) {
    try { await drawEffect(pose, view, light, fog, points, popcornEmitters, shadows); } catch (cause) { notDrawn.push(`${pose.model}: ${String(cause)}`); }
  }
  for (const light of points) delete light.shadowSlot;

  let water = false;
  if (scene.environment.terrainVisible && scene.terrain !== undefined) {
    try { bindScene(); water = await drawWater(gl, scene.terrain, scene.frame, view.view, view.projection, fog, textureAt, asset); }
    catch (cause) { notDrawn.push(`water: ${String(cause)}`); }
  }
  for (const emitter of popcornEmitters) notDrawn.push(`${emitter.model}: undrawn Popcorn emitter "${emitter.emitter}" (${emitter.effect || "no effect path"})`);
  resolve(gl, sceneBuffer);
  const post = graphics === "definitive" ? await postProcessing() : {};
  const projection = view.projection;
  compose(post, invert(projection), [(projection[0] ?? 1) * canvas.width / 2, (projection[5] ?? 1) * canvas.height / 2]);
  gl.viewport(0, 0, canvas.width, canvas.height);
  if (scene.filter !== undefined) await drawFilter(scene.filter, options?.capture === false);
  const live = options?.capture === false;
  const shown = live ? "block" : "none";
  if (canvas.style.display !== shown) { canvas.style.display = overlay.style.display = shown; output.style.display = live ? "none" : "block"; }
  const context = (live ? overlay : output).getContext("2d"); if (context === null) throw new Error("no output canvas");
  if (live) context.clearRect(0, 0, overlay.width, overlay.height);
  else context.drawImage(canvas, 0, 0);
  const clip = multiply(view.projection, view.view);
  const onScreen = (x: number, y: number, z: number): [number, number] | undefined => {
    const at = [0, 1, 3].map((row) => (clip[row] ?? 0) * x + (clip[4 + row] ?? 0) * y + (clip[8 + row] ?? 0) * z + (clip[12 + row] ?? 0));
    const w = at[2] ?? 0;
    return w <= 0 ? undefined : [((at[0] ?? 0) / w + 1) / 2 * output.width, (1 - (at[1] ?? 0) / w) / 2 * output.height];
  };
  for (const bolt of scene.lightnings ?? []) {
    const from = onScreen(...bolt.from), to = onScreen(...bolt.to);
    if (from === undefined || to === undefined || bolt.color[3] <= 0) continue;
    const [red, green, blue, alpha] = bolt.color.map((channel) => Math.max(0, Math.min(1, channel)));
    context.strokeStyle = `rgba(${Math.round((red ?? 1) * 255)},${Math.round((green ?? 1) * 255)},${Math.round((blue ?? 1) * 255)},${alpha})`;
    context.lineWidth = 3;
    context.beginPath(); context.moveTo(...from); context.lineTo(...to); context.stroke();
  }
  for (const tag of scene.textTags ?? []) {
    const at = [0, 1, 2, 3].map((row) => (clip[row] ?? 0) * tag.x + (clip[4 + row] ?? 0) * tag.y + (clip[8 + row] ?? 0) * tag.z + (clip[12 + row] ?? 0));
    const w = at[3] ?? 0;
    if (w <= 0 || tag.color[3] <= 0) continue;
    const [red, green, blue, alpha] = tag.color;
    drawText(context, tag.text, "sans-serif", tag.height * output.height / 0.6, `rgba(${red},${green},${blue},${alpha / 255})`, true,
      ((at[0] ?? 0) / w + 1) / 2 * output.width, "left", (1 - (at[1] ?? 0) / w) / 2 * output.height, "bottom");
  }
  const scaleX = output.height / 0.6, scaleY = output.height / 0.6;
  for (const frame of [...scene.ui].sort((a, b) => a.level - b.level)) {
    if (!frame.visible || frame.alpha <= 0 || frame.rectangle === undefined) continue;
    const [left, top, right, bottom] = frame.rectangle, x = output.width / 2 + (left - 0.4) * scaleX, y = (0.6 - top) * scaleY, width = (right - left) * scaleX, height = (top - bottom) * scaleY;
    context.globalAlpha = frame.alpha / 255;
    if (frame.texture !== "" && width > 0 && height > 0) {

      const image = live ? loaded(uiTextureLoad(frame.texture, frame.color)) : await uiTextureLoad(frame.texture, frame.color);
      context.globalAlpha *= (frame.color >>> 24) / 255; if (image !== undefined) context.drawImage(image, x, y, width, height); context.globalAlpha = frame.alpha / 255;
    }
    if (frame.text !== "") {

      const size = (frame.font.height > 0 ? frame.font.height * scaleY : Math.max(10, Math.min(22, height || 15))) * frame.scale;
      const alignment = frame.alignment ?? { vertical: "top", horizontal: "left" };
      drawText(context, frame.text, live ? loaded(fontFamily(frame.font.file)) ?? "sans-serif" : await fontFamily(frame.font.file), size, cssColor(frame.textColor), (frame.font.flags & 1) !== 0,
        alignment.horizontal === "left" ? x : alignment.horizontal === "center" ? x + width / 2 : x + width, alignment.horizontal,
        alignment.vertical === "top" ? y : alignment.vertical === "middle" ? y + height / 2 : y + height, alignment.vertical);
    }
  }
  context.globalAlpha = 1;
  return { png: options?.capture === false ? "" : output.toDataURL("image/png"), models: visible.length, textures: textures.size, notDrawn: [...new Set(notDrawn)], pointLights: points.length, absent: [...absent].sort(), popcornEmitters, shadows: { sun: shadows.sun !== undefined, pointCasters: casters.length }, post: { ambientOcclusion: post.occlusion !== undefined, bloom: post.bloom !== undefined }, water, heightFog: fog?.height !== undefined };
};
