local ____lualib = require("lualib_bundle")
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
local ____gameFiles = require("src.runtime.gameFiles")
local modelFailureFile = ____gameFiles.modelFailureFile
local modelFailureRequestFile = ____gameFiles.modelFailureRequestFile
local modelFailureTokenFile = ____gameFiles.modelFailureTokenFile
local ____fileio = require("src.platform.fileio")
local readChunk = ____fileio.readChunk
local writeLine = ____fileio.writeLine
local function state()
    local globals = _G
    return globals[runtimeConfiguration().globalPrefix .. "ModelFailures"]
end
--- Requests a new local report stream before any map models are created.
function ____exports.startModelFailures()
    local config = runtimeConfiguration()
    local globals = _G
    local slot = GetPlayerId(GetLocalPlayer())
    local ordinal = 1
    while readChunk(modelFailureTokenFile(slot, ordinal, config.filePrefix)) ~= nil do
        ordinal = ordinal + 1
    end
    local token = (tostring(slot) .. "-") .. tostring(ordinal)
    globals[config.globalPrefix .. "ModelFailures"] = {token = token, next = 1, ticks = 0, paths = {}}
    writeLine(
        modelFailureRequestFile(slot, config.filePrefix),
        token
    )
end
--- Local file results only change existing visual handles, never synchronized state.
function ____exports.pollModelFailures()
    local failures = state()
    if failures == nil then
        return
    end
    failures.ticks = failures.ticks + 1
    if failures.ticks < 32 then
        return
    end
    failures.ticks = 0
    local path = readChunk(modelFailureFile(
        failures.token,
        failures.next,
        runtimeConfiguration().filePrefix
    ))
    while path ~= nil do
        failures.paths[string.lower(table.concat(
            __TS__StringSplit(path, "\\"),
            "/"
        ))] = true
        failures.next = failures.next + 1
        path = readChunk(modelFailureFile(
            failures.token,
            failures.next,
            runtimeConfiguration().filePrefix
        ))
    end
end
function ____exports.modelFailed(path)
    local ____opt_0 = state()
    return (____opt_0 and ____opt_0.paths[string.lower(table.concat(
        __TS__StringSplit(path, "\\"),
        "/"
    ))]) == true
end
return ____exports
