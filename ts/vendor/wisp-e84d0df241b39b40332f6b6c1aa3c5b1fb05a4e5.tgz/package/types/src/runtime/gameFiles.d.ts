/** @noSelfInFile */
/** FileIO stores one chunk per tooltip level of its ability. */
export declare const CHUNKS_PER_FILE = 64;
/**
 * Bundle bytes per payload file. The file is raw Lua that stores them in one
 * tooltip; a 200,000-character tooltip read back intact in the game.
 */
export declare const PAYLOAD_FILE_BYTES = 200000;
/** The FileIO ability ('$wsl') whose tooltips carry text from host files. */
export declare const FILE_IO_ABILITY = 611808108;
/** Player slots that write their own copy of a per-slot file. */
export declare const FILE_SLOTS = 4;
export declare const hotFolder: (prefix?: string) => string;
/** The host's marker: it exists only in a folder a host created, and its content never changes. */
export declare const hostFile: (prefix?: string) => string;
export declare const manifestFile: (version: number, prefix?: string) => string;
/** Names a checksum in file names and as a Lua chunk name, which error positions carry. */
export declare const payloadKey: (payloadChecksum: string) => string;
/** A file of a version's full payload, named by the version's module state (wisp:src/runtime/modules.ts). */
export declare const payloadFile: (state: string, index: number, prefix?: string) => string;
/** A file of a version's delta: the modules its state has and `base` lacks. */
export declare const deltaFile: (state: string, base: string, index: number, prefix?: string) => string;
export declare const ackFile: (slot: number, prefix?: string) => string;
export declare const errorFile: (slot: number, prefix?: string) => string;
export declare const modelFailureRequestFile: (slot: number, prefix?: string) => string;
export declare const modelFailureTokenFile: (slot: number, ordinal: number, prefix?: string) => string;
export declare const modelFailureFile: (token: string, ordinal: number, prefix?: string) => string;
/** The manifest's base when a version offers no delta. */
export declare const NO_BASE = "-";
export interface Manifest {
    version: number;
    /** The checksum of the version's module index, which names its state. */
    state: string;
    /** Files of the full payload. */
    files: number;
    /** The state the delta applies to, or NO_BASE. */
    base: string;
    /** Files of the delta; 0 without one. */
    changes: number;
}
/** One line, which is also the start of every client's synchronized answer. */
export declare const formatManifest: ({ version, state, files, base, changes }: Manifest) => string;
export declare function parseManifest(text: string): Manifest | undefined;
/** The acknowledgement: the version every client installed, at the reloader's game time in seconds. */
export declare const acknowledgementLine: (version: number, elapsed: number) => string;
/** An error report's first line; the message and each stack line follow, one line each. */
export declare const errorHeading: (count: number, handler: string) => string;
