local ____lualib = require("lualib_bundle")
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__NumberToFixed = ____lualib.__TS__NumberToFixed
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__Number = ____lualib.__TS__Number
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Class = ____lualib.__TS__Class
local Set = ____lualib.Set
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__Spread = ____lualib.__TS__Spread
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local ____exports = {}
local isDigits, mixText, mixName, mixValue, isHandle, mix, nameHashes, INT32_LIMIT
local ____gameFiles = require("src.runtime.gameFiles")
local errorFile = ____gameFiles.errorFile
local FILE_IO_ABILITY = ____gameFiles.FILE_IO_ABILITY
local ____frames = require("src.headless.frames")
local FRAME_POINTS = ____frames.FRAME_POINTS
local Frames = ____frames.Frames
function isDigits(text)
    local start = __TS__StringStartsWith(text, "-") and 1 or 0
    if #text <= start then
        return false
    end
    do
        local index = start
        while index < #text do
            local code = __TS__StringCharCodeAt(text, index)
            if code < 48 or code > 57 then
                return false
            end
            index = index + 1
        end
    end
    return true
end
--- A number as both runtimes print it alike: an integer in digits, any other
-- value exactly, as an integer times a power of two. Lua prints 3.0 for a
-- float that JavaScript prints as 3, and neither prints every binary digit.
function ____exports.describeNumber(value)
    if value ~= value then
        return "nan"
    end
    if value == math.huge then
        return "inf"
    end
    if value == -math.huge then
        return "-inf"
    end
    if value == 0 then
        return "0"
    end
    local text = tostring(value)
    if isDigits(text) then
        return text
    end
    local mantissa = value
    local exponent = 0
    while mantissa ~= math.floor(mantissa) and exponent < 1100 do
        mantissa = mantissa * 2
        exponent = exponent + 1
    end
    return exponent == 0 and __TS__NumberToFixed(mantissa, 0) or (__TS__NumberToFixed(mantissa, 0) .. "p-") .. tostring(exponent)
end
function mixText(hash, text)
    local mixed = hash
    do
        local index = 0
        while index < #text do
            mixed = mix(
                mixed,
                __TS__StringCharCodeAt(text, index)
            )
            index = index + 1
        end
    end
    return mix(mixed, #text)
end
function mixName(hash, name)
    local named = nameHashes:get(name)
    if named == nil then
        named = mixText(0, name)
        nameHashes:set(name, named)
    end
    return mix(hash, named)
end
function mixValue(hash, value)
    if type(value) == "number" then
        if value == math.floor(value) and value >= -INT32_LIMIT and value < INT32_LIMIT then
            return mix(
                mix(hash, 1),
                math.floor(value)
            )
        end
        return mixText(
            mix(hash, 2),
            ____exports.describeNumber(value)
        )
    end
    if type(value) == "string" then
        return mixText(
            mix(hash, 3),
            value
        )
    end
    if type(value) == "boolean" then
        return mix(hash, value and 4 or 5)
    end
    if type(value) == "function" then
        return mix(hash, 6)
    end
    if isHandle(value) then
        return mix(
            mixName(
                mix(hash, 7),
                value.kind
            ),
            value.id
        )
    end
    return mix(hash, (value == nil or value == nil) and 8 or 9)
end
--- Natives Wisp's own runtime calls on one client only. A game adds the ones
-- its code calls that way: local UI, input polling, conversions for local text.
____exports.WISP_LOCAL_NATIVES = {
    GetLocalPlayer = "identifies the client; every local branch starts here",
    GetPlayerId = "names this client's files; no effect",
    BlzSendSyncData = "only the sending client calls it; its message reaches every client as an event",
    PreloadGenClear = "local file output",
    PreloadGenStart = "local file output",
    Preload = "local file output",
    PreloadGenEnd = "local file output",
    Preloader = "local file input, synchronized only through sync data",
    BlzGetAbilityTooltip = "FileIO's local file buffer",
    BlzSetAbilityTooltip = "FileIO's local file buffer",
    DisplayTextToPlayer = "a message on this client: reload results and error reports",
    BlzFrameSetText = "the frame meter's overlay: an existing frame's text on this client",
    BlzFrameSetVisible = "the frame meter's overlay: shows an existing frame on this client",
    TimerGetElapsed = "reads a timer; the reload acknowledgement only reports it",
    BlzGetLocalSpecialEffectX = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectY = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectZ = "the scene report reads an effect's local position"
}
____exports.FRAMES_PER_SECOND = 60
isHandle = function(value) return type(value) == "table" and value ~= nil and value.id ~= nil and value.kind ~= nil end
local function isFrame(value)
    return type(value) == "table" and value ~= nil and value.points ~= nil
end
--- A native argument, the same on every client and in both runtimes: handles by kind and number, callbacks as `fn`.
function ____exports.describeValue(value)
    if value == nil or value == nil then
        return "nil"
    end
    if type(value) == "number" then
        return ____exports.describeNumber(value)
    end
    if type(value) == "string" then
        return ("\"" .. value) .. "\""
    end
    if type(value) == "boolean" then
        return value and "true" or "false"
    end
    if type(value) == "function" then
        return "fn"
    end
    if isHandle(value) then
        return (value.kind .. "#") .. ____exports.describeNumber(value.id)
    end
    return "table"
end
function ____exports.describeCall(____bindingPattern0)
    local args
    local name
    name = ____bindingPattern0.name
    args = ____bindingPattern0.args
    local call = name .. "("
    do
        local index = 0
        while index < #args do
            if index > 0 then
                call = call .. ", "
            end
            call = call .. ____exports.describeValue(args[index + 1])
            index = index + 1
        end
    end
    return call .. ")"
end
--- Whether two clients made the same call: equal values, handles with the same kind and number, any two callbacks.
function ____exports.sameCall(left, right)
    if left.name ~= right.name or #left.args ~= #right.args then
        return false
    end
    do
        local index = 0
        while index < #left.args do
            do
                local leftArg = left.args[index + 1]
                local rightArg = right.args[index + 1]
                if leftArg == rightArg then
                    goto __continue30
                end
                if type(leftArg) == "function" and type(rightArg) == "function" then
                    goto __continue30
                end
                if isHandle(leftArg) and isHandle(rightArg) then
                    if leftArg.id ~= rightArg.id or leftArg.kind ~= rightArg.kind then
                        return false
                    end
                    goto __continue30
                end
                if ____exports.describeValue(leftArg) ~= ____exports.describeValue(rightArg) then
                    return false
                end
            end
            ::__continue30::
            index = index + 1
        end
    end
    return true
end
--- JASS S2I and S2R read a leading number and ignore the rest; no digits read as 0.
local function leadingNumber(text, fraction)
    local start = 0
    while start < #text and __TS__StringCharAt(text, start) == " " do
        start = start + 1
    end
    local ____end = start
    if ____end < #text and (__TS__StringCharAt(text, ____end) == "-" or __TS__StringCharAt(text, ____end) == "+") then
        ____end = ____end + 1
    end
    local digits = 0
    local point = false
    while ____end < #text do
        local character = __TS__StringCharAt(text, ____end)
        if character >= "0" and character <= "9" then
            digits = digits + 1
        elseif fraction and character == "." and not point then
            point = true
        else
            break
        end
        ____end = ____end + 1
    end
    if digits == 0 then
        return 0
    end
    local value = __TS__Number(__TS__StringSlice(text, start, ____end))
    return value == value and value or 0
end
mix = function(hash, value) return hash * 1000003 + value | 0 end
nameHashes = __TS__New(Map)
local function mixCall(hash, ____bindingPattern0)
    local args
    local name
    name = ____bindingPattern0.name
    args = ____bindingPattern0.args
    local mixed = mixName(hash, name)
    do
        local index = 0
        while index < #args do
            mixed = mixValue(mixed, args[index + 1])
            index = index + 1
        end
    end
    return mixed
end
INT32_LIMIT = 2147483648
____exports.HeadlessClient = __TS__Class()
local HeadlessClient = ____exports.HeadlessClient
HeadlessClient.name = "HeadlessClient"
function HeadlessClient.prototype.____constructor(self, options)
    self.log = {}
    self.forgotten = 0
    self.forgottenHash = 0
    self.errors = {}
    self.messages = {}
    self.thrown = {}
    self.files = __TS__New(Map)
    self.published = __TS__New(Map)
    self.missedLookups = 0
    self.natives = {}
    self.frame = 0
    self.nextId = 0
    self.timers = {}
    self.registrations = {}
    self.memo = __TS__New(Map)
    self.effects = __TS__New(Map)
    self.tooltips = __TS__New(Map)
    self.preloaded = __TS__New(Map)
    self.event = {
        player = 0,
        syncPrefix = "",
        syncData = "",
        chat = "",
        key = 0,
        timer = nil,
        frame = nil,
        frameEvent = nil
    }
    self.preload = {}
    self.slot = options.slot
    self.scope = options.scope
    self.filePrefix = options.filePrefix
    self.stored = options.files
    local behaviors = self:behaviors(options)
    local ____local = options.localNatives
    local log = self.log
    local function logged(name, parameters, behave)
        repeat
            local ____switch62 = parameters
            local ____cond62 = ____switch62 == 0
            if ____cond62 then
                return function()
                    log[#log + 1] = {name = name, args = {}}
                    return behave()
                end
            end
            ____cond62 = ____cond62 or ____switch62 == 1
            if ____cond62 then
                return function(a)
                    log[#log + 1] = {name = name, args = {a}}
                    return behave(a)
                end
            end
            ____cond62 = ____cond62 or ____switch62 == 2
            if ____cond62 then
                return function(a, b)
                    log[#log + 1] = {name = name, args = {a, b}}
                    return behave(a, b)
                end
            end
            ____cond62 = ____cond62 or ____switch62 == 3
            if ____cond62 then
                return function(a, b, c)
                    log[#log + 1] = {name = name, args = {a, b, c}}
                    return behave(a, b, c)
                end
            end
            ____cond62 = ____cond62 or ____switch62 == 4
            if ____cond62 then
                return function(a, b, c, d)
                    log[#log + 1] = {name = name, args = {a, b, c, d}}
                    return behave(a, b, c, d)
                end
            end
            do
                return function(...)
                    local args = {...}
                    log[#log + 1] = {name = name, args = args}
                    return behave(...)
                end
            end
        until true
    end
    local arity = __TS__New(Map)
    local declared = __TS__New(Set)
    for ____, ____value in ipairs(options.declarations.functions) do
        local name = ____value[1]
        local returns = ____value[2]
        local parameters = ____value[3]
        declared:add(name)
        arity:set(name, parameters)
        local behave = behaviors[name] or (__TS__StringStartsWith(name, "Convert") and (function(value) return value end) or self:defaultNative(returns))
        self.natives[name] = ____local[name] == nil and logged(name, parameters, behave) or behave
    end
    for ____, ____value in ipairs(options.declarations.constants) do
        local name = ____value[1]
        local ____type = ____value[2]
        local ____self_natives_2 = self.natives
        local ____name_3 = name
        local ____temp_1
        if ____type == "number" then
            ____temp_1 = 0
        else
            local ____temp_0
            if ____type == "boolean" then
                ____temp_0 = name == "TRUE"
            else
                ____temp_0 = name
            end
            ____temp_1 = ____temp_0
        end
        ____self_natives_2[____name_3] = ____temp_1
    end
    for ____, ____value in ipairs(options.declarations.variables) do
        local name = ____value[1]
        local ____type = ____value[2]
        self.natives[name] = self:defaultValue(____type)
    end
    local points = __TS__New(Map)
    do
        local index = 0
        while index < #FRAME_POINTS do
            local name, fromLeft, fromTop = table.unpack(FRAME_POINTS[index + 1] or ({"", 0, 0}), 1, 3)
            local ____points_set_5 = points.set
            local ____self_natives_name_4 = self.natives[name]
            if ____self_natives_name_4 == nil then
                ____self_natives_name_4 = name
            end
            ____points_set_5(points, ____self_natives_name_4, {fromLeft, fromTop})
            points:set(index, {fromLeft, fromTop})
            index = index + 1
        end
    end
    self.frames = __TS__New(Frames, points)
    self.frames:define(options.frames or ({}))
    local ____opt_6 = options.natives
    local extra = ____opt_6 and ____opt_6(self) or ({})
    for ____, name in ipairs(__TS__ObjectKeys(extra)) do
        local value = extra[name]
        self.natives[name] = type(value) == "function" and declared:has(name) and ____local[name] == nil and logged(
            name,
            arity:get(name) or 5,
            value
        ) or value
    end
end
function HeadlessClient.prototype.handle(self, kind)
    self.nextId = self.nextId + 1
    return {kind = kind, id = self.nextId}
end
function HeadlessClient.prototype.defaultNative(self, returns)
    repeat
        local ____switch82 = returns
        local ____cond82 = ____switch82 == "void"
        if ____cond82 then
            return function() return nil end
        end
        ____cond82 = ____cond82 or ____switch82 == "number"
        if ____cond82 then
            return function() return 0 end
        end
        ____cond82 = ____cond82 or ____switch82 == "string"
        if ____cond82 then
            return function() return "" end
        end
        ____cond82 = ____cond82 or ____switch82 == "boolean"
        if ____cond82 then
            return function() return false end
        end
        do
            return function() return self:handle(returns) end
        end
    until true
end
function HeadlessClient.prototype.defaultValue(self, ____type)
    if __TS__StringEndsWith(____type, "[]") then
        return {}
    end
    repeat
        local ____switch90 = ____type
        local ____cond90 = ____switch90 == "boolean"
        if ____cond90 then
            return false
        end
        ____cond90 = ____cond90 or ____switch90 == "number"
        if ____cond90 then
            return 0
        end
        ____cond90 = ____cond90 or ____switch90 == "string"
        if ____cond90 then
            return ""
        end
        do
            return self:handle(____type)
        end
    until true
end
function HeadlessClient.prototype.memoized(self, key, name)
    if name == nil then
        name = ""
    end
    local known = self.memo:get(key)
    if known ~= nil then
        return known
    end
    local created = self.frames:add(
        self:handle("framehandle"),
        "",
        name,
        nil,
        0
    )
    self.memo:set(key, created)
    return created
end
function HeadlessClient.prototype.created(self, ____type, name, owner, context)
    return self.frames:add(
        self:handle("framehandle"),
        ____type,
        name,
        isFrame(owner) and owner or nil,
        context
    )
end
function HeadlessClient.prototype.effectAt(self, model, x, y)
    local handle = self:handle("effect")
    self.effects:set(handle, {
        handle = handle,
        model = model,
        created = self.frame,
        x = x,
        y = y,
        z = 0,
        alpha = 255,
        scale = 1,
        timeScale = 1,
        flat = false
    })
    return handle
end
function HeadlessClient.prototype.show(self, text)
    local ____self_messages_8 = self.messages
    ____self_messages_8[#____self_messages_8 + 1] = text
end
function HeadlessClient.prototype.report(self, lines)
    local heading = lines[1] or ""
    local ____self_errors_9 = self.errors
    ____self_errors_9[#____self_errors_9 + 1] = (("error in " .. __TS__StringSlice(
        heading,
        (string.find(heading, " in ", nil, true) or 0) - 1 + 4
    )) .. ": ") .. (lines[2] or "")
end
function HeadlessClient.prototype.behaviors(self, ____bindingPattern0)
    local screenWidth
    local network
    local humans
    humans = ____bindingPattern0.humans
    network = ____bindingPattern0.network
    screenWidth = ____bindingPattern0.screenWidth
    local function playing(player)
        return __TS__ArrayIncludes(humans, player)
    end
    return {
        GetLocalPlayer = function() return self.slot end,
        Player = function(n) return n end,
        GetPlayerId = function(player) return player end,
        GetTriggerPlayer = function() return self.event.player end,
        GetHandleId = function(handle) return isHandle(handle) and handle.id or handle end,
        GetPlayerController = function(player) return playing(player) and "MAP_CONTROL_USER" or "MAP_CONTROL_NONE" end,
        GetPlayerSlotState = function(player) return playing(player) and "PLAYER_SLOT_STATE_PLAYING" or "PLAYER_SLOT_STATE_EMPTY" end,
        GetPlayersAll = function()
            if self.allPlayers == nil then
                self.allPlayers = self:handle("force")
            end
            return self.allPlayers
        end,
        CreateUnit = function(_owner, typeId, x, y) return __TS__ObjectAssign(
            {},
            self:handle("unit"),
            {
                typeId = typeId,
                x = x,
                y = y,
                moveSpeed = 0,
                attackCooldown = 0
            }
        ) end,
        GetUnitTypeId = function(unit) return unit.typeId end,
        GetUnitX = function(unit) return unit.x end,
        GetUnitY = function(unit) return unit.y end,
        SetUnitX = function(unit, x)
            unit.x = x
        end,
        SetUnitY = function(unit, y)
            unit.y = y
        end,
        SetUnitPosition = function(unit, x, y)
            unit.x = x
            unit.y = y
        end,
        SetUnitMoveSpeed = function(unit, value)
            unit.moveSpeed = value
        end,
        GetUnitMoveSpeed = function(unit) return unit.moveSpeed end,
        BlzSetUnitAttackCooldown = function(unit, value)
            unit.attackCooldown = value
        end,
        BlzGetUnitAttackCooldown = function(unit) return unit.attackCooldown end,
        BlzGetLocalClientWidth = function() return screenWidth end,
        BlzGetLocalClientHeight = function() return 1080 end,
        BlzIsLocalClientActive = function() return true end,
        BlzLoadTOCFile = function() return true end,
        BlzGetOriginFrame = function(____type, index) return self:memoized((("origin " .. ____exports.describeValue(____type)) .. " ") .. tostring(index)) end,
        BlzGetFrameByName = function(name, context) return self.frames:named(name, context) or self:memoized(
            (("name " .. name) .. " ") .. tostring(context),
            name
        ) end,
        BlzFrameGetChild = function(frame, index) return self:memoized((("child " .. tostring(frame.id)) .. " ") .. tostring(index)) end,
        BlzCreateFrame = function(name, owner, _priority, context) return self.frames:create(
            function() return self:handle("framehandle") end,
            name,
            isFrame(owner) and owner or nil,
            context
        ) end,
        BlzCreateSimpleFrame = function(name, owner, context) return self:created(name, name, owner, context) end,
        BlzCreateFrameByType = function(____type, name, owner, _inherits, context) return self:created(____type, name, owner, context) end,
        BlzDestroyFrame = function(frame)
            if isFrame(frame) then
                self.frames:destroy(frame)
            end
        end,
        BlzFrameGetName = function(frame) return isFrame(frame) and frame.name or "" end,
        BlzFrameGetParent = function(frame)
            local ____isFrame_result_10
            if isFrame(frame) then
                ____isFrame_result_10 = frame.parent
            else
                ____isFrame_result_10 = nil
            end
            return ____isFrame_result_10
        end,
        BlzFrameSetText = function(frame, text)
            if isFrame(frame) then
                frame.text = text
            end
        end,
        BlzFrameGetText = function(frame) return isFrame(frame) and frame.text or "" end,
        BlzFrameSetTextSizeLimit = function(frame, size)
            if isFrame(frame) then
                frame.textLimit = size
            end
        end,
        BlzFrameGetTextSizeLimit = function(frame) return isFrame(frame) and frame.textLimit or 0 end,
        BlzFrameSetVisible = function(frame, visible)
            if isFrame(frame) then
                frame.visible = visible
            end
        end,
        BlzFrameIsVisible = function(frame)
            local ____isFrame_result_11
            if isFrame(frame) then
                ____isFrame_result_11 = frame.visible
            else
                ____isFrame_result_11 = false
            end
            return ____isFrame_result_11
        end,
        BlzFrameSetEnable = function(frame, enabled)
            if isFrame(frame) then
                frame.enabled = enabled
            end
        end,
        BlzFrameGetEnable = function(frame)
            local ____isFrame_result_12
            if isFrame(frame) then
                ____isFrame_result_12 = frame.enabled
            else
                ____isFrame_result_12 = false
            end
            return ____isFrame_result_12
        end,
        BlzFrameSetFocus = function(frame, flag)
            if isFrame(frame) then
                self.frames:focus(frame, flag)
            end
        end,
        BlzFrameSetLevel = function(frame, level)
            if isFrame(frame) then
                frame.level = level
            end
        end,
        BlzFrameSetSize = function(frame, width, height)
            if isFrame(frame) then
                frame.width = width
                frame.height = height
            end
        end,
        BlzFrameSetAbsPoint = function(frame, point, x, y)
            if isFrame(frame) then
                frame.points:set(point, {x = x, y = y})
            end
        end,
        BlzFrameClearAllPoints = function(frame)
            if isFrame(frame) then
                frame.points:clear()
            end
        end,
        BlzTriggerRegisterFrameEvent = function(trigger, frame, event)
            if isFrame(frame) then
                local ____self_registrations_13 = self.registrations
                ____self_registrations_13[#____self_registrations_13 + 1] = {kind = "frame", trigger = trigger, frame = frame, event = event}
            end
            return self:handle("event")
        end,
        BlzGetTriggerFrame = function() return self.event.frame end,
        BlzGetTriggerFrameEvent = function() return self.event.frameEvent end,
        BlzGetTriggerFrameText = function()
            local ____opt_14 = self.event.frame
            return ____opt_14 and ____opt_14.text or ""
        end,
        BlzGetTriggerSyncData = function() return self.event.syncData end,
        BlzGetTriggerSyncPrefix = function() return self.event.syncPrefix end,
        GetEventPlayerChatString = function() return self.event.chat end,
        BlzGetTriggerPlayerKey = function() return self.event.key end,
        GetExpiredTimer = function() return self.event.timer end,
        CreateTrigger = function() return __TS__ObjectAssign(
            {},
            self:handle("trigger"),
            {actions = {}, destroyed = false}
        ) end,
        DestroyTrigger = function(trigger)
            trigger.destroyed = true
        end,
        TriggerAddAction = function(trigger, action)
            local ____trigger_actions_16 = trigger.actions
            ____trigger_actions_16[#____trigger_actions_16 + 1] = action
            return self:handle("triggeraction")
        end,
        BlzTriggerRegisterPlayerSyncEvent = function(trigger, player, prefix)
            local ____self_registrations_17 = self.registrations
            ____self_registrations_17[#____self_registrations_17 + 1] = {kind = "sync", trigger = trigger, player = player, prefix = prefix}
            return self:handle("event")
        end,
        TriggerRegisterPlayerChatEvent = function(trigger, player, text, exact)
            local ____self_registrations_18 = self.registrations
            ____self_registrations_18[#____self_registrations_18 + 1] = {
                kind = "chat",
                trigger = trigger,
                player = player,
                text = text,
                exact = exact
            }
            return self:handle("event")
        end,
        BlzTriggerRegisterPlayerKeyEvent = function(trigger, player, key, meta, down)
            local ____self_registrations_19 = self.registrations
            ____self_registrations_19[#____self_registrations_19 + 1] = {
                kind = "key",
                trigger = trigger,
                player = player,
                key = key,
                meta = meta,
                down = down
            }
            return self:handle("event")
        end,
        CreateTimer = function()
            local timer = __TS__ObjectAssign(
                {},
                self:handle("timer"),
                {
                    callback = nil,
                    periodFrames = 0,
                    dueFrame = 0,
                    startFrame = 0,
                    running = false
                }
            )
            local ____self_timers_20 = self.timers
            ____self_timers_20[#____self_timers_20 + 1] = timer
            return timer
        end,
        TimerStart = function(timer, timeout, periodic, callback)
            local frames = math.max(
                periodic and 1 or 0,
                math.floor(timeout * ____exports.FRAMES_PER_SECOND + 0x1p-1)
            )
            timer.callback = callback
            timer.periodFrames = periodic and frames or 0
            timer.dueFrame = self.frame + math.max(1, frames)
            timer.startFrame = self.frame
            timer.running = true
        end,
        PauseTimer = function(timer)
            timer.running = false
        end,
        DestroyTimer = function(timer)
            timer.running = false
        end,
        TimerGetElapsed = function(timer) return (self.frame - timer.startFrame) / ____exports.FRAMES_PER_SECOND end,
        BlzSendSyncData = function(prefix, data)
            network[#network + 1] = {sender = self.slot, prefix = prefix, data = data}
            return true
        end,
        DisplayTextToPlayer = function(player, _x, _y, text)
            if player == self.slot then
                self:show(text)
            end
        end,
        DisplayTimedTextToPlayer = function(player, _x, _y, _duration, text)
            if player == self.slot then
                self:show(text)
            end
        end,
        DisplayTextToForce = function(_force, text) return self:show(text) end,
        PreloadGenClear = function()
            self.preload = {}
        end,
        Preload = function(line)
            local ____self_preload_21 = self.preload
            ____self_preload_21[#____self_preload_21 + 1] = line
        end,
        PreloadGenEnd = function(name)
            self.files:set(name, self.preload)
            if name == errorFile(self.slot, self.filePrefix) then
                self:report(self.preload)
            end
            local ____opt_22 = self.stored
            if ____opt_22 ~= nil then
                ____opt_22.written(name, self.preload)
            end
        end,
        Preloader = function(name)
            local ____temp_26 = self.preloaded:get(name) or self.published:get(name)
            if ____temp_26 == nil then
                local ____opt_24 = self.stored
                ____temp_26 = ____opt_24 and ____opt_24.read(name)
            end
            local chunks = ____temp_26
            if chunks == nil then
                self.missedLookups = self.missedLookups + 1
                return
            end
            self.preloaded:set(name, chunks)
            do
                local level = 0
                while level < #chunks do
                    self.tooltips:set(
                        (tostring(FILE_IO_ABILITY) .. " ") .. tostring(level),
                        chunks[level + 1] or ""
                    )
                    level = level + 1
                end
            end
        end,
        BlzSetAbilityTooltip = function(ability, text, level)
            self.tooltips:set(
                (tostring(ability) .. " ") .. tostring(level),
                text
            )
        end,
        BlzGetAbilityTooltip = function(ability, level) return self.tooltips:get((tostring(ability) .. " ") .. tostring(level)) or "" end,
        AddSpecialEffect = function(model, x, y) return self:effectAt(model, x, y) end,
        AddSpecialEffectLoc = function(model) return self:effectAt(model, 0, 0) end,
        AddSpecialEffectTarget = function(model, target)
            local unit = target
            return self:effectAt(model, unit.x or 0, unit.y or 0)
        end,
        DestroyEffect = function(effect)
            self.effects:delete(effect)
        end,
        BlzSetSpecialEffectPosition = function(effect, x, y, z)
            local pose = self.effects:get(effect)
            if pose == nil then
                return
            end
            pose.x = x
            pose.y = y
            pose.z = z
        end,
        BlzSetSpecialEffectX = function(effect, x)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.x = x
            end
        end,
        BlzSetSpecialEffectY = function(effect, y)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.y = y
            end
        end,
        BlzSetSpecialEffectZ = function(effect, z)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.z = z
            end
        end,
        BlzSetSpecialEffectAlpha = function(effect, alpha)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.alpha = alpha
            end
        end,
        BlzSetSpecialEffectScale = function(effect, scale)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.scale = scale
            end
        end,
        BlzSetSpecialEffectTimeScale = function(effect, timeScale)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.timeScale = timeScale
            end
        end,
        BlzSetSpecialEffectMatrixScale = function(effect, x, y, z)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.flat = pose.flat or x == 0 or y == 0 or z == 0
            end
        end,
        BlzResetSpecialEffectMatrix = function(effect)
            local pose = self.effects:get(effect)
            if pose ~= nil then
                pose.flat = false
            end
        end,
        BlzGetLocalSpecialEffectX = function(effect)
            local ____opt_27 = self.effects:get(effect)
            return ____opt_27 and ____opt_27.x or 0
        end,
        BlzGetLocalSpecialEffectY = function(effect)
            local ____opt_29 = self.effects:get(effect)
            return ____opt_29 and ____opt_29.y or 0
        end,
        BlzGetLocalSpecialEffectZ = function(effect)
            local ____opt_31 = self.effects:get(effect)
            return ____opt_31 and ____opt_31.z or 0
        end,
        I2S = function(n) return ____exports.describeNumber(n) end,
        R2S = function(n) return __TS__NumberToFixed(n, 3) end,
        R2I = function(n) return n < 0 and math.ceil(n) or math.floor(n) end,
        I2R = function(n) return n end,
        S2I = function(text)
            local value = leadingNumber(text, false)
            return value < 0 and math.ceil(value) or math.floor(value)
        end,
        S2R = function(text) return leadingNumber(text, true) end,
        SubString = function(text, start, ____end) return __TS__StringSubstring(text, start, ____end) end,
        StringLength = function(text) return #text end,
        SquareRoot = function(n) return math.sqrt(n) end,
        Atan2 = function(y, x) return math.atan(y, x) end,
        BlzBitAnd = function(a, b) return a & b end,
        BlzBitOr = function(a, b) return a | b end,
        BlzBitXor = function(a, b) return a ~ b end
    }
end
function HeadlessClient.prototype.preloadedFiles(self)
    return {__TS__Spread(self.preloaded:keys())}
end
function HeadlessClient.prototype.effectPoses(self)
    local poses = {}
    for ____, pose in __TS__Iterator(self.effects:values()) do
        poses[#poses + 1] = __TS__ObjectAssign({}, pose)
    end
    return poses
end
function HeadlessClient.prototype.run(self, body)
    local ____opt_33 = self.scope
    if ____opt_33 ~= nil then
        ____opt_33.enter(self)
    end
    do
        local ____try, ____error = pcall(function()
            body()
        end)
        do
            local ____opt_35 = self.scope
            if ____opt_35 ~= nil then
                ____opt_35.leave(self)
            end
        end
        if not ____try then
            error(____error, 0)
        end
    end
end
function HeadlessClient.prototype.fire(self, trigger, event)
    if trigger.destroyed then
        return
    end
    if event.player ~= nil then
        self.event.player = event.player
    end
    if event.syncPrefix ~= nil then
        self.event.syncPrefix = event.syncPrefix
    end
    if event.syncData ~= nil then
        self.event.syncData = event.syncData
    end
    if event.chat ~= nil then
        self.event.chat = event.chat
    end
    if event.key ~= nil then
        self.event.key = event.key
    end
    if event.frame ~= nil then
        self.event.frame = event.frame
    end
    if event.frameEvent ~= nil then
        self.event.frameEvent = event.frameEvent
    end
    for ____, action in ipairs(trigger.actions) do
        action()
    end
end
function HeadlessClient.prototype.step(self)
    self:run(function()
        self.frame = self.frame + 1
        local count = #self.timers
        do
            local index = 0
            while index < count do
                do
                    local timer = self.timers[index + 1]
                    if timer == nil or not timer.running or timer.dueFrame > self.frame or timer.callback == nil then
                        goto __continue252
                    end
                    if timer.periodFrames > 0 then
                        timer.dueFrame = timer.dueFrame + timer.periodFrames
                    else
                        timer.running = false
                    end
                    self.event.timer = timer
                    timer.callback()
                end
                ::__continue252::
                index = index + 1
            end
        end
    end)
end
function HeadlessClient.prototype.deliverSync(self, ____bindingPattern0)
    local data
    local prefix
    local sender
    sender = ____bindingPattern0.sender
    prefix = ____bindingPattern0.prefix
    data = ____bindingPattern0.data
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "sync" and registration.player == sender and registration.prefix == prefix then
                self:fire(registration.trigger, {player = sender, syncPrefix = prefix, syncData = data})
            end
        end
    end)
end
function HeadlessClient.prototype.chat(self, sender, message)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            do
                if registration.kind ~= "chat" or registration.player ~= sender then
                    goto __continue263
                end
                local ____registration_exact_37
                if registration.exact then
                    ____registration_exact_37 = message == registration.text
                else
                    ____registration_exact_37 = __TS__StringIncludes(message, registration.text)
                end
                if ____registration_exact_37 then
                    self:fire(registration.trigger, {player = sender, chat = message})
                end
            end
            ::__continue263::
        end
    end)
end
function HeadlessClient.prototype.key(self, sender, key, meta, down)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "key" and registration.player == sender and registration.key == key and registration.meta == meta and registration.down == down then
                self:fire(registration.trigger, {player = sender, key = key})
            end
        end
    end)
end
function HeadlessClient.prototype.type(self, text)
    return self.frames:type(text)
end
function HeadlessClient.prototype.clickTarget(self, x, y)
    local click = self.natives.FRAMEEVENT_CONTROL_CLICK
    return self.frames:at(
        x,
        y,
        function(frame) return __TS__ArraySome(
            self.registrations,
            function(____, registration) return registration.kind == "frame" and registration.frame == frame and registration.event == click and not registration.trigger.destroyed end
        ) end
    )
end
function HeadlessClient.prototype.frameEvent(self, sender, id, event)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "frame" and registration.frame.id == id and registration.event == event then
                self:fire(registration.trigger, {player = sender, frame = registration.frame, frameEvent = event})
            end
        end
    end)
end
function HeadlessClient.prototype.callCount(self)
    return self.forgotten + #self.log
end
function HeadlessClient.prototype.forget(self, count)
    local hash = self.forgottenHash
    do
        local index = 0
        while index < count do
            local call = self.log[index + 1]
            if call ~= nil then
                hash = mixCall(hash, call)
            end
            index = index + 1
        end
    end
    self.forgottenHash = hash
    __TS__ArraySplice(self.log, 0, count)
    self.forgotten = self.forgotten + count
end
function HeadlessClient.prototype.checksum(self)
    local hash = self.forgottenHash
    for ____, call in ipairs(self.log) do
        hash = mixCall(hash, call)
    end
    return ____exports.describeNumber(hash)
end
return ____exports
