local ____lualib = require("lualib_bundle")
local __TS__StringReplaceAll = ____lualib.__TS__StringReplaceAll
local ____exports = {}
____exports.sceneFile = function(slot, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((prefix .. "-scene-p") .. tostring(slot)) .. ".txt"
end
____exports.sceneHeading = function(serial, frame, effects) return (((("scene " .. tostring(serial)) .. " frame ") .. tostring(frame)) .. " effects ") .. tostring(effects) end
--- Backslashes would sit inside the Preload file's JASS string literals.
____exports.reportedModel = function(model) return __TS__StringReplaceAll(model, "\\", "/") end
--- One line per model, its path last because a path may contain spaces.
____exports.sceneModelLine = function(____bindingPattern0)
    local destroyed
    local longest
    local age
    local created
    local drawn
    local inView
    local live
    local model
    model = ____bindingPattern0.model
    live = ____bindingPattern0.live
    inView = ____bindingPattern0.inView
    drawn = ____bindingPattern0.drawn
    created = ____bindingPattern0.created
    age = ____bindingPattern0.age
    longest = ____bindingPattern0.longest
    destroyed = ____bindingPattern0.destroyed
    return (((((((((((((("model " .. tostring(live)) .. " ") .. tostring(inView)) .. " ") .. tostring(drawn)) .. " ") .. tostring(created or "-")) .. " ") .. tostring(age or "-")) .. " ") .. tostring(longest)) .. " ") .. tostring(destroyed)) .. " ") .. model
end
return ____exports
