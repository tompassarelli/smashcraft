/** @noSelfInFile */
export declare const sceneFile: (slot: number, prefix?: string) => string;
export declare const sceneHeading: (serial: number, frame: number, effects: number) => string;
export interface SceneModel {
    readonly model: string;
    readonly live: number;
    readonly inView: number;
    readonly drawn: number;
    readonly created: number | undefined;
    readonly age: number | undefined;
    readonly longest: number;
    readonly destroyed: number;
}
/** Backslashes would sit inside the Preload file's JASS string literals. */
export declare const reportedModel: (model: string) => string;
/** One line per model, its path last because a path may contain spaces. */
export declare const sceneModelLine: ({ model, live, inView, drawn, created, age, longest, destroyed }: SceneModel) => string;
