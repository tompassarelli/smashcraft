local ____exports = {}
local split, scaleByPowerOfTwo, shiftRightJam, addLimbs, lessThan, subtractLimbs, bitLength, roundLimbs, limbFusedMultiplyAdd, TWO_POWERS, INFINITY, splitSignificand, splitExponent
local ____lookup = require("src.runtime.lookup")
local at = ____lookup.at
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local floorMod = ____intMath.floorMod
function split(value)
    local normalized = value < 0 and -value or value
    local exponent = -23
    while normalized >= 65536 do
        normalized = normalized * 0.0000152587890625
        exponent = exponent + 16
    end
    while normalized >= 16 do
        normalized = normalized * 0.0625
        exponent = exponent + 4
    end
    while normalized >= 2 do
        normalized = normalized * 0.5
        exponent = exponent + 1
    end
    while normalized < 0.0000152587890625 do
        normalized = normalized * 65536
        exponent = exponent - 16
    end
    while normalized < 0.0625 do
        normalized = normalized * 16
        exponent = exponent - 4
    end
    while normalized < 1 do
        normalized = normalized * 2
        exponent = exponent - 1
    end
    splitSignificand = normalized * 8388608.0 | 0
    splitExponent = exponent
end
function scaleByPowerOfTwo(value, scale)
    local result = value * 1.0
    local remaining = scale
    if remaining < 0 then
        while remaining <= -16 do
            result = result * 0.0000152587890625
            remaining = remaining + 16
        end
        while remaining <= -4 do
            result = result * 0.0625
            remaining = remaining + 4
        end
        while remaining < 0 do
            result = result * 0.5
            remaining = remaining + 1
        end
    else
        while remaining >= 16 do
            result = result * 65536.0
            remaining = remaining - 16
        end
        while remaining >= 4 do
            result = result * 16.0
            remaining = remaining - 4
        end
        while remaining > 0 do
            result = result * 2.0
            remaining = remaining - 1
        end
    end
    return result
end
function shiftRightJam(value, count)
    if count >= 72 then
        return {high = 0, middle = 0, low = (value.high ~= 0 or value.middle ~= 0 or value.low ~= 0) and 1 or 0}
    end
    local high = value.high
    local middle = value.middle
    local low = value.low
    local remaining = count
    while remaining >= 24 do
        local lost = low ~= 0
        low = middle
        middle = high
        high = 0
        if lost and low % 2 == 0 then
            low = low + 1
        end
        remaining = remaining - 24
    end
    if remaining > 0 then
        local divisor = at(TWO_POWERS, remaining)
        local carry = at(TWO_POWERS, 24 - remaining)
        local lost = low % divisor ~= 0
        low = low // divisor + middle % divisor * carry
        middle = middle // divisor + high % divisor * carry
        high = high // divisor
        if lost and low % 2 == 0 then
            low = low + 1
        end
    end
    return {high = high, middle = middle, low = low}
end
function addLimbs(a, b)
    local lowSum = a.low + b.low
    local middleSum = a.middle + b.middle + lowSum // 16777216
    return {high = a.high + b.high + middleSum // 16777216, middle = middleSum % 16777216, low = lowSum % 16777216}
end
function lessThan(a, b)
    return a.high < b.high or a.high == b.high and (a.middle < b.middle or a.middle == b.middle and a.low < b.low)
end
function subtractLimbs(a, b)
    local low = a.low - b.low
    local middle = a.middle - b.middle
    local high = a.high - b.high
    if low < 0 then
        low = low + 16777216
        middle = middle - 1
    end
    if middle < 0 then
        middle = middle + 16777216
        high = high - 1
    end
    return {high = high, middle = middle, low = low}
end
function bitLength(value)
    local remaining = value
    local result = 0
    if remaining >= 65536 then
        remaining = remaining // 65536
        result = result + 16
    end
    if remaining >= 256 then
        remaining = remaining // 256
        result = result + 8
    end
    if remaining >= 16 then
        remaining = remaining // 16
        result = result + 4
    end
    if remaining >= 4 then
        remaining = remaining // 4
        result = result + 2
    end
    if remaining >= 2 then
        remaining = remaining // 2
        result = result + 1
    end
    return result + remaining
end
function roundLimbs(value, scale, negative)
    local bits = value.high ~= 0 and 48 + bitLength(value.high) or (value.middle ~= 0 and 24 + bitLength(value.middle) or bitLength(value.low))
    if bits == 0 then
        return 0.0
    end
    local shift = bits - 24
    if scale + shift < -149 then
        shift = -149 - scale
    end
    local rounded = value.low
    local resultScale = scale
    if shift >= 2 then
        local truncated = shiftRightJam(value, shift - 2)
        rounded = truncated.middle * 4194304 + truncated.low // 4
        local remainder = truncated.low % 4
        if remainder > 2 or remainder == 2 and rounded % 2 ~= 0 then
            rounded = rounded + 1
        end
        resultScale = resultScale + shift
    elseif shift == 1 then
        rounded = value.middle * 8388608 + value.low // 2
        if value.low % 2 ~= 0 and rounded % 2 ~= 0 then
            rounded = rounded + 1
        end
        resultScale = resultScale + 1
    end
    if resultScale + bitLength(rounded) > 128 then
        return negative and -INFINITY or INFINITY
    end
    local result = scaleByPowerOfTwo(rounded, resultScale)
    return negative and -result or result
end
function limbFusedMultiplyAdd(a, b, c)
    if a == 0 or b == 0 then
        return a * b + c
    end
    split(a)
    local leftSignificand = splitSignificand
    local leftExponent = splitExponent
    split(b)
    local leftHigh = leftSignificand // 4096
    local leftLow = leftSignificand % 4096
    local rightHigh = splitSignificand // 4096
    local rightLow = splitSignificand % 4096
    local first = leftLow * rightLow
    local second = first // 4096 + leftHigh * rightLow + leftLow * rightHigh
    local wideHigh = leftHigh * rightHigh + second // 4096
    local wideLow = first % 4096 + second % 4096 * 4096
    local magnitude = {high = wideHigh // 2, middle = wideHigh % 2 * 8388608 + wideLow // 2, low = wideLow % 2 * 8388608}
    local scale = leftExponent + splitExponent - 23
    local negative = a < 0 ~= (b < 0)
    if c ~= 0 then
        split(c)
        local other = {high = splitSignificand // 2, middle = splitSignificand % 2 * 8388608, low = 0}
        local otherScale = splitExponent - 47
        if scale < otherScale then
            magnitude = shiftRightJam(magnitude, otherScale - scale)
            scale = otherScale
        else
            other = shiftRightJam(other, scale - otherScale)
        end
        if negative == (c < 0) then
            magnitude = addLimbs(magnitude, other)
        elseif lessThan(magnitude, other) then
            magnitude = subtractLimbs(other, magnitude)
            negative = c < 0
        else
            magnitude = subtractLimbs(magnitude, other)
        end
    end
    return roundLimbs(magnitude, scale, negative)
end
TWO_POWERS = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216
}
--- Truncation toward zero, which Lua and JavaScript both emit exactly.
function ____exports.toInt(value)
    return value < 0 and math.ceil(value) or math.floor(value)
end
local function binary32Infinity()
    local result = 16777216.0
    do
        local i = 1
        while i <= 6 do
            result = result * result
            i = i + 1
        end
    end
    return result
end
INFINITY = binary32Infinity()
local SIGNIFICAND_UNIT = 1.1920928955078125e-7
--- 2^-126 through 2^127, the normal powers of two: element i is 2^(i - 126).
local NORMAL_POWERS = {}
do
    local power = 1.0
    do
        local i = 0
        while i < 126 do
            power = power * 0.5
            i = i + 1
        end
    end
    NORMAL_POWERS[#NORMAL_POWERS + 1] = power
    do
        local i = 1
        while i < 254 do
            power = power * 2.0
            NORMAL_POWERS[#NORMAL_POWERS + 1] = power
            i = i + 1
        end
    end
end
local SMALLEST_NORMAL = at(NORMAL_POWERS, 0)
--- significand * 2^exponent for a significand in [2^23, 2^24); undefined unless the result is a normal binary32 value.
local function normalResult(significand, exponent, negative)
    local power = NORMAL_POWERS[exponent + 149 + 1]
    if power == nil then
        return nil
    end
    local magnitude = significand * SIGNIFICAND_UNIT * power
    return negative and -magnitude or magnitude
end
--- Rounds to the nearest binary32 value; NaN and infinity pass through.
function ____exports.roundToFloat32(value)
    if value >= SMALLEST_NORMAL and value < INFINITY or value <= -SMALLEST_NORMAL and value > -INFINITY then
        return value * 1.0
    end
    if value == 0 or value ~= value then
        return value
    end
    local negative = value < 0
    local significand = negative and -value or value
    local scale = 1.0
    local exponent = 0
    while significand >= 65536 and exponent <= 111 do
        significand = significand * 0.0000152587890625
        scale = scale * 65536
        exponent = exponent + 16
    end
    while significand >= 16 and exponent <= 123 do
        significand = significand * 0.0625
        scale = scale * 16
        exponent = exponent + 4
    end
    while significand >= 2 and exponent < 127 do
        significand = significand * 0.5
        scale = scale * 2
        exponent = exponent + 1
    end
    if significand >= 2 then
        return negative and -INFINITY or INFINITY
    end
    while significand < 0.0000152587890625 and exponent >= -110 do
        significand = significand * 65536
        scale = scale * 0.0000152587890625
        exponent = exponent - 16
    end
    while significand < 0.0625 and exponent >= -122 do
        significand = significand * 16
        scale = scale * 0.0625
        exponent = exponent - 4
    end
    while significand < 1 and exponent > -126 do
        significand = significand * 2
        scale = scale * 0.5
        exponent = exponent - 1
    end
    local units = significand * 8388608.0
    local rounded = math.floor(units)
    local remainder = units - rounded
    if remainder > 0.5 or remainder == 0.5 and rounded % 2 ~= 0 then
        rounded = rounded + 1
    end
    if exponent == 127 and rounded == 16777216 then
        return negative and -INFINITY or INFINITY
    end
    local result = rounded / 8388608.0 * scale
    return negative and -result or result
end
splitSignificand = 0
splitExponent = 0
--- Rounds (high * 2^24 + low) * 2^exponent, plus a fraction of 2^exponent in
-- (0, 1) when sticky, to 24 bits. Requires 0 < high < 2^31 or 0 < low, and
-- 0 <= low < 2^24; with sticky, high >= 2^23 - 1.
local function roundLimbsToNormal(high, low, exponent, sticky, negative)
    local top = high
    local bottom = low
    local scale = exponent
    local inexact = sticky
    while top >= 16777216 do
        if bottom % 2 ~= 0 then
            inexact = true
        end
        bottom = bottom // 2 + top % 2 * 8388608
        top = top // 2
        scale = scale + 1
    end
    local significand
    local remainder
    local half
    if top >= 8388608 then
        significand = top
        remainder = bottom
        half = 8388608
        scale = scale + 24
    elseif inexact then
        significand = top * 2 + bottom // 8388608
        remainder = bottom % 8388608
        half = 4194304
        scale = scale + 23
    else
        if top == 0 then
            top = bottom
            bottom = 0
            scale = scale - 24
        end
        while top < 8388608 do
            top = top * 2 + bottom // 8388608
            bottom = bottom % 8388608 * 2
            scale = scale - 1
        end
        significand = top
        remainder = bottom
        half = 8388608
        scale = scale + 24
    end
    if remainder > half or remainder == half and (inexact or significand % 2 ~= 0) then
        significand = significand + 1
        if significand == 16777216 then
            significand = 8388608
            scale = scale + 1
        end
    end
    return normalResult(significand, scale, negative)
end
--- (high * 2^24 + low) * 2^exponent, with high in [2^23, 2^24), plus c, rounded
-- once; undefined unless the result is a normal binary32 value.
local function addToLimbs(high, low, exponent, negative, c)
    split(c)
    local addend = splitSignificand
    local addendNegative = c < 0
    local shift = splitExponent - exponent
    if shift > 30 then
        local guarded = splitExponent - 6
        local part = 0
        local sticky = true
        if shift - 30 < 24 then
            local unit = TWO_POWERS[shift - 30 + 1] or 0
            part = high // unit
            sticky = high - part * unit ~= 0 or low ~= 0
        end
        local sum = addend * 64
        if negative == addendNegative then
            sum = sum + part
        else
            sum = sum - (part + (sticky and 1 or 0))
        end
        local dropped = sum >= 1073741824 and 7 or (sum >= 536870912 and 6 or 5)
        local unit = TWO_POWERS[dropped + 1] or 0
        local significand = sum // unit
        local remainder = sum - significand * unit
        local half = TWO_POWERS[dropped] or 0
        local scale = guarded + dropped
        if remainder > half or remainder == half and (sticky or significand % 2 ~= 0) then
            significand = significand + 1
            if significand == 16777216 then
                significand = 8388608
                scale = scale + 1
            end
        end
        return normalResult(significand, scale, addendNegative)
    end
    local top = high
    local bottom = low
    local sign = negative
    if shift < 0 then
        local part = 0
        local sticky = true
        if -shift < 24 then
            local unit = TWO_POWERS[-shift + 1] or 0
            part = addend // unit
            sticky = addend - part * unit ~= 0
        end
        if negative == addendNegative then
            bottom = bottom + part
            if bottom >= 16777216 then
                bottom = bottom - 16777216
                top = top + 1
            end
        else
            bottom = bottom - (part + (sticky and 1 or 0))
            if bottom < 0 then
                bottom = bottom + 16777216
                top = top - 1
            end
        end
        return roundLimbsToNormal(
            top,
            bottom,
            exponent,
            sticky,
            sign
        )
    end
    local addendHigh
    local addendLow = 0
    if shift >= 24 then
        addendHigh = addend * (TWO_POWERS[shift - 24 + 1] or 0)
    else
        local unit = TWO_POWERS[24 - shift + 1] or 0
        addendHigh = addend // unit
        addendLow = (addend - addendHigh * unit) * (TWO_POWERS[shift + 1] or 0)
    end
    if negative == addendNegative then
        top = top + addendHigh
        bottom = bottom + addendLow
        if bottom >= 16777216 then
            bottom = bottom - 16777216
            top = top + 1
        end
    else
        top = top - addendHigh
        bottom = bottom - addendLow
        if bottom < 0 then
            bottom = bottom + 16777216
            top = top - 1
        end
        if top < 0 then
            if bottom > 0 then
                top = -top - 1
                bottom = 16777216 - bottom
            else
                top = -top
            end
            sign = addendNegative
        elseif top == 0 and bottom == 0 then
            return 0.0
        end
    end
    return roundLimbsToNormal(
        top,
        bottom,
        exponent,
        false,
        sign
    )
end
function ____exports.addFloat32(a, b)
    if a == 0 then
        return 1.0 * a + b
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY then
        split(a)
        local ____temp_0
        if b == 0 then
            ____temp_0 = normalResult(splitSignificand, splitExponent, a < 0)
        else
            ____temp_0 = addToLimbs(
                splitSignificand,
                0,
                splitExponent - 24,
                a < 0,
                b
            )
        end
        local result = ____temp_0
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(1.0, a, b)
end
function ____exports.subtractFloat32(a, b)
    if b == 0 then
        return -1.0 * b + a
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY then
        split(b)
        local ____temp_1
        if a == 0 then
            ____temp_1 = normalResult(splitSignificand, splitExponent, not (b < 0))
        else
            ____temp_1 = addToLimbs(
                splitSignificand,
                0,
                splitExponent - 24,
                not (b < 0),
                a
            )
        end
        local result = ____temp_1
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(-1.0, b, a)
end
local productHigh = 0
local productLow = 0
local productExponent = 0
--- Sets the product limbs of two finite nonzero values.
local function multiplySplit(a, b)
    split(a)
    local left = splitSignificand
    local leftExponent = splitExponent
    split(b)
    local leftHigh = left // 4096
    local leftLow = left - leftHigh * 4096
    local rightHigh = splitSignificand // 4096
    local rightLow = splitSignificand - rightHigh * 4096
    local lowest = leftLow * rightLow
    local middle = lowest // 4096 + leftHigh * rightLow + leftLow * rightHigh
    local high = leftHigh * rightHigh + middle // 4096
    local low = lowest % 4096 + middle % 4096 * 4096
    local exponent = leftExponent + splitExponent
    if high < 8388608 then
        high = high * 2 + low // 8388608
        low = low % 8388608 * 2
        exponent = exponent - 1
    end
    productHigh = high
    productLow = low
    productExponent = exponent
end
function ____exports.multiplyFloat32(a, b)
    if a == 0 or b == 0 then
        return a * b + 0.0
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY then
        multiplySplit(a, b)
        local significand = productHigh
        local exponent = productExponent + 24
        if productLow > 8388608 or productLow == 8388608 and significand % 2 ~= 0 then
            significand = significand + 1
            if significand == 16777216 then
                significand = 8388608
                exponent = exponent + 1
            end
        end
        local result = normalResult(significand, exponent, a < 0 ~= (b < 0))
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(a, b, 0.0)
end
--- a * b + c with one binary32 rounding. Inputs must be finite binary32 values;
-- the exact product may leave binary32 range before cancellation.
function ____exports.fusedMultiplyAddFloat32(a, b, c)
    if a == 0 or b == 0 then
        return a * b + c
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY and c < INFINITY and c > -INFINITY then
        multiplySplit(a, b)
        local negative = a < 0 ~= (b < 0)
        local result
        if c == 0 then
            result = roundLimbsToNormal(
                productHigh,
                productLow,
                productExponent,
                false,
                negative
            )
        else
            result = addToLimbs(
                productHigh,
                productLow,
                productExponent,
                negative,
                c
            )
        end
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(a, b, c)
end
--- Long division keeps the quotient and sticky remainder; a zero divisor gives NaN.
function ____exports.divideFloat32(numerator, denominator)
    if denominator == 0 then
        return INFINITY - INFINITY
    end
    if numerator == 0 then
        return numerator
    end
    split(numerator)
    local remainder = splitSignificand
    local exponent = splitExponent
    split(denominator)
    local denominatorSignificand = splitSignificand
    exponent = exponent - splitExponent
    local negative = numerator < 0 ~= (denominator < 0)
    if remainder < denominatorSignificand then
        remainder = remainder * 2
        exponent = exponent - 1
    end
    remainder = remainder - denominatorSignificand
    local quotient = 1
    do
        local chunk = 1
        while chunk <= 4 do
            remainder = remainder * 64
            local digits = remainder // denominatorSignificand
            remainder = remainder - digits * denominatorSignificand
            quotient = quotient * 64 + digits
            chunk = chunk + 1
        end
    end
    remainder = remainder * 4
    local lastDigits = remainder // denominatorSignificand
    remainder = remainder - lastDigits * denominatorSignificand
    quotient = quotient * 4 + lastDigits
    local rounded = quotient // 8
    local roundingBits = quotient % 8
    if roundingBits > 4 or roundingBits == 4 and (remainder ~= 0 or rounded % 2 ~= 0) then
        rounded = rounded + 1
    end
    local scale = exponent - 23
    if exponent < -126 then
        local subnormalShift = exponent + 149
        if subnormalShift < -1 then
            return 0.0
        end
        if subnormalShift == -1 then
            rounded = (quotient ~= 67108864 or remainder ~= 0) and 1 or 0
        else
            local divisor = 1
            do
                local i = 1
                while i <= 26 - subnormalShift do
                    divisor = divisor * 2
                    i = i + 1
                end
            end
            rounded = quotient // divisor
            local roundingRemainder = quotient % divisor
            if roundingRemainder * 2 > divisor or roundingRemainder * 2 == divisor and (remainder ~= 0 or rounded % 2 ~= 0) then
                rounded = rounded + 1
            end
        end
        scale = -149
    elseif rounded == 16777216 then
        rounded = 8388608
        exponent = exponent + 1
        scale = exponent - 23
    end
    if exponent > 127 or exponent == 127 and rounded == 16777216 then
        return negative and -INFINITY or INFINITY
    end
    local result = scaleByPowerOfTwo(rounded, scale)
    return negative and -result or result
end
--- Correctly rounded square root of a binary32 input, independent of host math.
function ____exports.squareRootFloat32(value)
    if value == 0 or value ~= value then
        return value
    end
    if value < 0 then
        return INFINITY - INFINITY
    end
    if value - value ~= 0 then
        return value
    end
    split(value)
    local significand = splitSignificand
    local exponent = splitExponent + 23
    if exponent % 2 ~= 0 then
        significand = significand * 2
        exponent = exponent - 1
    end
    local high = significand // 2
    local low = significand % 2 * 8388608
    local remainder = 0
    local root = 0
    do
        local i = 0
        while i < 24 do
            local pair = high // 4194304
            high = high % 4194304 * 4 + low // 4194304
            low = low % 4194304 * 4
            remainder = remainder * 4 + pair
            local trial = root * 4 + 1
            root = root * 2
            if remainder >= trial then
                remainder = remainder - trial
                root = root + 1
            end
            i = i + 1
        end
    end
    if remainder > root then
        root = root + 1
    end
    return scaleByPowerOfTwo(root, exponent // 2 - 23)
end
return ____exports
