/** @noSelfInFile */
import { type ClientScope, HeadlessClient, type LocalNatives, type MapEntry, type NativeBehaviors, type SyncMessage } from "./client";
import type { NativeDeclarations } from "./declarations";
export interface LockstepOptions {
    readonly declarations: NativeDeclarations;
    /** One client per human player slot. */
    readonly players: readonly number[];
    /** The map's configureRuntime() filePrefix, which names its reload, acknowledgement and error files. */
    readonly filePrefix: string;
    /** Each client's map entry; called in that client, so a host can load the bundle there. */
    readonly entry: (this: void, client: HeadlessClient) => MapEntry;
    /** The text a hot reload publishes; each client's Lua `load` turns it back into the entry. */
    readonly bundle: string;
    /** The game's local-only natives, added to WISP_LOCAL_NATIVES. */
    readonly localNatives?: LocalNatives;
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly scope?: ClientScope;
}
export declare class Lockstep {
    readonly network: SyncMessage[];
    readonly clients: readonly HeadlessClient[];
    /** Frames every client has run. */
    frame: number;
    /** Hot reload versions published so far. */
    version: number;
    private readonly options;
    constructor(options: LockstepOptions);
    /** The map's main(): every client loads its entry and starts it. */
    start(): void;
    /** Runs `body` on every client, such as an entry the test chooses or an install() outside the reloader. */
    everywhere(body: (this: void) => void): void;
    /** Synchronized messages reach every client in the order they were sent. */
    private flush;
    frames(count: number): void;
    chat(sender: number, message: string): void;
    /** A key press and release with modifiers (2: Ctrl), as every client sees it. */
    press(sender: number, key: number, meta?: number): void;
    /** Puts a file in every client's CustomMapData, as the host writes it: one chunk per FileIO tooltip level. */
    publish(name: string, chunks: readonly string[]): void;
    /**
     * Publishes the bundle as the next hot reload version, as `wisp hot` does:
     * payload files, then the manifest. The clients find it on their next polls.
     */
    reload(): number;
    /** Clients whose acknowledgement doesn't name the latest version, each with why. */
    unappliedReloads(): string[];
    /** The first call at which two clients' logs differ, with the calls around it; undefined when they agree. */
    firstDivergence(): string | undefined;
}
