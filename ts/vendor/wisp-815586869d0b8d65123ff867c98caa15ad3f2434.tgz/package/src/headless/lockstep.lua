local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__New = ____lualib.__TS__New
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local ackFile = ____gameFiles.ackFile
local formatManifest = ____gameFiles.formatManifest
local manifestFile = ____gameFiles.manifestFile
local PAYLOAD_FILE_BYTES = ____gameFiles.PAYLOAD_FILE_BYTES
local payloadFile = ____gameFiles.payloadFile
local ____payload = require("src.runtime.payload")
local checksum = ____payload.checksum
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local ____client = require("src.headless.client")
local HeadlessClient = ____client.HeadlessClient
local WISP_LOCAL_NATIVES = ____client.WISP_LOCAL_NATIVES
local describeCall = ____client.describeCall
local sameCall = ____client.sameCall
--- Synchronized messages that keep causing more are a defect, not a frame.
local MAX_MESSAGES_PER_FLUSH = 10000
____exports.Lockstep = __TS__Class()
local Lockstep = ____exports.Lockstep
Lockstep.name = "Lockstep"
function Lockstep.prototype.____constructor(self, options)
    self.network = {}
    self.frame = 0
    self.version = 0
    self.options = options
    local localNatives = __TS__ObjectAssign({}, WISP_LOCAL_NATIVES, options.localNatives)
    local clients = {}
    do
        local index = 0
        while index < #options.players do
            local slot = options.players[index + 1] or index
            clients[#clients + 1] = __TS__New(
                HeadlessClient,
                __TS__ObjectAssign({
                    slot = slot,
                    humans = options.players,
                    declarations = options.declarations,
                    localNatives = localNatives,
                    network = self.network,
                    screenWidth = 1920 + 640 * index
                }, options.scope == nil and ({}) or ({scope = options.scope}), options.natives == nil and ({}) or ({natives = options.natives}))
            )
            index = index + 1
        end
    end
    self.clients = clients
end
function Lockstep.prototype.start(self)
    local entry = self.options.entry
    for ____, client in ipairs(self.clients) do
        client:run(function() return entry(client).start() end)
    end
    self:flush()
end
function Lockstep.prototype.everywhere(self, body)
    for ____, client in ipairs(self.clients) do
        client:run(body)
    end
    self:flush()
end
function Lockstep.prototype.flush(self)
    do
        local delivered = 0
        while #self.network > 0 do
            if delivered > MAX_MESSAGES_PER_FLUSH then
                do
                    local ____thrown = __TS__New(Error, "synchronized messages never settle")
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:80"
                    end
                    error(____thrown, 0)
                end
            end
            local message = table.remove(self.network, 1)
            if message ~= nil then
                for ____, client in ipairs(self.clients) do
                    client:deliverSync(message)
                end
            end
            delivered = delivered + 1
        end
    end
end
function Lockstep.prototype.frames(self, count)
    do
        local frame = 0
        while frame < count do
            self.frame = self.frame + 1
            for ____, client in ipairs(self.clients) do
                client:step()
            end
            self:flush()
            frame = frame + 1
        end
    end
end
function Lockstep.prototype.chat(self, sender, message)
    for ____, client in ipairs(self.clients) do
        client:chat(sender, message)
    end
    self:flush()
end
function Lockstep.prototype.press(self, sender, key, meta)
    if meta == nil then
        meta = 0
    end
    for ____, down in ipairs({true, false}) do
        for ____, client in ipairs(self.clients) do
            client:key(sender, key, meta, down)
        end
        self:flush()
    end
end
function Lockstep.prototype.publish(self, name, chunks)
    for ____, client in ipairs(self.clients) do
        client.published:set(name, chunks)
    end
end
function Lockstep.prototype.reload(self)
    local text = self.options.bundle
    local prefix = self.options.filePrefix
    local sum = checksum(
        #text,
        function(index) return __TS__StringCharCodeAt(text, index) end
    )
    local files = math.max(1, (#text + PAYLOAD_FILE_BYTES - 1) // PAYLOAD_FILE_BYTES)
    do
        local index = 0
        while index < files do
            self:publish(
                payloadFile(sum, index, prefix),
                {__TS__StringSlice(text, index * PAYLOAD_FILE_BYTES, (index + 1) * PAYLOAD_FILE_BYTES)}
            )
            index = index + 1
        end
    end
    self.version = self.version + 1
    self:publish(
        manifestFile(self.version, prefix),
        {formatManifest({version = self.version, files = files, checksum = sum})}
    )
    return self.version
end
function Lockstep.prototype.unappliedReloads(self)
    if self.version == 0 then
        return {}
    end
    local problems = {}
    for ____, client in ipairs(self.clients) do
        do
            local ____opt_0 = client.files:get(ackFile(client.slot, self.options.filePrefix))
            local acknowledgement = ____opt_0 and ____opt_0[1] or ""
            if __TS__StringStartsWith(
                acknowledgement,
                ("applied " .. tostring(self.version)) .. " at "
            ) then
                goto __continue41
            end
            local reason = "no answer yet"
            for ____, message in ipairs(client.messages) do
                if __TS__StringStartsWith(
                    message,
                    ("hot reload " .. tostring(self.version)) .. " not applied"
                ) then
                    reason = message
                end
            end
            problems[#problems + 1] = (((("p" .. tostring(client.slot)) .. ": hot reload ") .. tostring(self.version)) .. " not running: ") .. reason
        end
        ::__continue41::
    end
    return problems
end
function Lockstep.prototype.firstDivergence(self)
    local first = self.clients[1]
    if first == nil then
        return nil
    end
    do
        local other = 1
        while other < #self.clients do
            do
                local client = self.clients[other + 1]
                if client == nil then
                    goto __continue50
                end
                local length = math.max(#first.log, #client.log)
                do
                    local index = 0
                    while index < length do
                        do
                            local left = first.log[index + 1]
                            local right = client.log[index + 1]
                            if left ~= nil and right ~= nil and sameCall(left, right) then
                                goto __continue53
                            end
                            local function context(log)
                                local lines = {}
                                do
                                    local at = math.max(0, index - 4)
                                    while at < math.min(#log, index + 2) do
                                        local call = log[at + 1]
                                        if call ~= nil then
                                            lines[#lines + 1] = describeCall(call)
                                        end
                                        at = at + 1
                                    end
                                end
                                return table.concat(lines, "\n    ")
                            end
                            return (((((((((((("call " .. tostring(index)) .. " differs between slot ") .. tostring(first.slot)) .. " and slot ") .. tostring(client.slot)) .. ":\n  slot ") .. tostring(first.slot)) .. ":\n    ") .. context(first.log)) .. "\n  slot ") .. tostring(client.slot)) .. ":\n    ") .. context(client.log)
                        end
                        ::__continue53::
                        index = index + 1
                    end
                end
            end
            ::__continue50::
            other = other + 1
        end
    end
    return nil
end
return ____exports
