local ____lualib = require("lualib_bundle")
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local errorFile = ____gameFiles.errorFile
local errorHeading = ____gameFiles.errorHeading
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
--- Preload lines longer than this are cut so the file stays readable.
local MAX_LINE = 240
--- Lua runtime errors are strings that start with their position; thrown Errors are tables.
local function describe(____error)
    if type(____error) == "string" then
        return ____error
    end
    if type(____error) == "table" and ____error ~= nil and ____error.message ~= nil then
        local name = ____error.name ~= nil and tostring(____error.name) or "Error"
        return (name .. ": ") .. tostring(____error.message)
    end
    return tostring(____error)
end
--- The call stack at the error, when the game provides the debug library.
function ____exports.traceback()
    return type(debug) == "table" and debug.traceback(nil, 3) or ""
end
function ____exports.reportError(handler, ____error, stack)
    local configuration = runtimeConfiguration()
    local globals = _G
    local ____globals_0, ____temp_1 = globals, configuration.globalPrefix .. "Errors"
    if ____globals_0[____temp_1] == nil then
        ____globals_0[____temp_1] = {last = nil, count = 0}
    end
    local state = globals[configuration.globalPrefix .. "Errors"]
    local message = describe(____error)
    if message == state.last then
        return
    end
    state.last = message
    state.count = state.count + 1
    DisplayTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        (("error in " .. handler) .. ": ") .. message
    )
    PreloadGenClear()
    PreloadGenStart()
    Preload(errorHeading(state.count, handler))
    for ____, line in ipairs({
        message,
        table.unpack(__TS__StringSplit(stack, "\n"))
    }) do
        if line ~= "" then
            Preload(__TS__StringSlice(line, 0, MAX_LINE))
        end
    end
    PreloadGenEnd(errorFile(
        GetPlayerId(GetLocalPlayer()),
        configuration.filePrefix
    ))
end
return ____exports
