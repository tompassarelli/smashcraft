/** @noSelfInFile */
/** The call stack at the error, when the game provides the debug library. */
export declare function traceback(): string;
export declare function reportError(handler: string, error: unknown, stack: string): void;
