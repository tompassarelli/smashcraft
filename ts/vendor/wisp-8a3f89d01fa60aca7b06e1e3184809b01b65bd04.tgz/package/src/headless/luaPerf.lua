local ____lualib = require("lualib_bundle")
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____declarations = require("src.headless.declarations")
local parseNativeDeclarations = ____declarations.parseNativeDeclarations
local ____journey = require("src.headless.journey")
local journeyLines = ____journey.journeyLines
local journeyProblems = ____journey.journeyProblems
local runJourney = ____journey.runJourney
local ____lua = require("src.headless.lua")
local luaLockstep = ____lua.luaLockstep
local readFile = ____lua.readFile
local ____nativeCost = require("src.headless.nativeCost")
local WARCRAFT_COST = ____nativeCost.WARCRAFT_COST
local nativeFrameCost = ____nativeCost.nativeFrameCost
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local floorMod = ____intMath.floorMod
--- Instructions between the hook's counts: each run of a client counts its instructions rounded down to a multiple of this.
____exports.HOOK_STEP = 100
--- Kilobytes the heap may grow by between full collections, outside the measured runs.
local COLLECT_EVERY_KB = 16384
local serve
--- Runs the native it is resumed with on the arguments after it, yields the
-- result and serves the next call it is resumed with; tail calls keep it one
-- frame deep. Varargs pass every argument, nil ones included.
serve = function(...)
    local native = select(1, ...)
    return serve(coroutine.yield(native(select(2, ...))))
end
local function nativeThread()
    return coroutine.create(function(...)
        debug.sethook()
        return serve(...)
    end)
end
local function add(values, index, amount)
    values[index + 1] = (values[index + 1] or 0) + amount
end
--- A value to the nearest whole number: binary32 has too few digits for a frame's hundredths of a million instructions.
local function whole(value)
    return tostring(math.floor(value + 0x1p-1))
end
--- The value at a share of the sorted values, nearest rank.
local function rank(sorted, share)
    if #sorted == 0 then
        return 0
    end
    local index = math.max(
        0,
        math.min(
            #sorted - 1,
            math.ceil(share * #sorted) - 1
        )
    )
    return sorted[index + 1] or 0
end
local function valueLine(slot, name, values, first, last)
    local perFrame = {}
    local total = 0
    do
        local frame = first
        while frame <= last do
            local value = values[frame + 1] or 0
            perFrame[#perFrame + 1] = value
            total = total + value
            frame = frame + 1
        end
    end
    __TS__ArraySort(
        perFrame,
        function(____, left, right) return left - right end
    )
    local middle = #perFrame // 2
    local median = #perFrame == 0 and 0 or (#perFrame % 2 == 1 and (perFrame[middle + 1] or 0) or ((perFrame[middle] or 0) + (perFrame[middle + 1] or 0)) / 2)
    local mean = #perFrame == 0 and 0 or total / #perFrame
    return (((((((((((((("p" .. tostring(slot)) .. " ") .. name) .. " start=") .. whole(values[1] or 0)) .. " total=") .. whole(total)) .. " median=") .. whole(median)) .. " p95=") .. whole(rank(perFrame, 0xf33333p-24))) .. " mean=") .. whole(mean)) .. " max=") .. whole(rank(perFrame, 1))
end
local function costLines(cost, first, last, model)
    local callbacks = {}
    local typing = {}
    do
        local frame = 0
        while frame <= last do
            local predicted = nativeFrameCost(model, {instructions = cost.instructions[frame + 1] or 0, natives = cost.natives[frame + 1] or 0, allocatedKb = cost.allocatedKb[frame + 1] or 0, typedCharacters = cost.typed[frame + 1] or 0})
            callbacks[#callbacks + 1] = predicted.callbacksUs
            typing[#typing + 1] = predicted.typingUs
            frame = frame + 1
        end
    end
    local named = {
        {"instructions", cost.instructions},
        {"lua-us", cost.microseconds},
        {"natives", cost.natives},
        {"alloc-kb", cost.allocatedKb},
        {"typed", cost.typed},
        {"native-us", callbacks},
        {"typing-us", typing}
    }
    return __TS__ArrayMap(
        named,
        function(____, ____bindingPattern0)
            local values
            local name
            name = ____bindingPattern0[1]
            values = ____bindingPattern0[2]
            return valueLine(
                cost.slot,
                name,
                values,
                first,
                last
            )
        end
    )
end
--- Measures every client's frames while `play` drives the clients of the
-- bundle and declarations at these paths, prints the result as `wisp perf`
-- reads it and returns how many problems `play` found.
function ____exports.runLuaPerfWith(map, bundlePath, declarationsPath, play, options)
    if options == nil then
        options = {}
    end
    local declarations = readFile(declarationsPath)
    local costs = __TS__New(Map)
    local bySlot = __TS__New(Map)
    local fired = 0
    local function count()
        fired = fired + 1
    end
    local nativeSeconds = 0
    local depth = 0
    local thread = nativeThread()
    local entered = {
        fired = 0,
        seconds = 0,
        natives = 0,
        calls = 0,
        kb = 0,
        nativeKb = 0
    }
    local collectedKb = collectgarbage("count")
    --- The full collections between runs: their time and the kilobytes they freed.
    local collector = {us = 0, kb = 0}
    local clients
    local scope = {
        enter = function(client)
            local heap = collectgarbage("count")
            if heap > collectedKb + COLLECT_EVERY_KB then
                local started = os.clock()
                collectgarbage("collect")
                collectedKb = collectgarbage("count")
                collector.us = collector.us + (os.clock() - started) * 1000000
                collector.kb = collector.kb + (heap - collectedKb)
            end
            collectgarbage("stop")
            local cost = costs:get(client)
            debug.sethook(count, "", ____exports.HOOK_STEP)
            entered = {
                fired = fired,
                seconds = os.clock(),
                natives = nativeSeconds,
                calls = cost and cost.calls or 0,
                kb = collectgarbage("count"),
                nativeKb = cost and cost.nativeKb or 0
            }
        end,
        leave = function(client)
            local seconds = os.clock()
            debug.sethook()
            local kb = collectgarbage("count")
            collectgarbage("restart")
            local cost = costs:get(client)
            if cost == nil then
                return
            end
            local frame = clients and clients.frame or 0
            add(cost.instructions, frame, (fired - entered.fired) * ____exports.HOOK_STEP)
            add(cost.microseconds, frame, (seconds - entered.seconds - (nativeSeconds - entered.natives)) * 1000000)
            add(cost.natives, frame, cost.calls - entered.calls)
            add(cost.allocatedKb, frame, kb - entered.kb - (cost.nativeKb - entered.nativeKb))
        end
    }
    local function counted(cost, native)
        return function(...)
            cost.calls = cost.calls + 1
            if depth > 0 then
                return native(...)
            end
            depth = depth + 1
            local started = os.clock()
            local kb = collectgarbage("count")
            local ran, result = coroutine.resume(thread, native, ...)
            cost.nativeKb = cost.nativeKb + (collectgarbage("count") - kb)
            nativeSeconds = nativeSeconds + (os.clock() - started)
            depth = depth - 1
            if not ran then
                thread = nativeThread()
                error(result, 0)
            end
            return result
        end
    end
    local lockstep = luaLockstep(
        map,
        readFile(bundlePath),
        declarations,
        scope,
        options.delivery
    )
    clients = lockstep
    local names = __TS__ArrayMap(
        parseNativeDeclarations(declarations).functions,
        function(____, ____bindingPattern0)
            local name
            name = ____bindingPattern0[1]
            return name
        end
    )
    for ____, client in ipairs(lockstep.clients) do
        local cost = {
            slot = client.slot,
            instructions = {},
            microseconds = {},
            natives = {},
            allocatedKb = {},
            typed = {},
            calls = 0,
            nativeKb = 0
        }
        costs:set(client, cost)
        bySlot:set(client.slot, cost)
        for ____, name in ipairs(names) do
            local native = client.natives[name]
            if type(native) == "function" then
                client.natives[name] = counted(cost, native)
            end
        end
    end
    --- The first frame the summaries count.
    local first = 1
    local measure = {
        begin = function()
            first = lockstep.frame + 1
        end,
        typed = function(slot, characters)
            local cost = bySlot:get(slot)
            if cost ~= nil then
                add(cost.typed, lockstep.frame + 1, characters)
            end
        end
    }
    local result
    do
        local ____try, ____error = pcall(function()
            result = play(lockstep, measure)
        end)
        do
            debug.sethook()
            collectgarbage("restart")
        end
        if not ____try then
            error(____error, 0)
        end
    end
    print((((("frames " .. tostring(lockstep.frame - first + 1)) .. " step ") .. tostring(____exports.HOOK_STEP)) .. " problems ") .. tostring(result.problems))
    print((("collector us=" .. whole(collector.us)) .. " kb=") .. whole(collector.kb))
    local model = options.model or WARCRAFT_COST
    for ____, cost in __TS__Iterator(costs:values()) do
        for ____, line in ipairs(costLines(cost, first, lockstep.frame, model)) do
            print(line)
        end
    end
    if options.samples == true then
        do
            local frame = first
            while frame <= lockstep.frame do
                for ____, cost in __TS__Iterator(costs:values()) do
                    print((((((((((((("frame " .. tostring(frame)) .. " p") .. tostring(cost.slot)) .. " instructions=") .. tostring(cost.instructions[frame + 1] or 0)) .. " lua-us=") .. whole(cost.microseconds[frame + 1] or 0)) .. " natives=") .. tostring(cost.natives[frame + 1] or 0)) .. " alloc-bytes=") .. whole((cost.allocatedKb[frame + 1] or 0) * 1024)) .. " typed=") .. tostring(cost.typed[frame + 1] or 0))
                end
                frame = frame + 1
            end
        end
    end
    if result.problems > 0 then
        for ____, line in ipairs(result.lines) do
            print("journey: " .. line)
        end
    end
    return result.problems
end
--- Plays `journey` with the bundle and declarations at these paths, measuring
-- every client's frames, prints the result as `wisp perf` reads it and
-- returns how many problems the journey found.
function ____exports.runLuaPerf(map, journey, bundlePath, declarationsPath, options)
    if options == nil then
        options = {}
    end
    return ____exports.runLuaPerfWith(
        map,
        bundlePath,
        declarationsPath,
        function(clients)
            local result = runJourney(clients, journey, {checksums = false})
            return {
                problems = journeyProblems(result),
                lines = journeyLines(result)
            }
        end,
        options
    )
end
return ____exports
