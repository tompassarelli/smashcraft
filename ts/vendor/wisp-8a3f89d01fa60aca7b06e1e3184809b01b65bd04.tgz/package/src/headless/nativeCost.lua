local ____exports = {}
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
function ____exports.nativeFrameCost(model, work)
    local luaUs = model.luaFactor * model.hostUsPerThousandInstructions * work.instructions / 1000
    return {callbacksUs = luaUs + model.nativeCallUs * work.natives + model.collectorUsPerKb * work.allocatedKb, typingUs = model.typingUsPerCharacterSquared * work.typedCharacters * work.typedCharacters}
end
--- Warcraft III as measured (wisp:docs/frame-cost.md#predicted-native-cost):
-- Warcraft's Lua 1.17 times slower than the development host's 32-bit Lua on
-- Smashcraft's 4096-frame workload; that host's instruction rate on
-- Smashcraft's four-fighter bot match; native calls and the collector fitted
-- to the 0.0.49 four-fighter overlay; typing 0.00003 frames per character
-- squared, from 608 characters holding a client 180 ms.
____exports.WARCRAFT_COST = {
    hostUsPerThousandInstructions = 0x48cccdp-18,
    luaFactor = 0x95c28fp-23,
    nativeCallUs = 2,
    collectorUsPerKb = 2,
    typingUsPerCharacterSquared = 0x1p-1
}
return ____exports
