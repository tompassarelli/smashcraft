local ____lualib = require("lualib_bundle")
local __TS__ArrayReduce = ____lualib.__TS__ArrayReduce
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local Map = ____lualib.Map
local ____exports = {}
local ____random = require("src.headless.random")
local Random = ____random.Random
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
--- Battle.net as Smashcraft's #26 runs r7 and r8 measured it on 5 October
-- 2026: two clients on one host, 765 own-echo samples from the unsaturated
-- first seconds of each match.
____exports.MEASURED_BATTLE_NET = {latencyMs = 80, turnMs = 25, extraTurns = {
    0xcccccdp-25,
    0xf5c28fp-26,
    0x24dd2fp-24,
    0x2c3c9fp-25,
    0x6a2b17p-27,
    0xfecdd1p-29,
    0x263879p-27,
    0x16eeafp-27,
    0x44cc0dp-28
}}
--- Game milliseconds between a client's timer callbacks.
____exports.CALLBACK_MS = 1000 / 60
--- The game milliseconds from a send during `frame`'s callback until every client receives it.
function ____exports.syncAgeMs(latency, frame, extraTurns)
    local sentMs = frame * ____exports.CALLBACK_MS
    local turn = math.ceil((sentMs + latency.latencyMs) / latency.turnMs - 0x89705fp-53) + extraTurns
    return turn * latency.turnMs - sentMs
end
--- Further turns for one draw in (0, 1).
local function turnsFor(probabilities, draw)
    local rest = draw
    do
        local turns = 0
        while turns < #probabilities - 1 do
            rest = rest - (probabilities[turns + 1] or 0)
            if rest <= 0 then
                return turns
            end
            turns = turns + 1
        end
    end
    return #probabilities - 1
end
--- Lockstep delivery with the measured latency: a message sent during frame F
-- reaches every client before the callbacks of the first frame at or after
-- its arrival. Seeded, so a run repeats exactly.
function ____exports.syncDelivery(latency, seed)
    if latency == nil then
        latency = ____exports.MEASURED_BATTLE_NET
    end
    if seed == nil then
        seed = 1
    end
    local total = __TS__ArrayReduce(
        latency.extraTurns,
        function(____, sum, p) return sum + p end,
        0
    )
    if math.abs(total - 1) > 0x8637bdp-43 then
        do
            local ____thrown = __TS__New(
                Error,
                ("extra-turn probabilities sum to " .. tostring(total)) .. ", not 1"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:61"
            end
            error(____thrown, 0)
        end
    end
    if not (latency.turnMs > 0) or not (latency.latencyMs >= 0) then
        do
            local ____thrown = __TS__New(Error, "turn length must be positive and latency not negative")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:62"
            end
            error(____thrown, 0)
        end
    end
    local senders = __TS__New(Map)
    return {arrivalFrame = function(sender, frame, _message)
        local state = senders:get(sender)
        if state == nil then
            state = {
                random = __TS__New(Random, seed * 7919 + sender * 104729 + 1),
                lastArrivalMs = 0
            }
            senders:set(sender, state)
        end
        local arrivalMs = math.max(
            state.lastArrivalMs,
            frame * ____exports.CALLBACK_MS + ____exports.syncAgeMs(
                latency,
                frame,
                turnsFor(
                    latency.extraTurns,
                    state.random:next()
                )
            )
        )
        state.lastArrivalMs = arrivalMs
        return math.max(
            frame + 1,
            math.ceil(arrivalMs / ____exports.CALLBACK_MS - 0x89705fp-53)
        )
    end}
end
return ____exports
