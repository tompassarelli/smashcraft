local ____lualib = require("lualib_bundle")
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__Number = ____lualib.__TS__Number
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local ____exports = {}
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
local EQUIPMENT_NAMES = {
    "NONE",
    "HEAD",
    "CHEST",
    "GLOVES",
    "BOOTS",
    "RING",
    "PRIMARY",
    "OFFHAND",
    "TRINKET",
    "ANY"
}
local TAG_NAMES = {
    "UNDEFINED",
    "DROPPABLE",
    "QUESTREWARD",
    "BOSSDROP",
    "SECRET",
    "PUZZLE",
    "WORLD",
    "SHOP",
    "ANY"
}
local SLOT_NAMES = {
    "HEAD",
    "CHEST",
    "GLOVES",
    "BOOTS",
    "RING",
    "RINGALT",
    "PRIMARY",
    "OFFHAND",
    "TRINKET"
}
local ITEM_NAMES = {
    "PERMANENT",
    "CHARGED",
    "POWERUP",
    "ARTIFACT",
    "PURCHASABLE",
    "CAMPAIGN",
    "MISCELLANEOUS",
    "EQUIPMENT",
    "UNKNOWN",
    "ANY"
}
local function enumIndex(value, prefix, names)
    if type(value) == "number" then
        return value
    end
    local index = __TS__ArrayIndexOf(
        names,
        __TS__StringSlice(value, #prefix)
    )
    if not __TS__StringStartsWith(value, prefix) or index < 0 then
        do
            local ____thrown = __TS__New(Error, "unsupported inventory constant " .. value)
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:70"
            end
            error(____thrown, 0)
        end
    end
    return index
end
____exports.Warcraft3Inventory = __TS__Class()
local Warcraft3Inventory = ____exports.Warcraft3Inventory
Warcraft3Inventory.name = "Warcraft3Inventory"
function Warcraft3Inventory.prototype.____constructor(self, context, fixtures)
    if fixtures == nil then
        fixtures = {}
    end
    self.context = context
    self.fixtures = fixtures
    self.items = __TS__New(Map)
    self.units = __TS__New(Map)
    self.playerRaceSkins = __TS__New(Map)
end
function Warcraft3Inventory.prototype.withInventoryEvent(self, unit, item, kind, callback)
    local previous = self.event
    self.event = {unit = unit, item = item, kind = kind}
    do
        local ____try, ____hasReturned, ____returnValue = pcall(function()
            return true, callback()
        end)
        do
            self.event = previous
        end
        if not ____try then
            error(____hasReturned, 0)
        end
        if ____try and ____hasReturned then
            return ____returnValue
        end
    end
end
function Warcraft3Inventory.prototype.unitFixture(self, unit)
    local typeId = self.context.getUnitTypeId(unit)
    local ____opt_0 = self.fixtures.units
    local fixture = ____opt_0 and ____opt_0[typeId]
    if fixture == nil then
        do
            local ____thrown = __TS__New(
                Error,
                "inventory fixture missing for unit type " .. tostring(typeId)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:91"
            end
            error(____thrown, 0)
        end
    end
    return fixture
end
function Warcraft3Inventory.prototype.item(self, handle)
    local item = self.items:get(handle)
    if item == nil then
        do
            local ____thrown = __TS__New(
                Error,
                "inventory item missing: " .. tostring(handle.id)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:97"
            end
            error(____thrown, 0)
        end
    end
    return item
end
function Warcraft3Inventory.prototype.itemFixture(self, handle)
    local typeId = self:item(handle).typeId
    local ____opt_2 = self.fixtures.items
    local fixture = ____opt_2 and ____opt_2[typeId]
    if fixture == nil then
        do
            local ____thrown = __TS__New(
                Error,
                "inventory fixture missing for item type " .. tostring(typeId)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:104"
            end
            error(____thrown, 0)
        end
    end
    return fixture
end
function Warcraft3Inventory.prototype.unit(self, unit)
    local existing = self.units:get(unit)
    if existing ~= nil then
        return existing
    end
    local ____opt_4 = self.fixtures.units
    local fixture = ____opt_4 and ____opt_4[self.context.getUnitTypeId(unit)]
    local talents = __TS__New(Map)
    for ____, key in ipairs(__TS__ObjectKeys(fixture and fixture.talents or ({}))) do
        local ____talents_set_10 = talents.set
        local ____opt_6 = fixture and fixture.talents
        ____talents_set_10(talents, key, ____opt_6 and ____opt_6[key] or 0)
    end
    local state = {
        bag = __TS__New(Map),
        equipment = __TS__New(Map),
        talents = talents,
        heroGlowAllowed = fixture and fixture.heroGlowAllowed
    }
    self.units:set(unit, state)
    return state
end
function Warcraft3Inventory.prototype.detach(self, item)
    if item.holder ~= nil then
        local state = self:unit(item.holder)
        for ____, ____value in __TS__Iterator(state.bag) do
            local slot = ____value[1]
            local handle = ____value[2]
            if handle == item.handle then
                state.bag:delete(slot)
            end
        end
        for ____, ____value in __TS__Iterator(state.equipment) do
            local slot = ____value[1]
            local handle = ____value[2]
            if handle == item.handle then
                state.equipment:delete(slot)
            end
        end
    end
    item.holder = nil
    item.equipped = false
end
function Warcraft3Inventory.prototype.bagSlot(self, unit)
    local state = self:unit(unit)
    local size = self:unitFixture(unit).bagSize
    do
        local slot = 0
        while slot < size do
            if not state.bag:has(slot) then
                return slot
            end
            slot = slot + 1
        end
    end
    return nil
end
function Warcraft3Inventory.prototype.addItem(self, unit, handle)
    local item = self:item(handle)
    if item.removed then
        return false
    end
    if item.holder == unit and not item.equipped then
        return true
    end
    local slot = self:bagSlot(unit)
    if slot == nil then
        return false
    end
    self:detach(item)
    self:unit(unit).bag:set(slot, handle)
    item.holder = unit
    return true
end
function Warcraft3Inventory.prototype.equip(self, unit, handle)
    local item = self:item(handle)
    if item.removed then
        return false
    end
    if item.holder == unit and item.equipped then
        return true
    end
    local slots = self:unitFixture(unit).loadout[self:itemFixture(handle).equipmentType] or ({})
    local state = self:unit(unit)
    for ____, slot in ipairs(slots) do
        do
            if state.equipment:has(slot) then
                goto __continue38
            end
            self:detach(item)
            state.equipment:set(slot, handle)
            item.holder = unit
            item.equipped = true
            self:withInventoryEvent(
                unit,
                handle,
                "equip",
                function()
                    local ____opt_15 = self.context.inventoryEvent
                    return ____opt_15 and ____opt_15(unit, handle, "equip")
                end
            )
            return true
        end
        ::__continue38::
    end
    return false
end
function Warcraft3Inventory.prototype.unequip(self, unit, handle)
    local item = self:item(handle)
    if item.holder ~= unit or not item.equipped then
        return
    end
    local slot = self:bagSlot(unit)
    self:detach(item)
    if slot ~= nil then
        self:unit(unit).bag:set(slot, handle)
        item.holder = unit
    end
    self:withInventoryEvent(
        unit,
        handle,
        "unequip",
        function()
            local ____opt_17 = self.context.inventoryEvent
            return ____opt_17 and ____opt_17(unit, handle, "unequip")
        end
    )
end
function Warcraft3Inventory.prototype.randomItem(self, ____type, level, equipment, tag, invalid, nonRandom)
    local itemType = enumIndex(____type, "ITEM_TYPE_", ITEM_NAMES)
    local equipmentType = enumIndex(equipment, "EQUIPMENT_TYPE_", EQUIPMENT_NAMES)
    local itemTag = enumIndex(tag, "ITEMTAG_TYPE_", TAG_NAMES)
    if self.fixtures.items == nil then
        do
            local ____thrown = __TS__New(Error, "random item selection requires item fixtures")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:182"
            end
            error(____thrown, 0)
        end
    end
    local candidates = {}
    for ____, key in ipairs(__TS__ObjectKeys(self.fixtures.items)) do
        do
            local id = __TS__Number(key)
            local item = self.fixtures.items[id]
            if item == nil or itemType ~= 9 and item.itemType ~= itemType or item.level ~= level or equipmentType ~= 9 and item.equipmentType ~= equipmentType or itemTag ~= 8 and item.tag ~= itemTag or not invalid and not item.validMorph or not nonRandom and not item.pickRandom then
                goto __continue48
            end
            candidates[#candidates + 1] = id
        end
        ::__continue48::
    end
    __TS__ArraySort(
        candidates,
        function(____, a, b) return a - b end
    )
    if #candidates == 0 then
        return 0
    end
    if self.fixtures.chooseRandom == nil then
        do
            local ____thrown = __TS__New(Error, "random item selection requires a synchronized chooseRandom fixture")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:192"
            end
            error(____thrown, 0)
        end
    end
    local result = self.fixtures.chooseRandom(candidates)
    if not __TS__ArrayIncludes(candidates, result) then
        do
            local ____thrown = __TS__New(
                Error,
                "random item fixture selected excluded type " .. tostring(result)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:194"
            end
            error(____thrown, 0)
        end
    end
    return result
end
function Warcraft3Inventory.prototype.behaviors(self)
    return {
        CreateItem = function(typeId, x, y)
            local handle = self.context.handle("item")
            self.items:set(handle, {
                handle = handle,
                typeId = typeId,
                x = x,
                y = y,
                color = nil,
                holder = nil,
                equipped = false,
                removed = false
            })
            return handle
        end,
        RemoveItem = function(handle)
            local item = self:item(handle)
            self:detach(item)
            item.removed = true
        end,
        GetItemTypeId = function(handle)
            local item = self:item(handle)
            return item.removed and 0 or item.typeId
        end,
        GetItemX = function(handle) return self:item(handle).x end,
        GetItemY = function(handle) return self:item(handle).y end,
        SetItemPosition = function(handle, x, y)
            local item = self:item(handle)
            item.x = x
            item.y = y
        end,
        UnitAddItem = function(unit, item) return self:addItem(unit, item) end,
        UnitRemoveItem = function(unit, handle)
            local item = self:item(handle)
            if item.holder == unit then
                self:detach(item)
            end
        end,
        UnitRemoveItemFromSlot = function(unit, slot)
            local item = self:unit(unit).bag:get(slot)
            if item ~= nil then
                self:detach(self:item(item))
            end
            return item
        end,
        UnitHasItem = function(unit, handle) return self:item(handle).holder == unit end,
        UnitItemInSlot = function(unit, slot) return self:unit(unit).bag:get(slot) end,
        UnitInventorySize = function(unit) return self:unitFixture(unit).inventorySize end,
        BlzGetEquippedItem = function()
            local ____opt_19 = self.event
            return (____opt_19 and ____opt_19.kind) == "equip" and self.event.item or nil
        end,
        BlzGetUnequippedItem = function()
            local ____opt_21 = self.event
            return (____opt_21 and ____opt_21.kind) == "unequip" and self.event.item or nil
        end,
        BlzSetItemColor = function(handle, color)
            self:item(handle).color = color
        end,
        BlzIsItemEquipped = function(handle) return self:item(handle).equipped end,
        BlzIsItemInBag = function(handle)
            local item = self:item(handle)
            return item.holder ~= nil and not item.equipped
        end,
        BlzGetItemEquipmentType = function(handle) return self:itemFixture(handle).equipmentType end,
        BlzGetItemTag = function(handle) return self:itemFixture(handle).tag end,
        BlzUnitEquipItem = function(unit, handle) return self:equip(unit, handle) end,
        BlzUnitUnequipItem = function(unit, handle) return self:unequip(unit, handle) end,
        BlzUnitUnequipItemFromSlot = function(unit, slot)
            local item = self:unit(unit).equipment:get(enumIndex(slot, "EQUIPMENT_LOADOUT_SLOT_", SLOT_NAMES))
            if item ~= nil then
                self:unequip(unit, item)
            end
            return item
        end,
        BlzUnitHasItemBagged = function(unit, handle)
            local item = self:item(handle)
            return item.holder == unit and not item.equipped
        end,
        BlzUnitExtendedInventorySize = function(unit) return self:unitFixture(unit).extendedInventorySize end,
        BlzUnitItemInBagSlot = function(unit, slot) return self:unit(unit).bag:get(slot) end,
        BlzUnitItemInEquipmentSlot = function(unit, slot) return self:unit(unit).equipment:get(enumIndex(slot, "EQUIPMENT_LOADOUT_SLOT_", SLOT_NAMES)) end,
        BlzUnitHasItemEquipped = function(unit, handle)
            local item = self:item(handle)
            return item.holder == unit and item.equipped
        end,
        BlzUnitHasLoadoutSlotEmpty = function(unit, slot) return not self:unit(unit).equipment:has(enumIndex(slot, "EQUIPMENT_LOADOUT_SLOT_", SLOT_NAMES)) end,
        BlzUnitHasAnyItemEquipped = function(unit) return self:unit(unit).equipment.size > 0 end,
        BlzUnitHasItemEquipmentOfType = function(unit, equipment)
            local ____type = enumIndex(equipment, "EQUIPMENT_TYPE_", EQUIPMENT_NAMES)
            for ____, item in __TS__Iterator(self:unit(unit).equipment:values()) do
                if self:itemFixture(item).equipmentType == ____type then
                    return true
                end
            end
            return false
        end,
        BlzUnitCanEquipItemOfEquipmentType = function(unit, equipment) return #(self:unitFixture(unit).loadout[enumIndex(equipment, "EQUIPMENT_TYPE_", EQUIPMENT_NAMES)] or ({})) > 0 end,
        ChooseRandomItemExWithFilter = function(____type, level, equipment, tag) return self:randomItem(
            ____type,
            level,
            equipment,
            tag,
            false,
            false
        ) end,
        ChooseRandomItemExWithFilterAndIncludes = function(____type, level, equipment, tag, invalid, nonRandom) return self:randomItem(
            ____type,
            level,
            equipment,
            tag,
            invalid,
            nonRandom
        ) end,
        SetPlayerRaceSkin = function(player, preference)
            self.playerRaceSkins:set(player, preference)
        end,
        AllowHeroGlowOnUnit = function(unit)
            self:unit(unit).heroGlowAllowed = true
        end,
        DisallowHeroGlowOnUnit = function(unit)
            self:unit(unit).heroGlowAllowed = false
        end,
        HeroGlowIsAllowedOnUnit = function(unit)
            local allowed = self:unit(unit).heroGlowAllowed
            if allowed == nil then
                do
                    local ____thrown = __TS__New(Error, "hero glow initial value requires a unit fixture")
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:250"
                    end
                    error(____thrown, 0)
                end
            end
            return allowed
        end,
        BlzGetUnitAnimationDuration = function(unit, animation)
            local ____opt_23 = self:unitFixture(unit).animations
            local duration = ____opt_23 and ____opt_23[animation]
            if duration == nil then
                do
                    local ____thrown = __TS__New(Error, "animation duration fixture missing for " .. animation)
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:255"
                    end
                    error(____thrown, 0)
                end
            end
            return duration
        end,
        BlzGetUnitAnimationDurationByIndex = function(unit, index)
            local ____opt_25 = self:unitFixture(unit).animationIndices
            local duration = ____opt_25 and ____opt_25[index]
            if duration == nil then
                do
                    local ____thrown = __TS__New(
                        Error,
                        "animation duration fixture missing for index " .. tostring(index)
                    )
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:260"
                    end
                    error(____thrown, 0)
                end
            end
            return duration
        end,
        BlzResetUnitTalents = function(unit)
            local initial = self:unitFixture(unit).talents
            if initial == nil then
                do
                    local ____thrown = __TS__New(Error, "talent reset requires a unit fixture")
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:265"
                    end
                    error(____thrown, 0)
                end
            end
            local talents = self:unit(unit).talents
            talents:clear()
            for ____, key in ipairs(__TS__ObjectKeys(initial)) do
                talents:set(key, initial[key] or 0)
            end
        end,
        BlzUnitHeal = function(unit, source, amount, isItem, applyStatBonuses)
            local life = self.context.readLife(unit)
            if life <= 0 or amount <= 0 then
                return 0
            end
            local multiplier = 1
            if applyStatBonuses then
                local fixture = self:unitFixture(source)
                local ____isItem_27
                if isItem then
                    ____isItem_27 = fixture.itemHealMultiplier
                else
                    ____isItem_27 = fixture.healMultiplier
                end
                local bonus = ____isItem_27
                if bonus == nil then
                    do
                        local ____thrown = __TS__New(Error, "healing stat bonuses require a source unit fixture")
                        if _G.__wispThrown ~= ____thrown then
                            _G.__wispThrown = ____thrown
                            _G.__wispThrowSite = "wisp/src/headless/warcraft3Inventory.ts:277"
                        end
                        error(____thrown, 0)
                    end
                end
                multiplier = bonus
            end
            local next = math.min(
                self.context.readMaxLife(unit),
                f32(
                    life,
                    f32(amount, multiplier, 3),
                    1
                )
            )
            self.context.writeLife(unit, next)
            return f32(
                self.context.readLife(unit),
                life,
                2
            )
        end
    }
end
return ____exports
