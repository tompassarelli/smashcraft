// Rounds a real result to binary32 (Math.fround on the host). Warcraft's Lua
// numbers are binary32, but its raw arithmetic doesn't round to nearest: a
// product can land an ulp toward zero, and a quotient an ulp away from the
// nearest (smashcraft's native camera, 7 October 2026). So the
// warcraft-numbers plugin compiles f32(a + b), f32(a - b), f32(a * b) and
// f32(a / b) to f32(a, b, F32_ADD/SUBTRACT/MULTIPLY/DIVIDE), which rounds the
// exact result to nearest with the binary32 helpers, and any other f32(x) to
// x, which is already binary32 there.
import { addFloat32, divideFloat32, multiplyFloat32, subtractFloat32 } from "./binary32";
import { floorDiv } from "./intMath";

// Module locals: Lua reads an exported constant from the module table on every use.
const ADD = 1;
const SUBTRACT = 2;
const MULTIPLY = 3;
const DIVIDE = 4;

/** The operation codes the compiler passes as f32's third argument; no source writes them. */
export const F32_ADD = ADD;
export const F32_SUBTRACT = SUBTRACT;
export const F32_MULTIPLY = MULTIPLY;
export const F32_DIVIDE = DIVIDE;

/** Integers up to 2^24 are binary32 values, so arithmetic that stays within it is exact under any rounding. */
const EXACT_INTEGERS = 16777216;
/** 2^-100: from there up, the difference of two values within a factor of two of each other is a normal number. */
const STERBENZ_FLOOR = 7.888609052210118e-31;

const cachedLeft: number[] = [];
const cachedRight: number[] = [];
const cachedOperation: number[] = [];
const cachedResult: number[] = [];
for (let i = 0; i < 8192; i++) {
  cachedLeft.push(0);
  cachedRight.push(0);
  cachedOperation.push(0);
  cachedResult.push(0);
}

function slowFloat32(left: number, right: number, operation: number): number {
  // Zero signs and nonfinite values bypass equality keys. The hash uses exact
  // power-of-two scaling and integer arithmetic below Warcraft's signed limit.
  let index = -1;
  if (left !== 0 && right !== 0 && left >= -32768 && left <= 32768 && right >= -32768 && right <= 32768) {
    index = (floorDiv(left * 256.0, 1) ^ (floorDiv(right * 256.0, 1) * 31) ^ (operation * 131)) & 8191;
    if (cachedLeft[index] === left && cachedRight[index] === right && cachedOperation[index] === operation) {
      return cachedResult[index] ?? 0;
    }
  }
  const result = operation === MULTIPLY ? multiplyFloat32(left, right)
    : operation === DIVIDE ? divideFloat32(left, right)
    : operation === SUBTRACT ? subtractFloat32(left, right) : addFloat32(left, right);
  if (index >= 0) {
    cachedLeft[index] = left;
    cachedRight[index] = right;
    cachedOperation[index] = operation;
    cachedResult[index] = result;
  }
  return result;
}

// Every synchronized f32 operation runs this. Results exact under any
// rounding take Lua's raw operator; the integer tests are inline, as
// floorDiv(x, 1) is Lua's x // 1, without a call.
export function f32(value: number, right?: number, operation?: number): number {
  if (right === undefined || operation === undefined) return Math.fround(value);
  if (operation === MULTIPLY) {
    // Zeros keep their IEEE signs; small integers keep Lua's integer type.
    if (value === 0 || right === 0) return value * right;
    if (value === floorDiv(value, 1) && right === floorDiv(right, 1) && value >= -4096 && value <= 4096 && right >= -4096 && right <= 4096) return value * right;
    // A product with ±1 is exact; * 1.0 keeps the float the helper would return.
    if (right === 1 || right === -1 || value === 1 || value === -1) return value * right * 1.0;
    return slowFloat32(value, right, operation);
  }
  if (operation === DIVIDE) {
    // A zero numerator keeps its IEEE sign; integers that divide evenly give an integer within 2^24. Both are exact under any rounding.
    if (value === 0 || right === 0) return value / right;
    if (value === floorDiv(value, 1) && right === floorDiv(right, 1) && value >= -EXACT_INTEGERS && value <= EXACT_INTEGERS) {
      const quotient = floorDiv(value, right);
      if (quotient * right === value) return quotient * 1.0;
    }
    return slowFloat32(value, right, operation);
  }
  if (value === 0 || right === 0) return operation === SUBTRACT ? value - right : value + right;
  if (value === floorDiv(value, 1) && right === floorDiv(right, 1) && value >= -EXACT_INTEGERS && value <= EXACT_INTEGERS && right >= -EXACT_INTEGERS && right <= EXACT_INTEGERS) {
    const sum = operation === SUBTRACT ? value - right : value + right;
    if (sum > -EXACT_INTEGERS && sum < EXACT_INTEGERS) return sum;
  }
  // Sterbenz: subtracting a same-signed value within a factor of two is exact.
  const subtrahend = operation === SUBTRACT ? right : -right;
  if (
    value > 0
      ? subtrahend > 0 && value >= STERBENZ_FLOOR && value < EXACT_INTEGERS && subtrahend <= value * 2.0 && value <= subtrahend * 2.0
      : subtrahend < 0 && value <= -STERBENZ_FLOOR && value > -EXACT_INTEGERS && subtrahend >= value * 2.0 && value >= subtrahend * 2.0
  ) {
    return operation === SUBTRACT ? value - right : value + right;
  }
  return slowFloat32(value, right, operation);
}
