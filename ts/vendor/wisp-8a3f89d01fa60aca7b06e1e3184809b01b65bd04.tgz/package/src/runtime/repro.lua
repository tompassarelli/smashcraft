local ____lualib = require("lualib_bundle")
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__ArraySlice = ____lualib.__TS__ArraySlice
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____testing = require("src.runtime.testing")
local AssertionFailure = ____testing.AssertionFailure
____exports.REPRO_HEADER = "wisp-repro 1"
--- Characters per game line; Wisp's error reports cut Preload lines at 240.
____exports.REPRO_LINE_WIDTH = 200
--- A new name for each repro a client saves, as Preloader runs the first content it read from a name for the rest of the session.
____exports.reproFile = function(slot, frame, serial, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((((((prefix .. "-repro-p") .. tostring(slot)) .. "-f") .. tostring(frame)) .. "-") .. tostring(serial)) .. ".txt"
end
--- The lines of a repro file: header, the game's lines, and their count.
function ____exports.reproLines(____bindingPattern0, lines)
    local checksum
    local frame
    local build
    build = ____bindingPattern0.build
    frame = ____bindingPattern0.frame
    checksum = ____bindingPattern0.checksum
    local ____array_0 = __TS__SparseArrayNew(
        ____exports.REPRO_HEADER,
        "build " .. build,
        "frame " .. tostring(frame),
        "checksum " .. checksum,
        table.unpack(lines)
    )
    __TS__SparseArrayPush(
        ____array_0,
        "end " .. tostring(#lines)
    )
    return {__TS__SparseArraySpread(____array_0)}
end
--- The text after `word ` on a line, or undefined.
local function after(line, word)
    if line == nil or not __TS__StringStartsWith(line, word .. " ") then
        return nil
    end
    local text = __TS__StringSubstring(line, #word + 1)
    local ____temp_1
    if #text == 0 or __TS__StringIncludes(text, " ") then
        ____temp_1 = nil
    else
        ____temp_1 = text
    end
    return ____temp_1
end
local function count(text)
    if text == nil or #text > 9 then
        return nil
    end
    local value = 0
    do
        local index = 0
        while index < #text do
            local digit = __TS__StringCharCodeAt(text, index) - 48
            if digit < 0 or digit > 9 then
                return nil
            end
            value = value * 10 + digit
            index = index + 1
        end
    end
    return value
end
--- A repro from its file's lines, or what is wrong with them.
function ____exports.parseRepro(lines)
    if lines[1] ~= ____exports.REPRO_HEADER then
        return ("not a repro: its first line isn't \"" .. ____exports.REPRO_HEADER) .. "\""
    end
    local build = after(lines[2], "build")
    local frame = count(after(lines[3], "frame"))
    local checksum = after(lines[4], "checksum")
    local ____end = count(after(lines[#lines], "end"))
    if build == nil or frame == nil or checksum == nil then
        return "the repro's header is incomplete"
    end
    if ____end == nil or ____end ~= #lines - 5 then
        return "the repro is cut short: its end line doesn't count its lines"
    end
    return {
        build = build,
        frame = frame,
        checksum = checksum,
        lines = __TS__ArraySlice(lines, 4, #lines - 1)
    }
end
--- The test `wisp repro FILE --test NAME` writes: replaying the repro's lines
-- reaches the checksum the game recorded, with no problem on the way.
function ____exports.assertReproLands(lines, replay)
    local repro = ____exports.parseRepro(lines)
    if type(repro) == "string" then
        do
            local ____thrown = __TS__New(AssertionFailure, repro)
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/runtime/repro.ts:95"
            end
            error(____thrown, 0)
        end
    end
    local result = replay(repro)
    if #result.problems > 0 then
        do
            local ____thrown = __TS__New(
                AssertionFailure,
                table.concat(result.problems, "; ")
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/runtime/repro.ts:97"
            end
            error(____thrown, 0)
        end
    end
    if result.checksum ~= repro.checksum then
        do
            local ____thrown = __TS__New(
                AssertionFailure,
                (((("frame " .. tostring(repro.frame)) .. ": the game recorded checksum ") .. repro.checksum) .. ", the replay reached ") .. result.checksum
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/runtime/repro.ts:98"
            end
            error(____thrown, 0)
        end
    end
end
return ____exports
