local ____lualib = require("lualib_bundle")
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__Number = ____lualib.__TS__Number
local __TS__Class = ____lualib.__TS__Class
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local NO_BASE = ____gameFiles.NO_BASE
local PAYLOAD_FILE_BYTES = ____gameFiles.PAYLOAD_FILE_BYTES
local deltaFile = ____gameFiles.deltaFile
local payloadFile = ____gameFiles.payloadFile
local ____payload = require("src.runtime.payload")
local checksum = ____payload.checksum
--- Around a module's code, as TypeScriptToLua's bundle has it, the chunk takes
-- the require to link against and returns the module's function. The head is
-- one line, as the bundle's table entry head is, so the code keeps its lines.
____exports.MODULE_HEAD = "local require = ... return function(...) \n"
____exports.MODULE_TAIL = " end\n"
____exports.moduleChunk = function(code) return (____exports.MODULE_HEAD .. code) .. ____exports.MODULE_TAIL end
--- The one module of a whole bundle, for a compile with no per-module output.
____exports.BUNDLE_MODULE = "bundle"
____exports.bundleModules = function(bundle) return {
    entry = ____exports.BUNDLE_MODULE,
    modules = {{
        name = ____exports.BUNDLE_MODULE,
        text = ____exports.moduleChunk(bundle)
    }}
} end
____exports.textChecksum = function(text) return checksum(
    #text,
    function(index) return __TS__StringCharCodeAt(text, index) end
) end
--- What a module's hash covers: its name too, so equal code under two names keeps two source maps.
____exports.moduleHashText = function(name, text) return (name .. "\n") .. text end
--- The entry's name, then a line per module: its hash and name. Its checksum is the state's.
function ____exports.moduleIndex(entry, hashes)
    local lines = {entry}
    for ____, ____value in ipairs(hashes) do
        local name = ____value[1]
        local hash = ____value[2]
        lines[#lines + 1] = (hash .. " ") .. name
    end
    return table.concat(lines, "\n") .. "\n"
end
--- The index, a blank line, a line per carried module (its byte length and name), a blank line, then their texts.
function ____exports.modulePayload(index, carried)
    local lines = {}
    local texts = {}
    for ____, module in ipairs(carried) do
        lines[#lines + 1] = ((tostring(#module.text) .. " ") .. module.name) .. "\n"
        texts[#texts + 1] = module.text
    end
    return (((index .. "\n") .. table.concat(lines, "")) .. "\n") .. table.concat(texts, "")
end
--- Splits `line` at its first space: the field, and the name after it.
local function field(line)
    local space = (string.find(line, " ", nil, true) or 0) - 1
    local ____temp_0
    if space <= 0 or space == #line - 1 then
        ____temp_0 = nil
    else
        ____temp_0 = {
            __TS__StringSlice(line, 0, space),
            __TS__StringSlice(line, space + 1)
        }
    end
    return ____temp_0
end
--- A payload's index and texts; undefined when it is cut short, too long or malformed.
function ____exports.parsePayload(text)
    local indexEnd = (string.find(text, "\n\n", nil, true) or 0) - 1
    if indexEnd < 0 then
        return nil
    end
    local index = __TS__StringSlice(text, 0, indexEnd + 1)
    local lines = __TS__StringSplit(
        __TS__StringSlice(text, 0, indexEnd),
        "\n"
    )
    local entry = lines[1]
    if entry == nil or entry == "" then
        return nil
    end
    local hashes = {}
    local indexed = {}
    do
        local at = 1
        while at < #lines do
            local parsed = field(lines[at + 1] or "")
            if parsed == nil then
                return nil
            end
            hashes[#hashes + 1] = {parsed[2], parsed[1]}
            indexed[parsed[2]] = true
            at = at + 1
        end
    end
    local carried = {}
    local at = indexEnd + 2
    while true do
        local ____end = (string.find(
            text,
            "\n",
            math.max(at + 1, 1),
            true
        ) or 0) - 1
        if ____end < 0 then
            return nil
        end
        if ____end == at then
            break
        end
        local parsed = field(__TS__StringSlice(text, at, ____end))
        if parsed == nil or indexed[parsed[2]] ~= true then
            return nil
        end
        local length = __TS__Number(parsed[1])
        if not (length >= 0) then
            return nil
        end
        carried[#carried + 1] = {parsed[2], length}
        at = ____end + 1
    end
    at = at + 1
    local texts = {}
    for ____, ____value in ipairs(carried) do
        local name = ____value[1]
        local length = ____value[2]
        if at + length > #text then
            return nil
        end
        texts[name] = __TS__StringSlice(text, at, at + length)
        at = at + length
    end
    if at ~= #text then
        return nil
    end
    return {index = index, entry = entry, hashes = hashes, texts = texts}
end
--- Pieces of at most PAYLOAD_FILE_BYTES, cut before an ASCII byte so no UTF-8 character is split.
function ____exports.payloadPieces(text)
    local pieces = {}
    local start = 0
    while start < #text do
        local ____end = math.min(start + PAYLOAD_FILE_BYTES, #text)
        while ____end < #text and __TS__StringCharCodeAt(text, ____end) >= 128 do
            ____end = ____end - 1
        end
        pieces[#pieces + 1] = __TS__StringSlice(text, start, ____end)
        start = ____end
    end
    return pieces
end
--- Builds each version's files. A module's hash is computed again only when its
-- text changed; a version offers a delta from the newest state every client
-- installed, which `installed` names.
____exports.ModulePublisher = __TS__Class()
local ModulePublisher = ____exports.ModulePublisher
ModulePublisher.name = "ModulePublisher"
function ModulePublisher.prototype.____constructor(self, prefix, hash)
    if hash == nil then
        hash = ____exports.textChecksum
    end
    self.prefix = prefix
    self.hash = hash
    self.known = {}
end
function ModulePublisher.prototype.installed(self, state)
    self.base = state
end
function ModulePublisher.prototype.files(self, version, set)
    local hashes = {}
    local byName = {}
    local known = {}
    for ____, module in ipairs(set.modules) do
        local hashed = self.known[module.name]
        if hashed == nil or hashed.text ~= module.text then
            hashed = {
                text = module.text,
                hash = self.hash(____exports.moduleHashText(module.name, module.text))
            }
        end
        known[module.name] = hashed
        hashes[#hashes + 1] = {module.name, hashed.hash}
        byName[module.name] = hashed.hash
    end
    self.known = known
    local index = ____exports.moduleIndex(set.entry, hashes)
    local state = self.hash(index)
    local full = ____exports.payloadPieces(____exports.modulePayload(index, set.modules))
    local payloads = {}
    local fullBytes = 0
    do
        local piece = 0
        while piece < #full do
            payloads[#payloads + 1] = {
                payloadFile(state, piece, self.prefix),
                full[piece + 1] or ""
            }
            fullBytes = fullBytes + #(full[piece + 1] or "")
            piece = piece + 1
        end
    end
    local base = self.base
    local changed = set.modules
    local changedBytes = fullBytes
    local changes = 0
    if base ~= nil then
        changed = __TS__ArrayFilter(
            set.modules,
            function(____, module) return base.hashes[module.name] ~= byName[module.name] end
        )
        local delta = ____exports.payloadPieces(____exports.modulePayload(index, changed))
        changedBytes = 0
        do
            local piece = 0
            while piece < #delta do
                payloads[#payloads + 1] = {
                    deltaFile(state, base.state, piece, self.prefix),
                    delta[piece + 1] or ""
                }
                changedBytes = changedBytes + #(delta[piece + 1] or "")
                piece = piece + 1
            end
        end
        changes = #delta
    end
    return {
        manifest = {
            version = version,
            state = state,
            files = #full,
            base = base == nil and NO_BASE or base.state,
            changes = changes
        },
        payloads = payloads,
        published = {state = state, hashes = byName},
        changed = __TS__ArrayMap(
            changed,
            function(____, module) return module.name end
        ),
        changedBytes = changedBytes,
        fullBytes = fullBytes
    }
end
return ____exports
