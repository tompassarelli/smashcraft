local ____exports = {}
--- Numbered files avoid Warcraft's session-long Preloader content cache.
____exports.driverCommandFile = function(prefix, serial) return ((prefix .. "-hot\\driver-") .. tostring(serial)) .. ".txt" end
____exports.driverReadyFile = function(prefix, serial) return ((prefix .. "-hot\\driver-ready-") .. tostring(serial)) .. ".txt" end
____exports.driverStatusFile = function(prefix) return prefix .. "-hot\\driver-status.txt" end
return ____exports
