local ____lualib = require("lualib_bundle")
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__Class = ____lualib.__TS__Class
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ClassExtends = ____lualib.__TS__ClassExtends
local __TS__New = ____lualib.__TS__New
local __TS__ArrayIsArray = ____lualib.__TS__ArrayIsArray
local ____exports = {}
local isDecimal, realText, parseInteger, stringText, valueText, integerName, integerKey, undeclared, arrayLength, isKeyed, writeValue, writeFields, isFields, MAX_DEPTH, TWO_26, isDigit, isPlainCode, isInteger, HEX, isFieldName, isList
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
function isDecimal(text)
    local start = string.sub(text, 1, 1) == "-" and 1 or 0
    if #text <= start then
        return false
    end
    do
        local index = start
        while index < #text do
            if not isDigit(__TS__StringCharCodeAt(text, index)) then
                return false
            end
            index = index + 1
        end
    end
    return true
end
function realText(value)
    if value ~= value then
        return "~nan"
    end
    local negative = value < 0 or value == 0 and string.sub(
        tostring(value),
        1,
        1
    ) == "-"
    local magnitude = negative and -value or value
    if magnitude == 0 then
        return negative and "~-0" or "~0"
    end
    if magnitude * 2.0 == magnitude then
        return negative and "~-inf" or "~inf"
    end
    local exponent = 0
    while magnitude >= 2.0 do
        magnitude = magnitude * 0x1p-1
        exponent = exponent + 1
    end
    while magnitude < 1.0 do
        magnitude = magnitude * 2.0
        exponent = exponent - 1
    end
    local scaled = (magnitude - 1.0) * TWO_26
    local high = math.floor(scaled)
    local low = math.floor((scaled - high) * TWO_26)
    return ((((("~" .. (negative and "-" or "+")) .. tostring(exponent)) .. ":") .. tostring(high)) .. ":") .. tostring(low)
end
function parseInteger(text)
    if not isDecimal(text) then
        return nil
    end
    local negative = string.sub(text, 1, 1) == "-"
    local result = 0
    do
        local index = negative and 1 or 0
        while index < #text do
            result = result * 10 + (__TS__StringCharCodeAt(text, index) - 48)
            index = index + 1
        end
    end
    return negative and -result or result
end
function stringText(value)
    local text = "'"
    do
        local index = 0
        while index < #value do
            local code = __TS__StringCharCodeAt(value, index)
            if code > 255 then
                return nil
            end
            text = text .. (isPlainCode(code) and __TS__StringCharAt(value, index) or ("%" .. __TS__StringCharAt(HEX, code // 16)) .. __TS__StringCharAt(HEX, code & 15))
            index = index + 1
        end
    end
    return text
end
function valueText(value)
    if value == true then
        return "T"
    end
    if value == false then
        return "F"
    end
    if type(value) == "number" then
        return isInteger(value) and tostring(value) or realText(value)
    end
    if type(value) == "string" then
        return stringText(value)
    end
    return nil
end
function integerName(text)
    local value = parseInteger(text)
    return value ~= nil and isInteger(value) and tostring(value) == text and value or nil
end
function integerKey(key)
    local raw = key
    if type(raw) == "number" then
        return isInteger(raw) and raw or nil
    end
    return integerName(key)
end
function undeclared(writer, why)
    do
        local ____thrown = __TS__New(
            ____exports.IntegerKeysUndeclared,
            (("record text: " .. table.concat(writer.path, ".")) .. " ") .. why
        )
        if _G.__wispThrown ~= ____thrown then
            _G.__wispThrown = ____thrown
            _G.__wispThrowSite = "wisp/src/runtime/recordText.ts:195"
        end
        error(____thrown, 0)
    end
end
function arrayLength(value)
    local length
    local named = false
    for key in pairs(value) do
        local raw = key
        if type(raw) ~= "number" then
            named = true
        elseif not isInteger(raw) or raw < 1 then
            return false
        else
            length = math.max(length or 0, raw)
        end
    end
    if length ~= nil then
        local ____named_0
        if named then
            ____named_0 = false
        else
            ____named_0 = length
        end
        return ____named_0
    end
    if __TS__ArrayIsArray(value) then
        return #value
    end
    for key in pairs(value) do
        if isDecimal(key) then
            return false
        end
    end
    return nil
end
function isKeyed(value)
    local numbers = false
    for key in pairs(value) do
        local raw = key
        if type(raw) == "number" then
            numbers = true
        end
        if integerKey(key) == nil then
            return false
        end
    end
    return numbers or not __TS__ArrayIsArray(value) or #value == 0
end
function writeValue(writer, name, value, depth)
    if value == nil then
        return true
    end
    local ____writer_1 = writer
    local tokens = ____writer_1.tokens
    if not isFields(value) then
        local text = valueText(value)
        if text == nil then
            return false
        end
        tokens[#tokens + 1] = (name .. "=") .. text
        return true
    end
    if depth >= MAX_DEPTH then
        return false
    end
    local ____writer_path_2 = writer.path
    ____writer_path_2[#____writer_path_2 + 1] = name
    if writer.keyed[name] == true then
        if not isKeyed(value) then
            undeclared(writer, "is declared keyed by integers but has other keys or is an array")
        end
        tokens[#tokens + 1] = name .. "#"
        for key in pairs(value) do
            if not writeValue(
                writer,
                tostring(integerKey(key)),
                value[key],
                depth + 1
            ) then
                return false
            end
        end
        tokens[#tokens + 1] = "}"
    else
        local length = arrayLength(value)
        if length == false then
            undeclared(writer, "is keyed by integers but not declared so in recordTokens, or mixes integer and named keys")
        end
        local items = value
        if isList(items, length) then
            tokens[#tokens + 1] = name .. "["
            do
                local index = 0
                while index < (length or 0) do
                    if not writeValue(
                        writer,
                        tostring(index),
                        items[index + 1],
                        depth + 1
                    ) then
                        return false
                    end
                    index = index + 1
                end
            end
            tokens[#tokens + 1] = "]"
        else
            tokens[#tokens + 1] = name .. "{"
            if not writeFields(writer, value, depth + 1) then
                return false
            end
            tokens[#tokens + 1] = "}"
        end
    end
    table.remove(writer.path)
    return true
end
function writeFields(writer, record, depth)
    for key in pairs(record) do
        if not isFieldName(key) or not writeValue(writer, key, record[key], depth) then
            return false
        end
    end
    return true
end
isFields = function(value) return type(value) == "table" and value ~= nil end
MAX_DEPTH = 32
TWO_26 = 67108864.0
local LARGEST_INTEGER = 2147483647
local SMALLEST_INTEGER = -2147483648
isDigit = function(code) return code >= 48 and code <= 57 end
local function isNameCode(code)
    return isDigit(code) or code >= 65 and code <= 90 or code >= 97 and code <= 122 or code == 95
end
isPlainCode = function(code) return isNameCode(code) or code == 46 or code == 45 end
local function isName(text)
    if #text == 0 then
        return false
    end
    do
        local index = 0
        while index < #text do
            if not isNameCode(__TS__StringCharCodeAt(text, index)) then
                return false
            end
            index = index + 1
        end
    end
    return true
end
isInteger = function(value) return isDecimal(tostring(value)) and value >= SMALLEST_INTEGER and value <= LARGEST_INTEGER end
local function infinity()
    local result = 16777216.0
    do
        local step = 1
        while step <= 6 do
            result = result * result
            step = step + 1
        end
    end
    return result
end
local function parseReal(text)
    if text == "~0" then
        return 0.0
    end
    if text == "~-0" then
        return -0.0
    end
    if text == "~inf" then
        return infinity()
    end
    if text == "~-inf" then
        return -infinity()
    end
    if text == "~nan" then
        return infinity() - infinity()
    end
    local sign = string.sub(text, 2, 2)
    if sign ~= "+" and sign ~= "-" then
        return nil
    end
    local parts = __TS__StringSplit(
        __TS__StringSubstring(text, 2),
        ":"
    )
    if #parts ~= 3 then
        return nil
    end
    local exponent = parseInteger(parts[1] or "")
    local high = parseInteger(parts[2] or "")
    local low = parseInteger(parts[3] or "")
    if exponent == nil or high == nil or low == nil then
        return nil
    end
    if high < 0 or high >= TWO_26 or low < 0 or low >= TWO_26 or exponent < -1100 or exponent > 1100 then
        return nil
    end
    local value = 1.0 + (high + low / TWO_26) / TWO_26
    do
        local step = 0
        while step < exponent do
            value = value * 2.0
            step = step + 1
        end
    end
    do
        local step = 0
        while step > exponent do
            value = value * 0x1p-1
            step = step - 1
        end
    end
    return sign == "-" and -value or value
end
HEX = "0123456789ABCDEF"
local function parseString(text)
    local value = ""
    local index = 1
    while index < #text do
        do
            local character = __TS__StringCharAt(text, index)
            if character ~= "%" then
                if not isPlainCode(__TS__StringCharCodeAt(text, index)) then
                    return nil
                end
                value = value .. character
                index = index + 1
                goto __continue49
            end
            if index + 2 >= #text then
                return nil
            end
            local high = (string.find(
                HEX,
                __TS__StringCharAt(text, index + 1),
                nil,
                true
            ) or 0) - 1
            local low = (string.find(
                HEX,
                __TS__StringCharAt(text, index + 2),
                nil,
                true
            ) or 0) - 1
            if high < 0 or low < 0 then
                return nil
            end
            value = value .. string.char(high * 16 + low)
            index = index + 3
        end
        ::__continue49::
    end
    return value
end
local function parseValue(text)
    if text == "T" then
        return true
    end
    if text == "F" then
        return false
    end
    local first = string.sub(text, 1, 1)
    if first == "~" then
        return parseReal(text)
    end
    if first == "'" then
        return parseString(text)
    end
    return parseInteger(text)
end
isFieldName = function(text) return isName(text) and not isDecimal(text) end
--- Thrown for a table keyed by integers whose field recordTokens wasn't told
-- holds a record keyed by integers, or one it was told does but isn't: written
-- as an array, it would come back with other keys.
____exports.IntegerKeysUndeclared = __TS__Class()
local IntegerKeysUndeclared = ____exports.IntegerKeysUndeclared
IntegerKeysUndeclared.name = "IntegerKeysUndeclared"
__TS__ClassExtends(IntegerKeysUndeclared, Error)
isList = function(_value, length) return length ~= nil end
--- The tokens of a record's fields. A field named in `keyedByInteger` holds
-- a record keyed by integers (`{ readonly [action: number]: T }`), written
-- with its keys. Lua can't tell any other such record from an array, so one
-- not named throws IntegerKeysUndeclared, naming its path, when Bun sees it or
-- Lua sees a key below 1; one with keys from 1 Lua writes as an array, which
-- Lua alone reads back as the same table. Undefined when the record holds
-- anything else: a function, a cycle, a string byte above 255 or a key that
-- isn't letters, digits and `_`.
function ____exports.recordTokens(record, keyedByInteger)
    if keyedByInteger == nil then
        keyedByInteger = {}
    end
    if not isFields(record) or arrayLength(record) ~= nil then
        return nil
    end
    local keyed = {}
    for ____, name in ipairs(keyedByInteger) do
        keyed[name] = true
    end
    local writer = {tokens = {}, keyed = keyed, path = {}}
    return writeFields(writer, record, 0) and writer.tokens or nil
end
local function place(open, name, value)
    if open.fields ~= nil then
        if not isFieldName(name) then
            return false
        end
        open.fields[name] = value
        return true
    end
    if open.keyed ~= nil then
        local key = integerName(name)
        if key == nil then
            return false
        end
        open.keyed[key] = value
        return true
    end
    local index = parseInteger(name)
    if open.items == nil or index == nil or index < 0 then
        return false
    end
    open.items[index + 1] = value
    return true
end
local function opened(last)
    if last == "{" then
        return {fields = {}, items = nil, keyed = nil}
    end
    if last == "[" then
        return {fields = nil, items = {}, keyed = nil}
    end
    return {fields = nil, items = nil, keyed = {}}
end
--- The record that recordTokens wrote `tokens` for; undefined when they are malformed.
function ____exports.parseRecord(tokens)
    local root = {}
    local stack = {{fields = root, items = nil, keyed = nil}}
    for ____, token in ipairs(tokens) do
        do
            local open = stack[#stack]
            if open == nil then
                return nil
            end
            if token == "}" or token == "]" then
                if #stack == 1 or token == "}" ~= (open.items == nil) then
                    return nil
                end
                table.remove(stack)
                goto __continue122
            end
            local last = __TS__StringCharAt(token, #token - 1)
            if last == "{" or last == "[" or last == "#" then
                local child = opened(last)
                if not place(
                    open,
                    __TS__StringSubstring(token, 0, #token - 1),
                    child.fields or child.items or child.keyed
                ) then
                    return nil
                end
                stack[#stack + 1] = child
                goto __continue122
            end
            local equals = (string.find(token, "=", nil, true) or 0) - 1
            local ____temp_3
            if equals < 0 then
                ____temp_3 = nil
            else
                ____temp_3 = parseValue(__TS__StringSubstring(token, equals + 1))
            end
            local value = ____temp_3
            if value == nil or not place(
                open,
                __TS__StringSubstring(token, 0, equals),
                value
            ) then
                return nil
            end
        end
        ::__continue122::
    end
    return #stack == 1 and root or nil
end
--- Tokens joined by spaces into lines of at most `width` characters; a longer token has a line of its own.
function ____exports.tokenLines(tokens, width)
    local lines = {}
    local line = {}
    local length = -1
    for ____, token in ipairs(tokens) do
        if #line > 0 and length + 1 + #token > width then
            lines[#lines + 1] = table.concat(line, " ")
            line = {}
            length = -1
        end
        line[#line + 1] = token
        length = length + (1 + #token)
    end
    if #line > 0 then
        lines[#lines + 1] = table.concat(line, " ")
    end
    return lines
end
--- The tokens of lines that tokenLines wrote.
function ____exports.lineTokens(lines)
    local tokens = {}
    for ____, line in ipairs(lines) do
        for ____, token in ipairs(__TS__StringSplit(line, " ")) do
            if #token > 0 then
                tokens[#tokens + 1] = token
            end
        end
    end
    return tokens
end
return ____exports
