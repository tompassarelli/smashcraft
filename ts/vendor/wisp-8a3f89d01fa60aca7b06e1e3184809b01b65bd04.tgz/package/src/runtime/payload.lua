local ____exports = {}
local ____intMath = require("src.sim.intMath")
local floorMod = ____intMath.floorMod
--- Two polynomial lanes over `byteAt(0)` to `byteAt(length - 1)`. Each modulus
-- is the largest prime keeping lane * 263 + 256 + 1 below 2^31, so 32-bit Lua
-- integers never wrap.
function ____exports.checksum(length, byteAt)
    local first = 0
    local second = 0
    do
        local index = 0
        while index < length do
            local byte = byteAt(index)
            first = (first * 257 + byte + 1) % 8165329
            second = (second * 263 + byte + 1) % 8165323
            index = index + 1
        end
    end
    return (tostring(first) .. ":") .. tostring(second)
end
return ____exports
