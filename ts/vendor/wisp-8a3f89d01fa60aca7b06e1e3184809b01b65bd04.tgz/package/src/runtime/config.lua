local ____exports = {}
local configuration = {filePrefix = "wisp", readyPrefix = "WS_HRR", globalPrefix = "__wisp"}
--- Call before installing handlers in every bundle. Retain these values across live reloads.
function ____exports.configureRuntime(next)
    configuration = next
end
function ____exports.runtimeConfiguration()
    return configuration
end
return ____exports
