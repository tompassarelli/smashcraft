local ____exports = {}
local ____repro = require("src.runtime.repro")
local reproLines = ____repro.reproLines
local ____fileio = require("src.platform.fileio")
local writeLines = ____fileio.writeLines
--- Writes a repro; name it with reproFile, so no two share a name in a session. Keep each line within REPRO_LINE_WIDTH.
function ____exports.writeRepro(filename, header, lines)
    writeLines(
        filename,
        reproLines(header, lines)
    )
end
return ____exports
