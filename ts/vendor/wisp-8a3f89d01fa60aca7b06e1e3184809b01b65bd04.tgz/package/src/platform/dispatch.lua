local ____exports = {}
local run, ____table
local ____errors = require("src.platform.errors")
local reportError = ____errors.reportError
local restoreStack = ____errors.restoreStack
local stackDepth = ____errors.stackDepth
local traceback = ____errors.traceback
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
function run(name)
    local handler = ____table().handlers[name]
    if handler ~= nil then
        local depth = stackDepth()
        xpcall(
            handler,
            function(____error) return reportError(
                name,
                ____error,
                traceback(____error)
            ) end
        )
        restoreStack(depth)
    end
end
function ____table()
    local globals = _G
    local key = runtimeConfiguration().globalPrefix .. "Dispatch"
    local ____globals_0, ____key_1 = globals, key
    if ____globals_0[____key_1] == nil then
        ____globals_0[____key_1] = {handlers = {}, run = run}
    end
    return globals[key]
end
--- Makes this bundle's way of running handlers the current one.
function ____exports.installDispatch()
    ____table().run = run
end
--- Registers or replaces the handler for a named engine callback.
function ____exports.on(name, handler)
    ____table().handlers[name] = handler
end
--- A callback for natives (TimerStart, TriggerAddAction) that always runs the current handler.
function ____exports.trampoline(name)
    return function() return ____table().run(name) end
end
return ____exports
