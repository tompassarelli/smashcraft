local ____exports = {}
local ____intMath = require("src.sim.intMath")
local floorMod = ____intMath.floorMod
local FIRST = 8165329
local SECOND = 8165323
function ____exports.stringChecksum(text)
    local first = 0
    local second = 0
    local length = #text
    local position = 1
    do
        while position + 7 <= length do
            local b1, b2, b3, b4, b5, b6, b7, b8 = string.byte(text, position, position + 7)
            first = (first * 257 + b1 + 1) % FIRST
            second = (second * 263 + b1 + 1) % SECOND
            first = (first * 257 + b2 + 1) % FIRST
            second = (second * 263 + b2 + 1) % SECOND
            first = (first * 257 + b3 + 1) % FIRST
            second = (second * 263 + b3 + 1) % SECOND
            first = (first * 257 + b4 + 1) % FIRST
            second = (second * 263 + b4 + 1) % SECOND
            first = (first * 257 + b5 + 1) % FIRST
            second = (second * 263 + b5 + 1) % SECOND
            first = (first * 257 + b6 + 1) % FIRST
            second = (second * 263 + b6 + 1) % SECOND
            first = (first * 257 + b7 + 1) % FIRST
            second = (second * 263 + b7 + 1) % SECOND
            first = (first * 257 + b8 + 1) % FIRST
            second = (second * 263 + b8 + 1) % SECOND
            position = position + 8
        end
    end
    do
        while position <= length do
            local byte = string.byte(text, position)
            first = (first * 257 + byte + 1) % FIRST
            second = (second * 263 + byte + 1) % SECOND
            position = position + 1
        end
    end
    return (tostring(first) .. ":") .. tostring(second)
end
return ____exports
