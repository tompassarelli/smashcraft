local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local acknowledgementLine = ____gameFiles.acknowledgementLine
local ackFile = ____gameFiles.ackFile
local deltaFile = ____gameFiles.deltaFile
local formatManifest = ____gameFiles.formatManifest
local hostFile = ____gameFiles.hostFile
local manifestFile = ____gameFiles.manifestFile
local parseManifest = ____gameFiles.parseManifest
local payloadFile = ____gameFiles.payloadFile
local payloadKey = ____gameFiles.payloadKey
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
local ____modules = require("src.runtime.modules")
local moduleHashText = ____modules.moduleHashText
local parsePayload = ____modules.parsePayload
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local floorMod = ____intMath.floorMod
local ____dispatch = require("src.platform.dispatch")
local on = ____dispatch.on
local trampoline = ____dispatch.trampoline
local ____fileio = require("src.platform.fileio")
local readChunk = ____fileio.readChunk
local ____payloadChecksum = require("src.platform.payloadChecksum")
local stringChecksum = ____payloadChecksum.stringChecksum
local POLL_SECONDS = 0x1p-5
local IDLE_POLLS = 16
local MAX_SLOTS = 4
local function hot()
    local globals = _G
    local state = globals[runtimeConfiguration().globalPrefix .. "Hot"]
    if state == nil then
        do
            local ____thrown = __TS__New(Error, "hot reload used before startHotReload")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/hotReload.ts:97"
            end
            error(____thrown, 0)
        end
    end
    return state
end
local function isReloadable(value)
    return type(value) == "table" and value ~= nil and value.install ~= nil and type(value.install) == "function"
end
local function manifestExists(version)
    return readChunk(manifestFile(
        version,
        runtimeConfiguration().filePrefix
    )) ~= nil
end
local function hostSeen()
    return readChunk(hostFile(runtimeConfiguration().filePrefix)) ~= nil
end
--- The newest version published before this match. Manifests are never removed
-- and versions only rise, so existence is monotonic and a search finds it in
-- a logarithmic number of reads.
local function latestVersion()
    if not manifestExists(1) then
        return 0
    end
    local low = 1
    while manifestExists(low * 2) do
        low = low * 2
    end
    local high = low * 2
    while high - low > 1 do
        local middle = (low + high) // 2
        if manifestExists(middle) then
            low = middle
        else
            high = middle
        end
    end
    return low
end
local function playingHumans()
    local count = 0
    do
        local slot = 0
        while slot < MAX_SLOTS do
            local player = Player(slot)
            if GetPlayerSlotState(player) == PLAYER_SLOT_STATE_PLAYING and GetPlayerController(player) == MAP_CONTROL_USER then
                count = count + 1
            end
            slot = slot + 1
        end
    end
    return count
end
local function startClock()
    local clock = CreateTimer()
    TimerStart(
        clock,
        86400.0,
        false,
        function()
        end
    )
    return clock
end
local function report(text)
    DisplayTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        text
    )
end
--- A require over `modules`, as TypeScriptToLua's bundle defines it: each module runs once, on its first require.
local function link(modules)
    local values = {}
    local ____require
    ____require = function(name)
        local known = values[name]
        if known ~= nil then
            return known.value
        end
        local module = modules[name]
        if module == nil then
            do
                local ____thrown = ("module '" .. name) .. "' not found"
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/platform/hotReload.ts:152"
                end
                error(____thrown, 0)
            end
        end
        local value = module.chunk(____require)(name)
        values[name] = {value = value}
        return value
    end
    return ____require
end
--- This client's copy of a version, linked and evaluated but not installed, or why it failed.
local function loadLocal(state, manifest)
    local prefix = runtimeConfiguration().filePrefix
    local installed = state.modules
    local delta = installed ~= nil and manifest.changes > 0 and manifest.base == state.state
    local modules = {}
    local function refuse(reason)
        return {bundle = reason, modules = modules}
    end
    local parts = {}
    do
        local index = 0
        while index < (delta and manifest.changes or manifest.files) do
            parts[#parts + 1] = readChunk(delta and deltaFile(manifest.state, manifest.base, index, prefix) or payloadFile(manifest.state, index, prefix)) or ""
            index = index + 1
        end
    end
    local payload = parsePayload(table.concat(parts, ""))
    if payload == nil or stringChecksum(payload.index) ~= manifest.state then
        return refuse("payload missing or damaged")
    end
    for ____, ____value in ipairs(payload.hashes) do
        local name = ____value[1]
        local hash = ____value[2]
        do
            local text = payload.texts[name]
            if text == nil then
                local ____delta_0
                if delta then
                    ____delta_0 = installed[name]
                else
                    ____delta_0 = nil
                end
                local kept = ____delta_0
                if kept == nil or kept.hash ~= hash then
                    return refuse(("module " .. name) .. " missing")
                end
                modules[name] = kept
                goto __continue29
            end
            if stringChecksum(moduleHashText(name, text)) ~= hash then
                return refuse(("module " .. name) .. " damaged")
            end
            local chunk, ____error = load(
                text,
                "=hot-" .. payloadKey(hash)
            )
            if chunk == nil then
                return refuse(____error or ("module " .. name) .. " doesn't load")
            end
            modules[name] = {hash = hash, chunk = chunk}
        end
        ::__continue29::
    end
    local ran, entry = pcall(
        link(modules),
        payload.entry
    )
    if not ran then
        return refuse("failed while loading: " .. tostring(entry))
    end
    return {
        bundle = isReloadable(entry) and entry or "bundle exports no install()",
        modules = modules
    }
end
--- Loads this client's copy of a version and tells every client whether it is ready.
local function answer(state, manifest)
    if state.next <= manifest.version then
        state.next = manifest.version + 1
    end
    local ____loadLocal_result_1 = loadLocal(state, manifest)
    local bundle = ____loadLocal_result_1.bundle
    local modules = ____loadLocal_result_1.modules
    state.prepared = {version = manifest.version, state = manifest.state, bundle = bundle, modules = modules}
    BlzSendSyncData(
        runtimeConfiguration().readyPrefix,
        (formatManifest(manifest) .. " ") .. (type(bundle) == "string" and "refuse" or "ready")
    )
end
local function poll()
    local state = hot()
    if state.prepared ~= nil then
        return
    end
    if state.unseen ~= nil then
        state.unseen = (state.unseen + 1) % (2 * IDLE_POLLS)
        if state.unseen == IDLE_POLLS and hostSeen() then
            state.unseen = nil
        end
        if state.unseen ~= 0 then
            return
        end
    end
    if state.next <= state.decided then
        state.next = state.decided + 1
    end
    local text = readChunk(manifestFile(
        state.next,
        runtimeConfiguration().filePrefix
    ))
    if text == nil then
        return
    end
    state.unseen = nil
    local manifest = parseManifest(text)
    if manifest == nil or manifest.version ~= state.next then
        state.next = state.next + 1
        return
    end
    answer(state, manifest)
end
--- Tells host tools which version this client runs: 0 for the map's own bundle.
local function acknowledge(version, elapsed)
    PreloadGenClear()
    PreloadGenStart()
    Preload(acknowledgementLine(version, elapsed))
    PreloadGenEnd(ackFile(
        GetPlayerId(GetLocalPlayer()),
        runtimeConfiguration().filePrefix
    ))
end
local function decide(state, pending)
    local ____pending_manifest_2 = pending.manifest
    local version = ____pending_manifest_2.version
    local expected = ____pending_manifest_2.state
    state.pending = nil
    state.decided = version
    local prepared = state.prepared
    if prepared ~= nil and prepared.version <= version then
        state.prepared = nil
    end
    local loaded = prepared ~= nil and prepared.version == version and prepared.state == expected and prepared or nil
    local bundle = loaded == nil and "no local copy" or loaded.bundle
    if pending.refused or type(bundle) == "string" or loaded == nil then
        local reason = type(bundle) == "string" and bundle or "another client couldn't load it"
        report((("hot reload " .. tostring(version)) .. " not applied: ") .. reason)
        return
    end
    state.modules = loaded.modules
    state.state = loaded.state
    bundle.install()
    state.applied = version
    if state.clock == nil then
        state.clock = startClock()
    end
    acknowledge(
        version,
        TimerGetElapsed(state.clock)
    )
    report(("hot reload " .. tostring(version)) .. " applied")
end
local function answered()
    local state = hot()
    local text = BlzGetTriggerSyncData()
    local manifest = parseManifest(text)
    local verdict = __TS__StringSplit(text, " ")[6]
    if manifest == nil or manifest.version <= state.decided then
        return
    end
    local pending = state.pending
    if pending ~= nil and manifest.version < pending.manifest.version then
        return
    end
    if pending == nil or manifest.version > pending.manifest.version then
        pending = {
            manifest = manifest,
            answered = 0,
            waiting = playingHumans(),
            refused = false
        }
        state.pending = pending
    end
    local ____bit = 1 << GetPlayerId(GetTriggerPlayer())
    if pending.answered & ____bit ~= 0 then
        return
    end
    pending.answered = pending.answered | ____bit
    pending.waiting = pending.waiting - 1
    if verdict ~= "ready" or manifest.state ~= pending.manifest.state then
        pending.refused = true
    end
    if state.prepared == nil or state.prepared.version ~= pending.manifest.version then
        answer(state, pending.manifest)
    end
    if pending.waiting <= 0 and state.pending == pending then
        decide(state, pending)
    end
end
--- Registers the reloader's handlers; a reloaded bundle calls this again.
function ____exports.installHotReload()
    on("hotReload.poll", poll)
    on("hotReload.answered", answered)
end
--- Starts polling for new bundles. Call once, at match start.
function ____exports.startHotReload()
    local configuration = runtimeConfiguration()
    local globals = _G
    local published = latestVersion()
    local ____temp_3
    if published > 0 or hostSeen() then
        ____temp_3 = nil
    else
        ____temp_3 = 1
    end
    local unseen = ____temp_3
    globals[configuration.globalPrefix .. "Hot"] = {
        applied = 0,
        decided = 0,
        pending = nil,
        next = published + 1,
        prepared = nil,
        unseen = unseen
    }
    ____exports.installHotReload()
    local trigger = CreateTrigger()
    do
        local slot = 0
        while slot < MAX_SLOTS do
            BlzTriggerRegisterPlayerSyncEvent(
                trigger,
                Player(slot),
                configuration.readyPrefix,
                false
            )
            slot = slot + 1
        end
    end
    TriggerAddAction(
        trigger,
        trampoline("hotReload.answered")
    )
    TimerStart(
        CreateTimer(),
        POLL_SECONDS,
        true,
        trampoline("hotReload.poll")
    )
    acknowledge(0, 0)
end
return ____exports
