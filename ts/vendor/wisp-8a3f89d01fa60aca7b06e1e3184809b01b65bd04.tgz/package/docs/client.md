# Native clients

`wisp client` owns screen input, passive state and recovery for the clients
declared by the game. `wisp client look`, `wisp client read`, `wisp client click`,
`wisp client keys` and `wisp client chat` use that client's private desktop.

`wisp client watch [CLIENT...] [--once] [--json] [--record FILE]` reads its
events; `wisp client wait CLIENT STATE... [--seconds N]` waits for a state.
See [watching clients](watch.md).

`wisp client doctor [CLIENT...]` brings named clients, or all clients, to a
ready state. The game supplies its recovery command as the third argument
to `makeClient(clientsFile, watchOptions, doctorCommand, signOutCommand)`; see
[client recovery](doctor.md). Doctor signs a launcher in with the client's
declared account. `wisp client sign-out CLIENT...` signs clients out (the
fourth argument, from `makeSignOut`); the next doctor run signs them in again.
The sample map has no account recovery declaration.

`wisp client start [CLIENT...]` starts each client's private desktop and
Battle.net as user services that outlive the command and its caller, runs
doctor and returns at the menu; `wisp client status [CLIENT...]` names the
service behind each, and `wisp client stop [CLIENT...]` stops them. See
[clients as services](doctor.md#clients-as-services).
