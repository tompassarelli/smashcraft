/** @noSelfInFile */
/** Truncation toward zero, which Lua and JavaScript both emit exactly. */
export declare function toInt(value: number): number;
/** Rounds to the nearest binary32 value; NaN and infinity pass through. */
export declare function roundToFloat32(value: number): number;
export declare function addFloat32(a: number, b: number): number;
export declare function subtractFloat32(a: number, b: number): number;
/**
 * a + b rounded toward zero, for binary32 a and b that are zero or positive
 * and normal: Warcraft's timer clock (wisp:docs/warsmash-notes.md#timers-and-frame-stepping).
 */
export declare function addFloat32TowardZero(a: number, b: number): number;
/** a - b rounded toward zero, for binary32 a >= b that are zero or positive and normal. */
export declare function subtractFloat32TowardZero(a: number, b: number): number;
export declare function multiplyFloat32(a: number, b: number): number;
/** a * b rounded toward zero, as Warcraft's raw * rounds (wisp:docs/headless.md#raw-float-rounding); a result outside the normal range rounds to nearest. */
export declare function multiplyFloat32TowardZero(a: number, b: number): number;
/**
 * a * b + c with one binary32 rounding. Inputs must be finite binary32 values;
 * the exact product may leave binary32 range before cancellation.
 */
export declare function fusedMultiplyAddFloat32(a: number, b: number, c: number): number;
/** Long division keeps the quotient and sticky remainder; a zero divisor gives NaN. */
export declare function divideFloat32(numerator: number, denominator: number): number;
/** Correctly rounded square root of a binary32 input, independent of host math. */
export declare function squareRootFloat32(value: number): number;
