/** @noSelfInFile */
export declare function floorDiv(a: number, b: number): number;
export declare function floorMod(a: number, b: number): number;
/** Wurst `div`: the quotient truncated toward zero. */
export declare function idiv(a: number, b: number): number;
/** Wurst `mod`: the truncated remainder, plus b when it is negative. */
export declare function imod(a: number, b: number): number;
