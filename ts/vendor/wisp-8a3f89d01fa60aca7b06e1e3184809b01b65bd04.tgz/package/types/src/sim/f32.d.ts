/** @noSelfInFile */
/** The operation codes the compiler passes as f32's third argument; no source writes them. */
export declare const F32_ADD = 1;
export declare const F32_SUBTRACT = 2;
export declare const F32_MULTIPLY = 3;
export declare const F32_DIVIDE = 4;
export declare function f32(value: number, right?: number, operation?: number): number;
