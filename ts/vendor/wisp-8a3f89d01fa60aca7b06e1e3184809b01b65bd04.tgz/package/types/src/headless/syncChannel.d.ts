/** @noSelfInFile */
import type { SyncDelivery } from "./lockstep";
export interface SyncLatency {
    /** One-way latency in game milliseconds, before rounding up to a turn. */
    readonly latencyMs: number;
    /** Game milliseconds between synchronized turns. */
    readonly turnMs: number;
    /** Probabilities of 0, 1, 2, ... further turns; they sum to 1. */
    readonly extraTurns: readonly number[];
}
/**
 * Battle.net as Smashcraft's #26 runs r7 and r8 measured it on 5 October
 * 2026: two clients on one host, 765 own-echo samples from the unsaturated
 * first seconds of each match.
 */
export declare const MEASURED_BATTLE_NET: SyncLatency;
/** Game milliseconds between a client's timer callbacks. */
export declare const CALLBACK_MS: number;
/** The game milliseconds from a send during `frame`'s callback until every client receives it. */
export declare function syncAgeMs(latency: SyncLatency, frame: number, extraTurns: number): number;
/**
 * Lockstep delivery with the measured latency: a message sent during frame F
 * reaches every client before the callbacks of the first frame at or after
 * its arrival. Seeded, so a run repeats exactly.
 */
export declare function syncDelivery(latency?: SyncLatency, seed?: number): SyncDelivery;
