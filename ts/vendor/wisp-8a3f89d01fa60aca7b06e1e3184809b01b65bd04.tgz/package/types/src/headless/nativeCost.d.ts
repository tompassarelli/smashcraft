/** @noSelfInFile */
/** What one client's frame did, as a headless run measures it. */
export interface FrameWork {
    /** Lua instructions in the map's code. */
    readonly instructions: number;
    /** Calls of Warcraft's functions. */
    readonly natives: number;
    /** Kilobytes the map's code allocated. */
    readonly allocatedKb: number;
    /** Characters typed into the client's edit box before the frame. */
    readonly typedCharacters: number;
}
export interface NativeCostModel {
    /** The development host's 32-bit Lua microseconds per thousand instructions of map code. */
    readonly hostUsPerThousandInstructions: number;
    /** Warcraft's Lua time for one of the development host's 32-bit Lua microseconds. */
    readonly luaFactor: number;
    /** Microseconds per call of a native or Blizzard.j function, beyond the Lua around it. */
    readonly nativeCallUs: number;
    /** Collector microseconds per kilobyte allocated, in Warcraft. */
    readonly collectorUsPerKb: number;
    /** Microseconds the game stops per square of the characters an edit box takes in one frame. */
    readonly typingUsPerCharacterSquared: number;
}
/** A frame's predicted cost in Warcraft, in microseconds. */
export interface NativeFrameCost {
    /** The map's callbacks, collector included: what the frame meter's Lua time measures natively. */
    readonly callbacksUs: number;
    /** The game stopped taking typed text, outside the callbacks. */
    readonly typingUs: number;
}
export declare function nativeFrameCost(model: NativeCostModel, work: FrameWork): NativeFrameCost;
/**
 * Warcraft III as measured (wisp:docs/frame-cost.md#predicted-native-cost):
 * Warcraft's Lua 1.17 times slower than the development host's 32-bit Lua on
 * Smashcraft's 4096-frame workload; that host's instruction rate on
 * Smashcraft's four-fighter bot match; native calls and the collector fitted
 * to the 0.0.49 four-fighter overlay; typing 0.00003 frames per character
 * squared, from 608 characters holding a client 180 ms.
 */
export declare const WARCRAFT_COST: NativeCostModel;
