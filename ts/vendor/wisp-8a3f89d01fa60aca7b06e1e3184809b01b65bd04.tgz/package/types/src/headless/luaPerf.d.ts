/** @noSelfInFile */
import { type Journey } from "./journey";
import { Lockstep, type SyncDelivery } from "./lockstep";
import { type LuaHeadlessMap } from "./lua";
import { type NativeCostModel } from "./nativeCost";
/** Instructions between the hook's counts: each run of a client counts its instructions rounded down to a multiple of this. */
export declare const HOOK_STEP = 100;
/** What a game's own driver tells the measurement while it plays the clients. */
export interface PerfMeasure {
    /** `characters` were typed into `slot`'s edit box before the next frame. */
    typed(this: void, slot: number, characters: number): void;
    /** Counts frames from the next one on, such as a match's first frame after its menus. */
    begin(this: void): void;
}
export interface LuaPerfOptions {
    /** The model the predicted lines use; Warcraft's measured one by default. */
    readonly model?: NativeCostModel;
    /** Also print every client's every frame, `frame F pSLOT ...`, to calibrate a model. */
    readonly samples?: boolean;
    /** When synchronized messages arrive, such as Warcraft's measured latency; before the next frame without it. */
    readonly delivery?: SyncDelivery;
}
/**
 * Measures every client's frames while `play` drives the clients of the
 * bundle and declarations at these paths, prints the result as `wisp perf`
 * reads it and returns how many problems `play` found.
 */
export declare function runLuaPerfWith(map: LuaHeadlessMap, bundlePath: string, declarationsPath: string, play: (this: void, clients: Lockstep, measure: PerfMeasure) => {
    readonly problems: number;
    readonly lines: readonly string[];
}, options?: LuaPerfOptions): number;
/**
 * Plays `journey` with the bundle and declarations at these paths, measuring
 * every client's frames, prints the result as `wisp perf` reads it and
 * returns how many problems the journey found.
 */
export declare function runLuaPerf(map: LuaHeadlessMap, journey: Journey, bundlePath: string, declarationsPath: string, options?: LuaPerfOptions): number;
