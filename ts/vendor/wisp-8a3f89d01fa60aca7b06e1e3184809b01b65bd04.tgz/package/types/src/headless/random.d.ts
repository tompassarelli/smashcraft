/** @noSelfInFile */
/** Park-Miller minimal standard generator in Schrage's form: every product stays below 2^31. */
export declare class Random {
    private state;
    constructor(seed: number);
    /** Uniform in (0, 1). */
    next(): number;
    /** A whole number from `low` to `high`, both included. */
    between(low: number, high: number): number;
    /** True with probability `p`. */
    chance(p: number): boolean;
    /** One of `items`, which is not empty. */
    pick<T>(items: readonly T[]): T;
}
