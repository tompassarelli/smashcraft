/** @noSelfInFile */
export type TestCase = {
    name: string;
    run: () => void;
};
export declare const registeredTests: TestCase[];
export declare function test(name: string, run: () => void): void;
export declare class AssertionFailure {
    readonly message: string;
    constructor(message: string);
}
export declare function assertTrue(value: boolean): void;
export declare function assertFalse(value: boolean): void;
/** Exact equality (Object.is semantics except that 0 equals -0). */
export declare function assertEquals<T>(actual: T, expected: T, message?: string): void;
export declare function assertNear(actual: number, expected: number, delta: number): void;
export declare function assertGreaterThan(actual: number, bound: number): void;
export declare function assertLessThan(actual: number, bound: number): void;
/** The value, or a failure when it is undefined. */
export declare function assertDefined<T>(value: T | undefined, what?: string): T;
/** Runs every registered test, reports each failure and a summary line, and returns the number of failures. */
export declare function runTests(report: (this: void, line: string) => void): number;
