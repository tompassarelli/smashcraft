/** @noSelfInFile */
/** The element at `index` of a table whose callers guarantee the index; a miss is a defect and fails loudly. */
export declare function at<T>(items: readonly T[], index: number): T;
