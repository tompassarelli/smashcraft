/** @noSelfInFile */
/** Numbered files avoid Warcraft's session-long Preloader content cache. */
export declare const driverCommandFile: (prefix: string, serial: number) => string;
export declare const driverReadyFile: (prefix: string, serial: number) => string;
export declare const driverStatusFile: (prefix: string) => string;
