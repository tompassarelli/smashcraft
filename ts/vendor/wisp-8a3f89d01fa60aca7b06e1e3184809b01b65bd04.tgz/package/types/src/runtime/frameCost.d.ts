/** @noSelfInFile */
/** The report a client writes once the version it runs has played a window of frames. */
export declare const frameCostFile: (slot: number, prefix?: string) => string;
/** A value's median, mean and maximum over a window of frames. */
export interface Spread {
    readonly median: number;
    readonly mean: number;
    readonly max: number;
}
/** What a window of frames cost per frame. */
export interface FrameWindow {
    readonly frames: number;
    /** Lua time in microseconds; undefined where the game has no clock. */
    readonly lua: Spread | undefined;
    /** Calls to Warcraft's functions: every global function whose name starts with a capital letter. */
    readonly natives: Spread;
    /** Simulation frames the game advanced. */
    readonly catchUp: Spread;
}
/** The median, mean and maximum of the first `count` values; zeros for none. */
export declare function spread(values: readonly number[], count: number): Spread;
/** A non-negative number as reports write it, rounded to two decimals, alike in Lua and JavaScript. */
export declare function reportNumber(value: number): string;
/** The report's first line: the version measured after a reload, the one before it, and the clock's step in microseconds (0 without a clock). */
export declare const frameCostHeading: (version: number, previous: number, clockStep: number) => string;
/** One window's line, `before` or `after`: its frames, then each value's median/mean/max per frame. */
export declare const frameWindowLine: (label: string, window: FrameWindow) => string;
