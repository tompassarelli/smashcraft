/** @noSelfInFile */
import { type Manifest } from "./gameFiles";
export interface HotModule {
    /** The name the bundle's require uses. */
    readonly name: string;
    /** Its chunk: MODULE_HEAD, the module's code, MODULE_TAIL. */
    readonly text: string;
}
/** The map's code as modules, and the one whose exports have install(). */
export interface ModuleSet {
    readonly entry: string;
    readonly modules: readonly HotModule[];
}
/**
 * Around a module's code, as TypeScriptToLua's bundle has it, the chunk takes
 * the require to link against and returns the module's function. The head is
 * one line, as the bundle's table entry head is, so the code keeps its lines.
 */
export declare const MODULE_HEAD = "local require = ... return function(...) \n";
export declare const MODULE_TAIL = " end\n";
export declare const moduleChunk: (code: string) => string;
/** The one module of a whole bundle, for a compile with no per-module output. */
export declare const BUNDLE_MODULE = "bundle";
export declare const bundleModules: (bundle: string) => ModuleSet;
/** The checksum of a byte string. */
export type Hash = (this: void, text: string) => string;
export declare const textChecksum: Hash;
/** What a module's hash covers: its name too, so equal code under two names keeps two source maps. */
export declare const moduleHashText: (name: string, text: string) => string;
/** The entry's name, then a line per module: its hash and name. Its checksum is the state's. */
export declare function moduleIndex(entry: string, hashes: readonly (readonly [name: string, hash: string])[]): string;
/** The index, a blank line, a line per carried module (its byte length and name), a blank line, then their texts. */
export declare function modulePayload(index: string, carried: readonly HotModule[]): string;
export interface Payload {
    readonly index: string;
    readonly entry: string;
    /** Every module of the state, in index order: name and hash. */
    readonly hashes: readonly (readonly [string, string])[];
    /** Name to text of each module the payload carries. */
    readonly texts: Readonly<Record<string, string | undefined>>;
}
/** A payload's index and texts; undefined when it is cut short, too long or malformed. */
export declare function parsePayload(text: string): Payload | undefined;
/** Pieces of at most PAYLOAD_FILE_BYTES, cut before an ASCII byte so no UTF-8 character is split. */
export declare function payloadPieces(text: string): string[];
/** A published state: its hash and each module's. */
export interface ModuleState {
    readonly state: string;
    readonly hashes: Readonly<Record<string, string | undefined>>;
}
/** What the host writes for a version, payload files first; the manifest names them. */
export interface VersionFiles {
    readonly manifest: Manifest;
    /** Game paths and texts. */
    readonly payloads: readonly (readonly [string, string])[];
    readonly published: ModuleState;
    /** The modules a client running the base reads, and their bytes; every module and the full payload's bytes without a base. */
    readonly changed: readonly string[];
    readonly changedBytes: number;
    readonly fullBytes: number;
}
/**
 * Builds each version's files. A module's hash is computed again only when its
 * text changed; a version offers a delta from the newest state every client
 * installed, which `installed` names.
 */
export declare class ModulePublisher {
    private readonly prefix;
    private readonly hash;
    private known;
    private base;
    constructor(prefix: string, hash?: Hash);
    /** Every client installed `state`: later versions carry only what differs from it. */
    installed(state: ModuleState): void;
    files(version: number, set: ModuleSet): VersionFiles;
}
