/** @noSelfInFile */
/**
 * Two polynomial lanes over `byteAt(0)` to `byteAt(length - 1)`. Each modulus
 * is the largest prime keeping lane * 263 + 256 + 1 below 2^31, so 32-bit Lua
 * integers never wrap.
 */
export declare function checksum(length: number, byteAt: (index: number) => number): string;
