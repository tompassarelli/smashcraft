/** @noSelfInFile */
/**
 * Thrown for a table keyed by integers whose field recordTokens wasn't told
 * holds a record keyed by integers, or one it was told does but isn't: written
 * as an array, it would come back with other keys.
 */
export declare class IntegerKeysUndeclared extends Error {
}
/**
 * The tokens of a record's fields. A field named in `keyedByInteger` holds
 * a record keyed by integers (`{ readonly [action: number]: T }`), written
 * with its keys. Lua can't tell any other such record from an array, so one
 * not named throws IntegerKeysUndeclared, naming its path, when Bun sees it or
 * Lua sees a key below 1; one with keys from 1 Lua writes as an array, which
 * Lua alone reads back as the same table. Undefined when the record holds
 * anything else: a function, a cycle, a string byte above 255 or a key that
 * isn't letters, digits and `_`.
 */
export declare function recordTokens(record: object, keyedByInteger?: readonly string[]): string[] | undefined;
/** The record that recordTokens wrote `tokens` for; undefined when they are malformed. */
export declare function parseRecord(tokens: readonly string[]): Record<string, unknown> | undefined;
/** Tokens joined by spaces into lines of at most `width` characters; a longer token has a line of its own. */
export declare function tokenLines(tokens: readonly string[], width: number): string[];
/** The tokens of lines that tokenLines wrote. */
export declare function lineTokens(lines: readonly string[]): string[];
