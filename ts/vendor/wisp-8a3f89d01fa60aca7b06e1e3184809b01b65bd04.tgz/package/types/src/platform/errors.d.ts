/** @noSelfInFile */
interface StackFrames {
    depth: number;
    frames: Record<number, string | undefined>;
}
interface ShadowStack extends StackFrames {
    failure?: (StackFrames & {
        error: unknown;
    }) | undefined;
}
declare global {
    var __wispStack: ShadowStack | undefined;
    /** The latest value a compiled `throw` raised, and that statement's TypeScript file and line. */
    var __wispThrown: unknown;
    var __wispThrowSite: string | undefined;
}
/** The callback boundary restores this depth after Lua unwinds a failed call. */
export declare function stackDepth(): number;
export declare function restoreStack(depth: number): void;
/** Compiler-recorded TypeScript frames work in Warcraft without Lua's debug library. */
export declare function traceback(error?: unknown): string;
export declare function reportError(handler: string, error: unknown, stack: string): void;
export {};
