/** @noSelfInFile */
interface DriverState {
    serial: number;
    players: number;
    leader: number;
    frame: number;
    checksum: string;
    paused: boolean;
    payload: string | undefined;
    digest: string | undefined;
    answers: number;
    sent: boolean;
    polls: number;
    refused: boolean;
    offered: boolean;
}
declare global {
    var __wispDrive: DriverState | undefined;
}
/** Every client first verifies its numbered payload; the last matching sync answer applies it everywhere. */
export declare function installNativeDriver(handler: (text: string) => void): void;
/** Opt-in once at synchronized startup, before any commands are published. */
export declare function startNativeDriver(players: readonly number[], leader?: number): void;
/** Call on the existing callback even while simulation is held; no clock or timer is replaced. */
export declare function serviceNativeDriver(): void;
export declare function publishNativeDriverStatus(frame: number, checksum: string, paused: boolean): void;
export {};
