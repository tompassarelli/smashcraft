/** @noSelfInFile */
export declare function stringChecksum(text: string): string;
