/** @noSelfInFile */
import { type ReproHeader } from "../runtime/repro";
/** Writes a repro; name it with reproFile, so no two share a name in a session. Keep each line within REPRO_LINE_WIDTH. */
export declare function writeRepro(filename: string, header: ReproHeader, lines: readonly string[]): void;
