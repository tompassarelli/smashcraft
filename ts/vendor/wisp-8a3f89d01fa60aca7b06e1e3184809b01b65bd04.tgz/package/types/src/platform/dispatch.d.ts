/** @noSelfInFile */
type Handler = (this: void) => void;
/** Makes this bundle's way of running handlers the current one. */
export declare function installDispatch(): void;
/** Registers or replaces the handler for a named engine callback. */
export declare function on(name: string, handler: Handler): void;
/** A callback for natives (TimerStart, TriggerAddAction) that always runs the current handler. */
export declare function trampoline(name: string): Handler;
export {};
