/** @noSelfInFile */
export declare function readChunks(filename: string): string[];
/** The text of a file holding one chunk; undefined while it is missing or empty. Touches only the first level, for polling. */
export declare function readChunk(filename: string): string | undefined;
/** Writes a one-line file for a host tool to poll. */
export declare function writeLine(filename: string, line: string): void;
/** Writes a file of Preload lines for a host tool to read. */
export declare function writeLines(filename: string, lines: readonly string[]): void;
/**
 * Writes text the map reads back with readChunks: each line of the file sets
 * one tooltip level of the FileIO ability. False, writing nothing, for text
 * that does not fit or cannot be stored.
 */
export declare function writeChunks(filename: string, chunks: readonly string[]): boolean;
