/** @noSelfInFile */
/** Frames the overlay summarizes and each side of a reload's report covers: two seconds at 60 frames a second. */
export declare const FRAME_WINDOW = 120;
export interface FrameMeterOptions {
    /** The handler the game runs once per frame, such as its 60 Hz timer's: each run ends a frame. */
    readonly frame: string;
    /** The game's simulation frame; what it advanced during a frame is that frame's catch-up. */
    readonly simulationFrame?: (this: void) => number;
    /** Chat text that shows or hides the overlay for the player who types it. */
    readonly toggle: string;
}
/** Starts a bounded native capture after the current frame; no handles are created or freed. */
export declare function startFrameCostCapture(frames: number): number;
/**
 * Makes the dispatch table's run measure every callback and registers the
 * overlay's toggle. Call in every install(), after installDispatch(): a
 * reloaded bundle installs its own run.
 */
export declare function installFrameMeter(): void;
/**
 * Starts measuring and creates the overlay, hidden. Call once at match start,
 * after the first install(), in every client.
 */
export declare function startFrameMeter(options: FrameMeterOptions): void;
