/** @noSelfInFile */
/** What a reloadable bundle exports: re-register handlers, keep state. */
export interface Reloadable {
    install(this: void): void;
}
/** Registers the reloader's handlers; a reloaded bundle calls this again. */
export declare function installHotReload(): void;
/** Starts polling for new bundles. Call once, at match start. */
export declare function startHotReload(): void;
