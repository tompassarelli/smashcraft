var __defProp = Object.defineProperty;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __hasOwnProp = Object.prototype.hasOwnProperty;
function __accessProp(key) {
  return this[key];
}
var __toCommonJS = (from) => {
  var entry = (__moduleCache ??= new WeakMap).get(from), desc;
  if (entry)
    return entry;
  entry = __defProp({}, "__esModule", { value: true });
  if (from && typeof from === "object" || typeof from === "function") {
    for (var key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(entry, key))
        __defProp(entry, key, {
          get: __accessProp.bind(from, key),
          enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable
        });
  }
  __moduleCache.set(from, entry);
  return entry;
};
var __moduleCache;
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};

// plugins/number-rules-service.ts
var exports_number_rules_service = {};
__export(exports_number_rules_service, {
  default: () => init
});
module.exports = __toCommonJS(exports_number_rules_service);
var import_node_path = require("node:path");

// plugins/number-rules.ts
var NUMBER_RULE_CODE = 9300;
var HOLEY_LENGTH_MESSAGE = "the length of an array that may hold undefined is any of its borders in Lua; loop to a fixed count or keep the count";
var ROUNDING_HELPER_FILE = "/src/sim/f32.ts";
function isDeclaredIn(declarations, fileSuffix) {
  const file = declarations[0]?.fileName;
  return file !== undefined && (file.endsWith(fileSuffix) || file.endsWith(fileSuffix.replace(/\.ts$/, ".d.ts")));
}
function stands(test, declarations) {
  if (test === "standardLibrary")
    return declarations.some((declaration) => declaration.isDefaultLibrary);
  if (test === "warcraftNative")
    return isDeclaredIn(declarations, NATIVES_FILE);
  if (test === "roundingHelper")
    return isDeclaredIn(declarations, ROUNDING_HELPER_FILE);
  return !isDeclaredIn(declarations, ROUNDING_HELPER_FILE);
}
var NATIVES_FILE = "/src/natives/warcraft.d.ts";
var LIBRARY_MATH = new Set(["sin", "cos", "tan", "asin", "acos", "atan", "atan2", "sinh", "cosh", "tanh", "asinh", "acosh", "atanh", "exp", "expm1", "log", "log1p", "log2", "log10", "pow", "cbrt", "hypot", "sqrt"]);
var LIBRARY_MATH_MESSAGE = (name) => `Math.${name} comes from the platform's math library, which differs by an ulp between Bun and Warcraft; use wisp/src/sim/binary32 or the game's own approximation`;
var WARCRAFT_MATH = new Set(["Sin", "Cos", "Tan", "Asin", "Acos", "Atan", "Atan2", "SquareRoot", "Pow", "Deg2Rad", "Rad2Deg", "SinBJ", "CosBJ", "TanBJ", "AsinBJ", "AcosBJ", "AtanBJ", "Atan2BJ"]);
var WARCRAFT_RANDOM = new Set(["GetRandomInt", "GetRandomReal"]);
var RUNTIME_SERVICES = new Map([
  ["Date", "Date has no deterministic meaning in Warcraft; synchronized time is the frame counter"],
  ["JSON", "JSON isn't available in Warcraft's Lua"],
  ["Intl", "Intl isn't available in Warcraft's Lua"]
]);
function scanNumberRules(syntax, file) {
  if (file.fileName.endsWith("/src/sim/intMath.ts"))
    return [];
  const { SyntaxKind: kind } = syntax;
  const isMathMember = (node, member) => syntax.isPropertyAccessExpression(node) && syntax.isIdentifier(node.expression) && node.expression.text === "Math" && node.name.text === member;
  const isTest = file.fileName.endsWith(".tests.ts");
  const enclosingRounding = (node) => {
    for (let outer = node.parent;outer !== undefined && outer !== file; outer = outer.parent) {
      if (syntax.isCallExpression(outer) && syntax.isIdentifier(outer.expression) && outer.expression.text === "f32")
        return outer.expression;
    }
    return;
  };
  const findings = [];
  const reject = (node, message) => findings.push({ node, message });
  const visit = (node) => {
    if (syntax.isNumericLiteral(node)) {
      const text = node.getText();
      const value = Number(node.text);
      if (/[.eE]/.test(text) && Math.fround(value) !== value) {
        let outer = node;
        while (syntax.isParenthesizedExpression(outer.parent) || syntax.isPrefixUnaryExpression(outer.parent) && outer.parent.operator === kind.MinusToken) {
          outer = outer.parent;
        }
        const call = outer.parent;
        const message = `${text} isn't a binary32 value; write ${Math.fround(value)} or f32(${text})`;
        if (!syntax.isCallExpression(call) || call.arguments.length !== 1)
          reject(node, message);
        else if (syntax.isIdentifier(call.expression) && call.expression.text === "f32") {
          findings.push({ node, message, condition: { identifier: call.expression, test: "notRoundingHelper" } });
        } else if (!isMathMember(call.expression, "fround"))
          reject(node, message);
      }
    } else if (syntax.isBinaryExpression(node)) {
      const operator = node.operatorToken.kind;
      if (operator === kind.PercentToken || operator === kind.PercentEqualsToken) {
        reject(node.operatorToken, "`%` truncates in JavaScript and floors in Lua; use floorMod or imod");
      } else if (operator === kind.GreaterThanGreaterThanGreaterThanToken || operator === kind.GreaterThanGreaterThanGreaterThanEqualsToken) {
        reject(node.operatorToken, "`>>>` masks with 2^32 - 1, which 32-bit Lua can't hold; use floorDiv");
      }
    } else if (syntax.isCallExpression(node)) {
      let argument = node.arguments[0];
      while (argument !== undefined && syntax.isParenthesizedExpression(argument))
        argument = argument.expression;
      if (isMathMember(node.expression, "floor") && argument !== undefined && syntax.isBinaryExpression(argument) && argument.operatorToken.kind === kind.SlashToken) {
        reject(node, "Math.floor(a / b) divides in binary32 and loses bits above 2^24; use floorDiv or idiv");
      } else if (isMathMember(node.expression, "random")) {
        reject(node, "Math.random differs between clients; draw from the synchronized simulation instead");
      } else if (syntax.isPropertyAccessExpression(node.expression) && syntax.isIdentifier(node.expression.expression) && node.expression.expression.text === "Math" && LIBRARY_MATH.has(node.expression.name.text)) {
        const rounding = enclosingRounding(node);
        if (rounding !== undefined)
          findings.push({ node, message: LIBRARY_MATH_MESSAGE(node.expression.name.text), condition: { identifier: rounding, test: "roundingHelper" } });
      } else if (syntax.isIdentifier(node.expression) && (WARCRAFT_MATH.has(node.expression.text) || WARCRAFT_RANDOM.has(node.expression.text))) {
        const name = node.expression.text;
        const message = WARCRAFT_RANDOM.has(name) ? `${name} draws from Warcraft's generator, which a headless replay can't repeat; draw from the synchronized simulation instead` : `${name} computes with Warcraft's math library, which a headless replay can't repeat; use wisp/src/sim/binary32 or the game's own approximation`;
        findings.push({ node, message, condition: { identifier: node.expression, test: "warcraftNative" } });
      }
    } else if (syntax.isPropertyAccessExpression(node) && node.name.text === "length") {
      const array = syntax.isIdentifier(node.expression) ? node.expression : syntax.isPropertyAccessExpression(node.expression) ? node.expression.name : undefined;
      if (array !== undefined)
        findings.push({ node, message: HOLEY_LENGTH_MESSAGE, holeyArray: array });
    } else if (syntax.isIdentifier(node)) {
      const service = RUNTIME_SERVICES.get(node.text);
      if (service !== undefined && !syntax.isTypeReferenceNode(node.parent)) {
        findings.push({ node, message: service, condition: { identifier: node, test: "standardLibrary" } });
      }
    } else if (!isTest) {
      if (syntax.isNonNullExpression(node))
        reject(node, "non-null `!` asserts what the code should check; handle the absent case");
      else if (node.kind === kind.AnyKeyword)
        reject(node, "`any` turns off type checking; name the type");
      else if (syntax.isAsExpression(node) && syntax.isAsExpression(node.expression) && node.expression.type.kind === kind.UnknownKeyword)
        reject(node, "`as unknown as` forces an unrelated type; convert the value instead");
    }
    node.forEachChild(visit);
  };
  visit(file);
  return findings;
}
function isHoleyArray(typescript, checker, type) {
  const mayBeUndefined = (element) => (element.flags & (typescript.TypeFlags.Undefined | typescript.TypeFlags.Void)) !== 0 || element.isUnion() && element.types.some(mayBeUndefined);
  if (type.isUnion())
    return type.types.some((member) => isHoleyArray(typescript, checker, member));
  if (!checker.isArrayType(type) && !checker.isTupleType(type))
    return false;
  return checker.getTypeArguments(type).some(mayBeUndefined);
}
function declarationsOf(typescript, program, node) {
  const checker = program.getTypeChecker();
  let symbol = checker.getSymbolAtLocation(node);
  if (symbol !== undefined && symbol.flags & typescript.SymbolFlags.Alias)
    symbol = checker.getAliasedSymbol(symbol);
  return (symbol?.declarations ?? []).map((declaration) => {
    const file = declaration.getSourceFile();
    return { fileName: file.fileName, isDefaultLibrary: program.isSourceFileDefaultLibrary(file) };
  });
}
var scans = new WeakMap;
function programNumberRules(typescript, program, file) {
  if (file.isDeclarationFile || program.isSourceFileFromExternalLibrary(file))
    return [];
  const checker = program.getTypeChecker();
  let findings = scans.get(file);
  if (findings === undefined) {
    findings = scanNumberRules(typescript, file);
    scans.set(file, findings);
  }
  const diagnostics = [];
  for (const { node, message, condition, holeyArray } of findings) {
    if (condition !== undefined && !stands(condition.test, declarationsOf(typescript, program, condition.identifier)))
      continue;
    if (holeyArray !== undefined && !isHoleyArray(typescript, checker, checker.getTypeAtLocation(holeyArray)))
      continue;
    diagnostics.push({
      category: typescript.DiagnosticCategory.Error,
      code: NUMBER_RULE_CODE,
      source: "warcraft",
      file,
      start: node.getStart(file),
      length: node.getWidth(file),
      messageText: message
    });
  }
  return diagnostics;
}

// plugins/number-rules-service.ts
function init({ typescript }) {
  const normalize = typescript.server.toNormalizedPath;
  return {
    create(info) {
      const service = info.languageService;
      const host = info.serverHost;
      let mapFiles;
      const inMap = (fileName) => {
        const { project } = info.config;
        if (project === undefined)
          return true;
        const configPath = import_node_path.resolve(info.project.getCurrentDirectory(), project);
        const key = `${host.getModifiedTime?.(configPath)?.getTime()}\x00${info.project.getRootFiles().join("\x00")}`;
        if (mapFiles?.key !== key) {
          const parsed = typescript.getParsedCommandLineOfConfigFile(configPath, {}, {
            useCaseSensitiveFileNames: host.useCaseSensitiveFileNames,
            fileExists: (path) => host.fileExists(path),
            readFile: (path) => host.readFile(path),
            readDirectory: (path, extensions, excludes, includes, depth) => host.readDirectory(path, extensions, excludes, includes, depth),
            getCurrentDirectory: () => host.getCurrentDirectory(),
            onUnRecoverableConfigFileDiagnostic: () => {}
          });
          mapFiles = { key, names: new Set((parsed?.fileNames ?? []).map(normalize)) };
        }
        return mapFiles.names.has(normalize(fileName));
      };
      const proxy = { ...service };
      proxy.getSemanticDiagnostics = (fileName) => {
        const diagnostics = service.getSemanticDiagnostics(fileName);
        const program = service.getProgram();
        const file = program?.getSourceFile(fileName);
        if (program === undefined || file === undefined || !inMap(fileName))
          return diagnostics;
        return [...diagnostics, ...programNumberRules(typescript, program, file)];
      };
      return proxy;
    }
  };
}

module.exports = module.exports.default;
