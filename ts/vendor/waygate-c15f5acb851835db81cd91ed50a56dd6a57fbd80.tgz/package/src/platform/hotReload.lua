local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__Number = ____lualib.__TS__Number
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local acknowledgementLine = ____gameFiles.acknowledgementLine
local ackFile = ____gameFiles.ackFile
local manifestFile = ____gameFiles.manifestFile
local parseManifest = ____gameFiles.parseManifest
local payloadFile = ____gameFiles.payloadFile
local payloadKey = ____gameFiles.payloadKey
local ____payload = require("src.runtime.payload")
local checksum = ____payload.checksum
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local ____dispatch = require("src.platform.dispatch")
local on = ____dispatch.on
local trampoline = ____dispatch.trampoline
local ____fileio = require("src.platform.fileio")
local readChunk = ____fileio.readChunk
local POLL_SECONDS = 0.25
local MAX_SLOTS = 4
local function hot()
    local globals = _G
    local state = globals[runtimeConfiguration().globalPrefix .. "Hot"]
    if state == nil then
        error(
            __TS__New(Error, "hot reload used before startHotReload"),
            0
        )
    end
    return state
end
local function isReloadable(value)
    return type(value) == "table" and value ~= nil and value.install ~= nil and type(value.install) == "function"
end
local function manifestExists(version)
    return readChunk(manifestFile(
        version,
        runtimeConfiguration().filePrefix
    )) ~= nil
end
--- The newest version published before this match. Manifests are never removed
-- and versions only rise, so existence is monotonic and a search finds it in
-- a logarithmic number of reads.
local function latestVersion()
    if not manifestExists(1) then
        return 0
    end
    local low = 1
    while manifestExists(low * 2) do
        low = low * 2
    end
    local high = low * 2
    while high - low > 1 do
        local middle = (low + high) // 2
        if manifestExists(middle) then
            low = middle
        else
            high = middle
        end
    end
    return low
end
local function playingHumans()
    local count = 0
    do
        local slot = 0
        while slot < MAX_SLOTS do
            local player = Player(slot)
            if GetPlayerSlotState(player) == PLAYER_SLOT_STATE_PLAYING and GetPlayerController(player) == MAP_CONTROL_USER then
                count = count + 1
            end
            slot = slot + 1
        end
    end
    return count
end
local function startClock()
    local clock = CreateTimer()
    TimerStart(
        clock,
        86400.0,
        false,
        function()
        end
    )
    return clock
end
local function report(text)
    DisplayTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        text
    )
end
local function poll()
    local state = hot()
    if state.localSlot ~= state.hostSlot then
        return
    end
    local text = readChunk(manifestFile(
        state.announced + 1,
        runtimeConfiguration().filePrefix
    ))
    if text == nil then
        return
    end
    state.announced = state.announced + 1
    BlzSendSyncData(
        runtimeConfiguration().announcePrefix,
        text
    )
end
--- This client's copy of an announced bundle, loaded but not run, or why it failed.
local function loadLocal(announcement)
    local manifest = parseManifest(announcement)
    if manifest == nil then
        return nil
    end
    local version = manifest.version
    local files = manifest.files
    local expected = manifest.checksum
    local parts = {}
    do
        local index = 0
        while index < files do
            parts[#parts + 1] = readChunk(payloadFile(
                expected,
                index,
                runtimeConfiguration().filePrefix
            )) or ""
            index = index + 1
        end
    end
    local text = table.concat(parts, "")
    if checksum(
        #text,
        function(index) return string.byte(text, index + 1) end
    ) ~= expected then
        return {version = version, bundle = "payload missing or damaged"}
    end
    local chunk, ____error = load(
        text,
        "=hot-" .. payloadKey(expected)
    )
    if chunk == nil then
        return {version = version, bundle = ____error or "load failed"}
    end
    local ran, module = pcall(chunk)
    if not ran then
        return {
            version = version,
            bundle = "failed while loading: " .. tostring(module)
        }
    end
    return {
        version = version,
        bundle = isReloadable(module) and module or "bundle exports no install()"
    }
end
local function announced()
    local state = hot()
    local ____local = loadLocal(BlzGetTriggerSyncData())
    if ____local == nil or ____local.version <= state.applied then
        return
    end
    state.pending = __TS__ObjectAssign(
        {},
        ____local,
        {
            waiting = playingHumans(),
            refused = false
        }
    )
    BlzSendSyncData(
        runtimeConfiguration().readyPrefix,
        (tostring(____local.version) .. " ") .. (type(____local.bundle) == "string" and "refuse" or "ready")
    )
end
local function answered()
    local state = hot()
    local pending = state.pending
    local versionText, answer = table.unpack(
        __TS__StringSplit(
            BlzGetTriggerSyncData(),
            " "
        ),
        1,
        2
    )
    if pending == nil or __TS__Number(versionText) ~= pending.version then
        return
    end
    if answer ~= "ready" then
        pending.refused = true
    end
    pending.waiting = pending.waiting - 1
    if pending.waiting > 0 then
        return
    end
    state.pending = nil
    local version = pending.version
    local bundle = pending.bundle
    if pending.refused or type(bundle) == "string" then
        report((("hot reload " .. tostring(version)) .. " not applied: ") .. (type(bundle) == "string" and bundle or "another client couldn't load it"))
        return
    end
    bundle.install()
    state.applied = version
    if state.clock == nil then
        state.clock = startClock()
    end
    PreloadGenClear()
    PreloadGenStart()
    Preload(acknowledgementLine(
        version,
        TimerGetElapsed(state.clock)
    ))
    PreloadGenEnd(ackFile(
        state.localSlot,
        runtimeConfiguration().filePrefix
    ))
    report(("hot reload " .. tostring(version)) .. " applied")
end
--- Registers the reloader's handlers; a reloaded bundle calls this again.
function ____exports.installHotReload()
    on("hotReload.poll", poll)
    on("hotReload.announced", announced)
    on("hotReload.answered", answered)
end
local function onSync(prefix, handler)
    local trigger = CreateTrigger()
    do
        local slot = 0
        while slot < MAX_SLOTS do
            BlzTriggerRegisterPlayerSyncEvent(
                trigger,
                Player(slot),
                prefix,
                false
            )
            slot = slot + 1
        end
    end
    TriggerAddAction(
        trigger,
        trampoline(handler)
    )
end
--- Starts polling for new bundles; the host slot announces them.
function ____exports.startHotReload(hostSlot, localSlot)
    local configuration = runtimeConfiguration()
    local globals = _G
    globals[configuration.globalPrefix .. "Hot"] = {
        announced = latestVersion(),
        applied = 0,
        hostSlot = hostSlot,
        localSlot = localSlot,
        pending = nil
    }
    ____exports.installHotReload()
    onSync(configuration.announcePrefix, "hotReload.announced")
    onSync(configuration.readyPrefix, "hotReload.answered")
    TimerStart(
        CreateTimer(),
        POLL_SECONDS,
        true,
        trampoline("hotReload.poll")
    )
end
return ____exports
