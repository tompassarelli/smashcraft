local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local ____exports = {}
____exports.registeredTests = {}
function ____exports.test(name, run)
    local ____exports_registeredTests_0 = ____exports.registeredTests
    ____exports_registeredTests_0[#____exports_registeredTests_0 + 1] = {name = name, run = run}
end
____exports.AssertionFailure = __TS__Class()
local AssertionFailure = ____exports.AssertionFailure
AssertionFailure.name = "AssertionFailure"
function AssertionFailure.prototype.____constructor(self, message)
    self.message = message
end
local function fail(message)
    error(
        __TS__New(____exports.AssertionFailure, message),
        0
    )
end
function ____exports.assertTrue(value)
    if value ~= true then
        fail("expected true")
    end
end
function ____exports.assertFalse(value)
    if value ~= false then
        fail("expected false")
    end
end
--- Exact equality (Object.is semantics except that 0 equals -0).
function ____exports.assertEquals(actual, expected, message)
    if actual ~= expected then
        fail(((((message == nil and "" or message .. ": ") .. "expected ") .. tostring(expected)) .. ", actual ") .. tostring(actual))
    end
end
function ____exports.assertNear(actual, expected, delta)
    if math.abs(actual - expected) > delta then
        fail((((("expected " .. tostring(expected)) .. " within ") .. tostring(delta)) .. ", actual ") .. tostring(actual))
    end
end
function ____exports.assertGreaterThan(actual, bound)
    if not (actual > bound) then
        fail((("expected more than " .. tostring(bound)) .. ", actual ") .. tostring(actual))
    end
end
function ____exports.assertLessThan(actual, bound)
    if not (actual < bound) then
        fail((("expected less than " .. tostring(bound)) .. ", actual ") .. tostring(actual))
    end
end
--- The value, or a failure when it is undefined.
function ____exports.assertDefined(value, what)
    if what == nil then
        what = "value"
    end
    if value == nil then
        fail(("expected " .. what) .. " to be defined")
    end
    return value
end
return ____exports
