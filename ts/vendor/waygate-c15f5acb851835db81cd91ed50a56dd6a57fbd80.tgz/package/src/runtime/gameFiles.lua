local ____lualib = require("lualib_bundle")
local __TS__StringReplace = ____lualib.__TS__StringReplace
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__Number = ____lualib.__TS__Number
local ____exports = {}
--- FileIO stores one chunk per tooltip level of its ability.
____exports.CHUNKS_PER_FILE = 64
--- Bundle bytes per payload file. The file is raw Lua that stores them in one
-- tooltip; a 200,000-character tooltip read back intact in the game.
____exports.PAYLOAD_FILE_BYTES = 200000
--- The FileIO ability ('$wsl') whose tooltips carry text from host files.
____exports.FILE_IO_ABILITY = 611808108
--- Player slots that write their own copy of a per-slot file.
____exports.FILE_SLOTS = 4
____exports.manifestFile = function(version, prefix)
    if prefix == nil then
        prefix = "waygate"
    end
    return ((prefix .. "-hot-manifest-") .. tostring(version)) .. ".pld"
end
--- Names a bundle in file names and as its Lua chunk name, which error positions carry.
____exports.payloadKey = function(payloadChecksum) return __TS__StringReplace(payloadChecksum, ":", "-") end
____exports.payloadFile = function(payloadChecksum, index, prefix)
    if prefix == nil then
        prefix = "waygate"
    end
    return ((((prefix .. "-hot-") .. ____exports.payloadKey(payloadChecksum)) .. "-") .. tostring(index)) .. ".pld"
end
____exports.ackFile = function(slot, prefix)
    if prefix == nil then
        prefix = "waygate"
    end
    return ((prefix .. "-hot-ack-p") .. tostring(slot)) .. ".txt"
end
____exports.errorFile = function(slot, prefix)
    if prefix == nil then
        prefix = "waygate"
    end
    return ((prefix .. "-error-p") .. tostring(slot)) .. ".txt"
end
____exports.formatManifest = function(____bindingPattern0)
    local checksum
    local files
    local version
    version = ____bindingPattern0.version
    files = ____bindingPattern0.files
    checksum = ____bindingPattern0.checksum
    return (((tostring(version) .. " ") .. tostring(files)) .. " ") .. checksum
end
function ____exports.parseManifest(text)
    local versionText, filesText, checksum = table.unpack(
        __TS__StringSplit(text, " "),
        1,
        3
    )
    local version = __TS__Number(versionText)
    local files = __TS__Number(filesText)
    if not (version >= 1) or not (files >= 1) or checksum == nil then
        return nil
    end
    return {version = version, files = files, checksum = checksum}
end
--- The acknowledgement: the version every client installed, at the reloader's game time in seconds.
____exports.acknowledgementLine = function(version, elapsed) return (("applied " .. tostring(version)) .. " at ") .. tostring(elapsed) end
--- An error report's first line; the message and each stack line follow, one line each.
____exports.errorHeading = function(count, handler) return (("error " .. tostring(count)) .. " in ") .. handler end
return ____exports
