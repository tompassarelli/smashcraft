/** @noSelfInFile */
/** File, synchronized-message and persistent-state identities shared across reloads. */
export interface RuntimeConfiguration {
    readonly filePrefix: string;
    readonly announcePrefix: string;
    readonly readyPrefix: string;
    readonly globalPrefix: string;
}
/** Call before installing handlers in every bundle. Retain these values across live reloads. */
export declare function configureRuntime(next: RuntimeConfiguration): void;
export declare function runtimeConfiguration(): RuntimeConfiguration;
