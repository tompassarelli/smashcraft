local ____exports = {}
local binary32Infinity, decompose, scaleByPowerOfTwo, multiplySignificands, shiftRightJam, addLimbs, lessThan, subtractLimbs, bitLength, roundLimbs
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local floorMod = ____intMath.floorMod
function binary32Infinity()
    local result = 16777216.0
    do
        local i = 1
        while i <= 6 do
            result = result * result
            i = i + 1
        end
    end
    return result
end
function decompose(value)
    local normalized = value < 0 and -value or value
    local exponent = -23
    while normalized >= 2 do
        normalized = normalized * 0.5
        exponent = exponent + 1
    end
    while normalized < 1 do
        normalized = normalized * 2
        exponent = exponent - 1
    end
    return {
        significand = math.floor(normalized * 8388608.0),
        exponent = exponent
    }
end
function scaleByPowerOfTwo(value, scale)
    local result = value * 1.0
    if scale < 0 then
        do
            local i = 1
            while i <= -scale do
                result = result * 0.5
                i = i + 1
            end
        end
    else
        do
            local i = 1
            while i <= scale do
                result = result * 2.0
                i = i + 1
            end
        end
    end
    return result
end
function multiplySignificands(a, b)
    local aLow = a % 4096
    local bLow = b % 4096
    local aHigh = a // 4096
    local bHigh = b // 4096
    local first = aLow * bLow
    local second = first // 4096 + aHigh * bLow + aLow * bHigh
    return {high = aHigh * bHigh + second // 4096, low = first % 4096 + second % 4096 * 4096}
end
function shiftRightJam(value, count)
    if count >= 72 then
        return {high = 0, middle = 0, low = (value.high ~= 0 or value.middle ~= 0 or value.low ~= 0) and 1 or 0}
    end
    local result = value
    local remaining = count
    while remaining >= 24 do
        local lost = result.low ~= 0
        result = {high = 0, middle = result.high, low = result.middle}
        if lost and result.low % 2 == 0 then
            result.low = result.low + 1
        end
        remaining = remaining - 24
    end
    do
        local i = 1
        while i <= remaining do
            local lost = result.low % 2 ~= 0
            result = {high = result.high // 2, middle = result.middle // 2 + result.high % 2 * 8388608, low = result.low // 2 + result.middle % 2 * 8388608}
            if lost and result.low % 2 == 0 then
                result.low = result.low + 1
            end
            i = i + 1
        end
    end
    return result
end
function addLimbs(a, b)
    local lowSum = a.low + b.low
    local middleSum = a.middle + b.middle + lowSum // 16777216
    return {high = a.high + b.high + middleSum // 16777216, middle = middleSum % 16777216, low = lowSum % 16777216}
end
function lessThan(a, b)
    return a.high < b.high or a.high == b.high and (a.middle < b.middle or a.middle == b.middle and a.low < b.low)
end
function subtractLimbs(a, b)
    local low = a.low - b.low
    local middle = a.middle - b.middle
    local high = a.high - b.high
    if low < 0 then
        low = low + 16777216
        middle = middle - 1
    end
    if middle < 0 then
        middle = middle + 16777216
        high = high - 1
    end
    return {high = high, middle = middle, low = low}
end
function bitLength(value)
    local remaining = value
    local result = 0
    while remaining ~= 0 do
        remaining = remaining // 2
        result = result + 1
    end
    return result
end
function roundLimbs(value, scale, negative)
    local bits = value.high ~= 0 and 48 + bitLength(value.high) or (value.middle ~= 0 and 24 + bitLength(value.middle) or bitLength(value.low))
    if bits == 0 then
        return 0.0
    end
    local shift = bits - 24
    if scale + shift < -149 then
        shift = -149 - scale
    end
    local rounded = value.low
    local resultScale = scale
    if shift >= 2 then
        local truncated = shiftRightJam(value, shift - 2)
        rounded = truncated.middle * 4194304 + truncated.low // 4
        local remainder = truncated.low % 4
        if remainder > 2 or remainder == 2 and rounded % 2 ~= 0 then
            rounded = rounded + 1
        end
        resultScale = resultScale + shift
    elseif shift == 1 then
        rounded = value.middle * 8388608 + value.low // 2
        if value.low % 2 ~= 0 and rounded % 2 ~= 0 then
            rounded = rounded + 1
        end
        resultScale = resultScale + 1
    end
    if resultScale + bitLength(rounded) > 128 then
        return negative and -binary32Infinity() or binary32Infinity()
    end
    local result = scaleByPowerOfTwo(rounded, resultScale)
    return negative and -result or result
end
--- a * b + c with one binary32 rounding. Inputs must be finite binary32 values;
-- the exact product may leave binary32 range before cancellation.
function ____exports.fusedMultiplyAddFloat32(a, b, c)
    if a == 0 or b == 0 then
        return a * b + c
    end
    local left = decompose(a)
    local right = decompose(b)
    local product = multiplySignificands(left.significand, right.significand)
    local magnitude = {high = product.high // 2, middle = product.high % 2 * 8388608 + product.low // 2, low = product.low % 2 * 8388608}
    local scale = left.exponent + right.exponent - 23
    local negative = a < 0 ~= (b < 0)
    if c ~= 0 then
        local addend = decompose(c)
        local other = {high = addend.significand // 2, middle = addend.significand % 2 * 8388608, low = 0}
        local otherScale = addend.exponent - 47
        if scale < otherScale then
            magnitude = shiftRightJam(magnitude, otherScale - scale)
            scale = otherScale
        else
            other = shiftRightJam(other, scale - otherScale)
        end
        if negative == (c < 0) then
            magnitude = addLimbs(magnitude, other)
        elseif lessThan(magnitude, other) then
            magnitude = subtractLimbs(other, magnitude)
            negative = c < 0
        else
            magnitude = subtractLimbs(magnitude, other)
        end
    end
    return roundLimbs(magnitude, scale, negative)
end
--- Truncation toward zero, which Lua and JavaScript both emit exactly.
function ____exports.toInt(value)
    return value < 0 and math.ceil(value) or math.floor(value)
end
--- Rounds to the nearest binary32 value; NaN and infinity pass through.
function ____exports.roundToFloat32(value)
    if value == 0 or value ~= value then
        return value
    end
    local negative = value < 0
    local significand = negative and -value or value
    local scale = 1.0
    local exponent = 0
    while significand >= 2 and exponent < 127 do
        significand = significand * 0.5
        scale = scale * 2
        exponent = exponent + 1
    end
    if significand >= 2 then
        return negative and -binary32Infinity() or binary32Infinity()
    end
    while significand < 1 and exponent > -126 do
        significand = significand * 2
        scale = scale * 0.5
        exponent = exponent - 1
    end
    local units = significand * 8388608.0
    local rounded = math.floor(units)
    local remainder = units - rounded
    if remainder > 0.5 or remainder == 0.5 and rounded % 2 ~= 0 then
        rounded = rounded + 1
    end
    if exponent == 127 and rounded == 16777216 then
        return negative and -binary32Infinity() or binary32Infinity()
    end
    local result = rounded / 8388608.0 * scale
    return negative and -result or result
end
function ____exports.addFloat32(a, b)
    return ____exports.fusedMultiplyAddFloat32(1.0, a, b)
end
function ____exports.subtractFloat32(a, b)
    return ____exports.fusedMultiplyAddFloat32(-1.0, b, a)
end
function ____exports.multiplyFloat32(a, b)
    return ____exports.fusedMultiplyAddFloat32(a, b, 0.0)
end
--- Long division keeps the quotient and sticky remainder; a zero divisor gives NaN.
function ____exports.divideFloat32(numerator, denominator)
    if denominator == 0 then
        local infinity = binary32Infinity()
        return infinity - infinity
    end
    if numerator == 0 then
        return numerator
    end
    local left = decompose(numerator)
    local right = decompose(denominator)
    local negative = numerator < 0 ~= (denominator < 0)
    local remainder = left.significand
    local exponent = left.exponent - right.exponent
    if remainder < right.significand then
        remainder = remainder * 2
        exponent = exponent - 1
    end
    remainder = remainder - right.significand
    local quotient = 1
    do
        local i = 1
        while i <= 26 do
            remainder = remainder * 2
            quotient = quotient * 2
            if remainder >= right.significand then
                remainder = remainder - right.significand
                quotient = quotient + 1
            end
            i = i + 1
        end
    end
    local rounded = quotient // 8
    local roundingBits = quotient % 8
    if roundingBits > 4 or roundingBits == 4 and (remainder ~= 0 or rounded % 2 ~= 0) then
        rounded = rounded + 1
    end
    local scale = exponent - 23
    if exponent < -126 then
        local subnormalShift = exponent + 149
        if subnormalShift < -1 then
            return 0.0
        end
        if subnormalShift == -1 then
            rounded = (quotient ~= 67108864 or remainder ~= 0) and 1 or 0
        else
            local divisor = 1
            do
                local i = 1
                while i <= 26 - subnormalShift do
                    divisor = divisor * 2
                    i = i + 1
                end
            end
            rounded = quotient // divisor
            local roundingRemainder = quotient % divisor
            if roundingRemainder * 2 > divisor or roundingRemainder * 2 == divisor and (remainder ~= 0 or rounded % 2 ~= 0) then
                rounded = rounded + 1
            end
        end
        scale = -149
    elseif rounded == 16777216 then
        rounded = 8388608
        exponent = exponent + 1
        scale = exponent - 23
    end
    if exponent > 127 or exponent == 127 and rounded == 16777216 then
        return negative and -binary32Infinity() or binary32Infinity()
    end
    local result = scaleByPowerOfTwo(rounded, scale)
    return negative and -result or result
end
--- Correctly rounded square root of a binary32 input, independent of host math.
function ____exports.squareRootFloat32(value)
    if value == 0 or value ~= value then
        return value
    end
    if value < 0 then
        local infinity = binary32Infinity()
        return infinity - infinity
    end
    if value - value ~= 0 then
        return value
    end
    local parts = decompose(value)
    local significand = parts.significand
    local exponent = parts.exponent + 23
    if exponent % 2 ~= 0 then
        significand = significand * 2
        exponent = exponent - 1
    end
    local high = significand // 2
    local low = significand % 2 * 8388608
    local remainder = 0
    local root = 0
    do
        local i = 0
        while i < 24 do
            local pair = high // 4194304
            high = high % 4194304 * 4 + low // 4194304
            low = low % 4194304 * 4
            remainder = remainder * 4 + pair
            local trial = root * 4 + 1
            root = root * 2
            if remainder >= trial then
                remainder = remainder - trial
                root = root + 1
            end
            i = i + 1
        end
    end
    if remainder > root then
        root = root + 1
    end
    return scaleByPowerOfTwo(root, exponent // 2 - 23)
end
return ____exports
