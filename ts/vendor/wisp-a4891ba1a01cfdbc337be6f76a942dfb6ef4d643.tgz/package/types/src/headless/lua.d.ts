/** @noSelfInFile */
import type { ClientScope, LocalNatives } from "./client";
import type { FrameTemplate } from "./frames";
import type { SyncDelivery } from "./lockstep";
import { type Journey } from "./journey";
import { Lockstep } from "./lockstep";
/** What a game declares about its map for a headless run. */
export interface LuaHeadlessMap {
    /** The map's configureRuntime() filePrefix. */
    readonly filePrefix: string;
    readonly localNatives?: LocalNatives;
    /** Human player slots, one client each; two by default. */
    readonly players?: readonly number[];
    /** Frame definitions (wisp:docs/ui.md) whose trees BlzCreateFrame makes by name, as their generated FDF does in Warcraft. */
    readonly frames?: readonly FrameTemplate[];
}
/** A file's bytes, for a host program running in Lua. */
export declare function readFile(path: string): string;
/**
 * Clients that each run `bundle`, the map's compiled Lua, with the natives
 * `declarations` (warcraft.d.ts) lists; `scope` sees each client run, and
 * `delivery` delays synchronized messages as Warcraft does.
 */
export declare function luaLockstep(map: LuaHeadlessMap, bundle: string, declarations: string, scope?: ClientScope, delivery?: SyncDelivery): Lockstep;
/** Plays `journey` with the bundle and declarations at these paths, prints its result, and returns how many problems it found. */
export declare function runLuaJourney(map: LuaHeadlessMap, journey: Journey, bundlePath: string, declarationsPath: string): number;
