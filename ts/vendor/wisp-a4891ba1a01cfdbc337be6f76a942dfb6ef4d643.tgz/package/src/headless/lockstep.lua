local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local ackFile = ____gameFiles.ackFile
local formatManifest = ____gameFiles.formatManifest
local hostFile = ____gameFiles.hostFile
local manifestFile = ____gameFiles.manifestFile
local ____modules = require("src.runtime.modules")
local ModulePublisher = ____modules.ModulePublisher
local ____client = require("src.headless.client")
local HeadlessClient = ____client.HeadlessClient
local WISP_LOCAL_NATIVES = ____client.WISP_LOCAL_NATIVES
local describeCall = ____client.describeCall
local sameCall = ____client.sameCall
--- The key a typed character presses outside an edit box, with its modifiers (1: Shift); undefined for one with no key.
local function typedKey(code)
    if code >= 97 and code <= 122 then
        return {code - 32, 0}
    end
    if code >= 65 and code <= 90 then
        return {code, 1}
    end
    if code >= 48 and code <= 57 or code == 32 then
        return {code, 0}
    end
    return nil
end
--- Synchronized messages that keep causing more are a defect, not a frame.
local MAX_MESSAGES_PER_FLUSH = 10000
____exports.Lockstep = __TS__Class()
local Lockstep = ____exports.Lockstep
Lockstep.name = "Lockstep"
function Lockstep.prototype.____constructor(self, options)
    self.network = {}
    self.frame = 0
    self.version = 0
    self.files = nil
    self.inFlight = {}
    self.costs = {}
    self.options = options
    self.publisher = __TS__New(ModulePublisher, options.filePrefix, options.hash)
    local localNatives = __TS__ObjectAssign({}, WISP_LOCAL_NATIVES, options.localNatives)
    local clients = {}
    do
        local index = 0
        while index < #options.players do
            local slot = options.players[index + 1] or index
            local ____opt_0 = options.files
            local files = ____opt_0 and ____opt_0(slot)
            clients[#clients + 1] = __TS__New(
                HeadlessClient,
                __TS__ObjectAssign(
                    {
                        slot = slot,
                        filePrefix = options.filePrefix,
                        humans = options.players,
                        declarations = options.declarations,
                        localNatives = localNatives,
                        network = self.network,
                        screenWidth = 1920 + 640 * index
                    },
                    options.scope == nil and ({}) or ({scope = options.scope}),
                    options.natives == nil and ({}) or ({natives = options.natives}),
                    files == nil and ({}) or ({files = files}),
                    options.frames == nil and ({}) or ({frames = options.frames})
                )
            )
            index = index + 1
        end
    end
    self.clients = clients
end
function Lockstep.prototype.start(self, options)
    if options == nil then
        options = {}
    end
    if options.hostFolder ~= false then
        self:prepareHostFolder()
    end
    local entry = self.options.entry
    for ____, client in ipairs(self.clients) do
        client:run(function() return entry(client).start() end)
    end
    self:flush()
end
function Lockstep.prototype.everywhere(self, body)
    for ____, client in ipairs(self.clients) do
        client:run(body)
    end
    self:flush()
end
function Lockstep.prototype.flush(self)
    local delivery = self.options.delivery
    if delivery ~= nil then
        do
            local message = table.remove(self.network, 1)
            while message ~= nil do
                local arrival = delivery.arrivalFrame(message.sender, self.frame, message)
                if arrival <= self.frame then
                    do
                        local ____thrown = __TS__New(
                            Error,
                            (("a message sent during frame " .. tostring(self.frame)) .. " arrives at frame ") .. tostring(arrival)
                        )
                        if _G.__wispThrown ~= ____thrown then
                            _G.__wispThrown = ____thrown
                            _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:144"
                        end
                        error(____thrown, 0)
                    end
                end
                local index = #self.inFlight
                while true do
                    local ____temp_4 = index > 0
                    if ____temp_4 then
                        local ____opt_2 = self.inFlight[index]
                        ____temp_4 = (____opt_2 and ____opt_2.arrival or 0) > arrival
                    end
                    if not ____temp_4 then
                        break
                    end
                    index = index - 1
                end
                __TS__ArraySplice(self.inFlight, index, 0, {arrival = arrival, message = message})
                message = table.remove(self.network, 1)
            end
        end
        return
    end
    do
        local delivered = 0
        while #self.network > 0 do
            if delivered > MAX_MESSAGES_PER_FLUSH then
                do
                    local ____thrown = __TS__New(Error, "synchronized messages never settle")
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:152"
                    end
                    error(____thrown, 0)
                end
            end
            local message = table.remove(self.network, 1)
            if message ~= nil then
                for ____, client in ipairs(self.clients) do
                    client:deliverSync(message)
                end
            end
            delivered = delivered + 1
        end
    end
end
function Lockstep.prototype.arrive(self)
    while true do
        local ____opt_9 = self.inFlight[1]
        if not ((____opt_9 and ____opt_9.arrival or self.frame + 1) <= self.frame) then
            break
        end
        do
            local due = table.remove(self.inFlight, 1)
            if due == nil then
                goto __continue30
            end
            do
                local index = 0
                while index < #self.clients do
                    local ____opt_5 = self.options.cost
                    local started = ____opt_5 and ____opt_5()
                    local ____opt_7 = self.clients[index + 1]
                    if ____opt_7 ~= nil then
                        ____opt_7:deliverSync(due.message)
                    end
                    self:charge(index, started)
                    index = index + 1
                end
            end
        end
        ::__continue30::
    end
    self:flush()
end
function Lockstep.prototype.frames(self, count)
    do
        local frame = 0
        while frame < count do
            self.frame = self.frame + 1
            do
                local index = 0
                while index < #self.clients do
                    self.costs[index + 1] = 0
                    index = index + 1
                end
            end
            self:arrive()
            do
                local index = 0
                while index < #self.clients do
                    local ____opt_11 = self.options.cost
                    local started = ____opt_11 and ____opt_11()
                    local ____opt_13 = self.clients[index + 1]
                    if ____opt_13 ~= nil then
                        ____opt_13:step()
                    end
                    self:charge(index, started)
                    index = index + 1
                end
            end
            self:flush()
            self:settle()
            frame = frame + 1
        end
    end
end
function Lockstep.prototype.charge(self, index, started)
    local clock = self.options.cost
    if clock ~= nil and started ~= nil then
        self.costs[index + 1] = (self.costs[index + 1] or 0) + clock() - started
    end
end
function Lockstep.prototype.settle(self)
    local keep = self.options.keepCalls
    if keep == nil then
        return
    end
    if self.divergence == nil then
        local divergence = self:compare()
        if divergence ~= nil then
            self.divergence = (("after frame " .. tostring(self.frame)) .. ", ") .. divergence
        end
    end
    for ____, client in ipairs(self.clients) do
        if #client.log > keep then
            client:forget(#client.log - keep)
        end
    end
end
function Lockstep.prototype.chat(self, sender, message)
    for ____, client in ipairs(self.clients) do
        client:chat(sender, message)
    end
    self:flush()
end
function Lockstep.prototype.press(self, sender, key, meta)
    if meta == nil then
        meta = 0
    end
    for ____, down in ipairs({true, false}) do
        for ____, client in ipairs(self.clients) do
            client:key(sender, key, meta, down)
        end
        self:flush()
    end
end
function Lockstep.prototype.client(self, slot)
    for ____, client in ipairs(self.clients) do
        if client.slot == slot then
            return client
        end
    end
    do
        local ____thrown = __TS__New(
            Error,
            "no client plays slot " .. tostring(slot)
        )
        if _G.__wispThrown ~= ____thrown then
            _G.__wispThrown = ____thrown
            _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:224"
        end
        error(____thrown, 0)
    end
end
function Lockstep.prototype.type(self, sender, text)
    if self:client(sender):type(text) then
        return
    end
    do
        local index = 0
        while index < #text do
            local key = typedKey(__TS__StringCharCodeAt(text, index))
            if key == nil then
                do
                    local ____thrown = __TS__New(
                        Error,
                        ("no key types \"" .. __TS__StringCharAt(text, index)) .. "\" outside an edit box"
                    )
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/lockstep.ts:236"
                    end
                    error(____thrown, 0)
                end
            end
            self:press(sender, key[1], key[2])
            index = index + 1
        end
    end
end
function Lockstep.prototype.click(self, sender, x, y)
    local clicker = self:client(sender)
    local frame = clicker:clickTarget(x, y)
    if frame == nil then
        return false
    end
    clicker.frames:focus(frame, true)
    local click = clicker.natives.FRAMEEVENT_CONTROL_CLICK
    for ____, client in ipairs(self.clients) do
        client:frameEvent(sender, frame.id, click)
    end
    self:flush()
    return true
end
function Lockstep.prototype.publish(self, name, chunks)
    for ____, client in ipairs(self.clients) do
        client.published:set(name, chunks)
    end
end
function Lockstep.prototype.prepareHostFolder(self)
    for ____, client in ipairs(self.clients) do
        client.published:set(
            hostFile(self.options.filePrefix),
            {"host"}
        )
    end
end
function Lockstep.prototype.reload(self, modules)
    if modules == nil then
        modules = self.options.modules
    end
    self:prepareHostFolder()
    local previous = self.files
    if previous ~= nil and #self:unappliedReloads() == 0 then
        self.publisher:installed(previous.published)
    end
    self.version = self.version + 1
    local files = self.publisher:files(self.version, modules)
    for ____, ____value in ipairs(files.payloads) do
        local name = ____value[1]
        local text = ____value[2]
        self:publish(name, {text})
    end
    self:publish(
        manifestFile(self.version, self.options.filePrefix),
        {formatManifest(files.manifest)}
    )
    self.files = files
    return self.version
end
function Lockstep.prototype.unappliedReloads(self)
    if self.version == 0 then
        return {}
    end
    local problems = {}
    for ____, client in ipairs(self.clients) do
        do
            local ____opt_15 = client.files:get(ackFile(client.slot, self.options.filePrefix))
            local acknowledgement = ____opt_15 and ____opt_15[1] or ""
            if __TS__StringStartsWith(
                acknowledgement,
                ("applied " .. tostring(self.version)) .. " at "
            ) then
                goto __continue83
            end
            local reason = "no answer yet"
            for ____, message in ipairs(client.messages) do
                if __TS__StringStartsWith(
                    message,
                    ("hot reload " .. tostring(self.version)) .. " not applied"
                ) then
                    reason = message
                end
            end
            problems[#problems + 1] = (((("p" .. tostring(client.slot)) .. ": hot reload ") .. tostring(self.version)) .. " not running: ") .. reason
        end
        ::__continue83::
    end
    return problems
end
function Lockstep.prototype.firstDivergence(self)
    return self.divergence or self:compare()
end
function Lockstep.prototype.compare(self)
    local first = self.clients[1]
    if first == nil then
        return nil
    end
    do
        local other = 1
        while other < #self.clients do
            do
                local client = self.clients[other + 1]
                if client == nil then
                    goto __continue93
                end
                local length = math.max(#first.log, #client.log)
                do
                    local index = 0
                    local ____index_17 = index
                    local ____firstIteration_18 = true
                    while true do
                        local index = ____index_17
                        if not ____firstIteration_18 then
                            index = index + 1
                        end
                        ____firstIteration_18 = false
                        if not (index < length) then
                            break
                        end
                        do
                            local left = first.log[index + 1]
                            local right = client.log[index + 1]
                            if left ~= nil and right ~= nil and sameCall(left, right) then
                                goto __continue96
                            end
                            local function context(log)
                                local lines = {}
                                do
                                    local at = math.max(0, index - 4)
                                    while at < math.min(#log, index + 2) do
                                        local call = log[at + 1]
                                        if call ~= nil then
                                            lines[#lines + 1] = describeCall(call)
                                        end
                                        at = at + 1
                                    end
                                end
                                return table.concat(lines, "\n    ")
                            end
                            return (((((((((((("call " .. tostring(first.forgotten + index)) .. " differs between slot ") .. tostring(first.slot)) .. " and slot ") .. tostring(client.slot)) .. ":\n  slot ") .. tostring(first.slot)) .. ":\n    ") .. context(first.log)) .. "\n  slot ") .. tostring(client.slot)) .. ":\n    ") .. context(client.log)
                        end
                        ::__continue96::
                        ____index_17 = index
                    end
                end
            end
            ::__continue93::
            other = other + 1
        end
    end
    return nil
end
return ____exports
