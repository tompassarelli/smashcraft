local ____lualib = require("lualib_bundle")
local Map = ____lualib.Map
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__New = ____lualib.__TS__New
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
--- The framepointtype constants in ConvertFramePointType order, each with its
-- place on the frame: its share of the width from the left and of the height
-- from the top.
____exports.FRAME_POINTS = {
    {"FRAMEPOINT_TOPLEFT", 0, 0},
    {"FRAMEPOINT_TOP", 0x1p-1, 0},
    {"FRAMEPOINT_TOPRIGHT", 1, 0},
    {"FRAMEPOINT_LEFT", 0, 0x1p-1},
    {"FRAMEPOINT_CENTER", 0x1p-1, 0x1p-1},
    {"FRAMEPOINT_RIGHT", 1, 0x1p-1},
    {"FRAMEPOINT_BOTTOMLEFT", 0, 1},
    {"FRAMEPOINT_BOTTOM", 0x1p-1, 1},
    {"FRAMEPOINT_BOTTOMRIGHT", 1, 1}
}
--- Each point's place on a frame by its FDF name, such as TOPLEFT.
local NAMED_POINTS = __TS__New(
    Map,
    __TS__ArrayMap(
        ____exports.FRAME_POINTS,
        function(____, ____bindingPattern0)
            local fromTop
            local fromLeft
            local name
            name = ____bindingPattern0[1]
            fromLeft = ____bindingPattern0[2]
            fromTop = ____bindingPattern0[3]
            return {
                __TS__StringSlice(name, #"FRAMEPOINT_"),
                {fromLeft, fromTop}
            }
        end
    )
)
--- A text box's character limit until the map sets one.
local DEFAULT_TEXT_LIMIT = 4096
____exports.Frames = __TS__Class()
local Frames = ____exports.Frames
Frames.name = "Frames"
function Frames.prototype.____constructor(self, points)
    self.points = points
    self.all = {}
    self.templates = __TS__New(Map)
end
function Frames.prototype.add(self, handle, ____type, name, parent, context)
    local frame = __TS__ObjectAssign(
        {},
        handle,
        {
            type = ____type,
            name = name,
            context = context,
            parent = parent,
            text = "",
            visible = true,
            enabled = true,
            level = 0,
            textLimit = DEFAULT_TEXT_LIMIT,
            width = 0,
            height = 0,
            points = __TS__New(Map),
            anchors = {},
            destroyed = false
        }
    )
    local ____self_all_0 = self.all
    ____self_all_0[#____self_all_0 + 1] = frame
    return frame
end
function Frames.prototype.define(self, definitions)
    for ____, definition in ipairs(definitions) do
        self.templates:set(definition.name, definition)
    end
end
function Frames.prototype.create(self, handle, name, parent, context)
    local root = self:add(
        handle(),
        name,
        name,
        parent,
        context
    )
    local definition = self.templates:get(name)
    if definition == nil then
        return root
    end
    root.width = definition.width
    root.height = definition.height
    local byKey = __TS__New(Map, {{"root", root}})
    local placed = {}
    local make
    make = function(nodes, owner)
        for ____, node in ipairs(nodes) do
            local frame = self:add(
                handle(),
                node.type,
                (definition.name .. string.upper(string.sub(node.key, 1, 1))) .. string.sub(node.key, 2),
                owner,
                context
            )
            frame.width = node.width or 0
            frame.height = node.height or 0
            if node.type == "TEXT" and node.text ~= nil then
                frame.text = node.text
            end
            byKey:set(node.key, frame)
            placed[#placed + 1] = {node, frame}
            make(node.children or ({}), frame)
        end
    end
    make(definition.children, root)
    for ____, ____value in ipairs(placed) do
        local node = ____value[1]
        local frame = ____value[2]
        for ____, anchor in ipairs(node.points or ({})) do
            do
                local ____temp_1
                if anchor.relative == nil then
                    ____temp_1 = frame.parent
                else
                    ____temp_1 = byKey:get(anchor.relative)
                end
                local relative = ____temp_1
                if relative == nil then
                    goto __continue15
                end
                local ____frame_anchors_2 = frame.anchors
                ____frame_anchors_2[#____frame_anchors_2 + 1] = {
                    point = anchor.point,
                    relative = relative,
                    relativePoint = anchor.relativePoint or anchor.point,
                    x = anchor.x,
                    y = anchor.y
                }
            end
            ::__continue15::
        end
    end
    return root
end
function Frames.prototype.named(self, name, context)
    for ____, frame in ipairs(self.all) do
        if not frame.destroyed and frame.name == name and frame.context == context then
            return frame
        end
    end
    return nil
end
function Frames.prototype.byId(self, id)
    for ____, frame in ipairs(self.all) do
        if frame.id == id and not frame.destroyed then
            return frame
        end
    end
    return nil
end
function Frames.prototype.destroy(self, frame)
    frame.destroyed = true
    if self.focused == frame then
        self.focused = nil
    end
    for ____, child in ipairs(self.all) do
        if child.parent == frame and not child.destroyed then
            self:destroy(child)
        end
    end
end
function Frames.prototype.focus(self, frame, flag)
    if flag then
        self.focused = frame
    elseif self.focused == frame then
        self.focused = nil
    end
end
function Frames.prototype.shown(self, frame)
    do
        local at = frame
        while at ~= nil do
            if at.destroyed or not at.visible then
                return false
            end
            at = at.parent
        end
    end
    return true
end
function Frames.prototype.shownText(self)
    local texts = {}
    for ____, frame in ipairs(self.all) do
        if frame.text ~= "" and self:shown(frame) then
            texts[#texts + 1] = frame.text
        end
    end
    return texts
end
function Frames.prototype.rectangle(self, frame)
    local corners = {0, 0, 0, 0}
    local found = 0
    local placed = {}
    for ____, ____value in __TS__Iterator(frame.points) do
        local point = ____value[1]
        local at = ____value[2]
        local share = self.points:get(point)
        if share ~= nil then
            placed[#placed + 1] = {share, at}
        end
    end
    for ____, anchor in ipairs(frame.anchors) do
        do
            local share = NAMED_POINTS:get(anchor.point)
            local relativeShare = NAMED_POINTS:get(anchor.relativePoint)
            local relative = self:rectangle(anchor.relative)
            if share == nil or relativeShare == nil or relative == nil then
                goto __continue47
            end
            local left, top, right, bottom = table.unpack(relative, 1, 4)
            placed[#placed + 1] = {share, {x = left + relativeShare[1] * (right - left) + anchor.x, y = top - relativeShare[2] * (top - bottom) + anchor.y}}
        end
        ::__continue47::
    end
    for ____, ____value in ipairs(placed) do
        local share = ____value[1]
        local at = ____value[2]
        local left = at.x - share[1] * frame.width
        local top = at.y + share[2] * frame.height
        if found == 0 then
            corners[1] = left
            corners[2] = top
            corners[3] = left + frame.width
            corners[4] = top - frame.height
        else
            if share[1] == 0 then
                corners[1] = at.x
            end
            if share[1] == 1 then
                corners[3] = at.x
            end
            if share[2] == 0 then
                corners[2] = at.y
            end
            if share[2] == 1 then
                corners[4] = at.y
            end
        end
        found = found + 1
    end
    local ____temp_3
    if found == 0 then
        ____temp_3 = nil
    else
        ____temp_3 = corners
    end
    return ____temp_3
end
function Frames.prototype.at(self, x, y, takes)
    local found
    for ____, frame in ipairs(self.all) do
        do
            if not frame.enabled or not takes(frame) or not self:shown(frame) then
                goto __continue59
            end
            local rectangle = self:rectangle(frame)
            if rectangle == nil then
                goto __continue59
            end
            local left, top, right, bottom = table.unpack(rectangle, 1, 4)
            if x < left or x > right or y > top or y < bottom then
                goto __continue59
            end
            if found == nil or frame.level >= found.level then
                found = frame
            end
        end
        ::__continue59::
    end
    return found
end
function Frames.prototype.type(self, text)
    local box = self.focused
    if box == nil or box.type ~= "EDITBOX" or not box.enabled or not self:shown(box) then
        return false
    end
    box.text = __TS__StringSlice(
        box.text .. text,
        0,
        math.max(box.textLimit, #box.text)
    )
    return true
end
return ____exports
