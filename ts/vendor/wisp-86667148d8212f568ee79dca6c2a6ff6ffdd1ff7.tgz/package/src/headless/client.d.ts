/** @noSelfInFile */
import type { NativeDeclarations } from "./declarations";
import { type Frame, Frames } from "./frames";
export type Handle = {
    readonly kind: string;
    readonly id: number;
};
export interface NativeCall {
    readonly name: string;
    readonly args: readonly unknown[];
}
export interface SyncMessage {
    readonly sender: number;
    readonly prefix: string;
    readonly data: string;
}
/** What a map's entry exports: start once per match, install after each hot reload. */
export interface MapEntry {
    start(this: void): void;
    install(this: void): void;
}
/** Native name to why a client may call it when the others don't. */
export type LocalNatives = Readonly<Record<string, string>>;
/** A native's behavior; a host or game supplies one for a native the default stub can't answer. */
export type NativeBehavior = (this: void, ...args: never[]) => unknown;
/** Natives a host or game adds or replaces, and other globals its map code reads, such as Lua's. */
export type NativeBehaviors = Readonly<Record<string, unknown>>;
/**
 * Natives Wisp's own runtime calls on one client only. A game adds the ones
 * its code calls that way: local UI, input polling, conversions for local text.
 */
export declare const WISP_LOCAL_NATIVES: LocalNatives;
/** A special effect as the client shows it. */
export interface EffectPose {
    readonly handle: Handle;
    readonly model: string;
    /** The client frame it was created on. */
    readonly created: number;
    x: number;
    y: number;
    /** Where AddSpecialEffect puts it, 0, until the map moves it. */
    z: number;
    alpha: number;
    scale: number;
    timeScale: number;
    /** A matrix scale of zero on some axis since the matrix was last reset. */
    flat: boolean;
}
/**
 * A client's CustomMapData folder outside the process, so another program,
 * such as an input helper, reads what the map writes and writes what it reads.
 */
export interface ClientFiles {
    /** A file the map wrote with PreloadGenEnd: its Preload lines. */
    written(this: void, name: string, lines: readonly string[]): void;
    /** What Preloader reads from a file someone else wrote: one chunk per FileIO tooltip level; undefined while it is missing. */
    read(this: void, name: string): readonly string[] | undefined;
}
/** How a host makes one client's natives and state the ones map code sees while it runs. */
export interface ClientScope {
    enter(this: void, client: HeadlessClient): void;
    leave(this: void, client: HeadlessClient): void;
}
export interface ClientOptions {
    readonly slot: number;
    /** The map's configureRuntime() filePrefix, which names the file its error reports go to. */
    readonly filePrefix: string;
    /** Player slots with a human client; the others are empty. */
    readonly humans: readonly number[];
    readonly declarations: NativeDeclarations;
    readonly localNatives: LocalNatives;
    readonly network: SyncMessage[];
    readonly screenWidth: number;
    readonly scope?: ClientScope;
    /** Added or replacing natives; values that aren't declared natives, such as Lua globals, are set unlogged. */
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly files?: ClientFiles;
}
export declare const FRAMES_PER_SECOND = 60;
/**
 * A number as both runtimes print it alike: an integer in digits, any other
 * value exactly, as an integer times a power of two. Lua prints 3.0 for a
 * float that JavaScript prints as 3, and neither prints every binary digit.
 */
export declare function describeNumber(value: number): string;
/** A native argument, the same on every client and in both runtimes: handles by kind and number, callbacks as `fn`. */
export declare function describeValue(value: unknown): string;
export declare function describeCall({ name, args }: NativeCall): string;
/** Whether two clients made the same call: equal values, handles with the same kind and number, any two callbacks. */
export declare function sameCall(left: NativeCall, right: NativeCall): boolean;
export declare class HeadlessClient {
    readonly slot: number;
    /** Every native call the other clients must make alike, in order, since the calls forget() dropped. */
    readonly log: NativeCall[];
    /** Calls forget() dropped from the front of `log`; the checksum still covers them. */
    forgotten: number;
    private forgottenHash;
    /** Error reports the map wrote to its error file, shown on screen or not: `error in HANDLER: MESSAGE`. */
    readonly errors: string[];
    /** Every message the map showed this client. */
    readonly messages: string[];
    /** Where the host keeps what a thrown error says beyond the map's report, such as a JavaScript stack. */
    readonly thrown: string[];
    /** Files the map wrote, by name: their Preload lines. */
    readonly files: Map<string, string[]>;
    /** Files the host put in CustomMapData for Preloader: one chunk per FileIO tooltip level. */
    readonly published: Map<string, readonly string[]>;
    /**
     * Preloader calls for a file nobody had published, which Wine answers by
     * reading the folder that should hold it: all of CustomMapData when the
     * file's own folder is missing too (wisp:docs/hot-reload.md).
     */
    missedLookups: number;
    readonly natives: Record<string, unknown>;
    /** Frames this client has run. */
    frame: number;
    private nextId;
    private readonly scope;
    private readonly filePrefix;
    private readonly timers;
    private readonly registrations;
    private readonly memo;
    private allPlayers;
    private readonly effects;
    private readonly tooltips;
    /** Preloader runs the content it first read from a path for the rest of the session. */
    private readonly preloaded;
    private event;
    private preload;
    private readonly stored;
    /** The frames this client shows: their text, places, and which takes a click or the keyboard. */
    readonly frames: Frames;
    constructor(options: ClientOptions);
    private handle;
    private defaultNative;
    private defaultValue;
    /** A frame Warcraft made, such as an origin frame: one handle per frame, made at its first lookup. */
    private memoized;
    private created;
    /** Changes a frame the map holds; a handle that isn't one of this client's frames changes nothing. */
    private withFrame;
    private effectAt;
    private pose;
    private show;
    /** A report file's lines as the screen would show them: its heading names the handler, its next line the message. */
    private report;
    private behaviors;
    /** The published files Preloader has read in this client, in the order it first read them. */
    preloadedFiles(): string[];
    /** The effects this client shows now, as copies, in creation order. */
    effectPoses(): EffectPose[];
    /** Makes this client's natives and state the ones map code sees, and runs `body`. */
    run(body: (this: void) => void): void;
    private fire;
    /** One game frame: every due timer, in creation order. */
    step(): void;
    deliverSync({ sender, prefix, data }: SyncMessage): void;
    chat(sender: number, message: string): void;
    key(sender: number, key: number, meta: number, down: boolean): void;
    /**
     * Text this client's keyboard types: into the edit box that has the
     * keyboard, while the player sees it. False when none has it, so Warcraft
     * would take the text as key presses.
     */
    type(text: string): boolean;
    /** The frame a click at (x, y), in Warcraft's UI coordinates, reaches on this client: shown, enabled and registered for clicks. */
    clickTarget(x: number, y: number): Frame | undefined;
    /** A frame event from `sender` on the frame with this handle number, as every client receives it. */
    frameEvent(sender: number, id: number, event: unknown): void;
    /** Every call this client logged, forgotten ones included. */
    callCount(): number;
    /** Folds the first `count` logged calls into the checksum and drops them, so a long run keeps its memory. */
    forget(count: number): void;
    /** A 32-bit hash of every logged call: its name and arguments as describeValue identifies them. Equal logs hash alike in Bun and Lua. */
    checksum(): string;
}
