local ____lualib = require("lualib_bundle")
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__ArrayIsArray = ____lualib.__TS__ArrayIsArray
local ____exports = {}
local isName, realText, stringText, valueText, arrayLength, writeValue, writeFields, isFields, MAX_DEPTH, TWO_26, isNameCode, isPlainCode, isInteger, HEX, isList
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
function isName(text)
    if #text == 0 then
        return false
    end
    do
        local index = 0
        while index < #text do
            if not isNameCode(__TS__StringCharCodeAt(text, index)) then
                return false
            end
            index = index + 1
        end
    end
    return true
end
function realText(value)
    if value ~= value then
        return "~nan"
    end
    local negative = value < 0 or value == 0 and string.sub(
        tostring(value),
        1,
        1
    ) == "-"
    local magnitude = negative and -value or value
    if magnitude == 0 then
        return negative and "~-0" or "~0"
    end
    if magnitude * 2.0 == magnitude then
        return negative and "~-inf" or "~inf"
    end
    local exponent = 0
    while magnitude >= 2.0 do
        magnitude = magnitude * 0.5
        exponent = exponent + 1
    end
    while magnitude < 1.0 do
        magnitude = magnitude * 2.0
        exponent = exponent - 1
    end
    local scaled = (magnitude - 1.0) * TWO_26
    local high = math.floor(scaled)
    local low = math.floor((scaled - high) * TWO_26)
    return ((((("~" .. (negative and "-" or "+")) .. tostring(exponent)) .. ":") .. tostring(high)) .. ":") .. tostring(low)
end
function stringText(value)
    local text = "'"
    do
        local index = 0
        while index < #value do
            local code = __TS__StringCharCodeAt(value, index)
            if code > 255 then
                return nil
            end
            text = text .. (isPlainCode(code) and __TS__StringCharAt(value, index) or ("%" .. __TS__StringCharAt(HEX, code // 16)) .. __TS__StringCharAt(HEX, code & 15))
            index = index + 1
        end
    end
    return text
end
function valueText(value)
    if value == true then
        return "T"
    end
    if value == false then
        return "F"
    end
    if type(value) == "number" then
        return isInteger(value) and tostring(value) or realText(value)
    end
    if type(value) == "string" then
        return stringText(value)
    end
    return nil
end
function arrayLength(value)
    local length
    for key in pairs(value) do
        local raw = key
        if type(raw) == "number" then
            length = math.max(length or 0, raw)
        end
    end
    if length == nil and __TS__ArrayIsArray(value) then
        return #value
    end
    return length
end
function writeValue(tokens, name, value, depth)
    if value == nil then
        return true
    end
    if not isFields(value) then
        local text = valueText(value)
        if text == nil then
            return false
        end
        tokens[#tokens + 1] = (name .. "=") .. text
        return true
    end
    if depth >= MAX_DEPTH then
        return false
    end
    local length = arrayLength(value)
    local items = value
    if isList(items, length) then
        tokens[#tokens + 1] = name .. "["
        do
            local index = 0
            while index < (length or 0) do
                if not writeValue(
                    tokens,
                    tostring(index),
                    items[index + 1],
                    depth + 1
                ) then
                    return false
                end
                index = index + 1
            end
        end
        tokens[#tokens + 1] = "]"
        return true
    end
    tokens[#tokens + 1] = name .. "{"
    if not writeFields(tokens, value, depth + 1) then
        return false
    end
    tokens[#tokens + 1] = "}"
    return true
end
function writeFields(tokens, record, depth)
    for key in pairs(record) do
        if not isName(key) or not writeValue(tokens, key, record[key], depth) then
            return false
        end
    end
    return true
end
isFields = function(value) return type(value) == "table" and value ~= nil end
MAX_DEPTH = 32
TWO_26 = 67108864.0
local LARGEST_INTEGER = 2147483647
local SMALLEST_INTEGER = -2147483648
local function isDigit(code)
    return code >= 48 and code <= 57
end
isNameCode = function(code) return isDigit(code) or code >= 65 and code <= 90 or code >= 97 and code <= 122 or code == 95 end
isPlainCode = function(code) return isNameCode(code) or code == 46 or code == 45 end
--- Whether `text` is an optional minus and decimal digits.
local function isDecimal(text)
    local start = string.sub(text, 1, 1) == "-" and 1 or 0
    if #text <= start then
        return false
    end
    do
        local index = start
        while index < #text do
            if not isDigit(__TS__StringCharCodeAt(text, index)) then
                return false
            end
            index = index + 1
        end
    end
    return true
end
isInteger = function(value) return isDecimal(tostring(value)) and value >= SMALLEST_INTEGER and value <= LARGEST_INTEGER end
local function infinity()
    local result = 16777216.0
    do
        local step = 1
        while step <= 6 do
            result = result * result
            step = step + 1
        end
    end
    return result
end
local function parseInteger(text)
    if not isDecimal(text) then
        return nil
    end
    local negative = string.sub(text, 1, 1) == "-"
    local result = 0
    do
        local index = negative and 1 or 0
        while index < #text do
            result = result * 10 + (__TS__StringCharCodeAt(text, index) - 48)
            index = index + 1
        end
    end
    return negative and -result or result
end
local function parseReal(text)
    if text == "~0" then
        return 0.0
    end
    if text == "~-0" then
        return -0.0
    end
    if text == "~inf" then
        return infinity()
    end
    if text == "~-inf" then
        return -infinity()
    end
    if text == "~nan" then
        return infinity() - infinity()
    end
    local sign = string.sub(text, 2, 2)
    if sign ~= "+" and sign ~= "-" then
        return nil
    end
    local parts = __TS__StringSplit(
        __TS__StringSubstring(text, 2),
        ":"
    )
    if #parts ~= 3 then
        return nil
    end
    local exponent = parseInteger(parts[1] or "")
    local high = parseInteger(parts[2] or "")
    local low = parseInteger(parts[3] or "")
    if exponent == nil or high == nil or low == nil then
        return nil
    end
    if high < 0 or high >= TWO_26 or low < 0 or low >= TWO_26 or exponent < -1100 or exponent > 1100 then
        return nil
    end
    local value = 1.0 + (high + low / TWO_26) / TWO_26
    do
        local step = 0
        while step < exponent do
            value = value * 2.0
            step = step + 1
        end
    end
    do
        local step = 0
        while step > exponent do
            value = value * 0.5
            step = step - 1
        end
    end
    return sign == "-" and -value or value
end
HEX = "0123456789ABCDEF"
local function parseString(text)
    local value = ""
    local index = 1
    while index < #text do
        do
            local character = __TS__StringCharAt(text, index)
            if character ~= "%" then
                if not isPlainCode(__TS__StringCharCodeAt(text, index)) then
                    return nil
                end
                value = value .. character
                index = index + 1
                goto __continue49
            end
            if index + 2 >= #text then
                return nil
            end
            local high = (string.find(
                HEX,
                __TS__StringCharAt(text, index + 1),
                nil,
                true
            ) or 0) - 1
            local low = (string.find(
                HEX,
                __TS__StringCharAt(text, index + 2),
                nil,
                true
            ) or 0) - 1
            if high < 0 or low < 0 then
                return nil
            end
            value = value .. string.char(high * 16 + low)
            index = index + 3
        end
        ::__continue49::
    end
    return value
end
local function parseValue(text)
    if text == "T" then
        return true
    end
    if text == "F" then
        return false
    end
    local first = string.sub(text, 1, 1)
    if first == "~" then
        return parseReal(text)
    end
    if first == "'" then
        return parseString(text)
    end
    return parseInteger(text)
end
isList = function(_value, length) return length ~= nil end
--- The tokens of a record's fields. Undefined when it holds anything else: a
-- function, a cycle, a string byte above 255 or a key that isn't letters,
-- digits and `_`.
function ____exports.recordTokens(record)
    if not isFields(record) or arrayLength(record) ~= nil then
        return nil
    end
    local tokens = {}
    return writeFields(tokens, record, 0) and tokens or nil
end
local function place(open, name, value)
    if open.fields ~= nil then
        if not isName(name) then
            return false
        end
        open.fields[name] = value
        return true
    end
    local index = parseInteger(name)
    if open.items == nil or index == nil or index < 0 then
        return false
    end
    open.items[index + 1] = value
    return true
end
--- The record that recordTokens wrote `tokens` for; undefined when they are malformed.
function ____exports.parseRecord(tokens)
    local root = {}
    local stack = {{fields = root, items = nil}}
    for ____, token in ipairs(tokens) do
        do
            local open = stack[#stack]
            if open == nil then
                return nil
            end
            if token == "}" or token == "]" then
                if #stack == 1 or token == "}" ~= (open.fields ~= nil) then
                    return nil
                end
                table.remove(stack)
                goto __continue91
            end
            local last = __TS__StringCharAt(token, #token - 1)
            if last == "{" or last == "[" then
                local child = last == "{" and ({fields = {}, items = nil}) or ({fields = nil, items = {}})
                if not place(
                    open,
                    __TS__StringSubstring(token, 0, #token - 1),
                    child.fields or child.items
                ) then
                    return nil
                end
                stack[#stack + 1] = child
                goto __continue91
            end
            local equals = (string.find(token, "=", nil, true) or 0) - 1
            local ____temp_0
            if equals < 0 then
                ____temp_0 = nil
            else
                ____temp_0 = parseValue(__TS__StringSubstring(token, equals + 1))
            end
            local value = ____temp_0
            if value == nil or not place(
                open,
                __TS__StringSubstring(token, 0, equals),
                value
            ) then
                return nil
            end
        end
        ::__continue91::
    end
    return #stack == 1 and root or nil
end
--- Tokens joined by spaces into lines of at most `width` characters; a longer token has a line of its own.
function ____exports.tokenLines(tokens, width)
    local lines = {}
    local line = {}
    local length = -1
    for ____, token in ipairs(tokens) do
        if #line > 0 and length + 1 + #token > width then
            lines[#lines + 1] = table.concat(line, " ")
            line = {}
            length = -1
        end
        line[#line + 1] = token
        length = length + (1 + #token)
    end
    if #line > 0 then
        lines[#lines + 1] = table.concat(line, " ")
    end
    return lines
end
--- The tokens of lines that tokenLines wrote.
function ____exports.lineTokens(lines)
    local tokens = {}
    for ____, line in ipairs(lines) do
        for ____, token in ipairs(__TS__StringSplit(line, " ")) do
            if #token > 0 then
                tokens[#tokens + 1] = token
            end
        end
    end
    return tokens
end
return ____exports
