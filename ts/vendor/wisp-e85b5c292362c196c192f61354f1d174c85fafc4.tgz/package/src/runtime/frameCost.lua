local ____lualib = require("lualib_bundle")
local __TS__ArraySort = ____lualib.__TS__ArraySort
local ____exports = {}
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local floorMod = ____intMath.floorMod
--- The report a client writes once the version it runs has played a window of frames.
____exports.frameCostFile = function(slot, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((prefix .. "-perf-p") .. tostring(slot)) .. ".txt"
end
--- The median, mean and maximum of the first `count` values; zeros for none.
function ____exports.spread(values, count)
    if count <= 0 then
        return {median = 0, mean = 0, max = 0}
    end
    local sorted = {}
    local total = 0
    do
        local index = 0
        while index < count do
            local value = values[index + 1] or 0
            sorted[#sorted + 1] = value
            total = total + value
            index = index + 1
        end
    end
    __TS__ArraySort(
        sorted,
        function(____, left, right) return left - right end
    )
    local middle = count // 2
    local median = count % 2 == 1 and (sorted[middle + 1] or 0) or ((sorted[middle] or 0) + (sorted[middle + 1] or 0)) / 2
    return {median = median, mean = total / count, max = sorted[count] or 0}
end
--- A non-negative number as reports write it, rounded to two decimals, alike in Lua and JavaScript.
function ____exports.reportNumber(value)
    local hundredths = math.floor(value * 100 + 0.5)
    local whole = hundredths // 100
    local rest = hundredths % 100
    if rest == 0 then
        return tostring(whole)
    end
    return rest < 10 and (tostring(whole) .. ".0") .. tostring(rest) or (tostring(whole) .. ".") .. tostring(rest)
end
local function spreadText(____bindingPattern0)
    local max
    local mean
    local median
    median = ____bindingPattern0.median
    mean = ____bindingPattern0.mean
    max = ____bindingPattern0.max
    return (((____exports.reportNumber(median) .. "/") .. ____exports.reportNumber(mean)) .. "/") .. ____exports.reportNumber(max)
end
--- The report's first line: the version measured after a reload, the one before it, and the clock's step in microseconds (0 without a clock).
____exports.frameCostHeading = function(version, previous, clockStep) return (((("frame cost v" .. tostring(version)) .. " after v") .. tostring(previous)) .. " clock=") .. ____exports.reportNumber(clockStep) end
--- One window's line, `before` or `after`: its frames, then each value's median/mean/max per frame.
____exports.frameWindowLine = function(label, window) return (((((((label .. " frames=") .. tostring(window.frames)) .. " lua=") .. (window.lua == nil and "none" or spreadText(window.lua))) .. " natives=") .. spreadText(window.natives)) .. " catchup=") .. spreadText(window.catchUp) end
return ____exports
