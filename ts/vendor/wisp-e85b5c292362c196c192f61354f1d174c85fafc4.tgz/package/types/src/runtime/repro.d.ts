/** @noSelfInFile */
export declare const REPRO_HEADER = "wisp-repro 1";
/** Characters per game line; Wisp's error reports cut Preload lines at 240. */
export declare const REPRO_LINE_WIDTH = 200;
export interface ReproHeader {
    /** The build that saved it, without spaces. */
    readonly build: string;
    /** The frame the moment ends on. */
    readonly frame: number;
    /** The game's checksum of its state at that frame, which a replay must reach. */
    readonly checksum: string;
}
export interface Repro extends ReproHeader {
    /** The game's lines: what it needs to restore its state and run the frames. */
    readonly lines: readonly string[];
}
/** What a game's replay of a repro reached. */
export interface ReproResult {
    /** Its checksum after the last frame, comparable with the repro's. */
    readonly checksum: string;
    /** Frames it ran. */
    readonly frames: number;
    /** What went wrong on the way, such as a restored state that isn't the one saved. */
    readonly problems: readonly string[];
}
/** A game's replay: restores the repro's state and runs its frames. `wisp repro` runs it in each simulated client. */
export type ReproReplay = (this: void, repro: Repro) => ReproResult;
/** A new name for each repro a client saves, as Preloader runs the first content it read from a name for the rest of the session. */
export declare const reproFile: (slot: number, frame: number, serial: number, prefix?: string) => string;
/** The lines of a repro file: header, the game's lines, and their count. */
export declare function reproLines({ build, frame, checksum }: ReproHeader, lines: readonly string[]): string[];
/** A repro from its file's lines, or what is wrong with them. */
export declare function parseRepro(lines: readonly string[]): Repro | string;
/**
 * The test `wisp repro FILE --test NAME` writes: replaying the repro's lines
 * reaches the checksum the game recorded, with no problem on the way.
 */
export declare function assertReproLands(lines: readonly string[], replay: ReproReplay): void;
