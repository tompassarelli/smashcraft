local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____f32 = require("src.sim.f32")
local f32 = ____f32.f32
--- TextTagSpeed2Velocity's scale: a velocity of 0.071 moves a tag 128 world units a second.
local WORLD_UNITS_PER_VELOCITY = 128 / 0x916873p-27
____exports.TextTags = __TS__Class()
local TextTags = ____exports.TextTags
TextTags.name = "TextTags"
function TextTags.prototype.____constructor(self)
    self.tags = __TS__New(Map)
end
function TextTags.prototype.behaviors(self, context)
    local function tag(value)
        return self.tags:get(value)
    end
    return {
        CreateTextTag = function()
            local handle = context.handle("texttag")
            self.tags:set(handle, {
                handle = handle,
                text = "",
                height = 0,
                x = 0,
                y = 0,
                z = 0,
                color = {255, 255, 255, 255},
                xVelocity = 0,
                yVelocity = 0,
                visible = true,
                suspended = false,
                permanent = true,
                age = 0,
                lifespan = 0,
                fadepoint = 0
            })
            return handle
        end,
        DestroyTextTag = function(t)
            self.tags:delete(t)
        end,
        SetTextTagText = function(t, text, height)
            local found = tag(t)
            if found ~= nil then
                found.text = text
                found.height = height
            end
        end,
        SetTextTagPos = function(t, x, y, heightOffset)
            local found = tag(t)
            if found ~= nil then
                found.x = x
                found.y = y
                found.z = heightOffset
            end
        end,
        SetTextTagPosUnit = function(t, unit, heightOffset)
            local found = tag(t)
            local at = context.unitPosition(unit)
            if found ~= nil and at ~= nil then
                found.x = at.x
                found.y = at.y
                found.z = at.z + heightOffset
            end
        end,
        SetTextTagColor = function(t, red, green, blue, alpha)
            local found = tag(t)
            if found ~= nil then
                found.color = {red, green, blue, alpha}
            end
        end,
        SetTextTagVelocity = function(t, xVelocity, yVelocity)
            local found = tag(t)
            if found ~= nil then
                found.xVelocity = xVelocity
                found.yVelocity = yVelocity
            end
        end,
        SetTextTagVisibility = function(t, visible)
            local found = tag(t)
            if found ~= nil then
                found.visible = visible
            end
        end,
        SetTextTagSuspended = function(t, suspended)
            local found = tag(t)
            if found ~= nil then
                found.suspended = suspended
            end
        end,
        SetTextTagPermanent = function(t, permanent)
            local found = tag(t)
            if found ~= nil then
                found.permanent = permanent
            end
        end,
        SetTextTagAge = function(t, age)
            local found = tag(t)
            if found ~= nil then
                found.age = age
            end
        end,
        SetTextTagLifespan = function(t, lifespan)
            local found = tag(t)
            if found ~= nil then
                found.lifespan = lifespan
            end
        end,
        SetTextTagFadepoint = function(t, fadepoint)
            local found = tag(t)
            if found ~= nil then
                found.fadepoint = fadepoint
            end
        end
    }
end
function TextTags.prototype.tick(self, seconds)
    for ____, found in __TS__Iterator(self.tags:values()) do
        do
            if found.suspended then
                goto __continue30
            end
            found.x = found.x + found.xVelocity * WORLD_UNITS_PER_VELOCITY * seconds
            found.y = found.y + found.yVelocity * WORLD_UNITS_PER_VELOCITY * seconds
            found.age = found.age + seconds
            if not found.permanent and found.age >= found.lifespan then
                self.tags:delete(found.handle)
            end
        end
        ::__continue30::
    end
end
function TextTags.prototype.poses(self)
    local poses = {}
    for ____, found in __TS__Iterator(self.tags:values()) do
        do
            if not found.visible or found.text == "" then
                goto __continue35
            end
            local fading = not found.permanent and found.age > found.fadepoint and found.lifespan > found.fadepoint
            local share = fading and math.max(0, 1 - (found.age - found.fadepoint) / (found.lifespan - found.fadepoint)) or 1
            poses[#poses + 1] = {
                handle = found.handle,
                text = found.text,
                height = found.height,
                x = found.x,
                y = found.y,
                z = found.z,
                color = {
                    found.color[1],
                    found.color[2],
                    found.color[3],
                    math.floor(found.color[4] * share + 0x1p-1)
                }
            }
        end
        ::__continue35::
    end
    return poses
end
return ____exports
