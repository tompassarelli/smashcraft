local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local ____exports = {}
local ____declarations = require("src.headless.declarations")
local parseNativeDeclarations = ____declarations.parseNativeDeclarations
local ____journey = require("src.headless.journey")
local journeyLines = ____journey.journeyLines
local journeyProblems = ____journey.journeyProblems
local runJourney = ____journey.runJourney
local ____lockstep = require("src.headless.lockstep")
local Lockstep = ____lockstep.Lockstep
local ____modules = require("src.runtime.modules")
local bundleModules = ____modules.bundleModules
local ____payloadChecksum = require("src.platform.payloadChecksum")
local stringChecksum = ____payloadChecksum.stringChecksum
--- A file's bytes, for a host program running in Lua.
function ____exports.readFile(path)
    local file, problem = io.open(path, "rb")
    if file == nil then
        do
            local ____thrown = __TS__New(Error, (("can't read " .. path) .. ": ") .. problem)
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/lua.ts:37"
            end
            error(____thrown, 0)
        end
    end
    local text = file:read("a")
    file:close()
    if text == nil then
        do
            local ____thrown = __TS__New(Error, "can't read " .. path)
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/lua.ts:40"
            end
            error(____thrown, 0)
        end
    end
    return text
end
--- Clients that each run `bundle`, the map's compiled Lua, with the natives
-- `declarations` (warcraft.d.ts) lists; `scope` sees each client run, and
-- `delivery` delays synchronized messages as Warcraft does.
function ____exports.luaLockstep(map, bundle, declarations, scope, delivery)
    return __TS__New(
        Lockstep,
        __TS__ObjectAssign(
            {},
            scope == nil and ({}) or ({scope = scope}),
            delivery == nil and ({}) or ({delivery = delivery}),
            {
                declarations = parseNativeDeclarations(declarations),
                players = map.players or ({0, 1})
            },
            map.playerNames == nil and ({}) or ({playerNames = map.playerNames}),
            {
                filePrefix = map.filePrefix,
                modules = bundleModules(bundle),
                hash = stringChecksum
            },
            map.localNatives == nil and ({}) or ({localNatives = map.localNatives}),
            map.intentionalNoops == nil and ({}) or ({intentionalNoops = map.intentionalNoops}),
            map.frames == nil and ({}) or ({frames = map.frames}),
            map.unitStates == nil and ({}) or ({unitStates = map.unitStates}),
            map.scenery == nil and ({}) or ({scenery = map.scenery}),
            map.inventory == nil and ({}) or ({inventory = map.inventory}),
            map.effectDeaths == nil and ({}) or ({effectDeaths = map.effectDeaths}),
            {
                natives = function(client)
                    local environment = client.natives
                    setmetatable(environment, {__index = _G})
                    local ____temp_2 = {clock = function() return client:clockSeconds() end}
                    local function ____temp_3(text, name)
                        return load(text, name, "t", environment)
                    end
                    local ____opt_0 = map.natives
                    return __TS__ObjectAssign(
                        {_G = environment, os = ____temp_2, load = ____temp_3},
                        ____opt_0 and ____opt_0(client)
                    )
                end,
                entry = function(client)
                    local chunk, problem = load(bundle, "=map", "t", client.natives)
                    if chunk == nil then
                        do
                            local ____thrown = __TS__New(Error, "the map bundle doesn't load: " .. problem)
                            if _G.__wispThrown ~= ____thrown then
                                _G.__wispThrown = ____thrown
                                _G.__wispThrowSite = "wisp/src/headless/lua.ts:75"
                            end
                            error(____thrown, 0)
                        end
                    end
                    local entry = chunk()
                    return entry
                end
            }
        )
    )
end
--- Plays `journey` with the bundle and declarations at these paths, prints its result, and returns how many problems it found.
function ____exports.runLuaJourney(map, journey, bundlePath, declarationsPath)
    local result = runJourney(
        ____exports.luaLockstep(
            map,
            ____exports.readFile(bundlePath),
            ____exports.readFile(declarationsPath)
        ),
        journey
    )
    for ____, line in ipairs(journeyLines(result)) do
        print(line)
    end
    return journeyProblems(result)
end
return ____exports
