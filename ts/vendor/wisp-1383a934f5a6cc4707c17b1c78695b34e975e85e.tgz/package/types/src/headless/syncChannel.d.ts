/** @noSelfInFile */
import type { SyncMessage } from "./client";
import type { SyncDelivery } from "./lockstep";
export interface SyncLatency {
    /** One-way latency in game milliseconds, before rounding up to a turn. */
    readonly latencyMs: number;
    /** Game milliseconds between synchronized turns. */
    readonly turnMs: number;
    /** Probabilities of 0, 1, 2, ... further turns; they sum to 1. */
    readonly extraTurns: readonly number[];
}
/**
 * Battle.net as Smashcraft's #26 runs r7 and r8 measured it on 5 October
 * 2026: two clients on one host, 765 own-echo samples from the unsaturated
 * first seconds of each match.
 */
export declare const MEASURED_BATTLE_NET: SyncLatency;
/** Game milliseconds between a client's timer callbacks. */
export declare const CALLBACK_MS: number;
/** The game milliseconds from a send during `frame`'s callback until every client receives it. */
export declare function syncAgeMs(latency: SyncLatency, frame: number, extraTurns: number): number;
/**
 * Lockstep delivery with the measured latency: a message sent during frame F
 * reaches every client before the callbacks of the first frame at or after
 * its arrival. Seeded, so a run repeats exactly.
 */
export declare function syncDelivery(latency?: SyncLatency, seed?: number): SyncDelivery;
/** A message whose arrival a native capture measured: the first unused one `accepts` takes arrives at `atMs` on the delivery's clock. */
export interface ReplayedArrival {
    readonly accepts: (this: void, message: SyncMessage) => boolean;
    readonly atMs: number;
}
/**
 * Delivery that replays a capture's measured arrivals and leaves every other
 * message to `fallback`: a replayed message reaches every client at the
 * first frame due at or after `atMs`, where `nowMs` gives when the sending
 * frame was due on the same clock (RealtimeClients.frameDueMs), so frames run
 * late under load still land on the measured time. `arrivals` is read at each send, so a run can add
 * arrivals anchored to events it sees, such as when its Start press went in.
 * Each sender's messages still arrive in the order it sent them.
 */
export declare function replayedDelivery(arrivals: (this: void) => readonly ReplayedArrival[], fallback: SyncDelivery, nowMs: (this: void) => number): SyncDelivery;
