/** @noSelfInFile */
import type { Handle } from "./client";
/** A text tag as a renderer draws it: its colour's alpha already faded by age. */
export interface TextTagPose {
    readonly handle: Handle;
    readonly text: string;
    readonly height: number;
    readonly x: number;
    readonly y: number;
    readonly z: number;
    readonly color: readonly [number, number, number, number];
}
export interface TextTagContext {
    handle(this: void, kind: string): Handle;
    /** A live unit's position, for SetTextTagPosUnit. */
    unitPosition(this: void, unit: unknown): {
        readonly x: number;
        readonly y: number;
        readonly z: number;
    } | undefined;
}
export declare class TextTags {
    private readonly tags;
    behaviors(context: TextTagContext): Record<string, (...args: never[]) => unknown>;
    /** One game frame: unsuspended tags move by their velocity and age; a tag that isn't permanent ends at its lifespan. */
    tick(seconds: number): void;
    /** The tags a player sees now, in creation order. */
    poses(): TextTagPose[];
}
