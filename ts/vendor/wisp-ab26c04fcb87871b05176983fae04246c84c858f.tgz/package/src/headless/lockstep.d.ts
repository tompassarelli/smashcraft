/** @noSelfInFile */
import { type ClientScope, HeadlessClient, type LocalNatives, type MapEntry, type NativeBehaviors, type SyncMessage } from "./client";
import type { NativeDeclarations } from "./declarations";
export interface LockstepOptions {
    readonly declarations: NativeDeclarations;
    /** One client per human player slot. */
    readonly players: readonly number[];
    /** The map's configureRuntime() filePrefix, which names its reload, acknowledgement and error files. */
    readonly filePrefix: string;
    /** Each client's map entry; called in that client, so a host can load the bundle there. */
    readonly entry: (this: void, client: HeadlessClient) => MapEntry;
    /** The text a hot reload publishes; each client's Lua `load` turns it back into the entry. */
    readonly bundle: string;
    /** The game's local-only natives, added to WISP_LOCAL_NATIVES. */
    readonly localNatives?: LocalNatives;
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly scope?: ClientScope;
    /** When synchronized messages arrive; without it, each arrives before the next frame. */
    readonly delivery?: SyncDelivery;
}
/**
 * When a synchronized message reaches the clients, such as the measured
 * Battle.net latency of wisp:scripts/wisp/syncChannel.ts
 * (wisp:docs/network-model.md).
 */
export interface SyncDelivery {
    /** The frame before whose callbacks every client receives a message `sender` sent during `frame`; later than `frame`. */
    arrivalFrame(this: void, sender: number, frame: number, message: SyncMessage): number;
}
interface InFlight {
    readonly arrival: number;
    readonly message: SyncMessage;
}
export declare class Lockstep {
    readonly network: SyncMessage[];
    readonly clients: readonly HeadlessClient[];
    /** Frames every client has run. */
    frame: number;
    /** Hot reload versions published so far. */
    version: number;
    /** With a delivery: messages sent and not yet received, by arrival frame, then send order. */
    readonly inFlight: InFlight[];
    private readonly options;
    constructor(options: LockstepOptions);
    /**
     * The map's main(): every client loads its entry and starts it. A host has
     * prepared each client's hot folder first, as `wisp fresh` does before a
     * match, unless `hostFolder` is false: a client no host has touched.
     */
    start(options?: {
        readonly hostFolder?: boolean;
    }): void;
    /** Runs `body` on every client, such as an entry the test chooses or an install() outside the reloader. */
    everywhere(body: (this: void) => void): void;
    /** Synchronized messages reach every client in the order they were sent, at once or at their arrival frame. */
    private flush;
    /** Delivers the messages due at the current frame, before its callbacks, as Warcraft runs a turn's events first. */
    private arrive;
    frames(count: number): void;
    chat(sender: number, message: string): void;
    /** A key press and release with modifiers (2: Ctrl), as every client sees it. */
    press(sender: number, key: number, meta?: number): void;
    /** Puts a file in every client's CustomMapData, as the host writes it: one chunk per FileIO tooltip level. */
    publish(name: string, chunks: readonly string[]): void;
    /** Puts the host's marker in every client's hot folder, as `wisp fresh` and `wisp hot` do before anything else. */
    prepareHostFolder(): void;
    /**
     * Publishes the bundle as the next hot reload version, as `wisp hot` does:
     * the host's marker, payload files, then the manifest. The clients find it on their next polls.
     */
    reload(): number;
    /** Clients whose acknowledgement doesn't name the latest version, each with why. */
    unappliedReloads(): string[];
    /** The first call at which two clients' logs differ, with the calls around it; undefined when they agree. */
    firstDivergence(): string | undefined;
}
export {};
