/** @noSelfInFile */
import type { Lockstep } from "./lockstep";
/** After `frame` frames have run: a player's chat line, a key press and release, or a hot reload of the map's bundle. */
export type JourneyEvent = {
    readonly frame: number;
    readonly player: number;
    readonly chat: string;
} | {
    readonly frame: number;
    readonly player: number;
    readonly key: number;
    readonly meta: number;
} | {
    readonly frame: number;
    readonly reload: true;
};
export interface Journey {
    /** Frames the match runs after start. */
    readonly frames: number;
    /** In frame order. */
    readonly events: readonly JourneyEvent[];
}
export interface ClientResult {
    readonly slot: number;
    readonly calls: number;
    readonly checksum: string;
    readonly errors: readonly string[];
}
export interface JourneyResult {
    readonly frames: number;
    readonly clients: readonly ClientResult[];
    /** Where the first two clients' native calls part, if they do. */
    readonly divergence: string | undefined;
    /** Hot reload versions published. */
    readonly reloaded: number;
    /** Clients not running the last hot reload at the end. */
    readonly reloads: readonly string[];
}
/** Starts the map in every client and plays the journey. */
export declare function runJourney(clients: Lockstep, journey: Journey): JourneyResult;
/** Problems a journey found: a desync, an error report or a reload that didn't run. */
export declare function journeyProblems(result: JourneyResult): number;
/** The result as lines to print: each client's calls and checksum, then each problem. */
export declare function journeyLines(result: JourneyResult): string[];
