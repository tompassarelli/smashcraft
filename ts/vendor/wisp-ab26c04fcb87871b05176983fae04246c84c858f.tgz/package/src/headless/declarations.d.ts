/** @noSelfInFile */
export interface NativeDeclarations {
    readonly functions: readonly (readonly [name: string, returns: string])[];
    readonly constants: readonly (readonly [name: string, type: string])[];
    /** Global variables, such as `bj_mapInitialPlayableArea`; an array type ends with `[]`. */
    readonly variables: readonly (readonly [name: string, type: string])[];
}
export declare function parseNativeDeclarations(text: string): NativeDeclarations;
