local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
--- Starts the map in every client and plays the journey.
function ____exports.runJourney(clients, journey)
    clients:start()
    for ____, event in ipairs(journey.events) do
        if event.frame < clients.frame then
            do
                local ____thrown = __TS__New(
                    Error,
                    ("journey event at frame " .. tostring(event.frame)) .. " is out of order"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/journey.ts:40"
                end
                error(____thrown, 0)
            end
        end
        clients:frames(event.frame - clients.frame)
        if event.chat ~= nil then
            clients:chat(event.player, event.chat)
        elseif event.key ~= nil then
            clients:press(event.player, event.key, event.meta)
        else
            clients:reload()
        end
    end
    clients:frames(journey.frames - clients.frame)
    local results = {}
    for ____, client in ipairs(clients.clients) do
        results[#results + 1] = {
            slot = client.slot,
            calls = #client.log,
            checksum = client:checksum(),
            errors = client.errors
        }
    end
    return {
        frames = clients.frame,
        clients = results,
        divergence = clients:firstDivergence(),
        reloaded = clients.version,
        reloads = clients:unappliedReloads()
    }
end
--- Problems a journey found: a desync, an error report or a reload that didn't run.
function ____exports.journeyProblems(result)
    local problems = (result.divergence == nil and 0 or 1) + #result.reloads
    for ____, client in ipairs(result.clients) do
        problems = problems + #client.errors
    end
    return problems
end
--- The result as lines to print: each client's calls and checksum, then each problem.
function ____exports.journeyLines(result)
    local lines = {}
    for ____, client in ipairs(result.clients) do
        lines[#lines + 1] = (((("p" .. tostring(client.slot)) .. ": ") .. tostring(client.calls)) .. " native calls, checksum ") .. client.checksum
    end
    lines[#lines + 1] = result.divergence == nil and ("no desync in " .. tostring(result.frames)) .. " frames" or "desync: " .. result.divergence
    if result.reloaded > 0 and #result.reloads == 0 then
        lines[#lines + 1] = ("hot reload " .. tostring(result.reloaded)) .. " running in every client"
    end
    for ____, reload in ipairs(result.reloads) do
        lines[#lines + 1] = reload
    end
    for ____, client in ipairs(result.clients) do
        for ____, ____error in ipairs(client.errors) do
            lines[#lines + 1] = (("p" .. tostring(client.slot)) .. ": ") .. ____error
        end
    end
    return lines
end
return ____exports
