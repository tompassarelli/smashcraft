local ____lualib = require("lualib_bundle")
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringTrim = ____lualib.__TS__StringTrim
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
--- `declare KEYWORD NAME...`: the name, up to the first character that can't be in one.
local function declaredName(line, keyword)
    local start = #keyword
    local ____end = start
    while ____end < #line do
        local character = __TS__StringCharAt(line, ____end)
        if character == "(" or character == ":" or character == " " then
            break
        end
        ____end = ____end + 1
    end
    return ____end > start and __TS__StringSlice(line, start, ____end) or nil
end
--- The type after the last `: ` and before the closing `;`.
local function declaredType(line)
    if not __TS__StringEndsWith(line, ";") then
        return nil
    end
    do
        local colon = #line - 2
        while colon > 0 do
            if __TS__StringCharAt(line, colon) == ":" and __TS__StringCharAt(line, colon + 1) == " " then
                return __TS__StringSlice(line, colon + 2, #line - 1)
            end
            colon = colon - 1
        end
    end
    return nil
end
function ____exports.parseNativeDeclarations(text)
    local functions = {}
    local constants = {}
    local variables = {}
    for ____, line in ipairs(__TS__StringSplit(text, "\n")) do
        do
            local keyword = __TS__StringStartsWith(line, "declare function ") and "declare function " or (__TS__StringStartsWith(line, "declare const ") and "declare const " or (__TS__StringStartsWith(line, "declare let ") and "declare let " or nil))
            if keyword == nil then
                goto __continue11
            end
            local name = declaredName(line, keyword)
            local ____type = declaredType(__TS__StringTrim(line))
            if name == nil or ____type == nil then
                goto __continue11
            end
            if keyword == "declare function " then
                functions[#functions + 1] = {name, ____type}
            elseif keyword == "declare const " then
                constants[#constants + 1] = {name, ____type}
            else
                variables[#variables + 1] = {name, ____type}
            end
        end
        ::__continue11::
    end
    return {functions = functions, constants = constants, variables = variables}
end
return ____exports
