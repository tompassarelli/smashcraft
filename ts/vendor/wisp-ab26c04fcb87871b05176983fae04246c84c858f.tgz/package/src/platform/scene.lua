local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__Iterator = ____lualib.__TS__Iterator
local Map = ____lualib.Map
local __TS__Spread = ____lualib.__TS__Spread
local __TS__SparseArrayNew = ____lualib.__TS__SparseArrayNew
local __TS__SparseArrayPush = ____lualib.__TS__SparseArrayPush
local __TS__SparseArraySpread = ____lualib.__TS__SparseArraySpread
local Set = ____lualib.Set
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
local ____scene = require("src.runtime.scene")
local reportedModel = ____scene.reportedModel
local sceneFile = ____scene.sceneFile
local sceneHeading = ____scene.sceneHeading
local sceneModelLine = ____scene.sceneModelLine
local ____dispatch = require("src.platform.dispatch")
local on = ____dispatch.on
local trampoline = ____dispatch.trampoline
local REPORT_SECONDS = 0.5
local REPORT = "scene.report"
local function scene()
    local globals = _G
    local state = globals[runtimeConfiguration().globalPrefix .. "SceneReport"]
    if state == nil then
        do
            local ____thrown = __TS__New(Error, "scene report used before startSceneReport")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/scene.ts:55"
            end
            error(____thrown, 0)
        end
    end
    return state
end
local function now(state)
    local frame = state.options.frame()
    if frame < state.last then
        state.offset = state.offset + (state.last - frame + 1)
    end
    state.last = frame
    return state.offset + frame
end
local function leftView(state, effect, frame)
    if effect.since == nil then
        return
    end
    local stayed = frame - effect.since
    if stayed > (state.longest:get(effect.model) or 0) then
        state.longest:set(effect.model, stayed)
    end
    effect.since = nil
end
local function created(state, handle, model)
    state.effects:set(
        handle,
        {
            model = model,
            created = now(state),
            alpha = 255,
            scale = 1.0,
            flat = false,
            since = nil,
            drawn = false
        }
    )
    return handle
end
local function wrapNatives(state)
    local add = AddSpecialEffect
    local addAt = AddSpecialEffectLoc
    local attach = AddSpecialEffectTarget
    local destroy = DestroyEffect
    local setAlpha = BlzSetSpecialEffectAlpha
    local setScale = BlzSetSpecialEffectScale
    local setMatrixScale = BlzSetSpecialEffectMatrixScale
    local resetMatrix = BlzResetSpecialEffectMatrix
    local natives = _G
    natives.AddSpecialEffect = function(model, x, y) return created(
        state,
        add(model, x, y),
        model
    ) end
    natives.AddSpecialEffectLoc = function(model, where) return created(
        state,
        addAt(model, where),
        model
    ) end
    natives.AddSpecialEffectTarget = function(model, target, point) return created(
        state,
        attach(model, target, point),
        model
    ) end
    natives.DestroyEffect = function(handle)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            leftView(
                state,
                effect,
                now(state)
            )
            state.effects:delete(handle)
            if not state.options.parked(
                BlzGetLocalSpecialEffectX(handle),
                BlzGetLocalSpecialEffectY(handle),
                BlzGetLocalSpecialEffectZ(handle)
            ) then
                state.destroyed:set(
                    effect.model,
                    (state.destroyed:get(effect.model) or 0) + 1
                )
            end
        end
        destroy(handle)
    end
    natives.BlzSetSpecialEffectAlpha = function(handle, alpha)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.alpha = alpha
        end
        setAlpha(handle, alpha)
    end
    natives.BlzSetSpecialEffectScale = function(handle, scale)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.scale = scale
        end
        setScale(handle, scale)
    end
    natives.BlzSetSpecialEffectMatrixScale = function(handle, x, y, z)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.flat = effect.flat or x == 0 or y == 0 or z == 0
        end
        setMatrixScale(handle, x, y, z)
    end
    natives.BlzResetSpecialEffectMatrix = function(handle)
        local effect = state.effects:get(handle)
        if effect ~= nil then
            effect.flat = false
        end
        resetMatrix(handle)
    end
end
--- Where each effect stands now: in view since when, and whether its model is drawn.
local function observe(state, frame)
    local ____state_options_0 = state.options
    local parked = ____state_options_0.parked
    for ____, ____value in __TS__Iterator(state.effects) do
        local handle = ____value[1]
        local effect = ____value[2]
        local inView = not parked(
            BlzGetLocalSpecialEffectX(handle),
            BlzGetLocalSpecialEffectY(handle),
            BlzGetLocalSpecialEffectZ(handle)
        )
        if not inView then
            leftView(state, effect, frame)
        else
            if effect.since == nil then
                effect.since = frame
            end
        end
        effect.drawn = inView and effect.alpha > 0 and effect.scale > 0 and not effect.flat
    end
end
--- Every model's line, in path order.
local function sceneModels(state, frame)
    local summaries = __TS__New(Map)
    for ____, effect in __TS__Iterator(state.effects:values()) do
        do
            local summary = summaries:get(effect.model) or ({
                live = 0,
                inView = 0,
                drawn = 0,
                created = effect.created,
                since = nil
            })
            summaries:set(effect.model, summary)
            summary.live = summary.live + 1
            summary.created = math.min(summary.created, effect.created)
            if effect.drawn then
                summary.drawn = summary.drawn + 1
            end
            if effect.since == nil then
                goto __continue31
            end
            summary.inView = summary.inView + 1
            summary.since = math.min(summary.since or effect.since, effect.since)
        end
        ::__continue31::
    end
    local ____Set_2 = Set
    local ____array_1 = __TS__SparseArrayNew(__TS__Spread(summaries:keys()))
    __TS__SparseArrayPush(
        ____array_1,
        __TS__Spread(state.longest:keys())
    )
    __TS__SparseArrayPush(
        ____array_1,
        __TS__Spread(state.destroyed:keys())
    )
    local models = __TS__ArraySort({__TS__Spread(__TS__New(
        ____Set_2,
        {__TS__SparseArraySpread(____array_1)}
    ))})
    return __TS__ArrayMap(
        models,
        function(____, model)
            local summary = summaries:get(model)
            local ____temp_5
            if (summary and summary.since) == nil then
                ____temp_5 = nil
            else
                ____temp_5 = frame - summary.since
            end
            local age = ____temp_5
            return {
                model = reportedModel(model),
                live = summary and summary.live or 0,
                inView = summary and summary.inView or 0,
                drawn = summary and summary.drawn or 0,
                created = summary and summary.created,
                age = age,
                longest = math.max(
                    state.longest:get(model) or 0,
                    age or 0
                ),
                destroyed = state.destroyed:get(model) or 0
            }
        end
    )
end
local function writeReport()
    local state = scene()
    local frame = now(state)
    observe(state, frame)
    state.serial = state.serial + 1
    PreloadGenClear()
    PreloadGenStart()
    Preload(sceneHeading(state.serial, frame, state.effects.size))
    for ____, model in ipairs(sceneModels(state, frame)) do
        Preload(sceneModelLine(model))
    end
    PreloadGenEnd(sceneFile(
        GetPlayerId(GetLocalPlayer()),
        runtimeConfiguration().filePrefix
    ))
end
--- Registers the report's handler; a reloaded bundle calls this again.
function ____exports.installSceneReport()
    on(REPORT, writeReport)
end
--- Starts recording and, every half second of game time, observing and
-- reporting. Call once, after configureRuntime and before the map creates an
-- effect.
function ____exports.startSceneReport(options)
    local globals = _G
    local key = runtimeConfiguration().globalPrefix .. "SceneReport"
    if globals[key] ~= nil then
        return
    end
    local state = {
        effects = __TS__New(Map),
        longest = __TS__New(Map),
        destroyed = __TS__New(Map),
        options = options,
        offset = 0,
        last = options.frame(),
        serial = 0
    }
    globals[key] = state
    wrapNatives(state)
    ____exports.installSceneReport()
    TimerStart(
        CreateTimer(),
        REPORT_SECONDS,
        true,
        trampoline(REPORT)
    )
end
return ____exports
