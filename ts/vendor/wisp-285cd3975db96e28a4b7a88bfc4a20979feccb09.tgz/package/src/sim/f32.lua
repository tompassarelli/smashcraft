local ____exports = {}
local ____binary32 = require("src.sim.binary32")
local addFloat32 = ____binary32.addFloat32
local divideFloat32 = ____binary32.divideFloat32
local multiplyFloat32 = ____binary32.multiplyFloat32
local subtractFloat32 = ____binary32.subtractFloat32
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local ADD = 1
local SUBTRACT = 2
local MULTIPLY = 3
local DIVIDE = 4
--- The operation codes the compiler passes as f32's third argument; no source writes them.
____exports.F32_ADD = ADD
____exports.F32_SUBTRACT = SUBTRACT
____exports.F32_MULTIPLY = MULTIPLY
____exports.F32_DIVIDE = DIVIDE
--- Integers up to 2^24 are binary32 values, so arithmetic that stays within it is exact under any rounding.
local EXACT_INTEGERS = 16777216
--- 2^-100: from there up, the difference of two values within a factor of two of each other is a normal number.
local STERBENZ_FLOOR = 0x1p-100
function ____exports.f32(value, right, operation)
    if right == nil or operation == nil then
        return value
    end
    if operation == MULTIPLY then
        if value == 0 or right == 0 then
            return value * right
        end
        if value == value // 1 and right == right // 1 and value >= -4096 and value <= 4096 and right >= -4096 and right <= 4096 then
            return value * right
        end
        if right == 1 or right == -1 or value == 1 or value == -1 then
            return value * right * 1.0
        end
        return multiplyFloat32(value, right)
    end
    if operation == DIVIDE then
        if value == 0 or right == 0 then
            return value / right
        end
        if value == value // 1 and right == right // 1 and value >= -EXACT_INTEGERS and value <= EXACT_INTEGERS then
            local quotient = value // right
            if quotient * right == value then
                return quotient * 1.0
            end
        end
        return divideFloat32(value, right)
    end
    if value == 0 or right == 0 then
        return operation == SUBTRACT and value - right or value + right
    end
    if value == value // 1 and right == right // 1 and value >= -EXACT_INTEGERS and value <= EXACT_INTEGERS and right >= -EXACT_INTEGERS and right <= EXACT_INTEGERS then
        local sum = operation == SUBTRACT and value - right or value + right
        if sum > -EXACT_INTEGERS and sum < EXACT_INTEGERS then
            return sum
        end
    end
    local subtrahend = operation == SUBTRACT and right or -right
    local ____temp_0
    if value > 0 then
        ____temp_0 = subtrahend > 0 and value >= STERBENZ_FLOOR and value < EXACT_INTEGERS and subtrahend <= value * 2.0 and value <= subtrahend * 2.0
    else
        ____temp_0 = subtrahend < 0 and value <= -STERBENZ_FLOOR and value > -EXACT_INTEGERS and subtrahend >= value * 2.0 and value >= subtrahend * 2.0
    end
    if ____temp_0 then
        return operation == SUBTRACT and value - right or value + right
    end
    return operation == SUBTRACT and subtractFloat32(value, right) or addFloat32(value, right)
end
return ____exports
