/** @noSelfInFile */
import type { Handle } from "./client";
export interface Frame extends Handle {
    /** BlzCreateFrameByType's type, such as "EDITBOX"; a template's name for BlzCreateFrame; "" for frames the game made. */
    readonly type: string;
    readonly name: string;
    readonly context: number;
    readonly parent: Frame | undefined;
    text: string;
    visible: boolean;
    enabled: boolean;
    level: number;
    textLimit: number;
    width: number;
    height: number;
    /** Absolute points, by framepointtype value. */
    readonly points: Map<unknown, {
        readonly x: number;
        readonly y: number;
    }>;
    destroyed: boolean;
}
/**
 * The framepointtype constants in ConvertFramePointType order, each with its
 * place on the frame: its share of the width from the left and of the height
 * from the top.
 */
export declare const FRAME_POINTS: readonly (readonly [name: string, fromLeft: number, fromTop: number])[];
export declare class Frames {
    private readonly points;
    private readonly all;
    private focused;
    /**
     * `points`: each framepointtype constant's value as the map's code sees it,
     * with its place on the frame.
     */
    constructor(points: ReadonlyMap<unknown, readonly [number, number]>);
    add(handle: Handle, type: string, name: string, parent: Frame | undefined, context: number): Frame;
    /** A frame the map made by name, if one is alive. */
    named(name: string, context: number): Frame | undefined;
    byId(id: number): Frame | undefined;
    /** BlzDestroyFrame: the frame and its descendants. */
    destroy(frame: Frame): void;
    focus(frame: Frame, flag: boolean): void;
    /** Whether a player sees the frame: it and every parent are visible. */
    shown(frame: Frame): boolean;
    /** The text of every frame a player sees, in creation order. */
    shownText(): string[];
    /** Where the frame is, from an absolute point and its size, or two opposite corners; undefined without one. */
    private rectangle;
    /**
     * The frame a click at (x, y) reaches: among shown, enabled frames that
     * `takes`, the highest level whose rectangle holds the point, the latest
     * created on a tie.
     */
    at(x: number, y: number, takes: (frame: Frame) => boolean): Frame | undefined;
    /**
     * Text the keyboard types reaches the focused edit box while a player sees
     * it, up to its character limit, as Warcraft drops the rest. False when no
     * edit box has the keyboard.
     */
    type(text: string): boolean;
}
