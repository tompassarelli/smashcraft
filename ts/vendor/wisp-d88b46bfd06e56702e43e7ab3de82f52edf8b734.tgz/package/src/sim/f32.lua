local ____exports = {}
local ____binary32 = require("src.sim.binary32")
local addFloat32 = ____binary32.addFloat32
local multiplyFloat32 = ____binary32.multiplyFloat32
local subtractFloat32 = ____binary32.subtractFloat32
--- The operation codes the compiler passes as f32's third argument; no source writes them.
____exports.F32_ADD = 1
____exports.F32_SUBTRACT = 2
____exports.F32_MULTIPLY = 3
--- Integers up to 2^24 are binary32 values, so arithmetic that stays within it is exact under any rounding.
local EXACT_INTEGERS = 16777216
local function integerWithin(value, limit)
    return value == math.floor(value) and value >= -limit and value <= limit
end
function ____exports.f32(value, right, operation)
    if right == nil or type(operation) ~= "number" then
        return value
    end
    if operation == ____exports.F32_MULTIPLY then
        if value == 0 or right == 0 or integerWithin(value, 4096) and integerWithin(right, 4096) then
            return value * right
        end
        return multiplyFloat32(value, right)
    end
    if value == 0 or right == 0 then
        return operation == ____exports.F32_SUBTRACT and value - right or value + right
    end
    if integerWithin(value, EXACT_INTEGERS) and integerWithin(right, EXACT_INTEGERS) then
        local sum = operation == ____exports.F32_SUBTRACT and value - right or value + right
        if sum > -EXACT_INTEGERS and sum < EXACT_INTEGERS then
            return sum
        end
    end
    return operation == ____exports.F32_SUBTRACT and subtractFloat32(value, right) or addFloat32(value, right)
end
return ____exports
