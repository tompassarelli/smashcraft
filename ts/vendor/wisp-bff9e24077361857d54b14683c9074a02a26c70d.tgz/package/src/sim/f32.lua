local ____exports = {}
local ____binary32 = require("src.sim.binary32")
local addFloat32 = ____binary32.addFloat32
local divideFloat32 = ____binary32.divideFloat32
local multiplyFloat32 = ____binary32.multiplyFloat32
local subtractFloat32 = ____binary32.subtractFloat32
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local ADD = 1
local SUBTRACT = 2
local MULTIPLY = 3
local DIVIDE = 4
--- The operation codes the compiler passes as f32's third argument; no source writes them.
____exports.F32_ADD = ADD
____exports.F32_SUBTRACT = SUBTRACT
____exports.F32_MULTIPLY = MULTIPLY
____exports.F32_DIVIDE = DIVIDE
--- Integers up to 2^24 are binary32 values, so arithmetic that stays within it is exact under any rounding.
local EXACT_INTEGERS = 16777216
--- 2^-100: from there up, the difference of two values within a factor of two of each other is a normal number.
local STERBENZ_FLOOR = 0x1p-100
local cachedLeft = {}
local cachedRight = {}
local cachedOperation = {}
local cachedResult = {}
do
    local i = 0
    while i < 8192 do
        cachedLeft[#cachedLeft + 1] = 0
        cachedRight[#cachedRight + 1] = 0
        cachedOperation[#cachedOperation + 1] = 0
        cachedResult[#cachedResult + 1] = 0
        i = i + 1
    end
end
local function slowFloat32(left, right, operation)
    local index = -1
    if left ~= 0 and right ~= 0 and left >= -32768 and left <= 32768 and right >= -32768 and right <= 32768 then
        index = (left * 256.0 // 1 ~ right * 256.0 // 1 * 31 ~ operation * 131) & 8191
        if cachedLeft[index + 1] == left and cachedRight[index + 1] == right and cachedOperation[index + 1] == operation then
            return cachedResult[index + 1] or 0
        end
    end
    local result = operation == MULTIPLY and multiplyFloat32(left, right) or (operation == DIVIDE and divideFloat32(left, right) or (operation == SUBTRACT and subtractFloat32(left, right) or addFloat32(left, right)))
    if index >= 0 then
        cachedLeft[index + 1] = left
        cachedRight[index + 1] = right
        cachedOperation[index + 1] = operation
        cachedResult[index + 1] = result
    end
    return result
end
--- A sum or difference whose larger operand is outside [2^-16, 2^16), NaN or infinite.
local function outsideSumRange(value, right, operation)
    local subtrahend = operation == SUBTRACT and right or -right
    local ____temp_0
    if value > 0 then
        ____temp_0 = subtrahend > 0 and value >= STERBENZ_FLOOR and value < EXACT_INTEGERS and subtrahend <= value * 2.0 and value <= subtrahend * 2.0
    else
        ____temp_0 = subtrahend < 0 and value <= -STERBENZ_FLOOR and value > -EXACT_INTEGERS and subtrahend >= value * 2.0 and value >= subtrahend * 2.0
    end
    if ____temp_0 then
        return operation == SUBTRACT and value - right or value + right
    end
    return slowFloat32(value, right, operation)
end
function ____exports.f32(value, right, operation)
    if right == nil or operation == nil then
        return value
    end
    if operation == MULTIPLY then
        if value == 0 or right == 0 then
            return value * right
        end
        if value == value // 1 and right == right // 1 and value >= -4096 and value <= 4096 and right >= -4096 and right <= 4096 then
            return value * right
        end
        if right == 1 or right == -1 or value == 1 or value == -1 then
            return value * right * 1.0
        end
        return slowFloat32(value, right, operation)
    end
    if operation == DIVIDE then
        if value == 0 or right == 0 then
            return value / right
        end
        if value == value // 1 and right == right // 1 and value >= -EXACT_INTEGERS and value <= EXACT_INTEGERS then
            local quotient = value // right
            if quotient * right == value then
                return quotient * 1.0
            end
        end
        return slowFloat32(value, right, operation)
    end
    if value == 0 or right == 0 then
        return operation == SUBTRACT and value - right or value + right
    end
    if value == value // 1 and right == right // 1 and value >= -EXACT_INTEGERS and value <= EXACT_INTEGERS and right >= -EXACT_INTEGERS and right <= EXACT_INTEGERS then
        local sum = operation == SUBTRACT and value - right or value + right
        if sum > -EXACT_INTEGERS and sum < EXACT_INTEGERS then
            return sum
        end
    end
    local valueNegative = value < 0
    local ____temp_1
    if operation == SUBTRACT then
        ____temp_1 = right > 0
    else
        ____temp_1 = right < 0
    end
    local addendNegative = ____temp_1
    local big = valueNegative and -value or value
    local small = right < 0 and -right or right
    local negative = valueNegative
    if not (small <= big) then
        local larger = small
        small = big
        big = larger
        negative = addendNegative
    end
    local up
    local down
    if big < 1.0 then
        if big < 0x1p-8 then
            if big < 0x1p-12 then
                if big < 0x1p-14 then
                    if big < 0x1p-15 then
                        if big < 0x1p-16 then
                            return outsideSumRange(value, right, operation)
                        end
                        up = 549755813888.0
                        down = 0x1p-39
                    else
                        up = 274877906944.0
                        down = 0x1p-38
                    end
                else
                    if big < 0x1p-13 then
                        up = 137438953472.0
                        down = 0x1p-37
                    else
                        up = 68719476736.0
                        down = 0x1p-36
                    end
                end
            else
                if big < 0x1p-10 then
                    if big < 0x1p-11 then
                        up = 34359738368.0
                        down = 0x1p-35
                    else
                        up = 17179869184.0
                        down = 0x1p-34
                    end
                else
                    if big < 0x1p-9 then
                        up = 8589934592.0
                        down = 0x1p-33
                    else
                        up = 4294967296.0
                        down = 0x1p-32
                    end
                end
            end
        else
            if big < 0x1p-4 then
                if big < 0x1p-6 then
                    if big < 0x1p-7 then
                        up = 2147483648.0
                        down = 0x1p-31
                    else
                        up = 1073741824.0
                        down = 0x1p-30
                    end
                else
                    if big < 0x1p-5 then
                        up = 536870912.0
                        down = 0x1p-29
                    else
                        up = 268435456.0
                        down = 0x1p-28
                    end
                end
            else
                if big < 0x1p-2 then
                    if big < 0x1p-3 then
                        up = 134217728.0
                        down = 0x1p-27
                    else
                        up = 67108864.0
                        down = 0x1p-26
                    end
                else
                    if big < 0x1p-1 then
                        up = 33554432.0
                        down = 0x1p-25
                    else
                        up = 16777216.0
                        down = 0x1p-24
                    end
                end
            end
        end
    else
        if big < 256.0 then
            if big < 16.0 then
                if big < 4.0 then
                    if big < 2.0 then
                        up = 8388608.0
                        down = 0x1p-23
                    else
                        up = 4194304.0
                        down = 0x1p-22
                    end
                else
                    if big < 8.0 then
                        up = 2097152.0
                        down = 0x1p-21
                    else
                        up = 1048576.0
                        down = 0x1p-20
                    end
                end
            else
                if big < 64.0 then
                    if big < 32.0 then
                        up = 524288.0
                        down = 0x1p-19
                    else
                        up = 262144.0
                        down = 0x1p-18
                    end
                else
                    if big < 128.0 then
                        up = 131072.0
                        down = 0x1p-17
                    else
                        up = 65536.0
                        down = 0x1p-16
                    end
                end
            end
        else
            if big < 4096.0 then
                if big < 1024.0 then
                    if big < 512.0 then
                        up = 32768.0
                        down = 0x1p-15
                    else
                        up = 16384.0
                        down = 0x1p-14
                    end
                else
                    if big < 2048.0 then
                        up = 8192.0
                        down = 0x1p-13
                    else
                        up = 4096.0
                        down = 0x1p-12
                    end
                end
            else
                if big < 16384.0 then
                    if big < 8192.0 then
                        up = 2048.0
                        down = 0x1p-11
                    else
                        up = 1024.0
                        down = 0x1p-10
                    end
                else
                    if big < 32768.0 then
                        up = 512.0
                        down = 0x1p-9
                    else
                        if not (big < 65536.0) then
                            return outsideSumRange(value, right, operation)
                        end
                        up = 256.0
                        down = 0x1p-8
                    end
                end
            end
        end
    end
    local scaledBig = big * up
    local scaledSmall = small * up
    if scaledSmall < 0x1p-2 then
        return negative and -(scaledBig * down) or scaledBig * down
    end
    local whole = scaledSmall // 1
    local fraction = scaledSmall - whole
    local bigUnits = scaledBig | 0
    local smallUnits = whole | 0
    local units
    if valueNegative == addendNegative then
        units = bigUnits + smallUnits
        if units < 16777216 then
            if fraction > 0x1p-1 or fraction == 0x1p-1 and units & 1 == 1 then
                units = units + 1
            end
        elseif units & 1 == 1 then
            units = units + ((fraction > 0 or units & 2 == 2) and 1 or -1)
        end
    elseif fraction == 0 then
        units = bigUnits - smallUnits
        if units == 0 then
            return 0.0
        end
    else
        units = bigUnits - smallUnits - 1
        if units >= 8388608 then
            if fraction < 0x1p-1 or fraction == 0x1p-1 and units & 1 == 1 then
                units = units + 1
            end
        elseif units >= 4194304 then
            units = units * 2 + (fraction <= 0x1p-2 and 2 or (fraction < 0x3p-2 and 1 or 0))
            return negative and -(units * down * 0x1p-1) or units * down * 0x1p-1
        else
            return negative and small - big or big - small
        end
    end
    return negative and -(units * down) or units * down
end
return ____exports
