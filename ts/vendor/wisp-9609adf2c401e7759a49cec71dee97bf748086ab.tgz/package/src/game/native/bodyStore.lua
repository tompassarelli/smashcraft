local ____lualib = require("lualib_bundle")
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____binary32 = require("src.sim.binary32")
local ____f32 = require("src.sim.f32")
local ____animation = require("src.game.native.animation")
local PLAYER_COLORS = __TS__ArrayMap(
    {
        "RED",
        "BLUE",
        "CYAN",
        "PURPLE",
        "YELLOW",
        "ORANGE",
        "GREEN",
        "PINK",
        "LIGHT_GRAY",
        "LIGHT_BLUE",
        "AQUA",
        "BROWN",
        "MAROON",
        "NAVY",
        "TURQUOISE",
        "VIOLET",
        "WHEAT",
        "PEACH",
        "MINT",
        "LAVENDER",
        "COAL",
        "SNOW",
        "EMERALD",
        "PEANUT",
        "BLACK"
    },
    function(____, name) return "PLAYER_COLOR_" .. name end
)
--- The store's view of a body handle that the contract names as a Warcraft unit.
____exports.asBody = function(value) return value end
____exports.DEATH_CUTOFF = 0xcf5c29p-25
local RADIANS_PER_DEGREE = 0x8efa35p-29
local DEGREES_PER_RADIAN = 0xe52ee1p-18
local TURN = 0xc90fdbp-21
--- Two ulps above the binary32 nearest 1 / TURN, as 3.0.1 multiplies by it.
local TURNS_PER_RADIAN = 0xa2f985p-26
local function bodyFacing(degrees)
    local radians = ____binary32.multiplyFloat32TowardZero(degrees, RADIANS_PER_DEGREE)
    if radians >= TURN or radians < -TURN then
        local turns = ____binary32.multiplyFloat32TowardZero(radians, TURNS_PER_RADIAN)
        radians = ____binary32.multiplyFloat32TowardZero(
            __wispF32Subtract(
                turns,
                math.floor(turns)
            ),
            TURN
        )
    elseif radians < 0 then
        radians = ____binary32.subtractFloat32TowardZero(TURN, -radians)
    end
    return ____binary32.multiplyFloat32TowardZero(radians, DEGREES_PER_RADIAN)
end
--- The posed bodies of one running game and the locations the map asked for.
____exports.Bodies = __TS__Class()
local Bodies = ____exports.Bodies
Bodies.name = "Bodies"
function Bodies.prototype.____constructor(self, handle, states)
    self.handle = handle
    self.states = states
    self.live = __TS__New(Map)
    self.removals = {}
    self.locations = __TS__New(Map)
end
function Bodies.prototype.liveLocations(self)
    return self.locations.size
end
function Bodies.prototype.location(self, x, y)
    local handle = self.handle("location")
    self.locations:set(handle, {x = x, y = y})
    return handle
end
function Bodies.prototype.locationAt(self, handle)
    return self.locations:get(handle) or ({x = 0, y = 0})
end
function Bodies.prototype.removeLocation(self, handle)
    self.locations:delete(handle)
end
function Bodies.prototype.moveLocation(self, handle, x, y)
    local location = self.locations:get(handle)
    if location ~= nil then
        location.x = x
        location.y = y
    end
end
function Bodies.prototype.mapCenter(self)
    return {
        rect = self.handle("rect"),
        location = self.handle("location")
    }
end
function Bodies.prototype.create(self, owner, typeId, x, y, facing)
    local handle = self.handle("unit")
    local state = self.states[typeId]
    local body = __TS__ObjectAssign(
        {},
        handle,
        ____animation.freshAnimation(),
        {
            handle = handle,
            typeId = typeId,
            owner = owner,
            x = x,
            y = y,
            z = 0,
            facing = bodyFacing(facing),
            scale = {1, 1, 1},
            alpha = 255,
            color = {255, 255, 255},
            teamColor = owner,
            timeScale = 1,
            visible = true,
            moveSpeed = 0,
            attackCooldown = 0,
            life = state and state.life,
            maxLife = state and state.maxLife,
            mana = state and state.mana,
            maxMana = state and state.maxMana,
            dead = state ~= nil and state.life <= ____exports.DEATH_CUTOFF,
            removed = false
        }
    )
    self.live:set(body, body)
    return body
end
function Bodies.prototype.remove(self, body)
    local ____self_removals_8 = self.removals
    ____self_removals_8[#____self_removals_8 + 1] = body
    self.live:delete(body)
end
function Bodies.prototype.setX(self, body, x)
    body.x = x
end
function Bodies.prototype.setY(self, body, y)
    body.y = y
end
function Bodies.prototype.setHeight(self, body, height)
    body.z = height
end
function Bodies.prototype.setFacing(self, body, degrees)
    body.facing = bodyFacing(degrees)
end
function Bodies.prototype.setColor(self, body, color)
    body.teamColor = type(color) == "number" and color or __TS__ArrayIndexOf(PLAYER_COLORS, color)
end
function Bodies.prototype.setTint(self, body, red, green, blue, alpha)
    body.color = {red, green, blue}
    body.alpha = alpha
end
function Bodies.prototype.setScale(self, body, x, y, z)
    body.scale = {x, y, z}
end
function Bodies.prototype.setTimeScale(self, body, timeScale)
    body.timeScale = timeScale
end
function Bodies.prototype.setBlendTime(self, body, seconds)
    body.animationBlendTime = seconds
end
function Bodies.prototype.animate(self, body, animation)
    ____animation.selectAnimation(body, animation)
end
function Bodies.prototype.show(self, body, show)
    body.visible = show
end
function Bodies.prototype.setMoveSpeed(self, body, speed)
    body.moveSpeed = speed
end
function Bodies.prototype.setAttackCooldown(self, body, cooldown)
    body.attackCooldown = cooldown
end
function Bodies.prototype.kind(self, body)
    return body.removed and 0 or body.typeId
end
function Bodies.prototype.draw(self, seconds)
    for ____, body in __TS__Iterator(self.live:values()) do
        ____animation.advanceAnimation(body, body.timeScale, seconds)
    end
end
function Bodies.prototype.settleRemovals(self)
    for ____, body in ipairs(self.removals) do
        body.removed = true
    end
    self.removals = {}
end
function Bodies.prototype.poses(self)
    local poses = {}
    for ____, unit in __TS__Iterator(self.live:values()) do
        poses[#poses + 1] = {
            handle = unit.handle,
            typeId = unit.typeId,
            owner = unit.owner,
            x = unit.x,
            y = unit.y,
            z = unit.z,
            facing = unit.facing,
            scale = {table.unpack(unit.scale)},
            alpha = unit.alpha,
            color = {table.unpack(unit.color)},
            teamColor = unit.teamColor,
            timeScale = unit.timeScale,
            visible = unit.visible,
            animation = unit.animation,
            subAnimations = {table.unpack(unit.subAnimations)},
            animationElapsed = unit.animationElapsed,
            animationClock = unit.animationClock,
            animationBlendTime = unit.animationBlendTime,
            animationBlend = ____animation.copyBlend(unit.animationBlend)
        }
    end
    return poses
end
return ____exports
