local ____exports = {}
local ____textFormat = require("src.game.native.textFormat")
local ____world = require("src.game.native.world")
function ____exports.formatInt(value)
    ____world.logNativeCall("I2S", {value})
    return ____textFormat.describeNumber(value)
end
function ____exports.formatReal(value)
    ____world.logNativeCall("R2S", {value})
    return ____textFormat.fixed(value, 3)
end
function ____exports.formatRealWidth(value, width, precision)
    ____world.logNativeCall("R2SW", {value, width, precision})
    return ____textFormat.fixedWidth(value, width, precision)
end
function ____exports.parseInt(text)
    ____world.logNativeCall("S2I", {text})
    return ____textFormat.parsedInteger(text)
end
function ____exports.parseReal(text)
    ____world.logNativeCall("S2R", {text})
    return ____textFormat.parsedReal(text)
end
function ____exports.toReal(value)
    ____world.logNativeCall("I2R", {value})
    return value
end
function ____exports.truncate(value)
    ____world.logNativeCall("R2I", {value})
    return ____textFormat.truncated(value)
end
function ____exports.textLength(text)
    ____world.logNativeCall("StringLength", {text})
    return #text
end
return ____exports
