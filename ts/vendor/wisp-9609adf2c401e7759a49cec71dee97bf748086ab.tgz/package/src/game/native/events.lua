local ____exports = {}
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
function ____exports.createEvents()
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("CreateTrigger", {})
    end
    return ____types.fromHandle(world.events:create())
end
function ____exports.onEvents(events, handler)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("TriggerAddAction", {events, handler})
    end
    world.events:addAction(
        ____types.asHandle(events),
        handler
    )
end
function ____exports.destroyEvents(events)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("DestroyTrigger", {events})
    end
    world.events:destroy(____types.asHandle(events))
end
return ____exports
