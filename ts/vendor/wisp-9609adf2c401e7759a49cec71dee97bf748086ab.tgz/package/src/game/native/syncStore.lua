local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
--- The longest message the relay carries, in characters.
____exports.SYNC_LIMIT = 255
--- The messages that one running game's client has sent and that the host has not yet delivered to every client.
____exports.Sync = __TS__Class()
local Sync = ____exports.Sync
Sync.name = "Sync"
function Sync.prototype.____constructor(self, slot, outbox)
    self.slot = slot
    self.outbox = outbox
end
function Sync.prototype.send(self, prefix, data)
    local ____self_outbox_0 = self.outbox
    ____self_outbox_0[#____self_outbox_0 + 1] = {sender = self.slot, prefix = prefix, data = data}
    return true
end
return ____exports
