local ____exports = {}
--- Warcraft III's simulation rate, which headless clients, lockstep peers and the renderers step at.
____exports.FRAMES_PER_SECOND = 60
____exports.FRAME_MS = 1000 / ____exports.FRAMES_PER_SECOND
--- Frames headless clients have stepped in this process: a test's deterministic cost (wisp:host/testing/testCostPreload.ts).
____exports.steppedFrames = {count = 0}
____exports.EVEN_CALLBACKS = {wallMs = function(frame) return frame * ____exports.FRAME_MS end}
function ____exports.turnStart(timing, frame)
    if timing == nil then
        return frame
    end
    local start = frame
    while timing.wallMs(start) <= timing.wallMs(start - 1) do
        start = start + 1
    end
    return start
end
function ____exports.stampWallTime(timing, clients, frame)
    if timing == nil then
        return
    end
    for ____, client in ipairs(clients) do
        client:setWallTime(timing.wallMs(frame) / 1000)
    end
end
return ____exports
