local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local ____exports = {}
--- The players of one running game: who this client is, who plays, their names and the colour the map gave each slot.
____exports.Players = __TS__Class()
local Players = ____exports.Players
Players.name = "Players"
function Players.prototype.____constructor(self, slots)
    self.slots = slots
    self.colors = __TS__New(Map)
end
Players.prototype["local"] = function(self)
    return self.slots.slot
end
function Players.prototype.playing(self, slot)
    return __TS__ArrayIncludes(self.slots.humans, slot)
end
function Players.prototype.name(self, slot)
    local ____opt_0 = self.slots.names
    return ____opt_0 and ____opt_0[slot] or "Player " .. tostring(slot + 1)
end
function Players.prototype.control(self, slot)
    return self:playing(slot) and "MAP_CONTROL_USER" or "MAP_CONTROL_NONE"
end
function Players.prototype.slotState(self, slot)
    return self:playing(slot) and "PLAYER_SLOT_STATE_PLAYING" or "PLAYER_SLOT_STATE_EMPTY"
end
function Players.prototype.setColor(self, slot, color)
    self.colors:set(slot, color)
end
function Players.prototype.color(self, slot)
    return self.colors:get(slot)
end
return ____exports
