local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____syncStore = require("src.game.native.syncStore")
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
function ____exports.sendSync(prefix, data)
    if #data > ____syncStore.SYNC_LIMIT then
        do
            local ____thrown = __TS__New(
                Error,
                (("a sync message carries at most " .. tostring(____syncStore.SYNC_LIMIT)) .. " characters, not ") .. tostring(#data)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/game/native/sync.ts:8"
            end
            error(____thrown, 0)
        end
    end
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("BlzSendSyncData", {prefix, data})
    end
    return world.sync:send(prefix, data)
end
function ____exports.addSyncEvent(events, player, prefix)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("BlzTriggerRegisterPlayerSyncEvent", {events, player, prefix, false})
    end
    world.events:registerSync(
        ____types.asHandle(events),
        ____types.asNumber(player),
        prefix
    )
end
function ____exports.syncData()
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("BlzGetTriggerSyncData", {})
    end
    return world.events:syncData()
end
function ____exports.syncPrefix()
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("BlzGetTriggerSyncPrefix", {})
    end
    return world.events:syncPrefix()
end
return ____exports
