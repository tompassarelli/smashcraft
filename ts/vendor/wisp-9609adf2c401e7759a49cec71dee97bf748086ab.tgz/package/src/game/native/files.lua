local ____exports = {}
local ____world = require("src.game.native.world")
function ____exports.clearFileLines()
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("PreloadGenClear", {})
    end
    world.files:clear()
end
function ____exports.startFile()
    local ____opt_2 = ____world.boundWorld().log
    if ____opt_2 ~= nil then
        ____opt_2("PreloadGenStart", {})
    end
end
function ____exports.addFileLine(text)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("Preload", {text})
    end
    world.files:add(text)
end
function ____exports.endFile(path)
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("PreloadGenEnd", {path})
    end
    local ____self_8 = world.files
    ____self_8["end"](____self_8, path)
end
function ____exports.preloadAsset(path)
    local ____opt_9 = ____world.boundWorld().log
    if ____opt_9 ~= nil then
        ____opt_9("Preload", {path})
    end
end
return ____exports
