local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local ____f32 = require("src.sim.f32")
____exports.Lightnings = __TS__Class()
local Lightnings = ____exports.Lightnings
Lightnings.name = "Lightnings"
function Lightnings.prototype.____constructor(self, handle)
    self.handle = handle
    self.bolts = __TS__New(Map)
end
function Lightnings.prototype.add(self, codeName, x1, y1, z1, x2, y2, z2)
    local handle = self.handle("lightning")
    self.bolts:set(handle, {
        handle = handle,
        codeName = codeName,
        from = {x1, y1, z1},
        to = {x2, y2, z2},
        color = {1, 1, 1, 1}
    })
    return handle
end
function Lightnings.prototype.move(self, bolt, x1, y1, z1, x2, y2, z2)
    local found = self.bolts:get(bolt)
    if found == nil then
        return false
    end
    found.from = {x1, y1, z1}
    found.to = {x2, y2, z2}
    return true
end
function Lightnings.prototype.destroy(self, bolt)
    return self.bolts:delete(bolt)
end
function Lightnings.prototype.setColor(self, bolt, red, green, blue, alpha)
    local found = self.bolts:get(bolt)
    if found == nil then
        return false
    end
    found.color = {red, green, blue, alpha}
    return true
end
function Lightnings.prototype.channel(self, bolt, index)
    local ____opt_0 = self.bolts:get(bolt)
    return ____opt_0 and ____opt_0.color[index + 1] or 0
end
function Lightnings.prototype.poses(self)
    return __TS__ArrayMap(
        {__TS__Spread(self.bolts:values())},
        function(____, found) return {
            handle = found.handle,
            codeName = found.codeName,
            from = {table.unpack(found.from)},
            to = {table.unpack(found.to)},
            color = {table.unpack(found.color)}
        } end
    )
end
return ____exports
