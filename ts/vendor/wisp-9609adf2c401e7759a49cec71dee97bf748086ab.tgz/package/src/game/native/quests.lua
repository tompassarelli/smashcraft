local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Spread = ____lualib.__TS__Spread
local ____exports = {}
--- The quest log a game fills with `createQuest`; a headless test reads `entries()` where Warcraft would draw the log.
____exports.Quests = __TS__Class()
local Quests = ____exports.Quests
Quests.name = "Quests"
function Quests.prototype.____constructor(self, handle)
    self.handle = handle
    self.log = __TS__New(Map)
end
function Quests.prototype.create(self)
    local quest = self.handle("quest")
    self.log:set(quest, {
        title = "",
        description = "",
        iconPath = "",
        required = false,
        discovered = false,
        completed = false
    })
    return quest
end
function Quests.prototype.entry(self, quest)
    return self.log:get(quest)
end
function Quests.prototype.entries(self)
    return {__TS__Spread(self.log:values())}
end
return ____exports
