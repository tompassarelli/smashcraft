/** @noSelfInFile */
import { type AnimationState } from "./animation";
import type { FrameTemplate } from "./frames";
import type { NativeDeclarations } from "./declarations";
import { type Frame, Frames } from "./frames";
import { Warcraft3Abilities } from "./warcraft3Abilities";
import { Scenery, type SceneryFixtures } from "./warcraft3Scenery";
import { Warcraft3Inventory, type Warcraft3InventoryFixtures } from "./warcraft3Inventory";
export type Handle = {
    readonly kind: string;
    readonly id: number;
};
export interface NativeCall {
    readonly name: string;
    readonly args: readonly unknown[];
}
export interface SyncMessage {
    readonly sender: number;
    readonly prefix: string;
    readonly data: string;
}
/** What a map's entry exports: start once per match, install after each hot reload. */
export interface MapEntry {
    start(this: void): void;
    install(this: void): void;
}
/** Native name to why a client may call it when the others don't. */
export type LocalNatives = Readonly<Record<string, string>>;
/** Exact native names and why ignoring their behavior is intentional for this map. */
export type IntentionalNoops = Readonly<Record<string, string>>;
export interface MissingNative {
    readonly native: string;
    readonly client: number;
    readonly frame: number;
}
/** A native's behavior; a host or game supplies one for a native the default stub can't answer. */
export type NativeBehavior = (this: void, ...args: never[]) => unknown;
/** Natives a host or game adds or replaces, and other globals its map code reads, such as Lua's. */
export type NativeBehaviors = Readonly<Record<string, unknown>>;
/**
 * Natives Wisp's own runtime calls on one client only. A game adds the ones
 * its code calls that way: local UI, input polling, conversions for local text.
 */
export declare const WISP_LOCAL_NATIVES: LocalNatives;
/** A special effect as the client shows it. */
export interface EffectPose extends AnimationState {
    readonly handle: Handle;
    readonly model: string;
    /** The client frame it was created on. */
    readonly created: number;
    x: number;
    y: number;
    /** Where AddSpecialEffect puts it, 0, until the map moves it. */
    z: number;
    alpha: number;
    scale: number;
    timeScale: number;
    queuedAnimations: string[];
    yaw: number;
    pitch: number;
    roll: number;
    color: [number, number, number];
    teamColor: number;
    matrixScale: [number, number, number];
    /** A matrix scale of zero on some axis since the matrix was last reset. */
    flat: boolean;
    /** The frame DestroyEffect was called; EffectDeathTime removes the model after five game seconds. */
    destroyed?: number;
    /** Seconds of the model's Death sequence, when it has one. */
    death?: number;
}
/** Seconds of a model's Death sequence at time scale 1; undefined when it has none. */
export type EffectDeaths = (this: void, model: string) => number | undefined;
export interface CameraPose {
    readonly x: number;
    readonly y: number;
    readonly fields: Readonly<Record<string, number>>;
}
export interface SoundCue {
    readonly event: "create" | "start" | "stop" | "volume";
    readonly kind: "sound" | "music";
    readonly frame: number;
    readonly handle: Handle;
    readonly source: string | undefined;
    readonly label: string | undefined;
    readonly volume: number;
    readonly effectiveVolume: number;
    readonly looping: boolean;
    readonly pitch: number;
    readonly x: number;
    readonly y: number;
    readonly z: number;
}
/** One pure assertion over emitted cues; creation alone never counts as playing. */
export declare function assertSoundCue(log: readonly SoundCue[], expected: {
    readonly source?: string;
    readonly label?: string;
    readonly frame?: number;
    readonly count?: number;
}): void;
export interface UnitPose extends AnimationState {
    readonly handle: Handle;
    readonly typeId: number;
    owner: number;
    x: number;
    y: number;
    z: number;
    /** Warcraft's unit facing, in degrees. */
    facing: number;
    scale: [number, number, number];
    alpha: number;
    color: [number, number, number];
    teamColor: number;
    timeScale: number;
    visible: boolean;
}
/** Object-data values declared by the map, keyed by its unit type ID. */
export interface UnitStateFixture {
    readonly life: number;
    readonly maxLife: number;
    readonly mana: number;
    readonly maxMana: number;
}
export type UnitStateFixtures = Readonly<Record<number, UnitStateFixture>>;
/**
 * A client's CustomMapData folder outside the process, so another program,
 * such as an input helper, reads what the map writes and writes what it reads.
 */
export interface ClientFiles {
    /** A file the map wrote with PreloadGenEnd: its Preload lines. */
    written(this: void, name: string, lines: readonly string[]): void;
    /** What Preloader reads from a file someone else wrote: one chunk per FileIO tooltip level; undefined while it is missing. */
    read(this: void, name: string): readonly string[] | undefined;
}
/** How a host makes one client's natives and state the ones map code sees while it runs. */
export interface ClientScope {
    enter(this: void, client: HeadlessClient): void;
    leave(this: void, client: HeadlessClient): void;
}
export interface ClientOptions {
    readonly unitStates?: UnitStateFixtures;
    readonly scenery?: SceneryFixtures;
    readonly inventory?: Warcraft3InventoryFixtures;
    readonly slot: number;
    /** The map's configureRuntime() filePrefix, which names the file its error reports go to. */
    readonly filePrefix: string;
    /** Player slots with a human client; the others are empty. */
    readonly humans: readonly number[];
    readonly declarations: NativeDeclarations;
    readonly localNatives: LocalNatives;
    readonly intentionalNoops?: IntentionalNoops;
    readonly network: SyncMessage[];
    readonly screenWidth: number;
    readonly scope?: ClientScope;
    /** Added or replacing natives; values that aren't declared natives, such as Lua globals, are set unlogged. */
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly files?: ClientFiles;
    /** Frame definitions (wisp:docs/ui.md) whose trees BlzCreateFrame makes by name, as their generated FDF does in Warcraft. */
    readonly frames?: readonly FrameTemplate[];
    /** Death sequences of the models drawn; without one, a destroyed effect keeps its animation until cleanup. */
    readonly effectDeaths?: EffectDeaths;
    /** The player's Options > Sound music slider, 0 to 1 (default 1): it scales music cues' effectiveVolume, not sound effects'. */
    readonly musicSlider?: number;
}
export declare const FRAMES_PER_SECOND = 60;
/**
 * A number as both runtimes print it alike: an integer in digits, any other
 * value exactly, as an integer times a power of two. Lua prints 3.0 for a
 * float that JavaScript prints as 3, and neither prints every binary digit.
 */
export declare function describeNumber(value: number): string;
/** A native argument, the same on every client and in both runtimes: handles by kind and number, callbacks as `fn`. */
export declare function describeValue(value: unknown): string;
export declare function describeCall({ name, args }: NativeCall): string;
/** Whether two clients made the same call: equal values, handles with the same kind and number, any two callbacks. */
export declare function sameCall(left: NativeCall, right: NativeCall): boolean;
export declare class HeadlessClient {
    readonly scenery: Scenery;
    readonly inventory: Warcraft3Inventory;
    readonly abilities: Warcraft3Abilities;
    readonly textAreaAutoScroll: Map<Handle, boolean>;
    readonly heldMouseButtons: Set<unknown>;
    mouseScreenX: number;
    mouseScreenY: number;
    private heldMeta;
    readonly slot: number;
    /** Every native call the other clients must make alike, in order, since the calls forget() dropped. */
    readonly log: NativeCall[];
    /** Calls forget() dropped from the front of `log`; the checksum still covers them. */
    forgotten: number;
    private forgottenHash;
    /** Error reports the map wrote to its error file, shown on screen or not: `error in HANDLER: MESSAGE`. */
    readonly errors: string[];
    /** First unmodeled call of each native, including local-only calls. */
    readonly missingNatives: MissingNative[];
    /** Every message the map showed this client. */
    readonly messages: string[];
    /** Where the host keeps what a thrown error says beyond the map's report, such as a JavaScript stack. */
    readonly thrown: string[];
    /** Files the map wrote, by name: their Preload lines. */
    readonly files: Map<string, string[]>;
    /** Files the host put in CustomMapData for Preloader: one chunk per FileIO tooltip level. */
    readonly published: Map<string, readonly string[]>;
    /**
     * Preloader calls for a file nobody had published, which Wine answers by
     * reading the folder that should hold it: all of CustomMapData when the
     * file's own folder is missing too (wisp:docs/hot-reload.md).
     */
    missedLookups: number;
    readonly natives: Record<string, unknown>;
    /** Frames this client has run. */
    frame: number;
    private nextId;
    private readonly scope;
    private readonly filePrefix;
    private readonly timers;
    private timerOrder;
    /** Game time as natives read it, in binary32 seconds: a timer callback's own deadline, otherwise the end of the latest frame. */
    private now;
    private readonly registrations;
    private readonly heldKeys;
    private readonly memo;
    private allPlayers;
    /** Effects shown, in creation order, including destroyed ones still playing Death. */
    private readonly effects;
    private readonly effectDeaths;
    private readonly musicSlider;
    private readonly units;
    /** Units RemoveUnit took out of the world this frame; their handles keep their state until the frame ends. */
    private removals;
    private readonly unitStates;
    private readonly sounds;
    readonly soundLog: SoundCue[];
    private music;
    private musicVolume;
    private cameraX;
    private cameraY;
    private readonly cameraFields;
    private readonly tooltips;
    /** Preloader runs the content it first read from a path for the rest of the session. */
    private readonly preloaded;
    private event;
    private preload;
    private readonly stored;
    /** The frames this client shows: their text, places, and which takes a click or the keyboard. */
    readonly frames: Frames;
    constructor(options: ClientOptions);
    private handle;
    private defaultNative;
    private defaultValue;
    /** A frame Warcraft made, such as an origin frame: one handle per frame, made at its first lookup. */
    private memoized;
    private created;
    private effectAt;
    private unitAt;
    private unitValue;
    /**
     * Native life writes round the change from current life before applying it, with halfway changes
     * toward zero; the cutoff applies to that result (wisp:docs/warsmash-notes.md#native-results-for-44).
     */
    private setLife;
    private unitAnimation;
    private sound;
    private cue;
    private stopAudio;
    private playMusic;
    private startSound;
    private cameraField;
    /** The effect the map can still change: made and not destroyed. */
    private liveEffect;
    /** Warcraft starts Death when present, then removes the effect on its gameplay decay timer. */
    private destroyEffect;
    private playEffect;
    private show;
    /** A report file's lines as the screen would show them: its heading names the handler, its next line the message. */
    private report;
    private behaviors;
    /** The published files Preloader has read in this client, in the order it first read them. */
    preloadedFiles(): string[];
    /** The effects this client shows now, as copies, in creation order. */
    effectPoses(options?: {
        readonly visibleOnly?: boolean;
    }): EffectPose[];
    cameraPose(): CameraPose;
    /** Live unit appearance copied in creation order; hidden units retain their pose. */
    unitPoses(): UnitPose[];
    /** Makes this client's natives and state the ones map code sees, and runs `body`. */
    run(body: (this: void) => void): void;
    private fire;
    /** One game frame: the engine's clocks advance, then every timer callback due by its end runs. */
    step(): void;
    /** Seconds into a timer's current period, at the game time natives read: its period less what remains, each rounded toward zero. */
    private timerElapsed;
    /**
     * Every callback due by the end of this frame, earliest deadline first and
     * equal deadlines in TimerStart order; a period shorter than a frame
     * catches up within it, and a timer started in a callback fires in this
     * frame when it falls due in it. Each callback reads its own deadline as
     * the time (wisp:docs/warsmash-notes.md#timers-and-frame-stepping).
     */
    private runDueTimers;
    deliverSync({ sender, prefix, data }: SyncMessage): void;
    chat(sender: number, message: string): void;
    key(sender: number, key: number, meta: number, down: boolean): void;
    /**
     * Text this client's keyboard types: into the edit box that has the
     * keyboard, while the player sees it. False when none has it, so Warcraft
     * would take the text as key presses.
     */
    type(text: string): boolean;
    /** The frame a click at (x, y), in Warcraft's UI coordinates, reaches on this client: shown, enabled and registered for clicks. */
    clickTarget(x: number, y: number): Frame | undefined;
    /** A frame event from `sender` on the frame with this handle number, as every client receives it. */
    frameEvent(sender: number, id: number, event: unknown): void;
    /** Every call this client logged, forgotten ones included. */
    callCount(): number;
    /** Folds the first `count` logged calls into the checksum and drops them, so a long run keeps its memory. */
    forget(count: number): void;
    /** A 32-bit hash of every logged call: its name and arguments as describeValue identifies them. Equal logs hash alike in Bun and Lua. */
    checksum(): string;
}
