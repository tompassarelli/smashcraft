/** @noSelfInFile */
/** A client's scene report, rewritten while the map runs. */
export declare const sceneFile: (slot: number, prefix?: string) => string;
/** The report's first line: its serial, the game frame it describes and how many effects exist. */
export declare const sceneHeading: (serial: number, frame: number, effects: number) => string;
/** What the report says about every effect created with one model path. */
export interface SceneModel {
    /** The model path with `/` for `\`; empty when the game named none. */
    readonly model: string;
    /** Effects of this model that exist. */
    readonly live: number;
    /** Those in view, wherever the game doesn't park hidden effects. Alpha and scale don't stop a model's particle emitters. */
    readonly inView: number;
    /** Those in view with their model drawn: alpha and scale above zero. */
    readonly drawn: number;
    /** The game frame the oldest live one was created on; undefined when none is left. */
    readonly created: number | undefined;
    /** Frames the longest-standing one in view has been there; undefined while none is. */
    readonly age: number | undefined;
    /** The longest any one of them stayed in view without a break since the report started. */
    readonly longest: number;
}
/** Backslashes would sit inside the Preload file's JASS string literals. */
export declare const reportedModel: (model: string) => string;
/** One line per model, its path last because a path may contain spaces. */
export declare const sceneModelLine: ({ model, live, inView, drawn, created, age, longest }: SceneModel) => string;
