/** @noSelfInFile */
/** FileIO stores one chunk per tooltip level of its ability. */
export declare const CHUNKS_PER_FILE = 64;
/**
 * Bundle bytes per payload file. The file is raw Lua that stores them in one
 * tooltip; a 200,000-character tooltip read back intact in the game.
 */
export declare const PAYLOAD_FILE_BYTES = 200000;
/** The FileIO ability ('$wsl') whose tooltips carry text from host files. */
export declare const FILE_IO_ABILITY = 611808108;
/** Player slots that write their own copy of a per-slot file. */
export declare const FILE_SLOTS = 4;
export declare const hotFolder: (prefix?: string) => string;
export declare const manifestFile: (version: number, prefix?: string) => string;
/** Names a bundle in file names and as its Lua chunk name, which error positions carry. */
export declare const payloadKey: (payloadChecksum: string) => string;
export declare const payloadFile: (payloadChecksum: string, index: number, prefix?: string) => string;
export declare const ackFile: (slot: number, prefix?: string) => string;
export declare const errorFile: (slot: number, prefix?: string) => string;
export interface Manifest {
    version: number;
    files: number;
    checksum: string;
}
export declare const formatManifest: ({ version, files, checksum }: Manifest) => string;
export declare function parseManifest(text: string): Manifest | undefined;
/** The acknowledgement: the version every client installed, at the reloader's game time in seconds. */
export declare const acknowledgementLine: (version: number, elapsed: number) => string;
/** An error report's first line; the message and each stack line follow, one line each. */
export declare const errorHeading: (count: number, handler: string) => string;
