/** @noSelfInFile */
/** File, synchronized-message and persistent-state identities shared across reloads. */
export interface RuntimeConfiguration {
    readonly filePrefix: string;
    /** Prefix of the synchronized messages in which clients answer each hot reload. */
    readonly readyPrefix: string;
    readonly globalPrefix: string;
}
/** Call before installing handlers in every bundle. Retain these values across live reloads. */
export declare function configureRuntime(next: RuntimeConfiguration): void;
export declare function runtimeConfiguration(): RuntimeConfiguration;
