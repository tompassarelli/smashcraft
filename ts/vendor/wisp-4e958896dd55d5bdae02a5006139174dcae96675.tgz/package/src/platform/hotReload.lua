local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local acknowledgementLine = ____gameFiles.acknowledgementLine
local ackFile = ____gameFiles.ackFile
local formatManifest = ____gameFiles.formatManifest
local manifestFile = ____gameFiles.manifestFile
local parseManifest = ____gameFiles.parseManifest
local payloadFile = ____gameFiles.payloadFile
local payloadKey = ____gameFiles.payloadKey
local ____config = require("src.runtime.config")
local runtimeConfiguration = ____config.runtimeConfiguration
local ____intMath = require("src.sim.intMath")
local floorDiv = ____intMath.floorDiv
local ____dispatch = require("src.platform.dispatch")
local on = ____dispatch.on
local trampoline = ____dispatch.trampoline
local ____fileio = require("src.platform.fileio")
local readChunk = ____fileio.readChunk
local ____payloadChecksum = require("src.platform.payloadChecksum")
local stringChecksum = ____payloadChecksum.stringChecksum
local POLL_SECONDS = 0.03125
local MAX_SLOTS = 4
local function hot()
    local globals = _G
    local state = globals[runtimeConfiguration().globalPrefix .. "Hot"]
    if state == nil then
        do
            local ____thrown = __TS__New(Error, "hot reload used before startHotReload")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/platform/hotReload.ts:64"
            end
            error(____thrown, 0)
        end
    end
    return state
end
local function isReloadable(value)
    return type(value) == "table" and value ~= nil and value.install ~= nil and type(value.install) == "function"
end
local function manifestExists(version)
    return readChunk(manifestFile(
        version,
        runtimeConfiguration().filePrefix
    )) ~= nil
end
--- The newest version published before this match. Manifests are never removed
-- and versions only rise, so existence is monotonic and a search finds it in
-- a logarithmic number of reads.
local function latestVersion()
    if not manifestExists(1) then
        return 0
    end
    local low = 1
    while manifestExists(low * 2) do
        low = low * 2
    end
    local high = low * 2
    while high - low > 1 do
        local middle = (low + high) // 2
        if manifestExists(middle) then
            low = middle
        else
            high = middle
        end
    end
    return low
end
local function playingHumans()
    local count = 0
    do
        local slot = 0
        while slot < MAX_SLOTS do
            local player = Player(slot)
            if GetPlayerSlotState(player) == PLAYER_SLOT_STATE_PLAYING and GetPlayerController(player) == MAP_CONTROL_USER then
                count = count + 1
            end
            slot = slot + 1
        end
    end
    return count
end
local function startClock()
    local clock = CreateTimer()
    TimerStart(
        clock,
        86400.0,
        false,
        function()
        end
    )
    return clock
end
local function report(text)
    DisplayTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        text
    )
end
--- This client's copy of a version's bundle, loaded but not installed, or why it failed.
local function loadLocal(____bindingPattern0)
    local expected
    local files
    files = ____bindingPattern0.files
    expected = ____bindingPattern0.checksum
    local parts = {}
    do
        local index = 0
        while index < files do
            parts[#parts + 1] = readChunk(payloadFile(
                expected,
                index,
                runtimeConfiguration().filePrefix
            )) or ""
            index = index + 1
        end
    end
    local text = table.concat(parts, "")
    if stringChecksum(text) ~= expected then
        return "payload missing or damaged"
    end
    local chunk, ____error = load(
        text,
        "=hot-" .. payloadKey(expected)
    )
    if chunk == nil then
        return ____error or "load failed"
    end
    local ran, module = pcall(chunk)
    if not ran then
        return "failed while loading: " .. tostring(module)
    end
    return isReloadable(module) and module or "bundle exports no install()"
end
--- Loads this client's copy of a version and tells every client whether it is ready.
local function answer(state, manifest)
    if state.next <= manifest.version then
        state.next = manifest.version + 1
    end
    local bundle = loadLocal(manifest)
    state.prepared = {version = manifest.version, checksum = manifest.checksum, bundle = bundle}
    BlzSendSyncData(
        runtimeConfiguration().readyPrefix,
        (formatManifest(manifest) .. " ") .. (type(bundle) == "string" and "refuse" or "ready")
    )
end
local function poll()
    local state = hot()
    if state.prepared ~= nil then
        return
    end
    if state.next <= state.decided then
        state.next = state.decided + 1
    end
    local text = readChunk(manifestFile(
        state.next,
        runtimeConfiguration().filePrefix
    ))
    if text == nil then
        return
    end
    local manifest = parseManifest(text)
    if manifest == nil or manifest.version ~= state.next then
        state.next = state.next + 1
        return
    end
    answer(state, manifest)
end
--- Tells host tools which version this client runs: 0 for the map's own bundle.
local function acknowledge(version, elapsed)
    PreloadGenClear()
    PreloadGenStart()
    Preload(acknowledgementLine(version, elapsed))
    PreloadGenEnd(ackFile(
        GetPlayerId(GetLocalPlayer()),
        runtimeConfiguration().filePrefix
    ))
end
local function decide(state, pending)
    state.pending = nil
    state.decided = pending.version
    local prepared = state.prepared
    if prepared ~= nil and prepared.version <= pending.version then
        state.prepared = nil
    end
    local bundle = prepared ~= nil and prepared.version == pending.version and prepared.checksum == pending.checksum and prepared.bundle or "no local copy"
    if pending.refused or type(bundle) == "string" then
        local reason = type(bundle) == "string" and bundle or "another client couldn't load it"
        report((("hot reload " .. tostring(pending.version)) .. " not applied: ") .. reason)
        return
    end
    bundle.install()
    state.applied = pending.version
    if state.clock == nil then
        state.clock = startClock()
    end
    acknowledge(
        pending.version,
        TimerGetElapsed(state.clock)
    )
    report(("hot reload " .. tostring(pending.version)) .. " applied")
end
local function answered()
    local state = hot()
    local text = BlzGetTriggerSyncData()
    local manifest = parseManifest(text)
    local verdict = __TS__StringSplit(text, " ")[4]
    if manifest == nil or manifest.version <= state.decided then
        return
    end
    local pending = state.pending
    if pending ~= nil and manifest.version < pending.version then
        return
    end
    if pending == nil or manifest.version > pending.version then
        pending = {
            version = manifest.version,
            files = manifest.files,
            checksum = manifest.checksum,
            answered = 0,
            waiting = playingHumans(),
            refused = false
        }
        state.pending = pending
    end
    local ____bit = 1 << GetPlayerId(GetTriggerPlayer())
    if pending.answered & ____bit ~= 0 then
        return
    end
    pending.answered = pending.answered | ____bit
    pending.waiting = pending.waiting - 1
    if verdict ~= "ready" or manifest.checksum ~= pending.checksum then
        pending.refused = true
    end
    if state.prepared == nil or state.prepared.version ~= pending.version then
        answer(state, {version = pending.version, files = pending.files, checksum = pending.checksum})
    end
    if pending.waiting <= 0 and state.pending == pending then
        decide(state, pending)
    end
end
--- Registers the reloader's handlers; a reloaded bundle calls this again.
function ____exports.installHotReload()
    on("hotReload.poll", poll)
    on("hotReload.answered", answered)
end
--- Starts polling for new bundles. Call once, at match start.
function ____exports.startHotReload()
    local configuration = runtimeConfiguration()
    local globals = _G
    globals[configuration.globalPrefix .. "Hot"] = {
        applied = 0,
        decided = 0,
        pending = nil,
        next = latestVersion() + 1,
        prepared = nil
    }
    ____exports.installHotReload()
    local trigger = CreateTrigger()
    do
        local slot = 0
        while slot < MAX_SLOTS do
            BlzTriggerRegisterPlayerSyncEvent(
                trigger,
                Player(slot),
                configuration.readyPrefix,
                false
            )
            slot = slot + 1
        end
    end
    TriggerAddAction(
        trigger,
        trampoline("hotReload.answered")
    )
    TimerStart(
        CreateTimer(),
        POLL_SECONDS,
        true,
        trampoline("hotReload.poll")
    )
    acknowledge(0, 0)
end
return ____exports
